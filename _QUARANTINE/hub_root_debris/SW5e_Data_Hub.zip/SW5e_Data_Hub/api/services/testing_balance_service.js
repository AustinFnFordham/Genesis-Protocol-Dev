// Testing and Balance Scaffolding Service
// Handles automated balance testing, synergy validation, and power level assessment

class TestingBalanceService {
  constructor() {
    this.balanceRules = {};
    this.testingScenarios = {};
    this.powerLevelThresholds = {};
  }

  // Load testing and balance rules
  async loadBalanceRules(factionId) {
    try {
      const factionData = await this.fetchFactionData(factionId);
      this.balanceRules[factionId] = this.parseBalanceRules(factionData);
      this.testingScenarios[factionId] = this.parseTestingScenarios(factionData);
      this.powerLevelThresholds[factionId] = this.parsePowerLevelThresholds(factionData);
      return factionData;
    } catch (error) {
      console.error(`Error loading balance rules for ${factionId}:`, error);
      throw error;
    }
  }

  // Automated Balance Testing
  async testBalance(characterData, factionId) {
    if (!this.balanceRules[factionId]) {
      await this.loadBalanceRules(factionId);
    }

    const testResults = {
      combat_abilities: await this.testCombatAbilities(characterData, factionId),
      progression_balance: await this.testProgressionBalance(characterData, factionId),
      synergy_combinations: await this.testSynergyCombinations(characterData, factionId),
      cultural_features: await this.testCulturalFeatures(characterData, factionId),
      overall_assessment: 'Balanced'
    };

    // Determine overall assessment
    const failedTests = Object.values(testResults).filter(result => 
      result.status === 'Failed' || result.status === 'Overpowered'
    );

    if (failedTests.length > 0) {
      testResults.overall_assessment = 'Issues Detected';
    }

    return testResults;
  }

  // Test combat abilities against standard enemies
  async testCombatAbilities(characterData, factionId) {
    const { class: characterClass, rank, equipment } = characterData;
    const factionData = this.balanceRules[factionId];
    
    const combatScore = this.calculateCombatScore(characterData, factionData);
    const standardEnemyScore = this.getStandardEnemyScore(characterClass, rank);
    
    const ratio = combatScore / standardEnemyScore;
    
    return {
      status: ratio <= 1.5 ? 'Balanced' : 'Overpowered',
      combat_score: combatScore,
      enemy_score: standardEnemyScore,
      ratio: ratio,
      recommendations: this.generateCombatRecommendations(ratio, characterData)
    };
  }

  // Validate progression balance across ranks
  async testProgressionBalance(characterData, factionId) {
    const factionData = this.balanceRules[factionId];
    const rankOrder = ['foundling', 'warrior', 'veteran', 'champion', 'mandalore'];
    
    const progressionScores = [];
    
    for (const rank of rankOrder) {
      const rankScore = this.calculateRankScore(characterData, rank, factionData);
      progressionScores.push({ rank, score: rankScore });
    }
    
    // Check for exponential growth
    const growthRate = this.calculateGrowthRate(progressionScores);
    
    return {
      status: growthRate <= 1.5 ? 'Balanced' : 'Exponential Growth Detected',
      progression_scores: progressionScores,
      growth_rate: growthRate,
      recommendations: this.generateProgressionRecommendations(growthRate)
    };
  }

  // Check synergy combinations for power creep
  async testSynergyCombinations(characterData, factionId) {
    const synergies = await this.detectSynergies(characterData, factionId);
    const synergyScore = this.calculateSynergyScore(synergies);
    
    const maxAllowedSynergies = 2;
    const maxSynergyScore = 5;
    
    return {
      status: synergies.length <= maxAllowedSynergies && synergyScore <= maxSynergyScore ? 'Balanced' : 'Power Creep Detected',
      synergy_count: synergies.length,
      synergy_score: synergyScore,
      max_allowed: maxAllowedSynergies,
      max_score: maxSynergyScore,
      recommendations: this.generateSynergyRecommendations(synergies.length, synergyScore)
    };
  }

  // Ensure cultural features don't break balance
  async testCulturalFeatures(characterData, factionId) {
    const factionData = this.balanceRules[factionId];
    const culturalFeatures = factionData.cultural_features || [];
    
    const culturalScore = this.calculateCulturalScore(characterData, culturalFeatures);
    const maxCulturalScore = 3;
    
    return {
      status: culturalScore <= maxCulturalScore ? 'Balanced' : 'Cultural Features Overpowered',
      cultural_score: culturalScore,
      max_allowed: maxCulturalScore,
      active_features: this.getActiveCulturalFeatures(characterData, culturalFeatures),
      recommendations: this.generateCulturalRecommendations(culturalScore, maxCulturalScore)
    };
  }

  // Synergy Validation
  async validateSynergies(synergyCombination, factionId) {
    if (!this.balanceRules[factionId]) {
      await this.loadBalanceRules(factionId);
    }

    const validationResults = {
      cross_faction_synergies: this.validateCrossFactionSynergies(synergyCombination, factionId),
      class_faction_interactions: this.validateClassFactionInteractions(synergyCombination, factionId),
      species_faction_combinations: this.validateSpeciesFactionCombinations(synergyCombination, factionId),
      environmental_adaptations: this.validateEnvironmentalAdaptations(synergyCombination, factionId),
      overall_valid: true
    };

    // Check if any validation failed
    const failedValidations = Object.values(validationResults).filter(result => 
      result.valid === false
    );

    if (failedValidations.length > 0) {
      validationResults.overall_valid = false;
    }

    return validationResults;
  }

  // Power Level Assessment
  async assessPowerLevel(characterData, factionId) {
    if (!this.powerLevelThresholds[factionId]) {
      await this.loadBalanceRules(factionId);
    }

    const powerLevel = this.calculateOverallPowerLevel(characterData, factionId);
    const factionData = this.powerLevelThresholds[factionId];
    
    // Compare to other baseline factions
    const baselineComparison = await this.compareToBaselineFactions(characterData, factionId);
    
    // Validate rank progression scaling
    const progressionScaling = this.validateProgressionScaling(characterData, factionId);
    
    // Ensure balance across all abilities
    const abilityBalance = this.validateAbilityBalance(characterData, factionId);

    return {
      power_level: powerLevel,
      assessment: this.getPowerLevelAssessment(powerLevel),
      baseline_comparison: baselineComparison,
      progression_scaling: progressionScaling,
      ability_balance: abilityBalance,
      recommendations: this.generatePowerLevelRecommendations(powerLevel, characterData)
    };
  }

  // Integration Compatibility Testing
  async testIntegrationCompatibility(characterData, factionId) {
    const compatibilityResults = {
      existing_classes: await this.testClassIntegration(characterData, factionId),
      powers_system: await this.testPowersIntegration(characterData, factionId),
      item_equipment: await this.testItemIntegration(characterData, factionId),
      species_traits: await this.testSpeciesIntegration(characterData, factionId),
      overall_compatible: true
    };

    // Check if any integration failed
    const failedIntegrations = Object.values(compatibilityResults).filter(result => 
      result.compatible === false
    );

    if (failedIntegrations.length > 0) {
      compatibilityResults.overall_compatible = false;
    }

    return compatibilityResults;
  }

  // Narrative Consistency Validation
  async validateNarrativeConsistency(characterData, factionId) {
    const factionData = this.balanceRules[factionId];
    
    const consistencyResults = {
      cultural_authenticity: this.validateCulturalAuthenticity(characterData, factionData),
      honor_code_consistency: this.validateHonorCodeConsistency(characterData, factionData),
      clan_loyalty_mechanics: this.validateClanLoyaltyMechanics(characterData, factionData),
      mandalorian_integrity: this.validateMandalorianIntegrity(characterData, factionData),
      overall_consistent: true
    };

    // Check if any consistency check failed
    const failedChecks = Object.values(consistencyResults).filter(result => 
      result.consistent === false
    );

    if (failedChecks.length > 0) {
      consistencyResults.overall_consistent = false;
    }

    return consistencyResults;
  }

  // Helper Methods
  calculateCombatScore(characterData, factionData) {
    let score = 0;
    
    // Base combat score from class and rank
    score += this.getBaseCombatScore(characterData.class, characterData.rank);
    
    // Equipment bonuses
    score += this.getEquipmentCombatBonus(characterData.equipment);
    
    // Faction-specific combat bonuses
    score += this.getFactionCombatBonus(characterData, factionData);
    
    return score;
  }

  getStandardEnemyScore(characterClass, rank) {
    // Return standard enemy score based on class and rank
    const baseScores = {
      'Fighter': { foundling: 5, warrior: 8, veteran: 12, champion: 16, mandalore: 20 },
      'Scout': { foundling: 4, warrior: 7, veteran: 10, champion: 14, mandalore: 18 }
    };
    
    return baseScores[characterClass]?.[rank] || 10;
  }

  calculateRankScore(characterData, rank, factionData) {
    const rankData = factionData.ranks[rank];
    let score = 0;
    
    // Calculate score based on rank benefits and features
    if (rankData.benefits) {
      score += rankData.benefits.length * 2;
    }
    
    if (rankData.features) {
      score += rankData.features.length * 3;
    }
    
    return score;
  }

  calculateGrowthRate(progressionScores) {
    if (progressionScores.length < 2) return 1;
    
    const scores = progressionScores.map(ps => ps.score);
    let totalGrowth = 0;
    
    for (let i = 1; i < scores.length; i++) {
      totalGrowth += scores[i] / scores[i-1];
    }
    
    return totalGrowth / (scores.length - 1);
  }

  calculateSynergyScore(synergies) {
    let score = 0;
    
    for (const synergy of synergies) {
      // Calculate score based on synergy benefits
      score += synergy.benefits.length * 2;
      
      // Add bonus for powerful synergies
      if (synergy.benefits.some(benefit => benefit.includes('+3'))) {
        score += 1;
      }
    }
    
    return score;
  }

  calculateCulturalScore(characterData, culturalFeatures) {
    let score = 0;
    
    for (const feature of culturalFeatures) {
      if (this.isCulturalFeatureActive(characterData, feature)) {
        score += 1;
      }
    }
    
    return score;
  }

  validateCrossFactionSynergies(synergyCombination, factionId) {
    const factionData = this.balanceRules[factionId];
    const crossFactionSynergies = factionData.synergistic_mechanics?.cross_faction_synergies || [];
    
    for (const synergy of synergyCombination) {
      const matchingSynergy = crossFactionSynergies.find(cfs => cfs.name === synergy.name);
      if (!matchingSynergy) {
        return { valid: false, error: `Invalid cross-faction synergy: ${synergy.name}` };
      }
    }
    
    return { valid: true };
  }

  validateClassFactionInteractions(synergyCombination, factionId) {
    const factionData = this.balanceRules[factionId];
    const classSynergies = factionData.synergistic_mechanics?.class_synergies || [];
    
    for (const synergy of synergyCombination) {
      const matchingSynergy = classSynergies.find(cs => cs.name === synergy.name);
      if (!matchingSynergy) {
        return { valid: false, error: `Invalid class-faction synergy: ${synergy.name}` };
      }
    }
    
    return { valid: true };
  }

  validateSpeciesFactionCombinations(synergyCombination, factionId) {
    const factionData = this.balanceRules[factionId];
    const speciesSynergies = factionData.synergistic_mechanics?.species_synergies || [];
    
    for (const synergy of synergyCombination) {
      const matchingSynergy = speciesSynergies.find(ss => ss.name === synergy.name);
      if (!matchingSynergy) {
        return { valid: false, error: `Invalid species-faction synergy: ${synergy.name}` };
      }
    }
    
    return { valid: true };
  }

  validateEnvironmentalAdaptations(synergyCombination, factionId) {
    const factionData = this.balanceRules[factionId];
    const environmentalAdaptations = factionData.environmental_adaptations || [];
    
    for (const synergy of synergyCombination) {
      const matchingAdaptation = environmentalAdaptations.find(ea => ea.name === synergy.name);
      if (!matchingAdaptation) {
        return { valid: false, error: `Invalid environmental adaptation: ${synergy.name}` };
      }
    }
    
    return { valid: true };
  }

  calculateOverallPowerLevel(characterData, factionId) {
    let powerLevel = 0;
    
    // Base power from class and rank
    powerLevel += this.getBasePowerLevel(characterData.class, characterData.rank);
    
    // Equipment power
    powerLevel += this.getEquipmentPowerLevel(characterData.equipment);
    
    // Faction-specific power
    powerLevel += this.getFactionPowerLevel(characterData, factionId);
    
    // Synergy power
    const synergies = this.detectSynergies(characterData, factionId);
    powerLevel += this.getSynergyPowerLevel(synergies);
    
    return powerLevel;
  }

  async compareToBaselineFactions(characterData, factionId) {
    const baselineFactions = ['jedi_order_baseline', 'sith_order_baseline', 'bounty_hunters_baseline'];
    const comparisons = [];
    
    for (const baselineFaction of baselineFactions) {
      if (baselineFaction !== factionId) {
        const baselinePowerLevel = this.calculateOverallPowerLevel(characterData, baselineFaction);
        const currentPowerLevel = this.calculateOverallPowerLevel(characterData, factionId);
        
        comparisons.push({
          faction: baselineFaction,
          baseline_power: baselinePowerLevel,
          current_power: currentPowerLevel,
          difference: currentPowerLevel - baselinePowerLevel,
          balanced: Math.abs(currentPowerLevel - baselinePowerLevel) <= 2
        });
      }
    }
    
    return comparisons;
  }

  validateProgressionScaling(characterData, factionId) {
    const factionData = this.powerLevelThresholds[factionId];
    const rankOrder = ['foundling', 'warrior', 'veteran', 'champion', 'mandalore'];
    
    const scalingResults = [];
    
    for (let i = 0; i < rankOrder.length - 1; i++) {
      const currentRank = rankOrder[i];
      const nextRank = rankOrder[i + 1];
      
      const currentPower = this.calculateOverallPowerLevel({ ...characterData, rank: currentRank }, factionId);
      const nextPower = this.calculateOverallPowerLevel({ ...characterData, rank: nextRank }, factionId);
      
      const scalingFactor = nextPower / currentPower;
      
      scalingResults.push({
        from_rank: currentRank,
        to_rank: nextRank,
        scaling_factor: scalingFactor,
        appropriate: scalingFactor >= 1.2 && scalingFactor <= 1.8
      });
    }
    
    return scalingResults;
  }

  validateAbilityBalance(characterData, factionId) {
    const abilities = ['combat', 'social', 'survival', 'crafting', 'force'];
    const abilityScores = {};
    
    for (const ability of abilities) {
      abilityScores[ability] = this.calculateAbilityScore(characterData, ability, factionId);
    }
    
    const maxScore = Math.max(...Object.values(abilityScores));
    const minScore = Math.min(...Object.values(abilityScores));
    const balanceRatio = maxScore / minScore;
    
    return {
      ability_scores: abilityScores,
      balance_ratio: balanceRatio,
      balanced: balanceRatio <= 2.0,
      recommendations: this.generateAbilityBalanceRecommendations(abilityScores, balanceRatio)
    };
  }

  // Utility methods
  async fetchFactionData(factionId) {
    const response = await fetch(`/api/factions/${factionId}`);
    return response.json();
  }

  parseBalanceRules(factionData) {
    return factionData.testing_balance_scaffolding || {};
  }

  parseTestingScenarios(factionData) {
    return factionData.testing_balance_scaffolding?.automated_balance_testing || [];
  }

  parsePowerLevelThresholds(factionData) {
    return factionData.balance_considerations || {};
  }

  getPowerLevelAssessment(powerLevel) {
    if (powerLevel <= 10) return 'Low';
    if (powerLevel <= 20) return 'Medium';
    if (powerLevel <= 30) return 'High';
    return 'Very High';
  }

  // Additional helper methods would be implemented here
  generateCombatRecommendations(ratio, characterData) {
    const recommendations = [];
    
    if (ratio > 1.5) {
      recommendations.push('Consider reducing equipment bonuses');
      recommendations.push('Review faction combat bonuses');
    }
    
    return recommendations;
  }

  generateProgressionRecommendations(growthRate) {
    const recommendations = [];
    
    if (growthRate > 1.5) {
      recommendations.push('Consider reducing rank progression bonuses');
      recommendations.push('Review feature scaling across ranks');
    }
    
    return recommendations;
  }

  generateSynergyRecommendations(synergyCount, synergyScore) {
    const recommendations = [];
    
    if (synergyCount > 2) {
      recommendations.push('Reduce number of active synergies');
    }
    
    if (synergyScore > 5) {
      recommendations.push('Review synergy benefit values');
    }
    
    return recommendations;
  }

  generateCulturalRecommendations(culturalScore, maxScore) {
    const recommendations = [];
    
    if (culturalScore > maxScore) {
      recommendations.push('Reduce number of active cultural features');
      recommendations.push('Review cultural feature benefits');
    }
    
    return recommendations;
  }

  generatePowerLevelRecommendations(powerLevel, characterData) {
    const recommendations = [];
    
    if (powerLevel > 30) {
      recommendations.push('Consider reducing overall power level');
      recommendations.push('Review equipment and synergy combinations');
    }
    
    return recommendations;
  }

  generateAbilityBalanceRecommendations(abilityScores, balanceRatio) {
    const recommendations = [];
    
    if (balanceRatio > 2.0) {
      recommendations.push('Consider balancing ability scores');
      recommendations.push('Review ability score adjustments');
    }
    
    return recommendations;
  }
}

module.exports = TestingBalanceService;
