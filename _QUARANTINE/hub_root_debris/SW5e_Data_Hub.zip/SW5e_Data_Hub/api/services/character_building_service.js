// Character Building Integration Service
// Handles automated synergy detection, progression tracking, and balance validation

class CharacterBuildingService {
  constructor() {
    this.factionData = {};
    this.synergyRules = {};
    this.balanceThresholds = {};
  }

  // Load faction data and rules
  async loadFactionData(factionId) {
    try {
      const factionData = await this.fetchFactionData(factionId);
      this.factionData[factionId] = factionData;
      this.synergyRules[factionId] = this.parseSynergyRules(factionData);
      this.balanceThresholds[factionId] = this.parseBalanceThresholds(factionData);
      return factionData;
    } catch (error) {
      console.error(`Error loading faction data for ${factionId}:`, error);
      throw error;
    }
  }

  // Automated Synergy Detection
  async detectSynergies(characterData) {
    const { class: characterClass, faction, species, era } = characterData;
    const factionId = `${faction}_baseline`;
    
    if (!this.factionData[factionId]) {
      await this.loadFactionData(factionId);
    }

    const detectedSynergies = [];
    const suggestions = [];

    // Cross-faction synergies
    const crossFactionSynergies = this.factionData[factionId].synergistic_mechanics?.cross_faction_synergies || [];
    for (const synergy of crossFactionSynergies) {
      if (this.checkSynergyRequirements(synergy.requirements, characterData)) {
        detectedSynergies.push({
          type: 'cross_faction',
          name: synergy.name,
          description: synergy.description,
          benefits: synergy.benefits,
          balance: synergy.balance
        });
      }
    }

    // Class synergies
    const classSynergies = this.factionData[factionId].synergistic_mechanics?.class_synergies || [];
    for (const synergy of classSynergies) {
      if (this.checkClassSynergy(synergy, characterClass)) {
        detectedSynergies.push({
          type: 'class',
          name: synergy.name,
          description: synergy.description,
          benefits: synergy.benefits,
          balance: synergy.balance
        });
      }
    }

    // Species synergies
    const speciesSynergies = this.factionData[factionId].synergistic_mechanics?.species_synergies || [];
    for (const synergy of speciesSynergies) {
      if (this.checkSpeciesSynergy(synergy, species)) {
        detectedSynergies.push({
          type: 'species',
          name: synergy.name,
          description: synergy.description,
          benefits: synergy.benefits,
          balance: synergy.balance
        });
      }
    }

    // Generate suggestions
    suggestions.push(...this.generateSuggestions(characterData, factionId));

    return {
      detected_synergies: detectedSynergies,
      suggestions: suggestions,
      total_synergies: detectedSynergies.length
    };
  }

  // Faction Progression Tracking
  async trackProgression(characterId, factionId) {
    const character = await this.getCharacter(characterId);
    const factionData = this.factionData[factionId];
    
    if (!factionData) {
      await this.loadFactionData(factionId);
    }

    const currentRank = character.faction_ranks?.[factionId] || 'foundling';
    const rankData = factionData.ranks[currentRank];
    
    // Calculate progress to next rank
    const progressToNext = this.calculateProgress(character, currentRank, factionData);
    
    // Get available features
    const availableFeatures = this.getAvailableFeatures(currentRank, character, factionData);
    
    // Track honor and cultural standing
    const honorStanding = this.calculateHonorStanding(character, factionData);
    const clanRelationships = this.calculateClanRelationships(character, factionData);

    return {
      current_rank: currentRank,
      rank_description: rankData?.description || '',
      progress_to_next: progressToNext,
      available_features: availableFeatures,
      honor_standing: honorStanding,
      clan_relationships: clanRelationships,
      next_rank_requirements: this.getNextRankRequirements(currentRank, factionData)
    };
  }

  // Era Appropriate Content Filtering
  async filterEraContent(characterData, factionId) {
    const { era } = characterData;
    const factionData = this.factionData[factionId];
    
    if (!factionData) {
      await this.loadFactionData(factionId);
    }

    const filteredContent = {
      leadership: this.filterEraLeadership(factionData.overview.leadership, era),
      items: this.filterEraItems(factionData.items, era),
      facilities: this.filterEraFacilities(factionData.facilities, era),
      cultural_features: this.filterEraCulturalFeatures(factionData.cultural_features, era)
    };

    return filteredContent;
  }

  // Balance Validation
  async validateBalance(characterData) {
    const { class: characterClass, faction, rank, equipment } = characterData;
    const factionId = `${faction}_baseline`;
    
    if (!this.factionData[factionId]) {
      await this.loadFactionData(factionId);
    }

    const balanceAssessment = {
      power_level: this.calculatePowerLevel(characterData, factionId),
      balance_assessment: 'Balanced',
      warnings: [],
      recommendations: []
    };

    // Check for overpowered combinations
    const synergies = await this.detectSynergies(characterData);
    if (synergies.detected_synergies.length > 2) {
      balanceAssessment.warnings.push('Too many active synergies detected');
      balanceAssessment.balance_assessment = 'Potentially Overpowered';
    }

    // Check honor code compliance
    const honorCompliance = this.checkHonorCodeCompliance(characterData, factionId);
    if (!honorCompliance.compliant) {
      balanceAssessment.warnings.push(`Honor code violation: ${honorCompliance.violation}`);
    }

    // Check cultural authenticity
    const culturalAuthenticity = this.checkCulturalAuthenticity(characterData, factionId);
    if (!culturalAuthenticity.authentic) {
      balanceAssessment.warnings.push(`Cultural authenticity issue: ${culturalAuthenticity.issue}`);
    }

    // Generate recommendations
    balanceAssessment.recommendations = this.generateBalanceRecommendations(characterData, factionId);

    return balanceAssessment;
  }

  // Narrative Suggestion System
  async generateNarrativeSuggestions(characterData, factionId) {
    const factionData = this.factionData[factionId];
    
    if (!factionData) {
      await this.loadFactionData(factionId);
    }

    const suggestions = {
      character_development_paths: this.suggestDevelopmentPaths(characterData, factionData),
      story_elements: this.suggestStoryElements(characterData, factionData),
      character_growth_opportunities: this.suggestGrowthOpportunities(characterData, factionData),
      honor_based_decisions: this.suggestHonorDecisions(characterData, factionData)
    };

    return suggestions;
  }

  // Helper Methods
  checkSynergyRequirements(requirements, characterData) {
    // Implementation for checking if character meets synergy requirements
    return requirements.every(req => {
      // Check if character has required training, class, species, etc.
      return this.evaluateRequirement(req, characterData);
    });
  }

  checkClassSynergy(synergy, characterClass) {
    return synergy.requirements.includes(characterClass);
  }

  checkSpeciesSynergy(synergy, species) {
    return synergy.requirements.includes(species);
  }

  generateSuggestions(characterData, factionId) {
    const suggestions = [];
    const factionData = this.factionData[factionId];

    // Suggest compatible classes
    const compatibleClasses = this.getCompatibleClasses(factionData);
    if (!compatibleClasses.includes(characterData.class)) {
      suggestions.push(`Consider ${compatibleClasses.join(', ')} classes for enhanced synergy`);
    }

    // Suggest beneficial species
    const beneficialSpecies = this.getBeneficialSpecies(factionData);
    if (!beneficialSpecies.includes(characterData.species)) {
      suggestions.push(`${beneficialSpecies.join(', ')} species would provide cultural bonuses`);
    }

    return suggestions;
  }

  calculateProgress(character, currentRank, factionData) {
    // Implementation for calculating progress percentage to next rank
    const rankOrder = ['foundling', 'warrior', 'veteran', 'champion', 'mandalore'];
    const currentIndex = rankOrder.indexOf(currentRank);
    
    // Calculate based on achievements, honor standing, etc.
    return Math.min(100, Math.max(0, this.calculateProgressPercentage(character, currentRank)));
  }

  getAvailableFeatures(currentRank, character, factionData) {
    const rankData = factionData.ranks[currentRank];
    return rankData?.features?.map(feature => ({
      name: feature.name,
      description: feature.description,
      benefits: feature.benefits,
      selected: character.selected_features?.includes(feature.name) || false
    })) || [];
  }

  calculateHonorStanding(character, factionData) {
    // Implementation for calculating honor standing based on actions
    const honorScore = this.calculateHonorScore(character);
    
    if (honorScore >= 90) return 'Exemplary';
    if (honorScore >= 75) return 'Respected';
    if (honorScore >= 50) return 'Honorable';
    if (honorScore >= 25) return 'Questionable';
    return 'Dishonorable';
  }

  calculateClanRelationships(character, factionData) {
    // Implementation for calculating clan relationships
    return {
      'Clan Ordo': 'Allied',
      'Clan Fett': 'Neutral',
      'Clan Vizsla': 'Rival'
    };
  }

  // Utility methods
  async fetchFactionData(factionId) {
    // Implementation for fetching faction data from database or file
    const response = await fetch(`/api/factions/${factionId}`);
    return response.json();
  }

  parseSynergyRules(factionData) {
    return factionData.synergistic_mechanics || {};
  }

  parseBalanceThresholds(factionData) {
    return factionData.balance_considerations || {};
  }

  async getCharacter(characterId) {
    // Implementation for fetching character data
    const response = await fetch(`/api/characters/${characterId}`);
    return response.json();
  }

  async getUsableStarshipActions(characterData, options = {}) {
    const includeCombat = options.includeCombat !== false;
    const includeNonCombat = options.includeNonCombat !== false;

    const path = require('path');
    const fs = require('fs');
    const fsp = fs.promises;
    const YAML = require('yaml');

    const baseRoot = path.resolve(__dirname, '../../');
    const readYaml = async (absPath) => YAML.parse(await fsp.readFile(absPath, 'utf8'));
    const resolveDataPath = (p) => {
      if (!p) return null;
      const norm = p.replace(/\\/g, '/');
      const marker = 'SW5e_Data_Hub/';
      if (norm.includes(marker)) {
        const rel = norm.split(marker)[1];
        return path.join(baseRoot, rel);
      }
      return path.isAbsolute(p) ? p : path.join(baseRoot, p);
    };

    const rolesPath = path.join(baseRoot, 'data', 'starship_roles.yml');
    const registryPath = path.join(baseRoot, 'data', 'starship_actions_registry.yml');

    const [rolesDoc, registryDoc] = await Promise.all([
      readYaml(rolesPath),
      readYaml(registryPath)
    ]);

    const primaryRoleName = characterData?.starship?.primary_role || null;
    const secondaryRoleName = characterData?.starship?.secondary_role || null;

    const findRole = (name) => (rolesDoc?.roles || []).find(r => r.name === name);
    const primaryRole = primaryRoleName ? findRole(primaryRoleName) : null;
    const secondaryRole = secondaryRoleName ? findRole(secondaryRoleName) : null;

    const unionFilters = (setKey) => {
      const stations = new Set();
      const tagsAny = new Set();
      const add = (role) => {
        const f = role?.action_filters?.[setKey];
        if (!f) return;
        (f.stations || []).forEach(s => stations.add(s));
        (f.tags_any || []).forEach(t => tagsAny.add(t));
      };
      add(primaryRole);
      add(secondaryRole);
      // If no roles selected, default to General Crew semantics (broad access via station check)
      if (stations.size === 0) stations.add('Any');
      return { stations: Array.from(stations), tags_any: Array.from(tagsAny) };
    };

    const flattenActions = (doc) => {
      if (!doc || typeof doc !== 'object') return [];
      const actions = [];
      for (const [key, value] of Object.entries(doc)) {
        if (Array.isArray(value)) {
          for (const entry of value) {
            if (entry && typeof entry === 'object' && entry.station && entry.id) {
              actions.push({ ...entry });
            }
          }
        }
      }
      return actions;
    };

    const filterBy = (actions, filters) => {
      const stations = filters?.stations || [];
      const tagsAny = filters?.tags_any || [];
      return actions.filter(a => {
        const stationOk = stations.includes('Any') || stations.includes(a.station);
        if (!stationOk) return false;
        if (!tagsAny.length) return true;
        const aTags = Array.isArray(a.tags) ? a.tags : [];
        return aTags.some(t => tagsAny.includes(t));
      });
    };

    const result = {
      roles_used: [primaryRoleName, secondaryRoleName].filter(Boolean),
      filters_applied: {},
      combat: { actions: [] },
      non_combat: { actions: [] }
    };

    if (includeCombat) {
      const combatPath = resolveDataPath(registryDoc?.registry?.combat?.file);
      const combatDoc = combatPath ? await readYaml(combatPath) : null;
      const combatAll = flattenActions(combatDoc);
      const combatFilters = unionFilters('combat');
      result.filters_applied.combat = combatFilters;
      result.combat.actions = filterBy(combatAll, combatFilters).map(a => ({ ...a, source_set: 'combat' }));
    }

    if (includeNonCombat) {
      const ncPath = resolveDataPath(registryDoc?.registry?.non_combat?.file);
      const ncDoc = ncPath ? await readYaml(ncPath) : null;
      const ncAll = flattenActions(ncDoc);
      const ncFilters = unionFilters('non_combat');
      result.filters_applied.non_combat = ncFilters;
      result.non_combat.actions = filterBy(ncAll, ncFilters).map(a => ({ ...a, source_set: 'non_combat' }));
    }

    return result;
  }
}

module.exports = CharacterBuildingService;
