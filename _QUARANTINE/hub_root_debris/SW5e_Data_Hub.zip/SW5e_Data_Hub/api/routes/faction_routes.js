// Faction API Routes
// Exposes faction services as REST endpoints

const express = require('express');
const router = express.Router();
const CharacterBuildingService = require('../services/character_building_service');
const TestingBalanceService = require('../services/testing_balance_service');

const characterBuildingService = new CharacterBuildingService();
const testingBalanceService = new TestingBalanceService();

// ========================================
// CHARACTER BUILDING INTEGRATION ROUTES
// ========================================

// Automated Synergy Detection
router.post('/character/synergies/detect', async (req, res) => {
  try {
    const { class: characterClass, faction, species, era } = req.body;
    
    if (!faction) {
      return res.status(400).json({ error: 'Faction is required' });
    }

    const synergies = await characterBuildingService.detectSynergies({
      class: characterClass,
      faction,
      species,
      era
    });

    res.json({
      success: true,
      data: synergies
    });
  } catch (error) {
    console.error('Error detecting synergies:', error);
    res.status(500).json({ error: 'Failed to detect synergies' });
  }
});

// Faction Progression Tracking
router.get('/character/faction/progress/:characterId/:factionId', async (req, res) => {
  try {
    const { characterId, factionId } = req.params;
    
    const progression = await characterBuildingService.trackProgression(characterId, factionId);

    res.json({
      success: true,
      data: progression
    });
  } catch (error) {
    console.error('Error tracking progression:', error);
    res.status(500).json({ error: 'Failed to track progression' });
  }
});

// Era Appropriate Content Filtering
router.post('/character/era/content', async (req, res) => {
  try {
    const { characterData, factionId } = req.body;
    
    if (!characterData || !factionId) {
      return res.status(400).json({ error: 'Character data and faction ID are required' });
    }

    const filteredContent = await characterBuildingService.filterEraContent(characterData, factionId);

    res.json({
      success: true,
      data: filteredContent
    });
  } catch (error) {
    console.error('Error filtering era content:', error);
    res.status(500).json({ error: 'Failed to filter era content' });
  }
});

// Balance Validation
router.post('/character/balance/validate', async (req, res) => {
  try {
    const characterData = req.body;
    
    if (!characterData.faction) {
      return res.status(400).json({ error: 'Faction is required' });
    }

    const balanceAssessment = await characterBuildingService.validateBalance(characterData);

    res.json({
      success: true,
      data: balanceAssessment
    });
  } catch (error) {
    console.error('Error validating balance:', error);
    res.status(500).json({ error: 'Failed to validate balance' });
  }
});

// Narrative Suggestion System
router.post('/character/narrative/suggestions', async (req, res) => {
  try {
    const { characterData, factionId } = req.body;
    
    if (!characterData || !factionId) {
      return res.status(400).json({ error: 'Character data and faction ID are required' });
    }

    const suggestions = await characterBuildingService.generateNarrativeSuggestions(characterData, factionId);

    res.json({
      success: true,
      data: suggestions
    });
  } catch (error) {
    console.error('Error generating narrative suggestions:', error);
    res.status(500).json({ error: 'Failed to generate narrative suggestions' });
  }
});

// ========================================
// TESTING AND BALANCE SCAFFOLDING ROUTES
// ========================================

// Automated Balance Testing
router.post('/testing/balance/validate', async (req, res) => {
  try {
    const { characterData, factionId } = req.body;
    
    if (!characterData || !factionId) {
      return res.status(400).json({ error: 'Character data and faction ID are required' });
    }

    const testResults = await testingBalanceService.testBalance(characterData, factionId);

    res.json({
      success: true,
      data: testResults
    });
  } catch (error) {
    console.error('Error testing balance:', error);
    res.status(500).json({ error: 'Failed to test balance' });
  }
});

// Synergy Validation
router.post('/testing/synergies/validate', async (req, res) => {
  try {
    const { synergyCombination, factionId } = req.body;
    
    if (!synergyCombination || !factionId) {
      return res.status(400).json({ error: 'Synergy combination and faction ID are required' });
    }

    const validationResults = await testingBalanceService.validateSynergies(synergyCombination, factionId);

    res.json({
      success: true,
      data: validationResults
    });
  } catch (error) {
    console.error('Error validating synergies:', error);
    res.status(500).json({ error: 'Failed to validate synergies' });
  }
});

// Power Level Assessment
router.post('/testing/power/assess', async (req, res) => {
  try {
    const { characterData, factionId } = req.body;
    
    if (!characterData || !factionId) {
      return res.status(400).json({ error: 'Character data and faction ID are required' });
    }

    const powerAssessment = await testingBalanceService.assessPowerLevel(characterData, factionId);

    res.json({
      success: true,
      data: powerAssessment
    });
  } catch (error) {
    console.error('Error assessing power level:', error);
    res.status(500).json({ error: 'Failed to assess power level' });
  }
});

// Integration Compatibility Testing
router.post('/testing/integration/compatibility', async (req, res) => {
  try {
    const { characterData, factionId } = req.body;
    
    if (!characterData || !factionId) {
      return res.status(400).json({ error: 'Character data and faction ID are required' });
    }

    const compatibilityResults = await testingBalanceService.testIntegrationCompatibility(characterData, factionId);

    res.json({
      success: true,
      data: compatibilityResults
    });
  } catch (error) {
    console.error('Error testing integration compatibility:', error);
    res.status(500).json({ error: 'Failed to test integration compatibility' });
  }
});

// Narrative Consistency Validation
router.post('/testing/narrative/consistency', async (req, res) => {
  try {
    const { characterData, factionId } = req.body;
    
    if (!characterData || !factionId) {
      return res.status(400).json({ error: 'Character data and faction ID are required' });
    }

    const consistencyResults = await testingBalanceService.validateNarrativeConsistency(characterData, factionId);

    res.json({
      success: true,
      data: consistencyResults
    });
  } catch (error) {
    console.error('Error validating narrative consistency:', error);
    res.status(500).json({ error: 'Failed to validate narrative consistency' });
  }
});

// ========================================
// FACTION DATA ROUTES
// ========================================

// Get Faction Data
router.get('/factions/:factionId', async (req, res) => {
  try {
    const { factionId } = req.params;
    
    // Load faction data from YAML/JSON file
    const factionData = await characterBuildingService.loadFactionData(factionId);

    res.json({
      success: true,
      data: factionData
    });
  } catch (error) {
    console.error('Error loading faction data:', error);
    res.status(500).json({ error: 'Failed to load faction data' });
  }
});

// Get All Baseline Factions
router.get('/factions/baseline/all', async (req, res) => {
  try {
    const baselineFactions = [
      'mandalorian_clans_baseline',
      'jedi_order_baseline',
      'sith_order_baseline',
      'bounty_hunters_baseline',
      'smugglers_baseline',
      'criminals_baseline'
    ];

    const factions = [];
    
    for (const factionId of baselineFactions) {
      try {
        const factionData = await characterBuildingService.loadFactionData(factionId);
        factions.push({
          id: factionId,
          name: factionData.name,
          description: factionData.description,
          status: 'Available'
        });
      } catch (error) {
        factions.push({
          id: factionId,
          name: factionId.replace('_baseline', '').replace(/_/g, ' '),
          description: 'Faction data not yet available',
          status: 'Not Available'
        });
      }
    }

    res.json({
      success: true,
      data: factions
    });
  } catch (error) {
    console.error('Error loading baseline factions:', error);
    res.status(500).json({ error: 'Failed to load baseline factions' });
  }
});

// ========================================
// DEVELOPMENT AND TESTING ROUTES
// ========================================

// Get Testing Requirements
router.get('/development/testing/requirements/:factionId', async (req, res) => {
  try {
    const { factionId } = req.params;
    
    const factionData = await characterBuildingService.loadFactionData(factionId);
    const testingRequirements = factionData.implementation_notes?.testing_requirements || [];

    res.json({
      success: true,
      data: {
        faction_id: factionId,
        testing_requirements: testingRequirements,
        automated_tests: [
          'Combat ability scaling validation',
          'Synergy combination testing',
          'Cultural feature integration',
          'Environmental adaptation situational testing'
        ]
      }
    });
  } catch (error) {
    console.error('Error loading testing requirements:', error);
    res.status(500).json({ error: 'Failed to load testing requirements' });
  }
});

// Get Implementation Status
router.get('/development/implementation/status/:factionId', async (req, res) => {
  try {
    const { factionId } = req.params;
    
    const factionData = await characterBuildingService.loadFactionData(factionId);
    const implementationNotes = factionData.implementation_notes || {};

    res.json({
      success: true,
      data: {
        faction_id: factionId,
        priority: implementationNotes.priority || 'Not Set',
        status: implementationNotes.status || 'Unknown',
        testing_requirements: implementationNotes.testing_requirements || [],
        future_expansions: implementationNotes.future_expansions || [],
        balance_considerations: implementationNotes.balance_considerations || []
      }
    });
  } catch (error) {
    console.error('Error loading implementation status:', error);
    res.status(500).json({ error: 'Failed to load implementation status' });
  }
});

// ========================================
// UTILITY ROUTES
// ========================================

// Health Check
router.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'Faction API is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// API Documentation
router.get('/docs', (req, res) => {
  res.json({
    success: true,
    data: {
      title: 'Faction API Documentation',
      version: '1.0.0',
      endpoints: {
        'Character Building': {
          'POST /api/character/synergies/detect': 'Detect synergies for character',
          'GET /api/character/faction/progress/:characterId/:factionId': 'Track faction progression',
          'POST /api/character/era/content': 'Filter era-appropriate content',
          'POST /api/character/balance/validate': 'Validate character balance',
          'POST /api/character/narrative/suggestions': 'Generate narrative suggestions'
        },
        'Testing and Balance': {
          'POST /api/testing/balance/validate': 'Test character balance',
          'POST /api/testing/synergies/validate': 'Validate synergy combinations',
          'POST /api/testing/power/assess': 'Assess power level',
          'POST /api/testing/integration/compatibility': 'Test integration compatibility',
          'POST /api/testing/narrative/consistency': 'Validate narrative consistency'
        },
        'Faction Data': {
          'GET /api/factions/:factionId': 'Get faction data',
          'GET /api/factions/baseline/all': 'Get all baseline factions'
        },
        'Development': {
          'GET /api/development/testing/requirements/:factionId': 'Get testing requirements',
          'GET /api/development/implementation/status/:factionId': 'Get implementation status'
        }
      }
    }
  });
});

module.exports = router;
