#!/usr/bin/env node

/**
 * Simple Schema Syntax Test
 * Tests that our updated schemas have valid JSON syntax
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('🧪 Testing Schema Syntax...\n');

const schemaDir = path.join(__dirname, 'schema');
const schemaFiles = fs.readdirSync(schemaDir).filter(file => file.endsWith('.json'));

let passed = 0;
let failed = 0;

schemaFiles.forEach(file => {
    try {
        const filePath = path.join(schemaDir, file);
        const content = fs.readFileSync(filePath, 'utf8');
        JSON.parse(content);
        console.log(`  ✅ ${file} - Valid JSON syntax`);
        passed++;
    } catch (error) {
        console.log(`  ❌ ${file} - JSON syntax error: ${error.message}`);
        failed++;
    }
});

console.log(`\n📊 Test Summary:`);
console.log(`  Total Schemas: ${schemaFiles.length}`);
console.log(`  ✅ Passed: ${passed}`);
console.log(`  ❌ Failed: ${failed}`);
console.log(`  📈 Success Rate: ${((passed / schemaFiles.length) * 100).toFixed(1)}%`);

if (failed === 0) {
    console.log('\n🎉 All schemas have valid JSON syntax!');
    process.exit(0);
} else {
    console.log('\n⚠️  Some schemas have syntax errors that need to be fixed.');
    process.exit(1);
}
