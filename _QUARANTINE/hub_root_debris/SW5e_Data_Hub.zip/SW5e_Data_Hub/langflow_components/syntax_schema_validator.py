import yaml
import jsonschema
import json
from typing import Dict, Any, Union

# --- LangFlow 1.6.0 Imports ---
from langflow.custom.custom_component.component import Component
from langflow.io import MessageTextInput, Output, SecretStrInput
# This is the correct location for Data
from langflow.schema.data import Data
from langflow.schema.message import Message
# ------------------------------

class SyntaxSchemaValidator(Component):
    display_name = "Syntax Schema Validator (fixed)"
    description = "Checks YAML syntax. FIX: Outputs parsed data as a JSON string."
    icon = "file-check-2"
    name = "SyntaxSchemaValidatorFixed"

    inputs = [
        MessageTextInput(
            name="yaml_content",
            display_name="YAML Content",
            info="The raw YAML string to validate.",
            tool_mode=True,
        ),
        MessageTextInput(
            name="schema_json",
            display_name="JSON Schema (Optional)",
            info="An optional JSON string representing the schema to validate against.",
            advanced=True, # Hides this field in a dropdown
            value="" # Default to empty
        ),
    ]

    outputs = [
        Output(display_name="Result", name="result", method="validate_syntax"),
        # THIS IS THE FIX: The 'Parsed Data' output is now a STRING
        Output(display_name="Parsed Data (String)", name="parsed_data", method="validate_syntax"),
    ]

    def validate_syntax(self) -> Dict[str, Union[Message, Data]]:
        """
        This method validates the YAML. 
        It returns TWO outputs:
        1. `result`: A Message object with the pass/fail status for routing.
        2. `parsed_data`: A Data object containing the loaded YAML *as a JSON string*.
        """
        yaml_content = self.yaml_content
        schema_json = self.schema_json

        # Default outputs
        result_message: Union[Message, None] = None
        # FIX: parsed_data is now a Data object containing an empty string
        parsed_data = Data(data="") # Start with empty string

        # Step 1: Validate YAML Syntax
        try:
            loaded_yaml = yaml.safe_load(yaml_content)
            
            # --- THIS IS THE FIX ---
            # Convert the parsed YAML dict into a JSON string
            stringified_data = json.dumps(loaded_yaml, indent=2)
            # Output a Data object containing the STRING
            parsed_data = Data(data=stringified_data) 
            # ---------------------

        except yaml.YAMLError as e:
            result_data = {
                "status": "fail",
                "error_type": "Syntax",
                "message": f"Invalid YAML syntax: {e}"
            }
            self.status = result_data
            result_message = Message(text=json.dumps(result_data))
            return {"result": result_message, "parsed_data": parsed_data} # Return fail status and empty string data
        except Exception as e:
            result_data = {
                "status": "fail",
                "error_type": "Syntax",
                "message": f"An unexpected error occurred during YAML parsing: {e}"
            }
            self.status = result_data
            result_message = Message(text=json.dumps(result_data))
            return {"result": result_message, "parsed_data": parsed_data}

        # Step 2: Validate against JSON Schema (if provided)
        if schema_json:
            try:
                schema = json.loads(schema_json)
                jsonschema.validate(instance=loaded_yaml, schema=schema)
            except jsonschema.ValidationError as e:
                result_data = {
                    "status": "fail",
                    "error_type": "Schema",
                    "message": f"Schema validation failed: {e.message} (Path: {list(e.path)})"
                }
                self.status = result_data
                result_message = Message(text=json.dumps(result_data))
                # Return fail status, but *with* the stringified data
                return {"result": result_message, "parsed_data": parsed_data}
            except Exception as e:
                result_data = {
                    "status": "fail",
                    "error_type": "Schema",
                    "message": f"An unexpected error during schema validation: {e}"
                }
                self.status = result_data
                result_message = Message(text=json.dumps(result_data))
                return {"result": result_message, "parsed_data": parsed_data}

        # If all checks pass
        result_data = {
            "status": "pass",
            "message": "YAML syntax and schema (if provided) are valid.",
        }
        self.status = result_data
        result_message = Message(text=json.dumps(result_data))
        # Return PASS status and the STRINGIFIED PARSED DATA
        return {"result": result_message, "parsed_data": parsed_data}