#!/usr/bin/env node
import fs from 'fs/promises';
import path from 'path';
import YAML from 'yaml';

const baseRoot = path.resolve(process.cwd(), 'SW5e_Data_Hub');
const dataRoot = path.join(baseRoot, 'data');

const readYaml = async (absPath) => YAML.parse(await fs.readFile(absPath, 'utf8'));
const resolveDataPath = (p) => {
  if (!p) return null;
  const norm = p.replace(/\\/g, '/');
  const marker = 'SW5e_Data_Hub/';
  if (norm.includes(marker)) {
    const rel = norm.split(marker)[1];
    return path.join(baseRoot, rel);
  }
  return path.isAbsolute(p) ? p : path.join(baseRoot, p);
};

const flattenActions = (doc) => {
  if (!doc || typeof doc !== 'object') return [];
  const actions = [];
  for (const [key, value] of Object.entries(doc)) {
    if (Array.isArray(value)) {
      for (const entry of value) {
        if (entry && typeof entry === 'object' && entry.station && entry.id) {
          actions.push({ ...entry });
        }
      }
    }
  }
  return actions;
};

const filterBy = (actions, filters) => {
  const stations = filters?.stations || [];
  const tagsAny = filters?.tags_any || [];
  return actions.filter(a => {
    const stationOk = stations.includes('Any') || stations.includes(a.station);
    if (!stationOk) return false;
    if (!tagsAny.length) return true;
    const aTags = Array.isArray(a.tags) ? a.tags : [];
    return aTags.some(t => tagsAny.includes(t));
  });
};

const loadRole = async (name) => {
  const rolesDoc = await readYaml(path.join(dataRoot, 'starship_roles.yml'));
  return (rolesDoc?.roles || []).find(r => r.name.toLowerCase() === name.toLowerCase());
};

const unionFilters = (primaryRole, secondaryRole, setKey) => {
  const stations = new Set();
  const tagsAny = new Set();
  const add = (role) => {
    const f = role?.action_filters?.[setKey];
    if (!f) return;
    (f.stations || []).forEach(s => stations.add(s));
    (f.tags_any || []).forEach(t => tagsAny.add(t));
  };
  add(primaryRole);
  add(secondaryRole);
  if (stations.size === 0) stations.add('Any');
  return { stations: Array.from(stations), tags_any: Array.from(tagsAny) };
};

const listUsable = async ({ primaryRoleName, secondaryRoleName, includeCombat = true, includeNonCombat = true }) => {
  const registry = await readYaml(path.join(dataRoot, 'starship_actions_registry.yml'));
  const primaryRole = primaryRoleName ? await loadRole(primaryRoleName) : null;
  const secondaryRole = secondaryRoleName ? await loadRole(secondaryRoleName) : null;

  const out = { roles_used: [primaryRoleName, secondaryRoleName].filter(Boolean), combat: [], non_combat: [] };

  if (includeCombat) {
    const combatPath = resolveDataPath(registry?.registry?.combat?.file);
    const combatDoc = combatPath ? await readYaml(combatPath) : null;
    const combatAll = flattenActions(combatDoc);
    const filters = unionFilters(primaryRole, secondaryRole, 'combat');
    out.combat = filterBy(combatAll, filters).map(a => ({ id: a.id, name: a.name, station: a.station }));
  }

  if (includeNonCombat) {
    const ncPath = resolveDataPath(registry?.registry?.non_combat?.file);
    const ncDoc = ncPath ? await readYaml(ncPath) : null;
    const ncAll = flattenActions(ncDoc);
    const filters = unionFilters(primaryRole, secondaryRole, 'non_combat');
    out.non_combat = filterBy(ncAll, filters).map(a => ({ id: a.id, name: a.name, station: a.station }));
  }

  return out;
};

const main = async () => {
  const args = process.argv.slice(2);
  const idxRole = args.indexOf('--role');
  const idxChar = args.indexOf('--character');

  if (idxRole === -1 && idxChar === -1) {
    console.log('Usage: node scripts/starship_actions_preview.mjs --role "Pilot"');
    console.log('   or: node scripts/starship_actions_preview.mjs --character path/to/character.json');
    process.exit(1);
  }

  let primaryRoleName = null;
  let secondaryRoleName = null;

  if (idxRole !== -1) {
    primaryRoleName = args[idxRole + 1];
  }

  if (idxChar !== -1) {
    const charPath = path.resolve(process.cwd(), args[idxChar + 1]);
    const char = JSON.parse(await fs.readFile(charPath, 'utf8'));
    primaryRoleName = char?.starship?.primary_role || primaryRoleName;
    secondaryRoleName = char?.starship?.secondary_role || secondaryRoleName;
  }

  const result = await listUsable({ primaryRoleName, secondaryRoleName });
  console.log(JSON.stringify(result, null, 2));
};

main().catch(err => {
  console.error(err);
  process.exit(1);
});
