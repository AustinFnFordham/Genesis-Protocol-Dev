import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SPECIES_DIR = path.resolve(__dirname, '..', 'data', 'species');

const STOPWORD_IDS = new Set([
	'the', 'their', 'there', 'they',
	'although', 'despite', 'descended', 'physically', 'having', 'member', 'large', 'native', 'thin', 'while', 'externally', 'evolved', 'generally', 'possessed'
]);

async function main() {
	const entries = await fs.readdir(SPECIES_DIR, { withFileTypes: true });
	let removed = 0;
	for (const entry of entries) {
		if (!entry.isFile() || !entry.name.endsWith('.yml')) continue;
		const id = entry.name.replace(/\.yml$/i, '');
		if (STOPWORD_IDS.has(id)) {
			await fs.unlink(path.join(SPECIES_DIR, entry.name));
			removed += 1;
		}
	}
	console.log(`Removed ${removed} invalid species file(s).`);
}

main().catch((err) => {
	console.error(err);
	process.exit(1);
});
