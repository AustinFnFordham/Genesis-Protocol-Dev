import argparse
import re
from pathlib import Path
import difflib

ROOT = Path(__file__).resolve().parents[1]


def normalize(text: str) -> str:
    # Lowercase, collapse whitespace, remove zero-width/soft hyphen and stray artifacts
    text = text.lower()
    text = re.sub(r"[\u200b\u00ad]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def find_best_similarity(haystack: str, needle: str, window_chars: int = None):
    if window_chars is None:
        window_chars = max(2000, len(needle))
    best_ratio = 0.0
    best_segment = ""
    # Slide over haystack in chunks to find best ratio
    step = max(200, len(needle) // 3 or 1)
    for start in range(0, max(1, len(haystack) - window_chars + 1), step):
        segment = haystack[start:start + window_chars]
        ratio = difflib.SequenceMatcher(None, segment, needle).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_segment = segment
    return best_ratio, best_segment


def main():
    parser = argparse.ArgumentParser(description="Compare excerpt against cleaned AoR_Beta.txt")
    parser.add_argument("--aor", default=str(ROOT / "data" / "clean_source" / "AoR_Beta.txt"))
    parser.add_argument("--snippet", default=str(ROOT / "data" / "clean_source" / "copy" / "paste_test"))
    args = parser.parse_args()

    aor = Path(args.aor).read_text(encoding="utf-8", errors="ignore")
    snippet = Path(args.snippet).read_text(encoding="utf-8", errors="ignore")

    aor_n = normalize(aor)
    snippet_n = normalize(snippet)

    contains = snippet_n in aor_n
    print(f"Contains (normalized substring): {contains}")

    ratio = difflib.SequenceMatcher(None, aor_n, snippet_n).ratio()
    print(f"Global similarity ratio: {ratio:.4f}")

    best_ratio, best_segment = find_best_similarity(aor_n, snippet_n)
    print(f"Best window similarity: {best_ratio:.4f}")

    if not contains:
        print("--- Best matching excerpt (normalized) ---")
        # Show a small diff context
        diff = difflib.unified_diff(
            snippet_n.split(), best_segment.split(), lineterm=""
        )
        # Print only a short prefix of diff to keep output manageable
        count = 0
        for line in diff:
            print(line)
            count += 1
            if count > 80:
                print("...diff truncated...")
                break


if __name__ == "__main__":
    main()
