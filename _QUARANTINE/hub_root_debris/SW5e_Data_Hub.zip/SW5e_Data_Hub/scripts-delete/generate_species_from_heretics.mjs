import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROOT = path.resolve(__dirname, '..');
const RAW_FILE = path.join(ROOT, 'data', 'raw_source', 'Heretics_Guide.txt');
const OUT_DIR = path.join(ROOT, 'data', 'species');

function toIdFromName(name) {
	return name
		.toLowerCase()
		.replace(/[^a-z0-9]+/g, '_')
		.replace(/^_+|_+$/g, '')
		.replace(/_{2,}/g, '_');
}

function titleCase(s) {
	return s.replace(/(^|\s|-)([a-z])/g, (_, p1, p2) => p1 + p2.toUpperCase());
}

function singularizeSimple(word) {
	// Very naive singularization: drop trailing 's' if present and not ending with 'ss'
	if (/[^s]s$/i.test(word)) return word.slice(0, -1);
	return word;
}

function extractCandidateNames(line) {
	const results = new Set();
	// Pattern 1: after the double header, capture the first capitalized token
	const headerIdx = line.indexOf('BIOLOGY AND APPEARANCE');
	if (headerIdx !== -1) {
		// Use the last occurrence as the text tends to repeat twice
		const idx = line.lastIndexOf('BIOLOGY AND APPEARANCE');
		const after = line.slice(idx + 'BIOLOGY AND APPEARANCE'.length).trim();
		// Grab up to punctuation or ' are '
		const m = after.match(/^([A-Z][A-Za-z'\-]+)(?=\s+are\b|\s+is\b|\s|,|\.)/);
		if (m) results.add(m[1]);
	}
	return Array.from(results);
}

function buildYamlStub(name) {
	const id = toIdFromName(name);
	return (
		`id: ${id}\n` +
		`name: "${name}"\n` +
		`description: "TBD. Extract from source and hybridize per FFG Hybrid Protocol."\n` +
		`narrative_tags: []\n` +
		`starting_xp: 100\n` +
		`ability_score_increases:\n` +
		`  - ability: Choice\n` +
		`    value: 2\n` +
		`  - ability: Choice\n` +
		`    value: 1\n` +
		`speed: 30\n` +
		`size: Medium\n` +
		`languages: ["Basic"]\n` +
		`base_hp: 10\n` +
		`base_strain: 10\n` +
		`traits:\n` +
		`  - name: Placeholder Trait\n` +
		`    level: 1\n` +
		`    description: "TBD. Replace with species traits per sources."\n` +
		`    effects: []\n`
	);
}

async function main() {
	await fs.mkdir(OUT_DIR, { recursive: true });
	const raw = await fs.readFile(RAW_FILE, 'utf8');
	const lines = raw.split(/\r?\n/);
	const foundNames = new Set();
	for (const line of lines) {
		if (!line.includes('BIOLOGY AND APPEARANCE')) continue;
		for (const token of extractCandidateNames(line)) {
			const singular = singularizeSimple(token);
			const display = titleCase(singular.replace(/_/g, ' '));
			foundNames.add(display);
		}
	}
	if (foundNames.size === 0) {
		console.log('No candidate species names detected from Heretics_Guide.');
		return;
	}
	let created = 0;
	for (const name of foundNames) {
		const id = toIdFromName(name);
		const outPath = path.join(OUT_DIR, `${id}.yml`);
		try {
			await fs.access(outPath);
			continue; // already exists
		} catch {}
		await fs.writeFile(outPath, buildYamlStub(name), 'utf8');
		created += 1;
	}
	console.log(`Detected ${foundNames.size} candidate species; created ${created} new YAML stub(s).`);
}

main().catch((err) => {
	console.error(err);
	process.exit(1);
});
