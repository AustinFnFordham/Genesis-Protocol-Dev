import argparse
import os
import subprocess
import sys
from pathlib import Path

import ftfy
import pdfplumber
from syntok.segmenter import process as syntok_process

try:
    import pytesseract
    from pypdfium2 import PdfDocument
    TESS_AVAILABLE = True
except Exception:
    TESS_AVAILABLE = False

ROOT = Path(__file__).resolve().parents[1]
PDF_DIR = ROOT / 'data' / 'pdf'
OUT_DIR = ROOT / 'data' / 'clean_source'
TMP_DIR = ROOT / 'temp_ocr'


def run_ocrmypdf(input_pdf: Path, output_pdf: Path) -> bool:
    try:
        output_pdf.parent.mkdir(parents=True, exist_ok=True)
        cmd = [
            sys.executable, '-m', 'ocrmypdf',
            '--force-ocr',
            '--jobs', str(os.cpu_count() or 2),
            str(input_pdf), str(output_pdf),
        ]
        subprocess.run(cmd, check=True)
        return True
    except Exception as e:
        print(f"[warn] OCRmyPDF failed or not available for {input_pdf.name}: {e}")
        return False


def tesseract_ocr_pdf(input_pdf: Path, output_txt: Path, dpi: int = 300) -> bool:
    if not TESS_AVAILABLE:
        return False
    try:
        doc = PdfDocument(str(input_pdf))
        texts = []
        for i in range(len(doc)):
            page = doc[i]
            bitmap = page.render(scale=dpi/72).to_pil()
            # Use OEM LSTM with block-level analysis (psm 6)
            text = pytesseract.image_to_string(bitmap, lang='eng', config='--oem 1 --psm 6')
            texts.append(text)
        output_txt.write_text('\n\n'.join(texts), encoding='utf-8')
        return True
    except Exception as e:
        print(f"[warn] pytesseract OCR failed for {input_pdf.name}: {e}")
        return False


def extract_text_with_pdfplumber(pdf_path: Path) -> str:
    lines = []
    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            try:
                words = page.extract_words(use_text_flow=True, keep_blank_chars=False)
                if not words:
                    raw = page.extract_text() or ''
                    text = ftfy.fix_text(raw)
                    lines.append(f"===== PAGE {page_num} / {len(pdf.pages)} =====")
                    lines.append(text)
                    continue

                words.sort(key=lambda w: (round(w['top'] / 2), w['x0']))
                current_y = None
                current = []
                page_lines = []
                for w in words:
                    y = round(w['top'] / 2)
                    if current_y is None or abs(y - current_y) <= 1:
                        current.append(w)
                        current_y = y if current_y is None else (current_y + y) // 2
                    else:
                        text = ' '.join(t['text'] for t in current)
                        page_lines.append((min(t['x0'] for t in current), current_y, text))
                        current = [w]
                        current_y = y
                if current:
                    text = ' '.join(t['text'] for t in current)
                    page_lines.append((min(t['x0'] for t in current), current_y, text))

                xs = sorted(set(x for x, _, _ in page_lines))
                split_at = None
                max_gap = 0
                for a, b in zip(xs, xs[1:]):
                    gap = b - a
                    if gap > max_gap:
                        max_gap = gap
                        split_at = (a + b) / 2
                if split_at and max_gap > 100:
                    left = [pl for pl in page_lines if pl[0] <= split_at]
                    right = [pl for pl in page_lines if pl[0] > split_at]
                    page_lines_sorted = sorted(left, key=lambda x: -x[1]) + sorted(right, key=lambda x: -x[1])
                else:
                    page_lines_sorted = sorted(page_lines, key=lambda x: (-x[1], x[0]))

                lines.append(f"===== PAGE {page_num} / {len(pdf.pages)} =====")
                for _, __, text in page_lines_sorted:
                    lines.append(ftfy.fix_text(text))
            except Exception as e:
                print(f"[warn] Failed page {page_num}: {e}")
                lines.append(f"===== PAGE {page_num} / {len(pdf.pages)} =====")
    return '\n'.join(lines)


def reflow_with_syntok(text: str) -> str:
    paragraphs = []
    for para in syntok_process(text):
        tokens = []
        for sent in para:
            sent_text = ''.join([t.spacing + t.value for t in sent]).strip()
            tokens.append(sent_text)
        if tokens:
            paragraphs.append(' '.join(tokens))
    return '\n\n'.join(paragraphs)


def process_pdf(pdf_path: Path, use_ocr: bool, force_image_ocr: bool) -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    tmp_pdf = TMP_DIR / pdf_path.name
    TMP_DIR.mkdir(parents=True, exist_ok=True)

    ocr_ok = False
    if use_ocr and not force_image_ocr:
        ocr_ok = run_ocrmypdf(pdf_path, tmp_pdf)

    source = tmp_pdf if (use_ocr and not force_image_ocr and ocr_ok and tmp_pdf.exists()) else pdf_path

    if force_image_ocr and TESS_AVAILABLE:
        # Full image OCR path
        out_txt_tmp = TMP_DIR / (pdf_path.stem + '.txt')
        if tesseract_ocr_pdf(pdf_path, out_txt_tmp, dpi=300):
            raw = out_txt_tmp.read_text(encoding='utf-8')
            cleaned = reflow_with_syntok(raw)
            out_path = OUT_DIR / (pdf_path.stem + '.txt')
            out_path.write_text(cleaned, encoding='utf-8')
            return out_path

    raw = extract_text_with_pdfplumber(source)

    # If extraction is too sparse and OCR requested, fallback to direct Tesseract
    if use_ocr and len(raw.strip()) < 100 and TESS_AVAILABLE:
        out_txt_tmp = TMP_DIR / (pdf_path.stem + '.txt')
        if tesseract_ocr_pdf(pdf_path, out_txt_tmp):
            raw = out_txt_tmp.read_text(encoding='utf-8')

    cleaned = reflow_with_syntok(raw)
    out_path = OUT_DIR / (pdf_path.stem + '.txt')
    out_path.write_text(cleaned, encoding='utf-8')
    return out_path


def main():
    parser = argparse.ArgumentParser(description='OCR + extract + clean PDFs to clean_source')
    parser.add_argument('--ocr', action='store_true', help='Use OCRmyPDF to redo OCR')
    parser.add_argument('--force-image-ocr', action='store_true', help='Render each page and OCR with Tesseract')
    parser.add_argument('--target', default=str(PDF_DIR), help='Directory or PDF path to process')
    args = parser.parse_args()

    target = Path(args.target)
    pdfs = []
    if target.is_file() and target.suffix.lower() == '.pdf':
        pdfs = [target]
    else:
        pdfs = [p for p in target.glob('*.pdf')]

    if not pdfs:
        print('No PDFs found to process')
        sys.exit(0)

    for pdf in pdfs:
        print(f'Processing {pdf.name} (OCR={args.ocr}, FORCE_IMAGE_OCR={args.force_image_ocr})...')
        out = process_pdf(pdf, args.ocr, args.force_image_ocr)
        print(f' -> Wrote {out.relative_to(ROOT)}')


if __name__ == '__main__':
    main()
