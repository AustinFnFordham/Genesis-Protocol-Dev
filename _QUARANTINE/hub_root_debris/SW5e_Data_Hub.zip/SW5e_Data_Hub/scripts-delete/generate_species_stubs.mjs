import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROOT = path.resolve(__dirname, '..');
const RAW_FILE = path.join(ROOT, 'data', 'raw_source', 'EC_02_Species.txt');
const OUT_DIR = path.join(ROOT, 'data', 'species');

function toIdFromName(name) {
	return name
		.toLowerCase()
		.replace(/[^a-z0-9]+/g, '_')
		.replace(/^_+|_+$/g, '')
		.replace(/_{2,}/g, '_');
}

function yamlEscape(value) {
	// Wrap in double quotes and escape existing quotes
	const escaped = String(value).replace(/"/g, '\\"');
	return `"${escaped}"`;
}

function buildYamlStub(name) {
	const id = toIdFromName(name);
	return (
		`id: ${id}\n` +
		`name: ${yamlEscape(name)}\n` +
		`description: ${yamlEscape('TBD. Extract from source and hybridize per FFG Hybrid Protocol.')}\n` +
		`narrative_tags: []\n` +
		`starting_xp: 100\n` +
		`ability_score_increases:\n` +
		`  - ability: Choice\n` +
		`    value: 2\n` +
		`  - ability: Choice\n` +
		`    value: 1\n` +
		`speed: 30\n` +
		`size: Medium\n` +
		`languages: ["Basic"]\n` +
		`base_hp: 10\n` +
		`base_strain: 10\n` +
		`traits:\n` +
		`  - name: Placeholder Trait\n` +
		`    level: 1\n` +
		`    description: ${yamlEscape('TBD. Replace with species traits per sources.')}\n` +
		`    effects: []\n`
	);
}

async function parseSpeciesListFromToc(text) {
	// Find the line starting with 'SPECIES  TABLE OF CONTENTS'
	const tocLine = text.split(/\r?\n/).find((line) => line.includes('SPECIES') && line.includes('TABLE OF CONTENTS'));
	if (!tocLine) return [];
	// After the marker, the rest of the line is a list of species names separated by two or more spaces
	const idx = tocLine.indexOf('TABLE OF CONTENTS');
	const listPart = tocLine.slice(idx + 'TABLE OF CONTENTS'.length).trim();
	const names = listPart
		.split(/\s{2,}/)
		.map((n) => n.trim())
		.filter((n) => n.length > 0);
	return names;
}

async function main() {
	await fs.mkdir(OUT_DIR, { recursive: true });
	const raw = await fs.readFile(RAW_FILE, 'utf8');
	const speciesNames = await parseSpeciesListFromToc(raw);
	if (speciesNames.length === 0) {
		console.log('No species list found in EC_02_Species.txt');
		return;
	}
	console.log(`Found ${speciesNames.length} species in EC_02 table of contents.`);

	let created = 0;
	for (const name of speciesNames) {
		const id = toIdFromName(name);
		const filePath = path.join(OUT_DIR, `${id}.yml`);
		try {
			await fs.access(filePath);
			// already exists - skip
			continue;
		} catch {
			// does not exist - create
			const yaml = buildYamlStub(name);
			await fs.writeFile(filePath, yaml, 'utf8');
			created += 1;
		}
	}
	console.log(`Created ${created} new species YAML stub(s).`);
}

main().catch((err) => {
	console.error(err);
	process.exit(1);
});
