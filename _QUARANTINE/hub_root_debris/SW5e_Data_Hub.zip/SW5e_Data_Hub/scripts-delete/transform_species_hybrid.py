"""
transform_species_hybrid.py

Reads unstructured.io JSON outputs from SW5e and FFG sourcebooks and produces
hybridized Species YAML files matching the Species.schema.json.

This script uses a heuristic parser over unstructured elements to identify
species sections and extract key stats. It then applies one of three
conversion paths per species:
  - HYBRID: present in both SW5e and FFG
  - ADAPT: present only in SW5e
  - TRANSLATE: present only in FFG

Usage:
  python transform_species_hybrid.py \
    --sw5e-dir B:/API_Cursor_SW5e/SW5e_Data_Hub/data/pdf_json \
    --ffg-dir  B:/API_Cursor_SW5e/SW5e_Data_Hub/data/pdf_json \
    --output-dir B:/API_Cursor_SW5e/SW5e_Data_Hub/data/species

Notes:
  - The input directories should contain unstructured JSON files (array of
    elements with "type" and "text" fields). The script will scan all .json
    files inside each directory.
  - This is a best-effort extractor with conservative defaults to satisfy the
    Species schema even when data cannot be reliably extracted.
  - You can iterate on the regexes or add source-specific rules as you learn
    more about the input structure for your books.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import yaml

try:
    from jsonschema import Draft7Validator  # type: ignore
except Exception:  # noqa: BLE001
    Draft7Validator = None  # Optional dependency


# ----------------------------- Constants & Glossary -----------------------------

FFG_TO_OFFICIAL: Dict[str, str] = {
    "Wound Threshold": "base_hp",
    "Strain Threshold": "base_strain",
    "Soak": "dr_value",  # Not in Species.schema.json, may be added as a trait note
}

ABILITY_NAMES = [
    "Strength",
    "Dexterity",
    "Constitution",
    "Intelligence",
    "Wisdom",
    "Charisma",
]

SIZE_VALUES = ["Tiny", "Small", "Medium", "Large"]


# ----------------------------- Data Structures -----------------------------

@dataclass
class SpeciesBlock:
    name: str
    source: str  # "SW5e" or "FFG"
    elements: List[dict]


# ----------------------------- Utility Functions -----------------------------

def slugify(value: str) -> str:
    base = re.sub(r"[^a-zA-Z0-9\s'_\-]", "", value).strip().lower()
    base = base.replace("'", "").replace(" ", "_").replace("-", "_")
    base = re.sub(r"_+", "_", base)
    return base


def read_all_elements_from_dir(dir_path: Path) -> List[dict]:
    elements: List[dict] = []
    for json_file in sorted(dir_path.glob("*.json")):
        try:
            with json_file.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                # Annotate origin for debugging
                for el in data:
                    el.setdefault("_origin_file", str(json_file))
                elements.extend(data)
        except Exception as exc:  # noqa: BLE001
            print(f"[WARN] Skipping unreadable file: {json_file} ({exc})", file=sys.stderr)
    return elements


def window(elements: List[dict], start_idx: int, count: int) -> Iterable[dict]:
    for i in range(start_idx, min(len(elements), start_idx + count)):
        yield elements[i]


def looks_like_species_title(text: str) -> bool:
    # Heuristic: species names are Proper Case, usually 1-3 words, not common book headings
    if not text:
        return False
    # Filter out clearly non-species generic headings
    blacklist = {
        "TABLE OF CONTENTS",
        "CREDITS",
        "PLAYER'S HANDBOOK",
        "CHAPTER",
        "APPENDIX",
        "INDEX",
    }
    upper = text.strip().upper()
    if upper in blacklist:
        return False

    # Exclude lines that are all-caps (common for headings)
    # Allow apostrophes and hyphens but treat letters for caps
    letters = re.sub(r"[^A-Za-z]", "", text)
    if letters and letters.upper() == letters:
        return False

    # Must start with a letter and contain mostly letters/spaces/hyphen/quote
    if not re.match(r"^[A-Za-z][A-Za-z'\- ]{1,40}$", text.strip()):
        return False

    # Capitalization heuristic: Each word starts uppercase
    words = [w for w in text.strip().split() if w]
    if not words or len(words) > 3:
        return False
    if not all(w[0].isupper() for w in words):
        return False
    return True


def species_context_signals(text: str) -> int:
    # Score context keywords to decide if a title likely denotes a species section
    score = 0
    lowered = text.lower()
    for kw in [
        "speed",
        "size",
        "languages",
        "wound threshold",
        "strain threshold",
        "soak",
        "traits",
    ]:
        if kw in lowered:
            score += 1
    return score


def is_species_block(block: List[dict]) -> bool:
    # Require stronger signals in the actual block text
    text = "\n".join((e.get("text") or "") for e in block)
    hits = 0
    if re.search(r"\bLanguages?\b\s*[:\-]", text, flags=re.IGNORECASE):
        hits += 1
    if re.search(r"\bSize\b\s*[:\-]?[\s\S]*\b(Tiny|Small|Medium|Large)\b", text, flags=re.IGNORECASE):
        hits += 1
    if re.search(r"\bSpeed\b\s*[:\-]?\s*\d{2}\b", text, flags=re.IGNORECASE):
        hits += 1
    if re.search(r"\b(Ability Score Increase|ASI|increases by)\b", text, flags=re.IGNORECASE):
        hits += 1
    # FFG markers
    if re.search(r"\bWound Threshold\b", text, flags=re.IGNORECASE):
        hits += 1
    if re.search(r"\bStrain Threshold\b", text, flags=re.IGNORECASE):
        hits += 1
    return hits >= 2


def slice_block(elements: List[dict], start_idx: int) -> List[dict]:
    # Take elements until the next Title-like boundary
    block: List[dict] = []
    for i in range(start_idx, len(elements)):
        el = elements[i]
        if i > start_idx and el.get("type") in {"Title", "Header", "SectionHeader"}:
            # Stop at next header
            break
        block.append(el)
    return block


def extract_species_blocks(elements: List[dict], source: str) -> Dict[str, SpeciesBlock]:
    species: Dict[str, SpeciesBlock] = {}
    for idx, el in enumerate(elements):
        if el.get("type") not in {"Title", "Header", "SectionHeader"}:
            continue
        title = (el.get("text") or "").strip()
        if not looks_like_species_title(title):
            continue
        # Look ahead a window for species-relevant keywords
        context_text = " ".join((e.get("text") or "") for e in window(elements, idx + 1, 80))
        if species_context_signals(context_text) == 0:
            continue

        block_elements = slice_block(elements, idx)
        # Extra guard to reduce false positives
        if not is_species_block(block_elements):
            continue
        key = slugify(title)
        if key not in species:
            species[key] = SpeciesBlock(name=title, source=source, elements=block_elements)
    return species


# ----------------------------- Parsers -----------------------------

def extract_first_paragraph(block: List[dict]) -> str:
    texts = [e.get("text") or "" for e in block[1:]]  # skip the title line at [0]
    joined = "\n".join(texts)
    # Split on double newlines or period end-of-sentence as a heuristic
    parts = re.split(r"\n\s*\n|(?<=\.)\s+\n?", joined)
    for p in parts:
        cleaned = p.strip()
        if 80 <= len(cleaned) <= 800 and not cleaned.isupper():
            return cleaned
    return (texts[0] if texts else "").strip()


def parse_sw5e_stats(block: List[dict]) -> Dict[str, object]:
    text = "\n".join((e.get("text") or "") for e in block)
    data: Dict[str, object] = {}

    # Ability score increases
    asi: List[Dict[str, object]] = []
    for ability in ABILITY_NAMES:
        pattern = rf"{ability}[^\n\r]*?(?:increase(?:s)? by|\+)(?:\s*)?(\d+)"
        m = re.search(pattern, text, flags=re.IGNORECASE)
        if m:
            try:
                val = int(m.group(1))
                asi.append({"ability": ability, "value": val})
            except ValueError:
                pass
    data["ability_score_increases"] = asi

    # Speed in feet
    m = re.search(r"speed[^\d]*(\d{2})\s*(?:feet|ft)?", text, flags=re.IGNORECASE)
    if m:
        try:
            data["speed"] = int(m.group(1))
        except ValueError:
            pass

    # Size
    for size in SIZE_VALUES:
        if re.search(rf"\bsize\b[^\n]*\b{size}\b", text, flags=re.IGNORECASE):
            data["size"] = size
            break

    # Languages: naive parse of a line starting with Languages
    m = re.search(r"languages?[:\-]\s*(.+)", text, flags=re.IGNORECASE)
    languages: List[str] = []
    if m:
        raw = m.group(1).strip()
        raw = raw.split(".")[0]
        parts = re.split(r",|;| and ", raw)
        for p in parts:
            lang = p.strip()
            if lang:
                languages.append(lang)
    data["languages"] = languages

    return data


def parse_ffg_stats(block: List[dict]) -> Dict[str, object]:
    text = "\n".join((e.get("text") or "") for e in block)
    data: Dict[str, object] = {}

    def grab_int(label: str) -> Optional[int]:
        m = re.search(rf"{re.escape(label)}\s*[:\-]?\s*(\d+)", text, flags=re.IGNORECASE)
        if m:
            try:
                return int(m.group(1))
            except ValueError:
                return None
        return None

    wt = grab_int("Wound Threshold")
    st = grab_int("Strain Threshold")
    soak = grab_int("Soak")

    if wt is not None:
        data["base_hp"] = wt
    if st is not None:
        data["base_strain"] = st
    if soak is not None:
        # No explicit 'dr' field in schema; add as a trait placeholder
        data.setdefault("traits", [])
        data["traits"].append(
            {
                "name": "Damage Reduction (from Soak)",
                "level": 1,
                "description": f"This species typically exhibits Soak {soak} in FFG sources, represented here as flat Damage Reduction.",
            }
        )

    return data


# ----------------------------- Merge/Adapt/Translate -----------------------------

def default_starting_xp_for_species(name: str) -> int:
    # Simple default. You can refine this by species later.
    return 90


def default_base_hp_for_species(size: Optional[str]) -> int:
    if size == "Large":
        return 12
    if size == "Small" or size == "Tiny":
        return 8
    return 10


def default_base_strain_for_species(name: str) -> int:
    # Default strain value. Consider enhancing with per-species heuristics.
    return 10


def merge_hybrid(sw5e: Dict[str, object], ffg: Dict[str, object]) -> Dict[str, object]:
    merged: Dict[str, object] = {}

    # d20 foundation from SW5e
    for key in ["ability_score_increases", "speed", "size", "languages"]:
        if key in sw5e and sw5e.get(key):
            merged[key] = sw5e[key]

    # Narrative + unique mechanics prioritized from FFG
    for key in ["base_hp", "base_strain", "traits"]:
        if key in ffg and ffg.get(key) is not None:
            merged[key] = ffg[key]

    # Ensure required fields exist
    if "base_hp" not in merged:
        merged["base_hp"] = default_base_hp_for_species(merged.get("size"))
    if "base_strain" not in merged:
        merged["base_strain"] = default_base_strain_for_species("")
    merged.setdefault("traits", [])

    return merged


def adapt_sw5e_only(sw5e: Dict[str, object]) -> Dict[str, object]:
    adapted: Dict[str, object] = {}
    for key in ["ability_score_increases", "speed", "size", "languages"]:
        if sw5e.get(key) is not None:
            adapted[key] = sw5e[key]

    # Invent missing narrative mechanics with sensible defaults
    adapted["base_hp"] = default_base_hp_for_species(sw5e.get("size"))
    adapted["base_strain"] = default_base_strain_for_species("")
    adapted.setdefault("traits", [])
    adapted["traits"].append(
        {
            "name": "Narrative Hooks",
            "level": 1,
            "description": "Adapted from SW5e traits as narrative mechanics; expand with manual curation.",
        }
    )
    return adapted


def translate_ffg_only(ffg: Dict[str, object]) -> Dict[str, object]:
    translated: Dict[str, object] = {}
    if "base_hp" in ffg:
        translated["base_hp"] = ffg["base_hp"]
    else:
        translated["base_hp"] = default_base_hp_for_species(None)

    if "base_strain" in ffg:
        translated["base_strain"] = ffg["base_strain"]
    else:
        translated["base_strain"] = default_base_strain_for_species("")

    translated.setdefault("traits", [])
    if ffg.get("traits"):
        translated["traits"].extend(ffg["traits"])  # carry over Soak -> DR note

    # d20 foundation unknown -> defaults; may be refined later
    translated.setdefault("ability_score_increases", [])
    translated.setdefault("languages", [])
    translated.setdefault("speed", 30)
    translated.setdefault("size", "Medium")

    return translated


# ----------------------------- Orchestration -----------------------------

def build_master_species(
    sw5e_blocks: Dict[str, SpeciesBlock], ffg_blocks: Dict[str, SpeciesBlock]
) -> List[str]:
    keys = set(sw5e_blocks.keys()) | set(ffg_blocks.keys())
    return sorted(keys)


def construct_species_record(
    species_id: str,
    species_name: str,
    scenario: str,
    description: str,
    merged_data: Dict[str, object],
) -> Dict[str, object]:
    record: Dict[str, object] = {
        "id": species_id,
        "name": species_name,
        "description": description or "",
        "narrative_tags": [],
        "starting_xp": default_starting_xp_for_species(species_name),
        "ability_score_increases": merged_data.get("ability_score_increases", []),
        "speed": merged_data.get("speed", 30),
        "size": merged_data.get("size", "Medium"),
        "languages": merged_data.get("languages", []),
        "base_hp": merged_data.get("base_hp", default_base_hp_for_species(merged_data.get("size"))),
        "base_strain": merged_data.get("base_strain", default_base_strain_for_species(species_name)),
        "traits": merged_data.get("traits", []),
    }

    # Add a provenance trait for traceability
    record.setdefault("traits", [])
    record["traits"].append(
        {
            "name": "Data Provenance",
            "level": 1,
            "description": f"This species entry was created via {scenario} conversion.",
        }
    )

    return record


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Hybridize species data from SW5e and FFG unstructured JSON outputs into YAML."
    )
    parser.add_argument("--sw5e-dir", required=True, help="Directory with SW5e unstructured JSON files.")
    parser.add_argument("--ffg-dir", required=True, help="Directory with FFG unstructured JSON files.")
    parser.add_argument("--output-dir", required=True, help="Directory to write species YAML files.")
    parser.add_argument(
        "--schema",
        default=None,
        help=(
            "Path to Species.schema.json for validation. If omitted, the script will attempt to locate "
            "'../schema/Species.schema.json' relative to this script."
        ),
    )
    parser.add_argument(
        "--species-allowlist",
        default=None,
        help=(
            "Optional path to a text file with one species name per line. If provided, only these species "
            "will be considered during extraction."
        ),
    )
    args = parser.parse_args()

    sw5e_dir = Path(args.sw5e_dir)
    ffg_dir = Path(args.ffg_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load schema if available
    schema_path: Optional[Path] = None
    if args.schema:
        schema_path = Path(args.schema)
    else:
        # Default relative: scripts/ -> ../schema/Species.schema.json
        schema_path = (Path(__file__).resolve().parent.parent / "schema" / "Species.schema.json")
    schema: Optional[dict] = None
    validator = None
    if schema_path and schema_path.exists():
        try:
            with schema_path.open("r", encoding="utf-8") as f:
                schema = json.load(f)
            if Draft7Validator is not None:
                validator = Draft7Validator(schema)
                print(f"[INFO] Loaded schema for validation: {schema_path}")
            else:
                print("[WARN] jsonschema not installed; skipping validation.")
        except Exception as exc:  # noqa: BLE001
            print(f"[WARN] Failed to load schema at {schema_path}: {exc}")
    else:
        print(f"[WARN] Schema file not found at {schema_path}; skipping validation.")

    print(f"[INFO] Loading SW5e JSON files from: {sw5e_dir}")
    sw5e_elements = read_all_elements_from_dir(sw5e_dir)
    print(f"[INFO] Loaded {len(sw5e_elements):,} SW5e elements")

    print(f"[INFO] Loading FFG JSON files from: {ffg_dir}")
    ffg_elements = read_all_elements_from_dir(ffg_dir)
    print(f"[INFO] Loaded {len(ffg_elements):,} FFG elements")

    sw5e_blocks = extract_species_blocks(sw5e_elements, source="SW5e")
    ffg_blocks = extract_species_blocks(ffg_elements, source="FFG")

    master_species = build_master_species(sw5e_blocks, ffg_blocks)

    # Apply allowlist if provided
    if args.species_allowlist:
        allowlist_path = Path(args.species_allowlist)
        if allowlist_path.exists():
            names: List[str] = []
            try:
                if allowlist_path.suffix.lower() in {".yml", ".yaml"}:
                    with allowlist_path.open("r", encoding="utf-8") as f:
                        loaded = yaml.safe_load(f)
                    if isinstance(loaded, list):
                        names = [str(x) for x in loaded if isinstance(x, (str, int, float))]
                else:
                    with allowlist_path.open("r", encoding="utf-8") as f:
                        names = [line.strip() for line in f if line.strip()]
            except Exception as exc:  # noqa: BLE001
                print(f"[WARN] Failed to read allowlist {allowlist_path}: {exc}")
                names = []

            if names:
                allow_ids = {slugify(n) for n in names}
                master_species = [s for s in master_species if s in allow_ids]
                print(f"[INFO] Using allowlist with {len(allow_ids)} entries; {len(master_species)} matched.")
            else:
                print(f"[WARN] Allowlist at {allowlist_path} yielded no entries; ignoring.")
        else:
            print(f"[WARN] Allowlist not found at {allowlist_path}; ignoring.")
    print(f"[INFO] Identified {len(master_species)} unique species candidates")

    for species_key in master_species:
        sw5e_block = sw5e_blocks.get(species_key)
        ffg_block = ffg_blocks.get(species_key)

        species_name = (sw5e_block or ffg_block).name  # at least one must exist
        species_id = slugify(species_name)

        sw5e_data: Dict[str, object] = {}
        ffg_data: Dict[str, object] = {}
        description = ""

        if sw5e_block:
            sw5e_data = parse_sw5e_stats(sw5e_block.elements)
            if not description:
                description = extract_first_paragraph(sw5e_block.elements)
        if ffg_block:
            ffg_data = parse_ffg_stats(ffg_block.elements)
            # Prefer FFG narrative if available
            description = extract_first_paragraph(ffg_block.elements) or description

        if sw5e_block and ffg_block:
            scenario = "HYBRID"
            merged = merge_hybrid(sw5e_data, ffg_data)
        elif sw5e_block and not ffg_block:
            scenario = "ADAPT"
            merged = adapt_sw5e_only(sw5e_data)
        else:
            scenario = "TRANSLATE"
            merged = translate_ffg_only(ffg_data)

        record = construct_species_record(
            species_id=species_id,
            species_name=species_name,
            scenario=scenario,
            description=description,
            merged_data=merged,
        )

        out_path = output_dir / f"{species_id}.yml"
        # Validate if we can
        if validator is not None:
            errors = sorted(validator.iter_errors(record), key=lambda e: e.path)
            if errors:
                print(f"[ERROR] Validation failed for {species_id}:")
                for e in errors[:5]:
                    path = "/".join([str(p) for p in e.path]) or "<root>"
                    print(f"  - {path}: {e.message}")
            else:
                with out_path.open("w", encoding="utf-8") as f:
                    yaml.safe_dump(record, f, sort_keys=False, allow_unicode=True)
                print(f"[WRITE] {scenario:<9} -> {out_path}")
        else:
            with out_path.open("w", encoding="utf-8") as f:
                yaml.safe_dump(record, f, sort_keys=False, allow_unicode=True)
            print(f"[WRITE] {scenario:<9} -> {out_path}")

    print("[DONE] Species transformation complete.")


if __name__ == "__main__":
    main()


