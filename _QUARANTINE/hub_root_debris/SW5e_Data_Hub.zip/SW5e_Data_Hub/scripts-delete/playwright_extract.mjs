import { chromium } from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import http from 'node:http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROOT = path.resolve(__dirname, '..');
const PDF_DIR = path.join(ROOT, 'data', 'pdf');
const OUT_DIR = path.join(ROOT, 'data', 'clean_source');

function getContentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  switch (ext) {
    case '.html': return 'text/html; charset=utf-8';
    case '.js': return 'application/javascript; charset=utf-8';
    case '.css': return 'text/css; charset=utf-8';
    case '.map': return 'application/json; charset=utf-8';
    case '.pdf': return 'application/pdf';
    case '.png': return 'image/png';
    case '.jpg': case '.jpeg': return 'image/jpeg';
    case '.svg': return 'image/svg+xml';
    case '.json': return 'application/json; charset=utf-8';
    default: return 'application/octet-stream';
  }
}

function createStaticServer(port) {
  return new Promise((resolve, reject) => {
    const server = http.createServer(async (req, res) => {
      try {
        const urlPath = decodeURIComponent((req.url || '').split('?')[0]);
        let fsPath;
        if (urlPath.startsWith('/node_modules/')) {
          fsPath = path.join(ROOT, urlPath);
        } else if (urlPath.startsWith('/data/pdf/')) {
          fsPath = path.join(ROOT, urlPath);
        } else {
          res.statusCode = 404;
          res.end('Not Found');
          return;
        }
        const data = await fs.readFile(fsPath);
        res.setHeader('Content-Type', getContentType(fsPath));
        res.statusCode = 200;
        res.end(data);
      } catch (e) {
        res.statusCode = 404;
        res.end('Not Found');
      }
    });
    server.on('error', reject);
    server.listen(port, () => resolve(server));
  });
}

async function main() {
  const targetArg = process.argv[2];
  const targetPdf = targetArg ? path.resolve(ROOT, targetArg) : path.join(PDF_DIR, 'AoR_Beta.pdf');
  await fs.mkdir(OUT_DIR, { recursive: true });
  try { await fs.stat(targetPdf); } catch { console.error('PDF not found:', targetPdf); process.exit(1); }

  const port = 43219;
  const server = await createStaticServer(port);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  const pdfUrl = `/data/pdf/${path.basename(targetPdf)}`;
  const html = `<!doctype html>
  <meta charset="utf-8" />
  <script type="module">
    const { getDocument } = await import('/node_modules/pdfjs-dist/build/pdf.mjs');
    const url = ${JSON.stringify(pdfUrl)};
    const pdf = await getDocument(url).promise;
    function normalize(s){return s.replace(/\\s+/g,' ').trim();}
    function itemsToLines(items){
      const arr = items.map(it=>{ const t = it.transform; return { text: it.str||'', x: t[4], y: t[5] }; }).filter(it=>it.text.trim().length>0);
      arr.sort((a,b)=> (a.y-b.y) || (a.x-b.x));
      const yTol=2; const groups=[];
      for (const it of arr){ const last=groups[groups.length-1]; if(!last || Math.abs(it.y-last.y)>yTol) groups.push({y:it.y, items:[it]}); else last.items.push(it); }
      const lines = groups.map(g=>{ g.items.sort((a,b)=>a.x-b.x); return { y:g.y, xMin:g.items[0].x, text: normalize(g.items.map(i=>i.text).join(' ')) }; }).filter(l=>l.text.length>0);
      const xs=[...new Set(lines.map(l=>l.xMin))].sort((a,b)=>a-b); let maxGap=0, splitAt=null; for(let i=1;i<xs.length;i++){const gap=xs[i]-xs[i-1]; if(gap>maxGap){maxGap=gap; splitAt=(xs[i]+xs[i-1])/2;}}
      let ordered=[]; if(splitAt&&maxGap>100){const left=lines.filter(l=>l.xMin<=splitAt).sort((a,b)=>a.y-b.y); const right=lines.filter(l=>l.xMin>splitAt).sort((a,b)=>a.y-b.y); ordered=[...left,...right];} else {ordered=lines.sort((a,b)=>a.y-b.y);} 
      const out=[]; let para=''; for(const ln of ordered){const t=ln.text; if(!para){para=t; continue;} if(/\\w-$/.test(para)) para=para.slice(0,-1)+t; else if(/^[a-z\\d(\\[\"'–-]/.test(t) && /[a-zA-Z]$/.test(para)) para=para+' '+t; else {out.push(para); para=t;}} if(para) out.push(para);
      return out.join('\n');
    }
    let all='';
    for(let p=1;p<=pdf.numPages;p++){
      const page = await pdf.getPage(p);
      const content = await page.getTextContent();
      all += '===== PAGE ' + p + ' / ' + pdf.numPages + ' =====\n' + itemsToLines(content.items) + '\n';
    }
    window.__extracted = all;
  </script>`;

  await page.setContent(html, { waitUntil: 'load' });
  await page.waitForFunction('window.__extracted !== undefined', null, { timeout: 120000 });
  const allText = await page.evaluate('window.__extracted');

  const outPath = path.join(OUT_DIR, path.basename(targetPdf, path.extname(targetPdf)) + '.txt');
  await fs.writeFile(outPath, allText, 'utf8');
  console.log('Wrote', path.relative(ROOT, outPath));

  await browser.close();
  server.close();
}

main().catch((e)=>{console.error(e); process.exit(1);});
