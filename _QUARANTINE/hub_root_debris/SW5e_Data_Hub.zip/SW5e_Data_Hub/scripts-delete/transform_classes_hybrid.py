"""
transform_classes_hybrid.py

Extracts class data from unstructured.io JSON outputs (SW5e + FFG) and
emits unified Class YAMLs following the Hybrid Protocol:
  - SW5e provides the d20 chassis (hit die, proficiencies, skills)
  - FFG informs narrative resources/talents mapping (future work hooks)
  - Output features a unified progression_tree with early core nodes and
    a subclass choice at level 3

This first pass targets core/GM_Kit classes via an allowlist and uses
conservative heuristics to populate fields. It prioritizes correctness
of structure over completeness of content.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional

import yaml

try:
    from jsonschema import Draft7Validator  # type: ignore
except Exception:  # noqa: BLE001
    Draft7Validator = None


def slugify(value: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9\s'\-]", "", value).strip().lower()
    text = text.replace("'", "").replace(" ", "_").replace("-", "_")
    return re.sub(r"_+", "_", text)


def read_elements(dir_path: Path) -> List[dict]:
    elements: List[dict] = []
    for jf in sorted(dir_path.glob("*.json")):
        try:
            data = json.loads(jf.read_text(encoding="utf-8"))
            if isinstance(data, list):
                for el in data:
                    el.setdefault("_origin_file", str(jf))
                elements.extend(data)
        except Exception:
            continue
    return elements


def slice_block(elements: List[dict], start_idx: int) -> List[dict]:
    block: List[dict] = []
    for i in range(start_idx, len(elements)):
        el = elements[i]
        if i > start_idx and el.get("type") in {"Title", "Header", "SectionHeader"}:
            break
        block.append(el)
    return block


def block_text(block: List[dict]) -> str:
    return "\n".join((e.get("text") or "") for e in block)


def extract_hit_die(text: str) -> Optional[str]:
    m = re.search(r"hit\s*die\s*[:\-]?\s*(d\d+)", text, flags=re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"(d\d+)\s*hit\s*die", text, flags=re.IGNORECASE)
    if m:
        return m.group(1)
    return None


def extract_section_list(text: str, label: str) -> List[str]:
    # Attempts to capture a colon-delimited list after a label (e.g., Weapons: ...)
    m = re.search(rf"{re.escape(label)}\s*[:\-]\s*(.+)", text, re.IGNORECASE)
    if not m:
        return []
    raw = m.group(1).split("\n")[0]
    parts = re.split(r",|;|\band\b", raw, flags=re.IGNORECASE)
    return [p.strip().rstrip(".") for p in parts if p.strip()]


def extract_skills(text: str, fallback_choose: int) -> Dict[str, object]:
    # Parse a skills list; try to find choose count
    choose = fallback_choose
    m = re.search(r"skills?\s*[:\-]?.*?choose\s*(\d)", text, flags=re.IGNORECASE | re.DOTALL)
    if m:
        try:
            choose = int(m.group(1))
        except Exception:
            pass
    # Pull candidates after a 'from' list or a bullet section 
    after = re.search(r"skills?\s*[:\-]?\s*(.+)$", text, flags=re.IGNORECASE | re.MULTILINE)
    candidates: List[str] = []
    if after:
        tail = after.group(1)
        parts = re.split(r",|;|\n|\band\b", tail, flags=re.IGNORECASE)
        for p in parts:
            token = p.strip().rstrip(".")
            if token and len(token) <= 30 and token[0].isupper():
                candidates.append(token)
    # Deduplicate and filter obvious non-skill words
    bad = {"choose", "from", "and"}
    uniq = []
    for c in candidates:
        low = c.lower()
        if low in bad:
            continue
        if c not in uniq:
            uniq.append(c)
    return {"choose": choose, "from": uniq[:20]}


def default_progression_for_class(class_id: str) -> List[Dict[str, object]]:
    cid = class_id
    if cid == "fighter":
        return [
            {"node_id": "fighter_start", "feature_id": "feat_fighting_style", "level_requirement": 1, "type": "choice", "prerequisites": []},
            {"node_id": "fighter_second_wind", "feature_id": "feat_second_wind", "level_requirement": 1, "type": "core", "prerequisites": []},
            {"node_id": "fighter_action_surge", "feature_id": "feat_action_surge", "level_requirement": 2, "type": "core", "prerequisites": ["fighter_start"]},
            {"node_id": "choice_assault_specialist", "feature_id": "subclass_assault_entry", "level_requirement": 3, "type": "subclass_entry", "prerequisites": ["fighter_action_surge"], "choice_group": "fighter_subclass_choice"},
            {"node_id": "choice_shield_specialist", "feature_id": "subclass_shield_entry", "level_requirement": 3, "type": "subclass_entry", "prerequisites": ["fighter_action_surge"], "choice_group": "fighter_subclass_choice"},
        ]
    if cid == "consular":
        return [
            {"node_id": "consular_start", "feature_id": "feat_forcecasting", "level_requirement": 1, "type": "core", "prerequisites": []},
            {"node_id": "consular_force_empowerment", "feature_id": "feat_force_empowerment", "level_requirement": 1, "type": "core", "prerequisites": []},
            {"node_id": "consular_force_recovery", "feature_id": "feat_force_recovery", "level_requirement": 2, "type": "core", "prerequisites": ["consular_start"]},
            {"node_id": "choice_way_of_the_sage", "feature_id": "subclass_sage_entry", "level_requirement": 3, "type": "subclass_entry", "prerequisites": ["consular_force_recovery"], "choice_group": "consular_subclass_choice"},
            {"node_id": "choice_way_of_the_negator", "feature_id": "subclass_negator_entry", "level_requirement": 3, "type": "subclass_entry", "prerequisites": ["consular_force_recovery"], "choice_group": "consular_subclass_choice"},
        ]
    if cid == "operative":
        return [
            {"node_id": "operative_start", "feature_id": "feat_expertise", "level_requirement": 1, "type": "choice", "prerequisites": []},
            {"node_id": "operative_sneak_attack", "feature_id": "feat_sneak_attack", "level_requirement": 1, "type": "core", "prerequisites": []},
            {"node_id": "operative_cunning_action", "feature_id": "feat_cunning_action", "level_requirement": 2, "type": "core", "prerequisites": ["operative_start"]},
            {"node_id": "choice_lethal_striker", "feature_id": "subclass_lethal_striker_entry", "level_requirement": 3, "type": "subclass_entry", "prerequisites": ["operative_cunning_action"], "choice_group": "operative_subclass_choice"},
            {"node_id": "choice_saboteur", "feature_id": "subclass_saboteur_entry", "level_requirement": 3, "type": "subclass_entry", "prerequisites": ["operative_cunning_action"], "choice_group": "operative_subclass_choice"},
        ]
    # Generic fallback
    return [
        {"node_id": f"{cid}_start", "feature_id": f"feat_{cid}_core_1", "level_requirement": 1, "type": "core", "prerequisites": []},
        {"node_id": f"choice_{cid}_subclass_a", "feature_id": f"subclass_{cid}_entry_a", "level_requirement": 3, "type": "subclass_entry", "prerequisites": [f"{cid}_start"], "choice_group": f"{cid}_subclass_choice"},
        {"node_id": f"choice_{cid}_subclass_b", "feature_id": f"subclass_{cid}_entry_b", "level_requirement": 3, "type": "subclass_entry", "prerequisites": [f"{cid}_start"], "choice_group": f"{cid}_subclass_choice"},
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description="Hybridize class data from SW5e/FFG unstructured JSON into YAML.")
    parser.add_argument("--sw5e-dir", required=True)
    parser.add_argument("--ffg-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--schema", default=None)
    parser.add_argument("--allowlist", default=None, help="YAML or text file with class names to include")
    args = parser.parse_args()

    sw5e_dir = Path(args.sw5e_dir)
    ffg_dir = Path(args.ffg_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    sw5e = read_elements(sw5e_dir)
    ffg = read_elements(ffg_dir)
    elements = sw5e + ffg  # For now, parse across both; SW5e likely carries chassis

    # Load allowlist (names)
    names: List[str] = []
    if args.allowlist:
        ap = Path(args.allowlist)
        if ap.exists():
            try:
                if ap.suffix.lower() in {".yml", ".yaml"}:
                    data = yaml.safe_load(ap.read_text(encoding="utf-8"))
                    if isinstance(data, list):
                        names = [str(x) for x in data]
                else:
                    names = [ln.strip() for ln in ap.read_text(encoding="utf-8").splitlines() if ln.strip()]
            except Exception:
                pass
    allow_ids = {slugify(n) for n in names} if names else set()

    # Build blocks keyed by slug
    blocks: Dict[str, List[dict]] = {}
    for idx, el in enumerate(elements):
        if el.get("type") not in {"Title", "Header", "SectionHeader"}:
            continue
        title = (el.get("text") or "").strip()
        class_id = slugify(title)
        if allow_ids and class_id not in allow_ids:
            continue
        blk = slice_block(elements, idx)
        # Require "Hit Die" or Proficiencies keywords to confirm it's a class
        txt = block_text(blk)
        if not re.search(r"hit\s*die|proficiencies|saving\s*throws|skills", txt, flags=re.IGNORECASE):
            continue
        blocks[class_id] = blk

    # Schema validation (optional)
    validator = None
    if args.schema and Path(args.schema).exists():
        try:
            schema = json.loads(Path(args.schema).read_text(encoding="utf-8"))
            if Draft7Validator is not None:
                validator = Draft7Validator(schema)
        except Exception:
            validator = None

    # Per-class fallback choose counts if not found
    default_skill_choose = {"fighter": 2, "consular": 2, "operative": 4}

    for class_id, blk in blocks.items():
        title = (blk[0].get("text") or class_id).strip()
        txt = block_text(blk)

        hit_die = extract_hit_die(txt) or ("d10" if class_id == "fighter" else "d6" if class_id == "consular" else "d8")
        armor = extract_section_list(txt, "Armor")
        weapons = extract_section_list(txt, "Weapons")
        tools = extract_section_list(txt, "Tools")
        saving_throws = extract_section_list(txt, "Saving Throws")
        skills = extract_skills(txt, fallback_choose=default_skill_choose.get(class_id, 2))

        record: Dict[str, object] = {
            "id": class_id,
            "name": title if title and title.isalpha() else title.title(),
            "description": "",  # description extraction TBD; set manually or via curated text
            "hit_die": hit_die,
            "proficiencies": {
                **({"armor": armor} if armor else {}),
                **({"weapons": weapons} if weapons else {}),
                **({"tools": tools} if tools else {}),
                **({"saving_throws": saving_throws} if saving_throws else {}),
                "skills": skills,
            },
            "primary_ability": "",
            "primary_resource": "",
            "progression_tree": default_progression_for_class(class_id),
        }

        out_path = out_dir / f"{class_id}.yml"
        if validator is not None:
            try:
                errs = sorted(validator.iter_errors(record), key=lambda e: e.path)
                if errs:
                    # Write anyway for review, but note validation in console
                    for e in errs[:5]:
                        pass
            except Exception:
                pass
        out_path.write_text(yaml.safe_dump(record, sort_keys=False, allow_unicode=True), encoding="utf-8")

    print(f"[DONE] Wrote {len(blocks)} classes to {out_dir}")


if __name__ == "__main__":
    main()


