# Name: Austin Fordham
# Course: IT-140
# Date: 12/10/2025
# Assignment: Project Two - TextBasedGame.py

import random
import string

def show_instructions():
    """
    Displays the game's main menu and commands.
    """
    print("---------------------------------------------------------")
    print("           STAR WARS: ESCAPE THE DESTROYER")
    print("---------------------------------------------------------")
    print("Mission: You are a Rebel spy stranded on an Imperial Star Destroyer.")
    print("Find all 6 ship components to repair your transport and escape.")
    print("WARNING: The Inquisitor is hunting you! They move every 3 turns.")
    print("---------------------------------------------------------")
    print("Commands:")
    print("  Move: go [North, South, East, West]")
    print("  Get Item: get [Item Name]")
    print("  Exit: exit")
    print("---------------------------------------------------------")

def format_input(text):
    """
    Helper to properly capitalize input, handling apostrophes correctly.
    """
    return string.capwords(text, sep=None)

def show_map(current_room, boss_room, inventory):
    """
    Prints the custom ASCII map of the ship.
    X = Player, !! = Boss
    """
    print("\n--- TACTICAL DISPLAY ---")
    
    # Define a helper to get the content for each room slot
    # It returns " X " if player is there, "!!" if boss, "X!!" if both, or "   " if empty.
    def get_content(room_name):
        content = "   "
        if room_name == current_room and room_name == boss_room:
            content = "X!!" # Collision!
        elif room_name == current_room:
            content = " X "
        elif room_name == boss_room:
            content = " !!"
        return content

    # Map the room names to variables for cleaner f-string usage
    # Note: Using short variable names based on your map layout
    # ENG, LNG, ARM
    # COM, HGR, BRG
    # CRW, CRG
    
    # We map the specific room names from our dictionary to these visual slots
    r_eng = get_content('Engineering')
    r_arm = get_content('Armory')
    r_com = get_content('Comms Array')
    r_hgr = get_content('Main Hangar')
    r_brg = get_content('Bridge')
    r_lng = get_content('Officer\'s Lounge')
    r_crw = get_content('Crew Quarters')
    r_crg = get_content('Cargo Hold')

    # The Map String
    print(f"+-------------------------------------------------------------------------+")
    print(f"|                     +------------+     +-------------+                  |")
    print(f"|                     | {r_eng}        | ___ | {r_arm}         |                  |")
    print(f"|                     |    ENG     | ___ |     ARM     |                  |")
    print(f"|                     +------------+     +-------------+                  |")
    print(f"|                         |   |               |   |                       |")
    print(f"|                         |   |               |   |                       |")
    print(f"|                      +----------+      +-------------+                  |")
    print(f"|                      | {r_hgr}      | ___  | {r_lng}         |                  |")
    print(f"|    +-----------+     |    HGR   | ___  |     LNG     |                  |")
    print(f"|    | {r_com}       | ___ |          |      +-------------+                  |")
    print(f"|    |    COM    | ___ |          |           |   |                       |")
    print(f"|    |           |     |          |           |   |                       |")
    print(f"|    +-----------+     |          |      +-------------+                  |")
    print(f"|                      |          |      | {r_brg}         |                  |")
    print(f"|                      |          |      |     BRG     |                  |")
    print(f"|                      +----------+      +-------------+                  |")
    print(f"|                         |   |               |   |                       |")
    print(f"|                         |   |               |   |                       |")
    print(f"|                     +------------+     +-------------+                  |")
    print(f"|                     | {r_crw}        | ___ | {r_crg}         |                  |")
    print(f"|                     |    CRW     | ___ |     CRG     |                  |")
    print(f"|                     +------------+     +-------------+                  |")
    print(f"+-------------------------------------------------------------------------+")
    print("------------------------\n")

def show_status(current_room, inventory, rooms, boss_room):
    """
    Displays the player's current status, including room, inventory, and visible items.
    """
    show_map(current_room, boss_room, inventory)
    
    print(f"You are in the {current_room}")
    print(f"Inventory: {inventory}")
    
    if "item" in rooms[current_room]:
        print(f"You see a {rooms[current_room]['item']}")
    print("---------------------------")

def move_boss(boss_room, rooms):
    """
    Moves the boss to an adjacent room.
    """
    possible_moves = []
    # Boss logic: get valid connected rooms
    for direction, room in rooms[boss_room].items():
        if direction not in ['item']:
            possible_moves.append(room)
    
    if possible_moves:
        return random.choice(possible_moves)
    return boss_room

def main():
    """
    Main gameplay function containing the game loop and logic.
    """
    # 1. Setup Data Structures (Using layout matching your visual map)
    # Based on your ASCII art connections:
    # Hangar (Center) connects to: 
    #   - Comms (West)
    #   - Engineering (North)
    #   - Crew Quarters (South)
    #   - Officer's Lounge (East, based on the line going right)
    #
    # Engineering (Top Left) connects to:
    #   - Hangar (South)
    #   - Armory (East, based on the line going right)
    #
    # Armory (Top Right) connects to:
    #   - Engineering (West)
    #   - Officer's Lounge (South)
    #
    # Officer's Lounge (Middle Right) connects to:
    #   - Hangar (West)
    #   - Armory (North)
    #   - Bridge (South)
    #
    # Bridge (Middle/Lower Right) connects to:
    #   - Officer's Lounge (North)
    #   - Cargo Hold (South)
    #
    # Crew Quarters (Bottom Left) connects to:
    #   - Hangar (North)
    #   - Cargo Hold (East)
    #
    # Cargo Hold (Bottom Right) connects to:
    #   - Crew Quarters (West)
    #   - Bridge (North)

    rooms = {
        'Main Hangar': {
            'North': 'Engineering', 
            'South': 'Crew Quarters', 
            'East': 'Officer\'s Lounge', 
            'West': 'Comms Array'
        },
        'Engineering': {
            'South': 'Main Hangar', 
            'East': 'Armory', 
            'item': 'Hyperdrive Motivator'
        },
        'Armory': {
            'West': 'Engineering', 
            'South': 'Officer\'s Lounge',
            'item': 'Blaster'
        },
        'Comms Array': {
            'East': 'Main Hangar', 
            'item': 'Comlink'
        },
        'Officer\'s Lounge': {
            'West': 'Main Hangar',
            'North': 'Armory', 
            'South': 'Bridge', 
            'item': 'Navigational Charts'
        },
        'Bridge': {
            'North': 'Officer\'s Lounge',
            'South': 'Cargo Hold',
            'item': 'The Inquisitor' 
        },
        'Crew Quarters': {
            'North': 'Main Hangar', 
            'East': 'Cargo Hold', 
            'item': 'Ration Pack'
        },
        'Cargo Hold': {
            'West': 'Crew Quarters', 
            'North': 'Bridge',
            'item': 'Hydrospanner'
        }
    }

    # Initialize Game State
    current_room = 'Main Hangar'
    boss_room = 'Bridge' 
    inventory = []
    turn_counter = 0
    
    show_instructions()

    # 2. Gameplay Loop
    while True:
        show_status(current_room, inventory, rooms, boss_room)
        
        # Win/Loss Condition Check
        if current_room == boss_room:
            # If you walk into the boss (or they walk into you)
            if len(inventory) == 6:
                print("\n*** BATTLE STATIONS! ***")
                print("You confront the Inquisitor with all ship components!")
                print("You blast the door controls and escape to the Hangar.")
                print("YOU WIN! The galaxy is safe (for now).")
                break
            else:
                print("\n*** AMBUSH! ***")
                print("The Inquisitor steps out of the shadows.")
                print("You are missing parts needed to escape.")
                print("GAME OVER.")
                break
        
        # Get Input
        user_input = input("Enter your move: ").split()
        
        # Basic Validation
        if len(user_input) < 2:
            if len(user_input) == 1 and user_input[0].lower() == 'exit':
                print("Exiting game.")
                break
            print("Invalid command. Please use 'go [Direction]' or 'get [Item]'.")
            continue

        action = user_input[0].lower()
        target_raw = " ".join(user_input[1:]) # Keep raw string
        
        # Use capwords to fix "officer's lounge" bug
        target = string.capwords(target_raw) 
        
        # Move Logic
        if action == 'go':
            
            if target in rooms[current_room]:
                current_room = rooms[current_room][target]
                
                # Boss Move Logic (Every 3 turns)
                turn_counter += 1
                if turn_counter % 3 == 0:
                    print("\n*** SENSOR ALERT: The Inquisitor is moving... ***")
                    boss_room = move_boss(boss_room, rooms)
            else:
                print(f"You can't go {target} from here.")

        # Get Item Logic
        elif action == 'get':
            if "item" in rooms[current_room]:
                room_item = rooms[current_room]["item"]
                
                # Comparison should be case-insensitive for better UX
                if target_raw.lower() == room_item.lower():
                    if room_item in inventory:
                        print(f"You already have the {room_item}.")
                    else:
                        print(f"{room_item} retrieved!")
                        inventory.append(room_item)
                        del rooms[current_room]["item"]
                        
                        # Boss moves on turns where you pick stuff up too?
                        turn_counter += 1
                        if turn_counter % 3 == 0:
                            print("\n*** SENSOR ALERT: The Inquisitor is moving... ***")
                            boss_room = move_boss(boss_room, rooms)
                else:
                    print(f"There is no '{target_raw}' here.")
            else:
                print("There is nothing to get here.")
        else:
            print("Invalid command.")

if __name__ == "__main__":
    main()