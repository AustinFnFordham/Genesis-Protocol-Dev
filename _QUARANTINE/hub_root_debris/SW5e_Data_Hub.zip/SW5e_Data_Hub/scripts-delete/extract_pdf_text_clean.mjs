import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROOT = path.resolve(__dirname, '..');
const PDF_DIR = path.join(ROOT, 'data', 'pdf');
const OUT_DIR = path.join(ROOT, 'data', 'clean_source');

function replaceLigatures(s) {
	return s
		.replace(/\uFB00/g, 'ff')
		.replace(/\uFB01/g, 'fi')
		.replace(/\uFB02/g, 'fl')
		.replace(/\uFB03/g, 'ffi')
		.replace(/\uFB04/g, 'ffl');
}

function stripOddChars(s) {
	return s
		.replace(/[\u00AD\u200B\u200C\u200D]/g, '')
		.replace(/[\u2022\u00B7]/g, '')
		.replace(/\uFFFD/g, '')
		.replace(/[\u0092\u0093\u0094]/g, "'");
}

function normalizeQuotesAndDashes(s) {
	return s
		.replace(/[\u2018\u2019\u201A\u201B]/g, "'")
		.replace(/[\u201C\u201D\u201E\u201F]/g, '"')
		.replace(/[\u2013\u2014\u2212]/g, '-')
		.replace(/\s*([,.;:!?])\s*/g, '$1 ');
}

function commonOcrFixes(s) {
	return s
		// frequent 'the' glitches (J/U/T + l/1/I + e)
		.replace(/\b[JU Tju t][l1I]e\b/g, 'the')
		.replace(/\b[Jj]he\b/g, 'The')
		.replace(/\btl1e\b/gi, 'the')
		.replace(/\bt[l1]e\b/gi, 'the')
		.replace(/\btil\s*e\b/gi, 'the')
		.replace(/\bU[l1]emselves\b/g, 'themselves')
		// words in this excerpt
		.replace(/\bliding\b/gi, 'hiding')
		.replace(/\baffmity\b/gi, 'affinity')
		.replace(/\bremarning\b/gi, 'remaining')
		.replace(/\bdissrdents\b/gi, 'dissidents')
		.replace(/\bmemaid\b/gi, 'members')
		.replace(/\bAl\s*liance\b/gi, 'Alliance')
		.replace(/\bAliance\b/g, 'Alliance')
		.replace(/\bcomm it\b/gi, 'commit')
		.replace(/\bman power\b/gi, 'manpower')
		.replace(/\bAcE oF REBELLION\b/gi, 'AGE OF REBELLION');
}

function normalizeWhitespace(s) {
	return s
		.replace(/\s+/g, ' ')
		.replace(/\s*\n\s*/g, '\n')
		.replace(/\s{2,}/g, ' ')
		.trim();
}

function removeDuplicateHeadings(line) {
	return line.replace(/\b([A-Z][A-Z\s]+)\b\s+\1\b/g, '$1');
}

function mergeHyphenBreak(prev, current) {
	if (/\w-$/.test(prev)) {
		return prev.slice(0, -1) + current.replace(/^\s+/, '');
	}
	return `${prev} ${current}`;
}

function groupItemsIntoLines(textItems, yTolerance = 2) {
	const items = textItems
		.map((it) => ({ str: it.str || '', x: it.transform[4], y: it.transform[5] }))
		.filter((it) => it.str && it.str.trim().length > 0);
	items.sort((a, b) => (b.y - a.y) || (a.x - b.x));

	const lines = [];
	let currentY = null;
	let current = [];
	for (const it of items) {
		if (currentY === null || Math.abs(it.y - currentY) <= yTolerance) {
			current.push(it);
			currentY = currentY === null ? it.y : (currentY + it.y) / 2;
		} else {
			current.sort((a, b) => a.x - b.x);
			const text = current.map((i) => i.str).join(' ');
			lines.push({ y: currentY, xMin: current[0].x, text });
			current = [it];
			currentY = it.y;
		}
	}
	if (current.length) {
		current.sort((a, b) => a.x - b.x);
		lines.push({ y: currentY, xMin: current[0].x, text: current.map((i) => i.str).join(' ') });
	}
	return lines;
}

function segmentColumns(lines) {
	// Determine if there are two columns based on xMin gaps
	const xMins = lines.map((l) => l.xMin).sort((a, b) => a - b);
	let maxGap = 0;
	let splitAt = null;
	for (let i = 1; i < xMins.length; i++) {
		const gap = xMins[i] - xMins[i - 1];
		if (gap > maxGap) {
			maxGap = gap;
			splitAt = (xMins[i] + xMins[i - 1]) / 2;
		}
	}
	// Heuristic threshold for gap; adjust as needed for page width
	if (maxGap > 100 && splitAt != null) {
		const left = lines.filter((l) => l.xMin <= splitAt).sort((a, b) => b.y - a.y);
		const right = lines.filter((l) => l.xMin > splitAt).sort((a, b) => b.y - a.y);
		return [left, right];
	}
	return [lines.sort((a, b) => b.y - a.y)];
}

function isAllCapsHeading(line) {
	const t = line.trim();
	if (t.length < 3) return false;
	const letters = t.replace(/[^A-Za-z]/g, '');
	return letters.length >= 3 && letters === letters.toUpperCase();
}

function joinIfWordSplit(prev, line) {
	const m = line.match(/^([a-z]{1,3})\b(.*)$/);
	if (/[a-z]$/.test(prev) && m) {
		return prev + m[1] + m[2];
	}
	return `${prev} ${line}`;
}

function reflowParagraphs(lines) {
	const out = [];
	let para = '';
	for (const raw of lines) {
		const line = raw.trim();
		if (line.length === 0) continue;
		if (isAllCapsHeading(line)) {
			if (para) { out.push(para.trim()); para = ''; }
			out.push(line);
			continue;
		}
		if (!para) {
			para = line;
			continue;
		}
		const prev = para;
		if (/([.!?]\)?)"?$/.test(prev)) {
			out.push(prev);
			para = line;
		} else if (/\w-$/.test(prev)) {
			para = mergeHyphenBreak(prev, line);
		} else if (/^ing\b/.test(line) && /[A-Za-z]$/.test(prev)) {
			// previous line likely cut mid-verb (e.g., "suffer" + "ing")
			para = prev + line;
		} else if (/^[a-z\d(\["'–-]/.test(line)) {
			para = joinIfWordSplit(prev, line);
		} else {
			out.push(prev);
			para = line;
		}
	}
	if (para) out.push(para.trim());
	return out;
}

function postProcessLine(s) {
	let t = s;
	t = replaceLigatures(t);
	t = stripOddChars(t);
	t = normalizeQuotesAndDashes(t);
	t = commonOcrFixes(t);
	t = removeDuplicateHeadings(t);
	t = normalizeWhitespace(t);
	return t;
}

async function extractCleanTextFromPdf(filePath) {
	const data = new Uint8Array(await fs.readFile(filePath));
	const pdfDocument = await pdfjsLib.getDocument({ data }).promise;
	const out = [];
	for (let pageNumber = 1; pageNumber <= pdfDocument.numPages; pageNumber++) {
		const page = await pdfDocument.getPage(pageNumber);
		const textContent = await page.getTextContent();
		const rawLines = groupItemsIntoLines(textContent.items);
		const columns = segmentColumns(rawLines);
		const pageLines = [];
		for (const col of columns) {
			for (const ln of col) {
				pageLines.push(ln.text);
			}
		}
		let lines = pageLines.map(postProcessLine).filter((l) => l.length > 0);
		lines = reflowParagraphs(lines);
		out.push(`===== PAGE ${pageNumber} / ${pdfDocument.numPages} =====`);
		out.push(...lines);
	}
	return out.join('\n');
}

async function main() {
	await fs.mkdir(OUT_DIR, { recursive: true });
	const files = (await fs.readdir(PDF_DIR, { withFileTypes: true }))
		.filter((e) => e.isFile() && e.name.toLowerCase().endsWith('.pdf'))
		.map((e) => path.join(PDF_DIR, e.name));
	if (files.length === 0) {
		console.log('No PDFs found.');
		return;
	}
	for (const pdfPath of files) {
		try {
			const txt = await extractCleanTextFromPdf(pdfPath);
			const base = path.basename(pdfPath, path.extname(pdfPath));
			const outPath = path.join(OUT_DIR, `${base}.txt`);
			await fs.writeFile(outPath, txt, 'utf8');
			console.log(`Wrote ${path.relative(ROOT, outPath)}`);
		} catch (err) {
			console.error('Failed', path.basename(pdfPath), err?.message || err);
		}
	}
}

main().catch((e) => {
	console.error('Fatal', e);
	process.exit(1);
});
