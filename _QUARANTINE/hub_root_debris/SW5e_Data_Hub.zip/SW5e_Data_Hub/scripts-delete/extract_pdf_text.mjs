import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROOT = path.resolve(__dirname, '..');
const PDF_DIR = path.join(ROOT, 'data', 'pdf');
const OUT_DIR = path.join(ROOT, 'data', 'raw_source');

async function ensureDirectoriesExist() {
	await fs.mkdir(PDF_DIR, { recursive: true });
	await fs.mkdir(OUT_DIR, { recursive: true });
}

async function listPdfFiles(directoryPath) {
	const entries = await fs.readdir(directoryPath, { withFileTypes: true });
	return entries
		.filter((entry) => entry.isFile() && entry.name.toLowerCase().endsWith('.pdf'))
		.map((entry) => path.join(directoryPath, entry.name));
}

async function readPdfAsUint8Array(filePath) {
	const buffer = await fs.readFile(filePath);
	return new Uint8Array(buffer);
}

function textContentToString(textContent) {
	// Combine text items; respect simple line breaks if hinted
	return textContent.items
		.map((item) => (item.str || ''))
		.join(' ')
		.replace(/[\t\u00A0]+/g, ' ');
}

async function extractTextFromPdf(filePath) {
	const data = await readPdfAsUint8Array(filePath);
	const pdfDocument = await pdfjsLib.getDocument({ data }).promise;
	let combined = '';

	for (let pageNumber = 1; pageNumber <= pdfDocument.numPages; pageNumber++) {
		const page = await pdfDocument.getPage(pageNumber);
		const textContent = await page.getTextContent();
		const pageText = textContentToString(textContent);
		combined += `\n\n===== PAGE ${pageNumber} / ${pdfDocument.numPages} =====\n\n`;
		combined += pageText + '\n';
	}

	return combined.trim();
}

async function writeTextOutputForPdf(pdfPath, text) {
	const baseName = path.basename(pdfPath, path.extname(pdfPath));
	const outPath = path.join(OUT_DIR, `${baseName}.txt`);
	await fs.writeFile(outPath, text, 'utf8');
	return outPath;
}

async function main() {
	await ensureDirectoriesExist();
	const pdfFiles = await listPdfFiles(PDF_DIR);
	if (pdfFiles.length === 0) {
		console.log(`No PDFs found in ${PDF_DIR}. Drop files there and re-run: npm run extract-pdf-text`);
		return;
	}

	console.log(`Found ${pdfFiles.length} PDF(s). Extracting text...`);
	for (const pdfPath of pdfFiles) {
		try {
			console.log(`- Processing: ${path.basename(pdfPath)}`);
			const text = await extractTextFromPdf(pdfPath);
			const outPath = await writeTextOutputForPdf(pdfPath, text);
			console.log(`  -> Wrote: ${path.relative(ROOT, outPath)}`);
		} catch (error) {
			console.error(`  !! Failed: ${path.basename(pdfPath)} ->`, error?.message || error);
		}
	}
	console.log('Done.');
}

main().catch((error) => {
	console.error('Fatal error:', error);
	process.exit(1);
});
