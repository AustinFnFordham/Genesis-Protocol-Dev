import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import Ajv from 'ajv';
import YAML from 'yaml';
import { globSync } from 'glob';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROOT = path.resolve(__dirname, '..');
const SPECIES_DIR = path.join(ROOT, 'data', 'species');
const SCHEMA_PATH = path.join(ROOT, 'schema', 'Species.schema.json');

function normalizeAbilityName(name) {
	const map = {
		str: 'Strength', strength: 'Strength',
		dex: 'Dexterity', dexterity: 'Dexterity',
		con: 'Constitution', constitution: 'Constitution',
		int: 'Intelligence', intelligence: 'Intelligence',
		wis: 'Wisdom', wisdom: 'Wisdom',
		cha: 'Charisma', charisma: 'Charisma',
		choice: 'Choice'
	};
	return map[String(name || '').toLowerCase()] || name;
}

function coerceToArray(value) {
	if (value == null) return [];
	return Array.isArray(value) ? value : [value];
}

function coerceInteger(value, fallback = 0) {
	if (typeof value === 'number' && Number.isInteger(value)) return value;
	const n = Number.parseInt(value, 10);
	return Number.isFinite(n) ? n : fallback;
}

function guessSize(value) {
	const s = String(value || '').toLowerCase();
	if (['tiny','small','medium','large'].includes(s)) return s[0].toUpperCase() + s.slice(1);
	return 'Medium';
}

function ensureTraitShape(trait) {
	const fixed = { ...trait };
	if (!fixed.name) fixed.name = 'Placeholder Trait';
	if (fixed.level == null) fixed.level = 1;
	if (!fixed.description) fixed.description = 'TBD.';
	if (!Array.isArray(fixed.effects)) fixed.effects = [];
	return fixed;
}

async function loadSchema() {
	const schemaRaw = await fs.readFile(SCHEMA_PATH, 'utf8');
	const schema = JSON.parse(schemaRaw);
	// Stub unresolved $ref in traits to a permissive object so Ajv can compile
	if (schema?.properties?.traits?.items?.$ref) {
		schema.properties.traits.items = { type: 'object', additionalProperties: true };
	}
	return schema;
}

async function loadYaml(filePath) {
	const raw = await fs.readFile(filePath, 'utf8');
	return YAML.parse(raw);
}

async function saveYaml(filePath, data) {
	const doc = new YAML.Document();
	doc.contents = data;
	await fs.writeFile(filePath, String(doc), 'utf8');
}

function applyFixes(species) {
	const fixed = { ...species };
	if (!fixed.id && fixed.name) {
		fixed.id = fixed.name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
	}
	if (!fixed.name && fixed.id) {
		fixed.name = fixed.id.replace(/_/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase());
	}
	if (!fixed.description) fixed.description = 'TBD.';

	fixed.narrative_tags = coerceToArray(fixed.narrative_tags).map(String);

	fixed.starting_xp = coerceInteger(fixed.starting_xp, 100);

	fixed.ability_score_increases = coerceToArray(fixed.ability_score_increases).map((asi) => {
		if (!asi) return { ability: 'Choice', value: 1 };
		return {
			ability: normalizeAbilityName(asi.ability) || 'Choice',
			value: coerceInteger(asi.value, 1),
		};
	});
	if (fixed.ability_score_increases.length === 0) {
		fixed.ability_score_increases = [
			{ ability: 'Choice', value: 2 },
			{ ability: 'Choice', value: 1 },
		];
	}

	fixed.speed = coerceInteger(fixed.speed, 30);
	fixed.size = guessSize(fixed.size);
	fixed.languages = coerceToArray(fixed.languages).map(String);
	if (fixed.languages.length === 0) fixed.languages = ['Basic'];

	fixed.base_hp = coerceInteger(fixed.base_hp, 10);
	fixed.base_strain = coerceInteger(fixed.base_strain, 10);

	fixed.traits = coerceToArray(fixed.traits).map(ensureTraitShape);
	if (fixed.traits.length === 0) {
		fixed.traits = [ensureTraitShape({ name: 'Placeholder Trait' })];
	}

	return fixed;
}

async function main() {
	const schema = await loadSchema();
	const ajv = new Ajv({ allErrors: true, removeAdditional: false, useDefaults: false, coerceTypes: false });
	const validate = ajv.compile(schema);

	const files = globSync(path.join(SPECIES_DIR, '*.yml').replace(/\\/g, '/'));
	let fixedCount = 0;
	let stillInvalid = 0;
	for (const file of files) {
		let data = await loadYaml(file);
		let valid = validate(data);
		if (!valid) {
			data = applyFixes(data);
			valid = validate(data);
			if (valid) {
				await saveYaml(file, data);
				fixedCount += 1;
			} else {
				stillInvalid += 1;
				console.warn(`Invalid after fixes: ${path.basename(file)} ->`, validate.errors);
			}
		}
	}
	console.log(`Validation complete. Fixed: ${fixedCount}, Remaining invalid: ${stillInvalid}.`);
}

main().catch((err) => {
	console.error(err);
	process.exit(1);
});
