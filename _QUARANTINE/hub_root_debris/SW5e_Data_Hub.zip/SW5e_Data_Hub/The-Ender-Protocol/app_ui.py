import streamlit as st
import boto3
import json
from datetime import datetime

st.set_page_config(page_title="The Ender Protocol", page_icon="⚔️", layout="wide")

lambda_client = boto3.client('lambda', region_name='us-east-1')

# Initialize session state
if 'log' not in st.session_state:
    st.session_state.log = []
if 'session_id' not in st.session_state:
    st.session_state.session_id = None
if 'choices' not in st.session_state:
    st.session_state.choices = []

# Theme selection
with st.sidebar:
    theme_choice = st.selectbox(
        "Select Theme",
        ["Star Wars", "Cybersecurity"],
        index=0
    )

# Load theme
theme_file = "themes/star_wars_theme.json" if theme_choice == "Star Wars" else "themes/cyber_theme.json"
with open(theme_file, 'r') as f:
    theme = json.load(f)

st.title(f"⚔️ {theme['title']}")
st.markdown("*AI Training Platform: Red Team vs Blue Team*")

st.divider()

# Start new game button
if st.button(f"🎯 {theme['start_button_label']}", type="primary", disabled=st.session_state.session_id is not None):
    st.session_state.log = [f"🚀 {theme['status_messages']['sim_started']}"]
    st.session_state.log.append(f"\n{theme['status_messages']['red_team_turn']}")
    st.session_state.session_id = f'ui-game-{datetime.now().strftime("%Y%m%d-%H%M%S")}'
    
    payload = {'scenario_id': 'scenario_01_bruteforce', 'session_id': st.session_state.session_id}
    
    with st.spinner('Running Red Team turn...'):
        try:
            response = lambda_client.invoke(
                FunctionName='ender-protocol-supervisor-mock',
                InvocationType='RequestResponse',
                Payload=json.dumps(payload)
            )
            
            result = json.loads(response['Payload'].read().decode('utf-8'))
            game_data = json.loads(result['body'])
            
            game_state = game_data['game_state']
            red_action = game_state['red_team']['last_action']
            
            st.session_state.log.append(f"\n🔴 RED TEAM: {red_action['message']}")
            if red_action.get('success'):
                st.session_state.log.append(f"   ⚠️ Access Level: {red_action.get('access_level', 'unknown')}")
            
            st.session_state.choices = game_data.get('choices', [])
            st.rerun()
            
        except Exception as e:
            st.session_state.log.append(f"\n❌ Error: {str(e)}")
            st.session_state.session_id = None
            st.rerun()

# Display player choices
if st.session_state.choices:
    st.subheader(f"🛡️ {theme['status_messages']['player_turn']}")
    
    for choice in st.session_state.choices:
        action_label = theme['actions'].get(choice['action_id'], choice['label'])
        if st.button(action_label, key=choice['action_id']):
            st.session_state.log.append(f"\n🔵 YOU: {choice['label']}")
            
            payload = {
                'session_id': st.session_state.session_id,
                'player_action': choice['action_id']
            }
            
            with st.spinner('Executing action...'):
                try:
                    response = lambda_client.invoke(
                        FunctionName='ender-protocol-supervisor-mock',
                        InvocationType='RequestResponse',
                        Payload=json.dumps(payload)
                    )
                    
                    result = json.loads(response['Payload'].read().decode('utf-8'))
                    game_data = json.loads(result['body'])
                    
                    game_state = game_data['game_state']
                    
                    # Blue Team result
                    blue_action = game_state['blue_team']['last_action']
                    st.session_state.log.append(f"   {blue_action['message']}")
                    
                    # Red Team next turn
                    red_action = game_state['red_team']['last_action']
                    st.session_state.log.append(f"\n🔴 RED TEAM: {red_action['message']}")
                    if red_action.get('success'):
                        st.session_state.log.append(f"   ⚠️ Access Level: {red_action.get('access_level', 'unknown')}")
                    
                    st.session_state.log.append(f"\n✅ Turn {game_state['turn']} completed")
                    
                    # Check for game end
                    if game_state['status'] != 'active':
                        if game_state['status'] == 'blue_team_victory':
                            st.session_state.log.append(f"\n\n🏆 VICTORY! {game_state.get('end_message', 'Blue Team wins!')}")
                        else:
                            st.session_state.log.append(f"\n\n☠️ DEFEAT! {game_state.get('end_message', 'Red Team wins!')}")
                        st.session_state.choices = []
                    else:
                        st.session_state.choices = game_data.get('choices', [])
                    
                    st.rerun()
                    
                except Exception as e:
                    st.session_state.log.append(f"\n❌ Error: {str(e)}")
                    st.rerun()

# Reset button
if st.session_state.session_id:
    if st.button("🔄 Reset Game"):
        st.session_state.session_id = None
        st.session_state.choices = []
        st.session_state.log = []
        st.rerun()

st.subheader(f"📜 {theme['log_title']}")

if 'log' in st.session_state and st.session_state.log:
    log_text = "\n".join(st.session_state.log)
    st.text_area("Game Log Output", value=log_text, height=400, disabled=True, label_visibility="collapsed")
else:
    st.info("Click the button above to start a scenario.")
