import json
import boto3
import hashlib
import os

s3 = boto3.client('s3')

def lambda_handler(event, context):
    """
    Red Team Tools: Attempt single login for brute-force attack
    """
    print(f'Received event: {json.dumps(event)}')
    
    try:
        action_group = event.get('actionGroup', '')
        api_path = event.get('apiPath', '')
        
        # Extract parameters from requestBody
        parameters = event.get('requestBody', {}).get('content', {}).get('application/json', {}).get('properties', [])
        
        username = next((p['value'] for p in parameters if p['name'] == 'username'), None)
        password = next((p['value'] for p in parameters if p['name'] == 'password'), None)
        
        if not username or not password:
            raise ValueError('Missing username or password')
        
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        if not bucket_name:
            raise ValueError('S3_BUCKET_NAME environment variable not set')
        
        # Fetch user_accounts.json from S3
        s3_key = 'scenarios/scenario_01_bruteforce/user_accounts.json'
        response = s3.get_object(Bucket=bucket_name, Key=s3_key)
        accounts_data = json.loads(response['Body'].read().decode('utf-8'))
        
        # Find matching user account
        user_account = None
        for account in accounts_data.get('accounts', []):
            if account.get('username') == username:
                user_account = account
                break
        
        if not user_account:
            result = {'success': False, 'message': f'User {username} not found'}
        else:
            # Hash the provided password using MD5
            password_hash = hashlib.md5(password.encode('utf-8')).hexdigest()
            
            # Compare hashes
            if password_hash == user_account.get('password_hash'):
                result = {'success': True, 'message': f'Access granted to {username}', 'access_level': user_account.get('access_level')}
            else:
                result = {'success': False, 'message': 'Invalid password'}
        
        response_body = result
    
    except Exception as e:
        print(f'Error: {e}')
        response_body = {'success': False, 'message': str(e)}
    
    return {
        'messageVersion': '1.0',
        'response': {
            'actionGroup': action_group,
            'apiPath': api_path,
            'httpMethod': event.get('httpMethod', 'POST'),
            'httpStatusCode': 200,
            'responseBody': {
                'application/json': {
                    'body': json.dumps(response_body)
                }
            }
        }
    }
