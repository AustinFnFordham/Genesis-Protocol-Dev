import json
import boto3
import os
from datetime import datetime

s3 = boto3.client('s3')
lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    """
    Supervisor Agent: Mock version that calls Lambda functions directly
    """
    try:
        # Check if this is a player action or new game
        if 'player_action' in event:
            return handle_player_action(event)
        
        scenario_id = event.get('scenario_id', 'scenario_01_bruteforce')
        session_id = event.get('session_id', f'session-{datetime.now().timestamp()}')
        
        print(f'Starting game for scenario: {scenario_id}, session: {session_id}')
        
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        
        # Load scenario data
        accounts_key = f'scenarios/{scenario_id}/user_accounts.json'
        accounts_response = s3.get_object(Bucket=bucket_name, Key=accounts_key)
        accounts_data = json.loads(accounts_response['Body'].read().decode('utf-8'))
        
        passwords_key = f'scenarios/{scenario_id}/password_dictionary.json'
        passwords_response = s3.get_object(Bucket=bucket_name, Key=passwords_key)
        passwords_data = json.loads(passwords_response['Body'].read().decode('utf-8'))
        
        game_state = {
            'scenario_id': scenario_id,
            'session_id': session_id,
            'turn': 1,
            'status': 'active',
            'red_team': {'attempts': 0, 'successes': 0, 'failed_attempts': []},
            'blue_team': {'detections': 0, 'blocks': 0},
            'target_accounts': [acc['username'] for acc in accounts_data.get('accounts', [])],
            'available_passwords': passwords_data.get('passwords', [])
        }
        
        print(f'Game state initialized: {json.dumps(game_state)}')
        
        # === RED TEAM TURN (Direct Lambda call) ===
        print('Starting Red Team turn...')
        
        red_payload = {
            'actionGroup': 'red-team-tools',
            'apiPath': '/brute-force',
            'httpMethod': 'POST',
            'requestBody': {
                'content': {
                    'application/json': {
                        'properties': [
                            {'name': 'username', 'value': 'admin'},
                            {'name': 'password', 'value': 'password123'}
                        ]
                    }
                }
            }
        }
        
        red_response = lambda_client.invoke(
            FunctionName='ender-protocol-red-team-tools',
            InvocationType='RequestResponse',
            Payload=json.dumps(red_payload)
        )
        
        red_result = json.loads(red_response['Payload'].read().decode('utf-8'))
        red_body = json.loads(red_result['response']['responseBody']['application/json']['body'])
        
        print(f'Red Team result: {json.dumps(red_body)}')
        
        game_state['red_team']['attempts'] += 1
        game_state['red_team']['last_action'] = red_body
        
        # === BLUE TEAM TURN (Direct Lambda call) ===
        print('Starting Blue Team turn...')
        
        threat_report = {
            'type': 'brute_force_attack_success' if red_body.get('success') else 'brute_force_attack_attempt',
            'details': red_body.get('message', ''),
            'raw_data': red_body
        }
        
        blue_payload = {
            'actionGroup': 'blue-team-tools',
            'apiPath': '/block-ip',
            'httpMethod': 'POST',
            'requestBody': {
                'content': {
                    'application/json': {
                        'properties': [
                            {'name': 'scenario_id', 'value': scenario_id},
                            {'name': 'ip_address', 'value': '192.168.1.50'}
                        ]
                    }
                }
            }
        }
        
        blue_response = lambda_client.invoke(
            FunctionName='ender-protocol-blue-team-tools',
            InvocationType='RequestResponse',
            Payload=json.dumps(blue_payload)
        )
        
        blue_result = json.loads(blue_response['Payload'].read().decode('utf-8'))
        blue_body = json.loads(blue_result['response']['responseBody']['application/json']['body'])
        
        print(f'Blue Team result: {json.dumps(blue_body)}')
        
        game_state['blue_team']['last_action'] = blue_body
        game_state['turn'] += 1
        game_state['last_updated'] = datetime.now().isoformat()
        
        # Save game state
        state_key = f'game_sessions/{session_id}/state.json'
        s3.put_object(
            Bucket=bucket_name,
            Key=state_key,
            Body=json.dumps(game_state, indent=2),
            ContentType='application/json'
        )
        
        print(f'Game state saved to {state_key}')
        
        # Generate player choices
        choices = [
            {'action_id': 'block_ip', 'label': '🛡️ Block Attacker IP'},
            {'action_id': 'monitor', 'label': '🔍 Monitor and Gather Intel'},
            {'action_id': 'lockdown', 'label': '🔒 Lockdown All Accounts'}
        ]
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'game_state': game_state,
                'threat_report': threat_report,
                'choices': choices,
                'message': 'Turn completed successfully (mock mode)'
            })
        }
        
    except Exception as e:
        print(f'Error: {str(e)}')
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def handle_player_action(event):
    """
    Handle player's chosen action and run next Red Team turn
    """
    try:
        session_id = event['session_id']
        player_action = event['player_action']
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        
        print(f'Handling player action: {player_action} for session: {session_id}')
        
        # Load game state
        state_key = f'game_sessions/{session_id}/state.json'
        response = s3.get_object(Bucket=bucket_name, Key=state_key)
        game_state = json.loads(response['Body'].read().decode('utf-8'))
        
        # Execute player's chosen action
        if player_action == 'block_ip':
            blue_payload = {
                'actionGroup': 'blue-team-tools',
                'apiPath': '/block-ip',
                'httpMethod': 'POST',
                'requestBody': {
                    'content': {
                        'application/json': {
                            'properties': [
                                {'name': 'scenario_id', 'value': game_state['scenario_id']},
                                {'name': 'ip_address', 'value': '192.168.1.50'}
                            ]
                        }
                    }
                }
            }
        elif player_action == 'monitor':
            blue_payload = None
            game_state['blue_team']['last_action'] = {'status': 'monitoring', 'message': 'Monitoring attacker activity'}
        elif player_action == 'lockdown':
            blue_payload = None
            game_state['blue_team']['last_action'] = {'status': 'lockdown', 'message': 'All accounts locked down'}
        
        # Execute Blue Team action if needed
        if blue_payload:
            blue_response = lambda_client.invoke(
                FunctionName='ender-protocol-blue-team-tools',
                InvocationType='RequestResponse',
                Payload=json.dumps(blue_payload)
            )
            blue_result = json.loads(blue_response['Payload'].read().decode('utf-8'))
            blue_body = json.loads(blue_result['response']['responseBody']['application/json']['body'])
            game_state['blue_team']['last_action'] = blue_body
        
        # Run Red Team next turn
        red_payload = {
            'actionGroup': 'red-team-tools',
            'apiPath': '/brute-force',
            'httpMethod': 'POST',
            'requestBody': {
                'content': {
                    'application/json': {
                        'properties': [
                            {'name': 'username', 'value': 'jsmith'},
                            {'name': 'password', 'value': '123456'}
                        ]
                    }
                }
            }
        }
        
        red_response = lambda_client.invoke(
            FunctionName='ender-protocol-red-team-tools',
            InvocationType='RequestResponse',
            Payload=json.dumps(red_payload)
        )
        
        red_result = json.loads(red_response['Payload'].read().decode('utf-8'))
        red_body = json.loads(red_result['response']['responseBody']['application/json']['body'])
        
        game_state['red_team']['attempts'] += 1
        game_state['red_team']['last_action'] = red_body
        
        # Track successes
        if red_body.get('success'):
            game_state['red_team']['successes'] += 1
        
        game_state['turn'] += 1
        game_state['last_updated'] = datetime.now().isoformat()
        
        # Check win/loss conditions
        if game_state['red_team']['successes'] >= 3:
            game_state['status'] = 'red_team_victory'
            game_state['end_message'] = 'Red Team has compromised multiple accounts. System breached!'
        elif game_state['turn'] >= 10:
            game_state['status'] = 'blue_team_victory'
            game_state['end_message'] = 'Blue Team successfully defended the system for 10 turns!'
        
        # Save updated state
        s3.put_object(
            Bucket=bucket_name,
            Key=state_key,
            Body=json.dumps(game_state, indent=2),
            ContentType='application/json'
        )
        
        # Generate new choices (only if game is still active)
        if game_state['status'] == 'active':
            choices = [
                {'action_id': 'block_ip', 'label': '🛡️ Block Attacker IP'},
                {'action_id': 'monitor', 'label': '🔍 Monitor and Gather Intel'},
                {'action_id': 'lockdown', 'label': '🔒 Lockdown All Accounts'}
            ]
        else:
            choices = []
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'game_state': game_state,
                'choices': choices,
                'message': 'Player action executed'
            })
        }
        
    except Exception as e:
        print(f'Error handling player action: {str(e)}')
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
