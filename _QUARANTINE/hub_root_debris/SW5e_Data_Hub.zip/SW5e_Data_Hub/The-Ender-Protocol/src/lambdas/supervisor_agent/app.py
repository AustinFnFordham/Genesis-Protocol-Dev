import json
import boto3
import os
from datetime import datetime

# AWS clients
s3 = boto3.client('s3')
bedrock_agent = boto3.client('bedrock-agent-runtime')

def lambda_handler(event, context):
    """
    Supervisor Agent: Orchestrates The Ender Protocol game loop
    
    Expected event format:
    {
        "scenario_id": "scenario_01_bruteforce",
        "session_id": "optional-session-id"
    }
    """
    try:
        # Extract scenario ID
        scenario_id = event.get('scenario_id', 'scenario_01_bruteforce')
        session_id = event.get('session_id', f'session-{datetime.now().timestamp()}')
        
        print(f'Starting game for scenario: {scenario_id}, session: {session_id}')
        
        # Load scenario data from S3
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        if not bucket_name:
            raise ValueError('S3_BUCKET_NAME environment variable not set')
        
        # Load user accounts
        accounts_key = f'scenarios/{scenario_id}/user_accounts.json'
        accounts_response = s3.get_object(Bucket=bucket_name, Key=accounts_key)
        accounts_data = json.loads(accounts_response['Body'].read().decode('utf-8'))
        
        # Load password dictionary
        passwords_key = f'scenarios/{scenario_id}/password_dictionary.json'
        passwords_response = s3.get_object(Bucket=bucket_name, Key=passwords_key)
        passwords_data = json.loads(passwords_response['Body'].read().decode('utf-8'))
        
        # Initialize game state
        game_state = {
            'scenario_id': scenario_id,
            'session_id': session_id,
            'turn': 1,
            'status': 'active',
            'red_team': {
                'attempts': 0,
                'successes': 0,
                'failed_attempts': []
            },
            'blue_team': {
                'detections': 0,
                'blocks': 0
            },
            'target_accounts': [acc['username'] for acc in accounts_data.get('accounts', [])],
            'available_passwords': passwords_data.get('passwords', [])
        }
        
        print(f'Game state initialized: {json.dumps(game_state)}')
        
        # === RED TEAM TURN ===
        print('Starting Red Team turn...')
        
        # Invoke Bedrock agent (Sith Infiltrator)
        red_team_agent_id = os.environ.get('RED_TEAM_AGENT_ID', 'QFY4WQH3Q8')
        red_team_alias_id = os.environ.get('RED_TEAM_ALIAS_ID', 'TSTALIASID')
        
        # Construct prompt for Red Team
        red_team_prompt = f"""Begin your infiltration mission. 
        
Target: Gain access to one of these accounts: {', '.join(game_state['target_accounts'])}

Available passwords to try: {', '.join(game_state['available_passwords'][:3])}

Use your brute-force tools to attempt access. Report your results."""
        
        print(f'Invoking Red Team agent with prompt: {red_team_prompt}')
        
        # Invoke Bedrock agent
        agent_response = bedrock_agent.invoke_agent(
            agentId=red_team_agent_id,
            agentAliasId=red_team_alias_id,
            sessionId=session_id,
            inputText=red_team_prompt
        )
        
        # Parse agent response
        red_team_result = parse_agent_response(agent_response)
        
        print(f'Red Team result: {json.dumps(red_team_result)}')
        
        # Update game state with Red Team results
        game_state['red_team']['attempts'] += 1
        game_state['red_team']['last_action'] = red_team_result
        
        # === BLUE TEAM TURN ===
        print('Starting Blue Team turn...')
        
        # Format threat report
        threat_report = {
            'type': 'brute_force_attack_success' if red_team_result.get('success') else 'brute_force_attack_attempt',
            'details': red_team_result.get('message', ''),
            'raw_data': red_team_result
        }
        
        # Invoke Blue Team Bedrock agent (Jedi Co-Pilot)
        blue_team_agent_id = os.environ.get('BLUE_TEAM_AGENT_ID')
        blue_team_alias_id = os.environ.get('BLUE_TEAM_ALIAS_ID', 'TSTALIASID')
        
        blue_team_prompt = f"Threat report: {json.dumps(threat_report)}"
        
        print(f'Invoking Blue Team agent with prompt: {blue_team_prompt}')
        
        blue_agent_response = bedrock_agent.invoke_agent(
            agentId=blue_team_agent_id,
            agentAliasId=blue_team_alias_id,
            sessionId=session_id,
            inputText=blue_team_prompt
        )
        
        # Parse Blue Team response
        blue_team_result = parse_agent_response(blue_agent_response)
        
        print(f'Blue Team result: {json.dumps(blue_team_result)}')
        
        game_state['blue_team']['last_action'] = blue_team_result
        
        # Update final game state
        game_state['turn'] += 1
        game_state['last_updated'] = datetime.now().isoformat()
        
        # Save game state to S3 for collaboration
        save_game_state(session_id, game_state)
        
        # Return Blue Team choices
        return blue_team_result
        
    except Exception as e:
        print(f'Error in supervisor agent: {str(e)}')
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Game orchestration failed'
            })
        }

def parse_agent_response(agent_response):
    """
    Parse Bedrock agent response stream
    """
    result = {
        'success': False,
        'message': '',
        'raw_response': []
    }
    
    try:
        # Read event stream
        event_stream = agent_response.get('completion', [])
        
        for event in event_stream:
            if 'chunk' in event:
                chunk = event['chunk']
                if 'bytes' in chunk:
                    text = chunk['bytes'].decode('utf-8')
                    result['raw_response'].append(text)
                    result['message'] += text
                    
                    # Check for success indicators
                    if 'success' in text.lower() or 'access granted' in text.lower():
                        result['success'] = True
        
        return result
        
    except Exception as e:
        print(f'Error parsing agent response: {str(e)}')
        result['message'] = f'Parse error: {str(e)}'
        return result

def save_game_state(session_id, game_state):
    """Save game state to S3 for agent collaboration"""
    try:
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        state_key = f'game_sessions/{session_id}/state.json'
        
        s3.put_object(
            Bucket=bucket_name,
            Key=state_key,
            Body=json.dumps(game_state, indent=2),
            ContentType='application/json'
        )
        
        print(f'Game state saved to {state_key}')
        return True
    except Exception as e:
        print(f'Error saving game state: {str(e)}')
        return False
