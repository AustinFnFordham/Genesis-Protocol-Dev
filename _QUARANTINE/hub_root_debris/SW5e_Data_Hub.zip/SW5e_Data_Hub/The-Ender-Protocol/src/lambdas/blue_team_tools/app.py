import json
import boto3
import os

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    """
    Blue Team Tools: Block malicious IP addresses
    """
    print(f'Received event: {json.dumps(event)}')
    
    try:
        action_group = event.get('actionGroup', '')
        api_path = event.get('apiPath', '')
        
        # Extract parameters from requestBody
        parameters = event.get('requestBody', {}).get('content', {}).get('application/json', {}).get('properties', [])
        
        scenario_id = next((p['value'] for p in parameters if p['name'] == 'scenario_id'), None)
        ip_address = next((p['value'] for p in parameters if p['name'] == 'ip_address'), None)
        
        if not scenario_id or not ip_address:
            raise ValueError('Missing scenario_id or ip_address')
        
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        file_key = f'scenarios/{scenario_id}/firewall_rules.json'
        
        # Get current firewall rules
        response = s3_client.get_object(Bucket=bucket_name, Key=file_key)
        firewall_rules = json.loads(response['Body'].read().decode('utf-8'))
        
        # Add IP to blocked list
        if ip_address not in firewall_rules['blocked_ips']:
            firewall_rules['blocked_ips'].append(ip_address)
        
        # Save updated rules
        s3_client.put_object(
            Bucket=bucket_name,
            Key=file_key,
            Body=json.dumps(firewall_rules)
        )
        
        response_body = {'status': 'success', 'message': f'IP {ip_address} blocked'}
    
    except Exception as e:
        print(f'Error: {e}')
        response_body = {'status': 'error', 'message': str(e)}
    
    return {
        'messageVersion': '1.0',
        'response': {
            'actionGroup': action_group,
            'apiPath': api_path,
            'httpMethod': event.get('httpMethod', 'POST'),
            'httpStatusCode': 200,
            'responseBody': {
                'application/json': {
                    'body': json.dumps(response_body)
                }
            }
        }
    }
