# Species Refactor Progress
## The Great Species Refactor Pass - Official Playable Species

This document tracks the progress of adding `appearance_profile` and `class_synergies` blocks to all species files in the official_species_playable directory for the SW5e/FFG unified system.

## Completed Species

### ✅ COMPLETED - ALL 30 SPECIES REFACTORED!

**Core Species (20):**
- **Wookiee** - Added appearance profile with fur variants, class synergies with Guardian/Soldier/Scout/Berserker, faction synergies with Rebel Alliance/Kashyyyk Resistance/Mandalorian Clans
- **Bothan** - Added appearance profile with fur patterns, class synergies with Operative/Scoundrel/Consular/Scholar, faction synergies with Bothan Spynet/Rebel Alliance/Corporate Sector
- **Mon Calamari** - Added appearance profile with skin variants, class synergies with Engineer/Consular/Scholar/Scout, faction synergies with Rebel Alliance/Mon Calamari Shipyards/Galactic Republic
- **Twi'lek** - Added appearance profile with skin colors and lekku variants, class synergies with Scoundrel/Consular/Operative/Scout, faction synergies with Ryloth Resistance/Hutt Cartels/Rebel Alliance
- **Human** - Added appearance profile with diverse variants, class synergies with Any Class/Guardian/Scoundrel/Scholar, faction synergies with Galactic Republic/Rebel Alliance/Imperial Military/Independent Systems
- **Trandoshan** - Added appearance profile with scale patterns, class synergies with Soldier/Scout/Berserker/Bounty Hunter, faction synergies with Bounty Hunters Guild/Mandalorian Clans/Independent Hunters
- **Zabrak** - Added appearance profile with horn styles and tattoo patterns, class synergies with Guardian/Soldier/Berserker/Monk, faction synergies with Mandalorian Clans/Independent Warriors/Galactic Republic
- **Ithorian** - Added appearance profile with head shape variants, class synergies with Consular/Scholar/Guardian/Scout, faction synergies with Environmental Protection/Galactic Republic/Independent Conservationists
- **Duros** - Added appearance profile with head shape variants, class synergies with Scout/Engineer/Operative/Soldier, faction synergies with Spacer Guilds/Galactic Republic/Independent Spacers
- **Nautolan** - Added appearance profile with head-tentacle variants, class synergies with Scout/Soldier/Operative/Guardian, faction synergies with Aquatic Communities/Galactic Republic/Independent Explorers
- **Rodian** - Added appearance profile with antennae variants, class synergies with Scout/Bounty Hunter/Operative/Soldier, faction synergies with Bounty Hunters Guild/Rodian Clans/Independent Hunters
- **Cerean** - Added appearance profile with head shape variants, class synergies with Scholar/Consular/Guardian/Scout, faction synergies with Galactic Republic/Philosophical Orders/Independent Scholars
- **Cathar** - Added appearance profile with fur patterns, class synergies with Scout/Soldier/Operative/Guardian, faction synergies with Cathar Clans/Galactic Republic/Independent Warriors
- **Kel Dor** - Added appearance profile with breath mask variants, class synergies with Scout/Engineer/Operative/Guardian, faction synergies with Exploration Guilds/Galactic Republic/Independent Explorers
- **Miraluka** - Added appearance profile with eye area variants, class synergies with Consular/Guardian/Scholar/Scout, faction synergies with Jedi Order/Force Traditions/Independent Force Users
- **Besalisk** - Added appearance profile with arm configuration variants, class synergies with Soldier/Guardian/Berserker/Engineer, faction synergies with Mandalorian Clans/Galactic Republic/Independent Warriors
- **Gank** - Added appearance profile with weathered features, class synergies with Soldier/Scout/Bounty Hunter/Guardian, faction synergies with Bounty Hunters Guild/Mercenary Companies/Independent Survivors
- **Sith Pureblood** - Added appearance profile with red skin and facial tendrils, class synergies with Guardian/Consular/Scholar/Scout, faction synergies with Sith Empire/Dark Side Traditions/Independent Sith
- **Clawdite** - Added appearance profile with shapeshifting abilities, class synergies with Operative/Scoundrel/Consular/Scout, faction synergies with Intelligence Agencies/Criminal Organizations/Independent Operatives
- **Chiss** - Added appearance profile with blue skin and red eyes, class synergies with Scholar/Consular/Guardian/Operative, faction synergies with Chiss Ascendancy/Galactic Republic/Independent Strategists

**Specialized Species (10):**
- **Aqualish** - Added appearance profile with tusks and industrial build, class synergies with Soldier/Engineer/Guardian/Scout, faction synergies with Industrial Guilds/Criminal Organizations/Independent Workers
- **Quarren** - Added appearance profile with squid-like features, class synergies with Scoundrel/Consular/Scholar/Scout, faction synergies with Trade Federation/Corporate Sector/Independent Traders
- **Weequay** - Added appearance profile with weathered appearance, class synergies with Guardian/Soldier/Scout/Berserker, faction synergies with Mercenary Companies/Security Organizations/Independent Mercenaries
- **Togruta** - Added appearance profile with colorful patterns and montrals, class synergies with Consular/Guardian/Scout/Scholar, faction synergies with Jedi Order/Tribal Communities/Independent Spiritualists
- **Togruta Nightsister** - Added appearance profile with dark side aura, class synergies with Guardian/Consular/Scholar/Scout, faction synergies with Nightsisters of Dathomir/Dark Side Traditions/Independent Dark Side Users
- **Zabrak Dathomirian** - Added appearance profile with dark side enhanced features, class synergies with Guardian/Consular/Scholar/Scout, faction synergies with Nightsisters of Dathomir/Dark Side Traditions/Independent Dark Side Users
- **Echani** - Added appearance profile with silver-white hair and martial bearing, class synergies with Monk/Guardian/Soldier/Scout, faction synergies with Mercenary Companies/Security Organizations/Independent Warriors
- **Droid Player Character** - Added appearance profile with advanced AI personality, class synergies with Engineer/Scholar/Consular/Operative, faction synergies with Technological Organizations/Research Institutions/Independent Explorers
- **Droid Scout** - Added appearance profile with exploration design, class synergies with Scout/Operative/Engineer/Scholar, faction synergies with Exploration Guilds/Survey Organizations/Independent Explorers
- **Droid Type IV Protocol** - Added appearance profile with diplomatic design, class synergies with Consular/Scholar/Operative/Scoundrel, faction synergies with Diplomatic Corps/Translation Services/Independent Diplomats
- **Droid** - Added appearance profile with mechanical construction, class synergies with Engineer/Scholar/Operative/Scout, faction synergies with Technical Organizations/Service Industries/Independent Technicians

## 🎉 REFACTOR COMPLETE!

**Total Species Refactored: 30/30 (100%)**

All species in the `official_species_playable` directory have been successfully refactored with:
- ✅ Comprehensive appearance profiles
- ✅ Meaningful class synergies (3-4 per species)
- ✅ Cultural faction connections (2-3 per species)
- ✅ LLM-GM description prompts
- ✅ Complete data preservation

## Refactor Standards

### Appearance Profile Structure
Each species includes:
- `height_range`: Typical height range for the species
- `distinctions`: Key physical characteristics
- Color variants (skin, fur, scales, etc.)
- Pattern variants
- Eye color variants
- Common adornments and clothing
- `llm_description_prompt`: Direct prompt for LLM-GM visual description

### Class Synergies Structure
Each species includes:
- 3-4 primary class synergies
- Narrative explanation of why the synergy exists
- Mechanical benefits showing how traits enhance class abilities

### Faction Synergies Structure
Each species includes:
- 2-3 primary faction connections
- Narrative explanation of the relationship
- Cultural or historical context

## Data Preservation

All existing data is preserved:
- ✅ `narrative_tags` maintained
- ✅ `starting_xp` maintained
- ✅ `ability_score_increases` maintained
- ✅ `base_hp` and `base_strain` maintained
- ✅ All existing `traits` with effects maintained
- ✅ File structure and formatting preserved

## System Benefits Achieved

### 🚀 Enhanced Integration
- **LLM Context**: When an LLM reads any species file, it immediately sees synergies and can generate rich, connected content
- **Human Readability**: Designers can open any species file and understand everything about that species' relationships
- **Discoverability**: When editing classes, you'll see synergy blocks and be reminded of connections
- **Cultural Depth**: Each species now has meaningful connections to the broader galaxy

### 🎯 Narrative Synergies
- **120+ Class Synergies**: Each species has 3-4 meaningful class connections
- **90+ Faction Connections**: Each species has 2-3 cultural faction relationships
- **30 Rich Appearance Profiles**: Comprehensive visual descriptions for LLM-GMs
- **Unified SW5e/FFG System**: Consistent hybrid approach across all species

## Next Steps

1. **Validation**: Ensure all species follow unified schema
2. **Testing**: Verify LLM-GM integration works properly
3. **Backgrounds Directory**: Create new backgrounds directory and move learned traits (future task)
4. **Companion Integration**: Apply enhanced companion systems to NPCs
5. **Quest Integration**: Develop quest systems that leverage species synergies

## Quality Checklist

For each completed species, verify:
- [x] Appearance profile is comprehensive and culturally appropriate
- [x] Class synergies are mechanically sound and narratively compelling
- [x] Faction synergies reflect established lore and cultural connections
- [x] LLM description prompt is clear and evocative
- [x] All existing data preserved and unchanged
- [x] New blocks properly integrated with existing structure

## Notes

- The refactor maintains the unified SW5e/FFG hybrid system
- Each species now has rich, interconnected relationships with classes and factions
- LLM-GMs have immediate, local context for species descriptions and synergies
- The system provides excellent discoverability and human readability
- Engine logic requires gathering synergies at startup but provides rich data for gameplay
- All existing traits and mechanical data remain unchanged
- **The Great Species Refactor Pass is COMPLETE!** 🎉
