# Phase 4: YAML Validation & Performance System

## 🎯 Overview

Phase 4 implements a comprehensive YAML validation and performance optimization system for the SW5e Data Hub. This system ensures data quality, consistency, and optimal performance across all YAML files in the project.

## 📋 System Components

### 1. YAML Validation Rules (`yaml_validation_rules.yml`)
- **Schema Validation**: Validates YAML files against JSON schemas
- **Cross-Reference Validation**: Ensures references between files are valid
- **Balance Validation**: Validates game balance and power levels
- **Error Reporting**: Comprehensive error categorization and suggestions

### 2. Performance Guidelines (`performance_guidelines.yml`)
- **File Size Optimization**: Guidelines for optimal file sizes
- **Loading Time Optimization**: Strategies for fast loading
- **Memory Usage Optimization**: Memory management techniques
- **Caching Strategies**: Multi-level caching implementation

### 3. Automated Testing (`automated_testing.yml`)
- **Test Categories**: Schema, cross-reference, balance, performance, integration
- **Test Configuration**: Execution modes and coverage requirements
- **CI/CD Integration**: GitHub Actions, GitLab CI, Jenkins support
- **Monitoring & Alerting**: Real-time monitoring and notifications

### 4. Main Validator Script (`scripts/yaml-validator.mjs`)
- **Comprehensive Validation**: Implements all validation rules
- **Parallel Processing**: Multi-threaded validation for performance
- **Multiple Output Formats**: JSON, YAML, text, HTML reports
- **CLI Interface**: Command-line tool with various options

## 🚀 Quick Start

### Installation
```bash
# Install dependencies
npm install

# Install additional dependencies for validation
npm install ajv-formats fs-extra
```

### Basic Usage
```bash
# Run standard validation
npm run validate-yaml

# Run strict validation
npm run validate-yaml:strict

# Run quick validation
npm run validate-yaml:quick

# Generate HTML report
npm run validate-yaml:html

# Generate text report
npm run validate-yaml:text
```

### Advanced Usage
```bash
# Custom validation with specific options
node scripts/yaml-validator.mjs --mode strict --output html --max-jobs 8

# Validate specific file patterns
node scripts/yaml-validator.mjs --mode standard --output json

# Performance-focused validation
node scripts/yaml-validator.mjs --mode performance --no-parallel
```

## 📊 Validation Modes

### 1. Strict Mode
- **Description**: All validations enabled, no warnings allowed
- **Use Case**: Production validation, CI/CD pipelines
- **Features**:
  - Schema validation (strict)
  - Cross-reference validation
  - Balance validation
  - Performance validation
  - Fails on any warnings

### 2. Standard Mode
- **Description**: Standard validation with warnings
- **Use Case**: Development validation, quality assurance
- **Features**:
  - Schema validation
  - Cross-reference validation
  - Balance validation
  - Performance validation
  - Allows warnings

### 3. Performance Mode
- **Description**: Performance-focused validation
- **Use Case**: Performance optimization, large datasets
- **Features**:
  - Schema validation
  - Performance validation
  - Skips cross-reference and balance validation
  - Optimized for speed

### 4. Quick Mode
- **Description**: Quick validation for development
- **Use Case**: Development workflow, rapid feedback
- **Features**:
  - Schema validation only
  - Fastest execution
  - Minimal resource usage

## 🔍 Validation Features

### Schema Validation
- Validates YAML files against JSON schemas
- Supports all SW5e data types (Species, Classes, Powers, Items, etc.)
- Strict mode prevents additional properties
- Detailed error reporting with suggestions

### Cross-Reference Validation
- Validates references between files
- Checks species, class, power, item, background, faction, starship references
- Detects orphaned and broken references
- Validates reference consistency

### Balance Validation
- Validates game balance and power levels
- Checks damage scaling by level
- Validates cost ranges and effectiveness
- Ensures prerequisite requirements are reasonable

### Performance Validation
- Validates file sizes against guidelines
- Checks line length and formatting
- Monitors memory usage
- Provides optimization suggestions

## 📈 Performance Optimization

### File Size Optimization
- **Target Sizes**:
  - Species files: 25KB
  - Class files: 150KB
  - Power files: 75KB
  - Item files: 100KB
  - Background files: 20KB
  - Faction files: 30KB
  - Starship files: 200KB
  - Mode files: 60KB
  - Synergy files: 80KB

### Loading Optimization
- **Loading Priorities**:
  - Critical: Species, Classes, Backgrounds
  - High: Powers, Items, Properties
  - Medium: Factions, Starships, Combat Rules
  - Low: Lore, Gameplay Examples, Campaign States

### Memory Optimization
- **Memory Limits**:
  - Maximum: 512MB
  - Warning threshold: 256MB
  - Target: 128MB
- **Strategies**:
  - Object pooling
  - Garbage collection
  - Weak references
  - Lazy loading

### Caching Strategies
- **Memory Cache**: Hot data (32MB, 5min TTL)
- **Disk Cache**: Warm data (64MB, 30min TTL)
- **Cold Cache**: Rare data (32MB, 1hr TTL)
- **Cache Policies**: By file type, access pattern, and size

## 🧪 Automated Testing

### Test Categories
1. **Schema Validation Tests**
   - Basic schema validation
   - Advanced schema validation
   - Version compatibility

2. **Cross-Reference Tests**
   - Reference existence
   - Reference consistency
   - Reference integrity

3. **Balance Tests**
   - Power level validation
   - Prerequisite validation
   - Synergy validation

4. **Performance Tests**
   - File size validation
   - Loading time validation
   - Memory usage validation

5. **Integration Tests**
   - System compatibility
   - API compatibility
   - Frontend compatibility

### Test Execution
- **Unit Tests**: Individual file tests (parallel)
- **Integration Tests**: System integration tests (sequential)
- **Performance Tests**: Performance validation (sequential)
- **Full Test Suite**: All tests (parallel)

### Coverage Requirements
- Schema validation: 100%
- Cross-reference: 95%
- Balance validation: 90%
- Performance validation: 85%
- Integration validation: 90%

## 📊 Reporting and Output

### Output Formats
1. **JSON**: Programmatic access, detailed results
2. **YAML**: Human-readable, detailed results
3. **Text**: Console output, summary only
4. **HTML**: Web display, interactive dashboard

### Report Content
- **Summary**: Overall statistics and metrics
- **Detailed Results**: Per-file validation results
- **Performance Metrics**: Execution time and memory usage
- **Recommendations**: Optimization suggestions
- **Coverage Report**: Test coverage information
- **Historical Comparison**: Trend analysis

### Report Structure
```
validation-results/
├── validation-report-1234567890.json
├── validation-report-1234567890.yml
├── validation-report-1234567890.txt
└── validation-report-1234567890.html
```

## 🔧 Configuration

### Validation Rules Configuration
```yaml
validation_system:
  core_rules:
    schema_validation:
      enabled: true
      strict_mode: true
      allow_additional_properties: false
    
    cross_reference_validation:
      enabled: true
      validate_references: true
      check_circular_references: true
    
    balance_validation:
      enabled: true
      validate_power_levels: true
      validate_cost_effectiveness: true
```

### Performance Guidelines Configuration
```yaml
performance_guidelines:
  file_size_optimization:
    general_guidelines:
      max_file_size_kb: 1024
      target_file_size_kb: 512
    
  loading_optimization:
    loading_priorities:
      critical: ["species", "classes", "backgrounds"]
      high: ["powers", "items", "properties"]
      medium: ["factions", "starships", "combat_rules"]
      low: ["lore", "gameplay_examples", "campaign_states"]
```

### Automated Testing Configuration
```yaml
automated_testing:
  test_configuration:
    execution:
      modes:
        unit:
          parallel_execution: true
          max_parallel_jobs: 8
          timeout_seconds: 30
        
        integration:
          parallel_execution: false
          max_parallel_jobs: 1
          timeout_seconds: 300
```

## 🚀 CI/CD Integration

### GitHub Actions
```yaml
name: YAML Validation
on: [push, pull_request]
jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm install
      - run: npm run validate-yaml:strict
```

### Pre-commit Hooks
```bash
#!/bin/sh
# .git/hooks/pre-commit
npm run validate-yaml:quick
```

### Quality Gates
- Schema validation pass rate: 100%
- Cross-reference pass rate: 95%
- Balance validation pass rate: 90%
- Performance validation pass rate: 85%
- Integration validation pass rate: 90%

## 📈 Monitoring and Alerting

### Metrics Collection
- Test execution time
- Test success rate
- Test coverage
- Test failure rate
- Test error rate

### Alert Conditions
- Critical failures: Immediate notification
- High failure rate (>10%): Immediate notification
- Low coverage (<80%): Daily notification
- Performance degradation (>20%): Weekly notification

### Alert Channels
- Email notifications
- Slack webhooks
- Custom webhooks
- Dashboard alerts

## 🛠️ Troubleshooting

### Common Issues
1. **Schema Validation Failures**
   - Check required fields are present
   - Verify data types are correct
   - Ensure no additional properties (in strict mode)

2. **Cross-Reference Errors**
   - Verify referenced files exist
   - Check reference field names match
   - Ensure reference values are correct

3. **Performance Issues**
   - Check file sizes against guidelines
   - Monitor memory usage
   - Review loading patterns

4. **Test Failures**
   - Check test data quality
   - Verify schema compatibility
   - Review test configuration

### Debugging
```bash
# Enable verbose logging
DEBUG=* node scripts/yaml-validator.mjs --mode standard

# Run with specific file
node scripts/yaml-validator.mjs --mode quick --files "species/*.yml"

# Generate detailed report
node scripts/yaml-validator.mjs --output html --mode strict
```

## 📚 Best Practices

### Development Workflow
1. Run quick validation before committing
2. Use standard validation for quality assurance
3. Run strict validation before releases
4. Monitor performance metrics regularly

### File Organization
- Keep related files in same directory
- Use consistent naming conventions
- Split large files into smaller ones
- Use descriptive file names

### Content Structure
- Use consistent field ordering
- Minimize nested structures
- Use references for duplicate data
- Keep descriptions concise

### Performance Optimization
- Monitor file sizes regularly
- Implement lazy loading for large datasets
- Use caching strategies effectively
- Profile memory usage

## 🔮 Future Enhancements

### Planned Features
1. **Advanced Schema Validation**
   - Custom validation rules
   - Conditional validation
   - Cross-field validation

2. **Performance Optimization**
   - Incremental validation
   - Smart caching
   - Background processing

3. **Integration Enhancements**
   - IDE integration
   - Real-time validation
   - Auto-fix suggestions

4. **Advanced Reporting**
   - Trend analysis
   - Predictive analytics
   - Custom dashboards

### Roadmap
- **Q1 2025**: Advanced schema validation
- **Q2 2025**: Performance optimization
- **Q3 2025**: Integration enhancements
- **Q4 2025**: Advanced reporting

## 📞 Support

### Documentation
- [Validation Rules Reference](yaml_validation_rules.yml)
- [Performance Guidelines](performance_guidelines.yml)
- [Automated Testing Guide](automated_testing.yml)

### Issues and Questions
- Check troubleshooting section
- Review configuration examples
- Run with debug logging
- Generate detailed reports

### Contributing
- Follow coding standards
- Add tests for new features
- Update documentation
- Review performance impact

---

**Phase 4: YAML Validation & Performance System** is now complete and ready for production use. This comprehensive system ensures data quality, consistency, and optimal performance across all SW5e Data Hub YAML files.
