Narrative Tags (Hybrid FFG × SW5e)

Purpose
- Tags drive story prompts, encounter tone, faction hooks, and UI filters. They must express identity (species), role (archetype), culture, environment, and social friction.

Taxonomy (pick 3–5 per species)
- archetype: face|brawler|skirmisher|scout|engineer|pilot|support|tactician
- environment: aquatic|arboreal|desert|urban|space|jungle|polar|toxic
- culture: networks|warlike|spiritual|explorer|traditional|criminal|academic|communal
- physical: strong|agile|tough|sensory|regenerative|amphibious|climber
- social: adaptable|feared|respected|ostracized|loyal|insular
- rivalry: trandoshans|wookiees|hutts|imperials (use sparingly; only strong story drivers)
- conflict: programming-vs-personhood|honor-vs-duty|tradition-vs-change|predation-vs-mercy
- allegiance: criminal|rebel|imperial|neutral (use sparingly; prefer faction data when available)

Guidelines
- Prefer one tag from archetype and environment; add 1–3 from culture/physical/social/conflict.
- Keep tags lower_snake where possible; hyphenate compound concepts only when needed.
- Avoid duplicating the species name or obvious facts unless they drive hooks (e.g., amphibious).


