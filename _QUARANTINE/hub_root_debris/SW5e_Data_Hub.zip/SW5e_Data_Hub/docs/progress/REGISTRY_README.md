# Species Registry Guide

## Overview
The `SPECIES_REGISTRY.yml` file serves as a comprehensive catalog and quick reference for all 30 playable species and variants in the SW5e/FFG hybrid system.

## Quick Navigation

### 🎯 **By Archetype (Character Role)**
- **Face**: Human, Twi'lek, Chiss, Cerean, Alderaanian Human, Droid Type IV Protocol, Togruta
- **Brawler**: Wookiee, Trandoshan, Gank, Besalisk, Aqualish
- **Skirmisher**: Zabrak, Cathar, Echani
- **Scout**: Bothan, Nautolan, Rodian, Clawdite, Lothal Human, Droid Scout
- **Pilot**: Duros, Corellian Human
- **Engineer**: Mon Calamari
- **Support**: Ithorian, Kel Dor, Chandrilan Human
- **Force User**: Sith Pureblood, Miraluka, Zabrak Dathomirian, Togruta Nightsister
- **Versatile**: Human, Droid Player Character
- **Merchant**: Quarren
- **Thug**: Weequay

### 🎨 **By Complexity**
- **Simple**: Human (1 species)
- **Medium**: Most species (26 species)
- **High**: Clawdite, Droid Player Character (2 species)

### 🌍 **By Environment**
- **Aquatic**: Mon Calamari, Ithorian, Nautolan, Quarren
- **Space**: Duros, Corellian Human
- **Urban**: Bothan, Alderaanian Human, Aqualish
- **Wilderness**: Lothal Human, Droid Scout
- **Rural**: Chandrilan Human
- **Cultured**: Alderaanian Human
- **Civilized**: Droid Type IV Protocol
- **Dark Side**: Zabrak Dathomirian, Togruta Nightsister
- **Universal**: Human
- **Varied**: Most species (adaptable to many environments)

### 🏷️ **By Special Tags**
- **Force Sensitive**: Sith Pureblood, Miraluka, Zabrak Dathomirian, Togruta Nightsister
- **Dark Side**: Sith Pureblood, Zabrak Dathomirian, Togruta Nightsister
- **Shapeshifter**: Clawdite
- **Aquatic**: Mon Calamari, Ithorian, Nautolan, Quarren
- **Mechanical**: Gank, Droid Type IV Protocol, Droid Scout, Droid Player Character
- **Four-Armed**: Besalisk
- **Near-Human**: Most species (18 total)
- **Player Favorites**: Chiss, Clawdite, Sith Pureblood, Gank, Besalisk

## Using the Registry

### For Character Creation
1. **Choose your archetype** (what role do you want to play?)
2. **Consider complexity** (new players might prefer simple/medium)
3. **Think about environment** (where will your character operate?)
4. **Check special tags** (any unique abilities you want?)

### For Game Masters
1. **Browse by environment** for setting-appropriate species
2. **Check complexity** to match player experience levels
3. **Use narrative tags** for story hooks and world-building
4. **Reference player favorites** for popular choices

### For Developers
1. **File paths** are included for easy programmatic access
2. **Metadata** tracks completion status and system info
3. **Indexes** provide multiple search methods
4. **Search tags** enable filtered queries

## Registry Structure

### Core Species (21 total)
- **Near-Human**: Human, Wookiee, Zabrak, Twi'lek, Bothan, Duros, Chiss, Sith Pureblood, Miraluka, Cathar, Cerean, Echani
- **Aquatic**: Mon Calamari, Ithorian, Nautolan
- **Warrior**: Trandoshan, Rodian
- **Unique**: Clawdite, Gank, Besalisk, Kel Dor

### Variants (9 total)
- **Cultural Variants**: Alderaanian, Corellian, Chandrilan, Lothal Humans
- **Role Variants**: Droid Type IV Protocol, Droid Scout
- **Advanced Variants**: Droid Player Character
- **Force-Sensitive Variants**: Zabrak Dathomirian, Togruta Nightsister

## Quick Reference Stats

| Category | Count | Examples |
|----------|-------|----------|
| **Total Species** | 34 | All playable options |
| **Core Species** | 25 | Base species without variants |
| **Variants** | 9 | Cultural, role, and special variants |
| **Force Sensitive** | 4 | Sith Pureblood, Miraluka, Zabrak Dathomirian, Togruta Nightsister |
| **Player Favorites** | 5 | Chiss, Clawdite, Sith Pureblood, Gank, Besalisk |
| **Simple Complexity** | 1 | Human |
| **High Complexity** | 2 | Clawdite, Droid Player Character |

## NPC Species (Essential for Galactic Population)

### **Galactic Mainstays (The "Cantina" Crowd)**
- **Bith** - Large-headed musicians and scientists, ideal for info-brokers
- **Ishi Tib** - Green-skinned amphibious beings, often in leadership roles

### **Syndicate & Fringe Staples (Jabba's Palace)**
- **Hutt** - The ultimate crime lords, essential for underworld campaigns
- **Nikto** - Classic species often found in Hutt employ
- **Gamorrean** - Iconic pig-like guards, perfect as simple melee minions

### **Antagonistic Forces**
- **Geonosian** - Insectoid builders of the Droid Army, great for hive-mind encounters
- **Tusken Raider** - Iconic denizens of Tatooine, perfect desert adversaries

### **Fan Favorites & Companions**
- **Jawa** - Scavengers and traders, excellent for companions or quest-givers
- **Ewok** - Fierce but small warriors, can be formidable allies or adversaries

## File Organization
- **Core species**: Individual YAML files in `/official_species_playable/`
- **Variants**: Individual YAML files in `/official_species_playable/`
- **Registry**: `SPECIES_REGISTRY.yml` (this catalog)
- **Documentation**: `README.md` (main species documentation)

## Updates
The registry is automatically updated when:
- New species are added
- Variants are created
- Species are modified
- Status changes occur

All **34 playable species** are now **complete** and ready for production use! 🎉

## 🎯 **Species Completion Summary**

### **Core Species (25 total) - ALL COMPLETE** ✅
- **Near-Human**: Human, Wookiee, Zabrak, Twi'lek, Bothan, Duros, Chiss, Sith Pureblood, Miraluka, Cathar, Cerean, Echani, **Togruta**, **Aqualish**, **Quarren**, **Weequay**
- **Aquatic**: Mon Calamari, Ithorian, Nautolan, **Quarren**
- **Warrior**: Trandoshan, Rodian
- **Unique**: Clawdite, Gank, Besalisk, Kel Dor

### **Variants (9 total) - ALL COMPLETE** ✅
- **Cultural Variants**: Alderaanian, Corellian, Chandrilan, Lothal Humans
- **Role Variants**: Droid Type IV Protocol, Droid Scout
- **Advanced Variants**: Droid Player Character
- **Force-Sensitive Variants**: Zabrak Dathomirian, Togruta Nightsister

### **NPC Species (8 total) - PLANNED** 📋
- **Galactic Mainstays**: Bith, Ishi Tib
- **Syndicate Staples**: Hutt, Nikto, Gamorrean
- **Antagonistic Forces**: Geonosian, Tusken Raider
- **Fan Favorites**: Jawa, Ewok

**The playable species system is now fully complete and ready for character creation!** 🌟
