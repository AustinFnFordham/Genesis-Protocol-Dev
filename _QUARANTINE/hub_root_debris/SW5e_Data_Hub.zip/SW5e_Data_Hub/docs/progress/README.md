# Official Playable Species

This directory contains the production-standard species files for the SW5e/FFG hybrid system.

## Current Status
All species have been standardized to contain **3+ innate traits** each, representing universal biological and cultural characteristics.

## Species Inventory
- **Human** (3 innate traits)
- **Wookiee** (3 innate traits) 
- **Zabrak** (3 innate traits)
- **Twi'lek** (3 innate traits)
- **Bothan** (3 innate traits)
- **Duros** (3 innate traits)
- **Mon Calamari** (3 innate traits)
- **Ithorian** (3 innate traits)
- **Trandoshan** (3 innate traits)
- **Rodian** (3 innate traits)
- **Nautolan** (3 innate traits)
- **Chiss** (3 innate traits)
- **Clawdite** (3 innate traits)
- **Sith Pureblood** (3 innate traits)
- **Gank** (3 innate traits)
- **Besalisk** (3 innate traits)
- **Miraluka** (3 innate traits)
- **Kel Dor** (3 innate traits)
- **Cathar** (3 innate traits)
- **Cerean** (3 innate traits)
- **Echani** (3 innate traits) - *NEW*

## Architecture
- **Nature vs. Nurture**: Species files contain only innate, universal traits
- **Backgrounds**: Learned/professional traits moved to `/data/backgrounds/`
- **Starship Backgrounds**: Space roles in `/data/starship_backgrounds/`
- **Trait Marketplace**: Optional traits available for customization at `/data/traits/`

## Character Creation Flow
1. Choose species (get innate traits)
2. Optionally select marketplace traits for customization
3. Choose ground background(s)
4. Optionally choose starship background

## Recent Additions
- **Chiss**: Tactical Genius, Chiss Resilience, Enhanced Vision
- **Clawdite**: Shapeshifting, Natural Infiltrator, Adaptive Physiology  
- **Sith Pureblood**: Dark Side Affinity, Sith Heritage, Force Sensitivity
- **Gank**: Natural Survivor, Combat Instincts, Harsh Environment Adaptation
- **Besalisk**: Four-Armed Strength, Natural Resilience, Multi-Armed Combat
- **Miraluka**: Force Sight, Force Sensitivity, Spiritual Insight
- **Kel Dor**: Darkvision, Toxic Resistance, Environmental Adaptation
- **Cathar**: Cat's Claws, Feline Agility, Keen Senses
- **Cerean**: Closed Mind, Natural Harmony, Diplomatic Insight
- **Echani**: Martial Arts Training, Combat Discipline, Combat Communication

## Variants Completed
- **Human cultural variants**: 
  - **Alderaanian Human** ✅ - Diplomatic, artistic, cultured
  - **Corellian Human** ✅ - Piloting, engineering, spacer instincts
  - **Chandrilan Human** ✅ - Agricultural, community, practical wisdom
  - **Lothal Human** ✅ - Frontier survival, resourcefulness, independence
- **Droid variants**:
  - **Droid Type IV Protocol** ✅ - Diplomatic, translation, cultural protocols
  - **Droid Scout** ✅ - Exploration, reconnaissance, environmental adaptation
  - **Droid Player Character** ✅ - Advanced AI, emotional development, unique capabilities

## Variants Completed
- **Human cultural variants**: 
  - **Alderaanian Human** ✅ - Diplomatic, artistic, cultured
  - **Corellian Human** ✅ - Piloting, engineering, spacer instincts
  - **Chandrilan Human** ✅ - Agricultural, community, practical wisdom
  - **Lothal Human** ✅ - Frontier survival, resourcefulness, independence
- **Droid variants**:
  - **Droid Type IV Protocol** ✅ - Diplomatic, translation, cultural protocols
  - **Droid Scout** ✅ - Exploration, reconnaissance, environmental adaptation
  - **Droid Player Character** ✅ - Advanced AI, emotional development, unique capabilities
- **Force-sensitive variants**:
  - **Zabrak Dathomirian** ✅ - Dark side Force sensitivity, Nightsister heritage
  - **Togruta Nightsister** ✅ - Dark side mastery, mystical connection

## All Variants Complete! 🎉


