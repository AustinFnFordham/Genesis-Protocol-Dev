# Class and Progression System Refactor Status

## Overview
This document tracks the implementation of the new architectural directive for the game's class and progression system, which combines SW5e's level-based design with FFG's branching talent trees. **NEW: Implementing "Gold Standard" with Class Identity Profiles.**

## Completed Tasks ✅

### Task 1: Rethink Base Classes (Gold Standard)
- **bounty_hunter.yml**: ✅ Refactored to use new `level_progression` block + **NEW: Added `class_identity_profile`**
  - Removed complex `progression_tree`
  - Added linear SW5e-style benefits for levels 1-20
  - **NEW: Rich narrative identity with core_fantasy, iconic_gear, famous_exemplars, species/faction synergies**
  - Includes proficiency bonus progression, feature grants, and subclass unlocks

- **guardian.yml**: ✅ Refactored to use new `level_progression` block + **NEW: Added `class_identity_profile`**
  - Removed simple `class_features` list
  - Added comprehensive level progression with Force-related features
  - **NEW: Jedi Guardian identity with Force-wielder narrative, lightsaber focus, Jedi Order synergies**
  - Includes Force sensitivity and power progression

### Task 2: Build the Talent Trees (Gold Standard)
- **bounty_hunter_assassin.yml**: ✅ Implemented comprehensive talent tree + **NEW: Added `subclass_identity_profile`**
  - 16 total talents across 5 tiers
  - **NEW: Assassin-specific narrative with stealth focus, famous exemplars, specialized gear**
  - Tier 1: Foundation talents (5 XP each) - quick_strike, stalker, shadow_veil, precision_training
  - Tier 2: Specialization talents (10 XP each) - death_strike, shadow_step, silent_killer
  - Tier 3: Advanced talents (15 XP each) - master_assassin, phantom_strike, death_mark, shadow_mastery
  - Tier 4: Master talents (20 XP each) - legendary_assassin, death_whisper, shadow_legend
  - Tier 5: Legendary talents (25 XP each) - death_incarnate, shadow_incarnate

### Task 3: Implement Power Acquisition (Enhanced)
- **force_power_mastery.yml**: ✅ Created feature with `grant_choice` effect
- **force_training_adept.yml**: ✅ **NEW: Created foundational power acquisition talent**
  - Demonstrates new power acquisition system
  - Allows choice from specific Force power list: `all_level_1_force_powers`
  - Includes Force Points increase and efficient casting benefits
  - **NEW: Shows how power learning is integrated into talent progression**

### New Feature Files Created
1. **quick_strike.yml** - Tier 1 foundation talent for initiative and first strike
2. **stalker.yml** - Tier 1 foundation talent for tracking and stealth
3. **shadow_veil.yml** - Tier 1 foundation talent for shadow concealment
4. **precision_training.yml** - Tier 1 foundation talent for accuracy and critical hits
5. **silent_killer.yml** - Tier 2 specialization talent for silent elimination
6. **phantom_strike.yml** - Tier 3 advanced talent for shadow teleportation
7. **death_incarnate.yml** - Tier 5 legendary talent for instant death abilities
8. **force_power_mastery.yml** - Tier 3 talent demonstrating power acquisition
9. **force_training_adept.yml** - **NEW: Tier 1 foundational Force power learning talent**

## **NEW: Gold Standard Implementation**

### Class Identity Profiles
- **Narrative Soul**: Each class now has a `class_identity_profile` that captures its essence
- **Core Fantasy**: Defines what it feels like to play this class
- **Iconic Gear**: Lists the signature equipment that defines the class
- **Famous Exemplars**: Provides recognizable examples from Star Wars lore
- **Species Synergies**: Shows how different species naturally fit the class
- **Faction Synergies**: Explains the class's relationship with major galactic factions

### Subclass Identity Profiles
- **Specialized Narrative**: Each subclass gets its own `subclass_identity_profile`
- **Unique Focus**: Captures the specific fantasy of that specialization
- **Specialized Gear**: Lists equipment unique to that subclass
- **Famous Exemplars**: Provides examples specific to that specialization

### Enhanced Power Acquisition
- **Talent-Based Learning**: Powers are now acquired through specific talents in the tree
- **Meaningful Choices**: Learning a power requires XP investment and represents character growth
- **Integrated Progression**: Power acquisition is part of the natural talent tree progression
- **Flexible Lists**: `source_list` can reference specific power categories or levels

## Remaining Tasks 🔄

### Task 1: Complete Base Class Refactoring (Gold Standard)
- Refactor remaining class files in `/classes/` with `class_identity_profile`:
  - seeker.yml, mystic.yml, consular.yml, spy.yml, diplomat.yml, commander.yml
  - engineer.yml, smuggler.yml, explorer.yml, colonist.yml, hired_gun.yml
  - tracker.yml, scoundrel.yml, trooper.yml, juggernaut.yml, scout.yml
  - soldier.yml, inquisitor.yml, sith.yml, sentinel.yml
- **Note**: Class.schema.json has been completed to gold standard

### Task 2: Complete Talent Tree Implementation (Gold Standard)
- Design and implement talent trees for all subclasses in `/subclasses/` with `subclass_identity_profile`
- Create corresponding feature files for each talent in the trees
- Ensure proper prerequisite chains and progression paths
- **NEW: Include power acquisition talents for Force/Tech classes**
- **Note**: CharacterClassFeature.schema.json has been completed to gold standard

### Task 3: Expand Power Acquisition System
- Create power acquisition talents for all Force-casting classes (Guardian, Consular, Mystic, etc.)
- Create tech power acquisition talents for tech-casting classes (Engineer, etc.)
- Design power lists appropriate for each class and subclass
- **NEW: Implement tiered power acquisition (Level 1, Level 2, etc.)**

## Key Architectural Features Implemented

### Level Progression (SW5e Path)
- Linear progression from levels 1-20
- Automatic grants of core features, proficiency bonuses, and subclass unlocks
- Provides solid foundation for character advancement

### Talent Progression (FFG Path)
- Branching talent trees with prerequisites
- XP-based talent purchasing system
- Multiple tiers with increasing costs and power levels
- Deep customization and specialization options
- **NEW: Integrated power acquisition through talents**

### Power Acquisition System
- `grant_choice` effect for learning new powers
- `choice_type: "power"` with `source_list` of available powers
- `count` parameter for number of choices granted
- Integrated with Force Points and tech resource systems
- **NEW: Talent-based progression for power learning**

### **NEW: Class Identity System**
- Rich narrative profiles for every class and subclass
- Thematic consistency across mechanics and flavor
- Clear synergies with species and factions
- Recognizable examples from Star Wars lore

## File Structure
```
SW5e_Data_Hub/data/
├── classes/
│   ├── bounty_hunter.yml (✅ refactored + gold standard)
│   ├── guardian.yml (✅ refactored + gold standard)
│   └── [other classes] (🔄 pending gold standard)
├── subclasses/
│   └── bounty_hunter_subclasses/
│       └── bounty_hunter_assassin.yml (✅ refactored + gold standard)
└── features/
    ├── bounty_hunter/
    │   └── assassin/
    │       ├── quick_strike.yml (✅ new)
    │       ├── stalker.yml (✅ new)
    │       ├── shadow_veil.yml (✅ new)
    │       ├── precision_training.yml (✅ new)
    │       ├── silent_killer.yml (✅ new)
    │       ├── phantom_strike.yml (✅ new)
    │       └── death_incarnate.yml (✅ new)
    └── guardian/
        ├── force_power_mastery.yml (✅ new)
        └── force_training_adept.yml (✅ new)
```

## Next Steps
1. **Continue with "Template-Prime" approach**: Perfect the Bounty Hunter class completely
2. **Complete remaining base classes** with gold standard identity profiles
3. **Design talent trees for all subclasses** with subclass identity profiles
4. **Create comprehensive feature files** for all talents
5. **Implement power acquisition** for all casting classes
6. **Test and validate** the new system
7. **Update documentation and schemas**

## Success Metrics
- ✅ Base class simplification completed for 2 classes (gold standard)
- ✅ Talent tree implementation completed for 1 subclass (gold standard)
- ✅ Power acquisition system demonstrated and enhanced
- ✅ **NEW: Class identity profiles implemented**
- 🔄 Remaining: 22 base classes, ~50+ subclasses, ~200+ feature files

## **NEW: Gold Standard Benefits**
- **Rich Narrative**: Every class now has a compelling story and identity
- **Thematic Consistency**: Mechanics and flavor work together seamlessly
- **Clear Synergies**: Players understand how species and factions interact with classes
- **Recognizable Examples**: Famous characters provide clear archetypes
- **Integrated Progression**: Power acquisition feels natural and meaningful
