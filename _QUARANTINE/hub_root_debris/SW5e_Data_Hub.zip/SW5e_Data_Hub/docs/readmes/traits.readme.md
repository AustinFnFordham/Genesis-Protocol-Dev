# Traits Marketplace

## Goal
- Standardize every species to at least 3 traits. If a species defines fewer than 3 innate traits, players can **choose** optional traits from this marketplace to reach 3.

## Rules
- **Innate traits** live on species entries and should be universal and identity-defining.
- **Marketplace traits** represent broadly learnable, non-space talents (e.g., tradecraft, storyteller, shipwright's eye for ground work) and are **selectable during creation** when a species lists <3 traits.
- **Space roles** remain in starship backgrounds.
- **User Agency**: Players choose which marketplace traits to apply, if any.

## Selection Flow
1) Pick species (use its innate traits).
2) **If innate trait count < 3, optionally choose marketplace traits** until you reach 3 total.
3) Optionally choose one starship background for space-side play.

## Stacking
- Do not duplicate proficiencies; convert duplicates into advantage on the next related check this session or allow a replacement from a curated list.

## Current Status
- **Species with 3+ innate traits** (no marketplace needed): Twi'lek, Wookiee, Zabrak, Rodian, Nautolan, Bothan, Duros, Mon Calamari, Ithorian, Trandoshan, Human, Chiss, Clawdite, Sith Pureblood
- **Species needing marketplace options**: None currently - all species have 3+ innate traits
- **Available marketplace traits**: 8 options for future species or player preference

## Recent Improvements
- **Chiss**: Added "Enhanced Vision" trait for low-light perception
- **Clawdite**: Added "Adaptive Physiology" trait for grapple escape and poison resistance  
- **Sith Pureblood**: Already had 3 traits, updated narrative tags for consistency


