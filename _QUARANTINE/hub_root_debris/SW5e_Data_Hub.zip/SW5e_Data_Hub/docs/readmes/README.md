# SW5e x FFG Unified System - Lore Directory

## Overview
This directory contains all lore-related content for the unified SW5e x FFG hybrid system, organized by eras and baseline factions.

## Directory Structure

```
API_Cursor_SW5E/
└── lore/
    ├── eras/
    │   ├── high_republic/
    │   │   └── factions/
    │   ├── old_republic/
    │   │   └── factions/
    │   │       └── old_republic_era.yml ✅
    │   ├── clone_wars/
    │   │   └── factions/
    │   ├── early_empire/
    │   │   └── factions/
    │   ├── galactic_civil_war/
    │   │   └── factions/
    │   │       ├── criminal_factions.yml ✅
    │   │       └── legitimate_factions.yml ✅
    │   ├── new_republic/
    │   │   └── factions/
    │   └── resistance/
    │       └── factions/
    ├── baseline_factions/
    │   ├── sith_order.yml ✅
    │   └── mandalorian_clans_baseline.yml ✅
    └── planning/
        ├── unified_development_direction.yml ✅
        ├── factions_expansion_plan.yml ✅
        ├── factions_expansion_addendum.yml ✅
        ├── factions_table_of_contents.yml ✅
        ├── hideout_system.yml ✅
        └── factions_integration.yml ✅
```

## Organization Principles

### Era-Specific Factions
- **Location**: `lore/eras/[era_name]/factions/`
- **Content**: Factions that are specific to a particular era
- **Examples**: 
  - Old Republic: Czerka Corporation, The Exchange
  - Clone Wars: Clone Army, Droid Army
  - Galactic Civil War: Black Sun, Hutt Cartels

### Baseline Factions (Cross-Era)
- **Location**: `lore/baseline_factions/`
- **Content**: Factions that exist across multiple eras with variations
- **Examples**: Jedi Order, Sith Order, Mandalorian Clans, Bounty Hunters

### Planning and Integration
- **Location**: `lore/planning/`
- **Content**: All planning documents, development directions, and integration guides

## Development Status

### ✅ Completed
- **Old Republic Era**: Comprehensive faction system with 8 major factions
- **Galactic Civil War Era**: Core criminal and legitimate factions
- **Sith Order**: Baseline faction with full progression
- **Mandalorian Clans**: Baseline faction with complete unified structure
- **Planning System**: Complete unified development direction

### 🔄 In Progress
- **Directory Structure**: Created and organized
- **File Migration**: Moving existing files to appropriate locations

### 📋 To Create
- **Baseline Factions**: 
  - Jedi Order (Baseline)
  - Bounty Hunters (Baseline)
  - Smugglers (Baseline)
  - Criminals (Baseline)
- **Era-Specific Factions**: All other eras need expansion
- **High Republic Era**: Complete planning and implementation

## Content Structure Requirements

All faction files must follow the unified content structure:

1. **Name and Description**
2. **Overview and Leadership**
3. **Ranks and Progression (5 ranks minimum)**
4. **Benefits and Features (3 features per rank, choice-based)**
5. **Items: Armor, Weapons, Gear (3x expanded)**
6. **Tool Proficiencies (3x expanded)**
7. **Ability Score Adjustments (3x expanded)**
8. **Hideouts, Facilities, Space Stations, Capital Ships**
9. **Entertainment and Downtime Activities (3x expanded)**
10. **Customization Options: Appearance (x10), Equipment (x10)**
11. **Conflicts and Relations**
12. **Balance Considerations**
13. **Synergistic Mechanics (including obscure cross-faction synergies)**
14. **Cultural Features (x5)**
15. **Environmental Adaptations (x5)**
16. **Character Building Integration**
17. **Testing and Balance Scaffolding**

## Next Steps

### Phase 1: Immediate (Next 2-4 weeks)
1. **Create Baseline Factions**:
   - Jedi Order (Baseline)
   - Sith Order (Baseline) - Update existing
   - Bounty Hunters (Baseline)

### Phase 2: Short Term (4-8 weeks)
1. **Complete all baseline factions**
2. **Create era-specific faction variations**
3. **Develop faction-specific items, tools, and features**

### Phase 3: Medium Term (8-16 weeks)
1. **Complete all era-specific factions**
2. **Develop character building integration**
3. **Develop testing and balance scaffolding**

### Phase 4: Long Term (16+ weeks)
1. **Advanced faction systems**
2. **StarshipActions.schema.json development**

## Key Features

### Cross-Faction Synergies
- **Fallen Jedi**: +2 to Force checks, dark side powers, -1 to light side powers
- **Redeemed Sith**: +2 to Force checks, light side powers, -1 to dark side powers
- **Soldier Turned Scoundrel**: +1 to combat, +1 to criminal, enhanced discipline
- **Corporate Spy Turned Rebel**: +1 to business, +1 to rebel, enhanced infiltration
- **Mandalorian Jedi**: +1 to combat, +1 to Force, enhanced honor

### Cultural Features (x5 per faction)
- Primarily narrative, minor mechanical benefits
- Examples: Mandalorian Honor Code, Jedi Meditation Practices

### Environmental Adaptations (x5 per faction)
- Situational advantages, not universal bonuses
- Examples: Desert Survival, Urban Navigation, Space Adaptation

## Integration Points

All factions integrate with:
- **Classes**: How classes affect faction abilities
- **Powers**: How Force/Tech powers interact with factions
- **Items**: How faction-specific equipment works
- **Species**: How species traits affect faction membership
- **Actions**: How faction abilities affect action economy

## Balance Guidelines

- All synergies must enhance existing abilities, not create new ones
- Bonuses should be +1 to +3 maximum for any single synergy
- Synergies must require specific combinations, not universal bonuses
- Must maintain class identity and prevent homogenization
- Should create interesting choices, not mandatory combinations

## Success Metrics

- All eras have complete faction systems
- All baseline factions are complete
- All factions have 3x expanded content
- All factions have era-specific leadership
- All factions have cross-faction synergies
- All factions have extensive customization
- All factions maintain balance and narrative focus
- Character building integration is comprehensive
- Testing and balance scaffolding is robust

## Contact and Development

This system follows the unified SW5e x FFG hybrid approach, ensuring narrative focus with mechanical support while maintaining balance and accessibility for all players.
