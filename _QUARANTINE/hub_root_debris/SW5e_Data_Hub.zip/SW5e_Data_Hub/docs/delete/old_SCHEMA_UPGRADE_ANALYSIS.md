# Schema Upgrade Analysis

## Overview
This document analyzes all schema files outside of species, classes, and companions to identify what needs to be updated to match the new "gold standard" structure. The new structure includes narrative blocks for LLM-GM integration, enhanced mechanics, and better organization.

## Key Findings from Species Schema Review

The species schema already includes several elements that should be applied to other schemas:
- **narrative_tags**: Keywords for LLM storytelling (e.g., 'physical: reptilian', 'social: feared')
- **Rich effects system**: Comprehensive effects with conditions, target_scopes, and actions
- **Structured progression**: Level-based trait granting system

## Schema Analysis & Required Updates

### 1. **Power.schema.json** - ✅ **COMPLETED** 

**Status: UPGRADED TO GOLD STANDARD**
- ✅ Added comprehensive narrative blocks for LLM-GM integration
- ✅ Added flavor_text with iconic quotes
- ✅ Added power_type field (Force/Tech)
- ✅ Added components array (Somatic, Verbal, Material, Focus)
- ✅ Added base_effect block with detailed mechanics
- ✅ Added upgrades array with XP costs and prerequisites
- ✅ Added alignment field for Force powers
- ✅ Added level field for power requirements
- ✅ Added synergies with classes, species, and factions
- ✅ Added LLM-GM integration guidance

**Example Implementation:**
- Created `force_push.yml` demonstrating the new structure
- Includes 5 upgrade tiers with XP costs and prerequisites
- Rich narrative integration with Star Wars lore
- Comprehensive synergies and LLM-GM guidance

### 2. **Faction.schema.json** - ✅ **COMPLETED**

**Status: UPGRADED TO GOLD STANDARD**
- ✅ Added comprehensive narrative blocks for LLM-GM integration
- ✅ Added core_ideology description
- ✅ Added famous_exemplars from Star Wars lore
- ✅ Added era field for faction time periods
- ✅ Added territory and influence descriptions
- ✅ Added relationships with other factions
- ✅ Added iconic_gear, iconic_abilities, and iconic_locations
- ✅ Added synergies with species, classes, and backgrounds
- ✅ Added LLM-GM integration guidance with narrative hooks, missions, and politics
- ✅ Enhanced ranks system with narrative descriptions and requirements
- ✅ Added membership_perks system (renamed from faction_benefits)

**Example Implementations:**
- Created `jedi_order.yml` demonstrating religious order faction
- Created `galactic_empire.yml` demonstrating government faction
- Both include comprehensive narrative integration, relationships, and synergies
- Rich LLM-GM guidance for storytelling and mission generation

### 3. **Lore.schema.json** - ✅ **COMPLETED**

**Status: UPGRADED TO GOLD STANDARD**
- ✅ Added comprehensive narrative blocks for LLM-GM integration
- ✅ Added flavor_text with iconic Star Wars quotes
- ✅ Added cultural_significance description
- ✅ Added era field for lore time periods
- ✅ Added importance_level field (Galactic, Regional, Local, Personal)
- ✅ Enhanced lore_type with expanded categories
- ✅ Added physical_description, historical_context, and current_status
- ✅ Enhanced connections system with narrative descriptions
- ✅ Added synergies with factions, species, classes, and locations
- ✅ Added iconic_examples, famous_events, and notable_figures
- ✅ Added LLM-GM integration guidance with narrative hooks, adventure seeds, and knowledge checks
- ✅ Added mechanical_effects system for knowledge benefits and skill modifiers
- ✅ Added themes and mood for atmospheric guidance

**Example Implementations:**
- Created `coruscant.yml` demonstrating planet lore entry
- Created `battle_of_yavin.yml` demonstrating historical event lore entry
- Both include comprehensive narrative integration, connections, and synergies
- Rich LLM-GM guidance for storytelling and adventure generation

### 4. **Item.schema.json** - MODERATE UPDATE NEEDED ⚠️

**Current State:**
- Good mechanical structure
- Has narrative_outcomes
- Missing narrative integration
- Could use enhanced LLM-GM features

**Required Updates:**
```yaml
# ADD TO EXISTING STRUCTURE:
- Add "narrative" block for LLM-GM integration
- Add "flavor_text" with iconic descriptions
- Add "iconic_usage" examples
- Add "faction_synergies" for items tied to specific groups
- Add "era_synergies" for items from specific time periods
- Enhance "narrative_outcomes" with more detailed LLM guidance
```

### 5. **Background.schema.json** - MODERATE UPDATE NEEDED ⚠️

**Current State:**
- Good structure with personality options
- Missing narrative integration
- Could use enhanced LLM-GM features

**Required Updates:**
```yaml
# ADD TO EXISTING STRUCTURE:
- Add "narrative" block for LLM-GM integration
- Add "core_fantasy" description
- Add "famous_exemplars" from Star Wars lore
- Add "species_synergies" for backgrounds that fit certain species
- Add "faction_synergies" for backgrounds tied to organizations
- Add "era_synergies" for backgrounds from specific time periods
- Enhance "personality_options" with more narrative guidance
```

### 6. **Starship.schema.json** - MODERATE UPDATE NEEDED ⚠️

**Current State:**
- Comprehensive mechanical structure
- Missing narrative integration
- Could use enhanced LLM-GM features

**Required Updates:**
```yaml
# ADD TO EXISTING STRUCTURE:
- Add "narrative" block for LLM-GM integration
- Add "famous_exemplars" from Star Wars lore
- Add "manufacturer_narrative" for ship builders
- Add "era_synergies" for ships from specific time periods
- Add "faction_synergies" for ships tied to organizations
- Add "iconic_usage" examples
- Add "crew_culture" descriptions
```

### 7. **CraftingRecipe.schema.json** - MODERATE UPDATE NEEDED ⚠️

**Current State:**
- Good mechanical structure
- Missing narrative integration
- Could use enhanced LLM-GM features

**Required Updates:**
```yaml
# ADD TO EXISTING STRUCTURE:
- Add "narrative" block for LLM-GM integration
- Add "crafting_process" description
- Add "famous_crafters" from Star Wars lore
- Add "faction_synergies" for recipes tied to organizations
- Add "era_synergies" for recipes from specific time periods
- Add "iconic_usage" examples
```

### 8. **Action.schema.json** - MINOR UPDATE NEEDED ⚠️

**Current State:**
- Good mechanical structure
- Has narrative_outcomes
- Could use enhanced LLM-GM features

**Required Updates:**
```yaml
# ADD TO EXISTING STRUCTURE:
- Add "narrative" block for LLM-GM integration
- Add "iconic_usage" examples
- Add "skill_synergies" for actions that work with specific skills
- Enhance "narrative_outcomes" with more detailed LLM guidance
- Add "action_economy_notes" for tactical guidance
```

### 9. **Status.schema.json** - MINOR UPDATE NEEDED ⚠️

**Current State:**
- Simple but effective structure
- Missing narrative integration
- Could use enhanced LLM-GM features

**Required Updates:**
```yaml
# ADD TO EXISTING STRUCTURE:
- Add "narrative" block for LLM-GM integration
- Add "visual_description" for how the status appears
- Add "removal_methods" with narrative guidance
- Add "synergies" with other status effects
- Add "iconic_examples" from Star Wars lore
```

### 10. **Combat.schema.json** - MINOR UPDATE NEEDED ⚠️

**Current State:**
- Comprehensive mechanical structure
- Missing narrative integration
- Could use enhanced LLM-GM features

**Required Updates:**
```yaml
# ADD TO EXISTING STRUCTURE:
- Add "narrative" blocks for different combat scenarios
- Add "tactical_guidance" for LLM-GM
- Add "iconic_examples" from Star Wars battles
- Add "environment_synergies" for different terrain types
```

## Updated Priority Order for Updates

### **MEDIUM PRIORITY** (Important Systems)
1. **Item.schema.json** - Enhanced narrative integration
2. **Background.schema.json** - Enhanced narrative integration
3. **Starship.schema.json** - Enhanced narrative integration
4. **CraftingRecipe.schema.json** - Enhanced narrative integration

### **LOW PRIORITY** (Supporting Systems)
5. **Action.schema.json** - Minor enhancements
6. **Status.schema.json** - Minor enhancements
7. **Combat.schema.json** - Minor enhancements

## Implementation Strategy

### Phase 1: Core Systems (Item, Background, Starship, Crafting) - IN PROGRESS
- Add narrative blocks to existing schemas
- Enhance LLM-GM integration
- Add synergies and examples

### Phase 2: Supporting Systems (Action, Status, Combat)
- Minor enhancements to existing schemas
- Add narrative guidance
- Improve LLM-GM integration

## Benefits of These Updates

1. **Enhanced LLM-GM Integration**: All schemas will have rich narrative content for AI game masters
2. **Better Player Experience**: More flavorful and thematic content
3. **Improved Consistency**: All schemas will follow the same "gold standard" structure
4. **Enhanced Storytelling**: Rich narrative hooks and examples from Star Wars lore
5. **Better Synergies**: Clear connections between different game elements

## Next Steps

1. **Begin Item Schema Refactor** - Next medium priority
2. **Create example data files** - Show how the new schemas work in practice
3. **Update existing data files** - Refactor current data to match new schemas
4. **Test LLM-GM integration** - Verify that the narrative blocks work well with AI game masters

## Progress Summary

- ✅ **Power.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Faction.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Lore.schema.json** - COMPLETED with full gold standard implementation
- 🔄 **Item.schema.json** - NEXT PRIORITY
- 🔄 **Background.schema.json** - MEDIUM PRIORITY
- 🔄 **Starship.schema.json** - MEDIUM PRIORITY
- 🔄 **CraftingRecipe.schema.json** - MEDIUM PRIORITY
- 🔄 **Action.schema.json** - LOW PRIORITY
- 🔄 **Status.schema.json** - LOW PRIORITY
- 🔄 **Combat.schema.json** - LOW PRIORITY

The Power, Faction, and Lore schema upgrades demonstrate the successful implementation of the new "gold standard" structure and provide templates for upgrading the remaining schemas. The Faction schema refactor shows how the gold standard can be applied to different types of systems with comprehensive narrative integration and LLM-GM guidance. The Lore schema refactor shows how the gold standard can be applied to informational content with rich narrative integration and comprehensive connections between different lore elements.
