# SW5e Data Hub - Schema Inventory

## **📊 COMPREHENSIVE SCHEMA STATUS**

### **✅ COMPLETED SCHEMAS (Gold Standard)**
These schemas have been refactored to the "gold standard" with comprehensive narrative blocks, LLM-GM integration, and enhanced mechanics:

1. **Power.schema.json** ✅
   - Status: Complete with power_cost, manifestation, corruption_transform
   - Example: `data/powers/force_push.yml`

2. **Status.schema.json** ✅
   - Status: Complete with dynamic scaling, removal conditions, synergies
   - Example: `data/status_effects/acid_corrosion.yml`

3. **Master_Action.schema.json** ✅
   - Status: Complete unified action schema with skill_check support
   - Example: `data/actions/hack_terminal_master.yml`

4. **Faction.schema.json** ✅
   - Status: Complete with narrative blocks, relationships, membership_perks
   - Example: `data/factions/jedi_order.yml`

5. **Lore.schema.json** ✅
   - Status: Complete with layered knowledge, unified connections
   - Example: `data/lore/coruscant.yml`

6. **Item.schema.json** ✅
   - Status: Complete with narrative integration, LLM guidance
   - Example: `data/items/lightsaber.yml`

7. **Background.schema.json** ✅
   - Status: Complete with narrative blocks, unified connections
   - Example: `data/backgrounds/background_jedi.yml`

8. **Starship.schema.json** ✅
   - Status: Complete with narrative integration, LLM guidance
   - Example: `data/starships/millennium_falcon.yml`

9. **CraftingRecipe.schema.json** ✅
   - Status: Complete with tag_requirement, narrative integration
   - Example: `data/crafting/lightsaber_recipe.yml`

10. **Object.schema.json** ✅
    - Status: Complete with hackable_interface, interaction systems
    - Example: `data/objects/imperial_blast_door_controls.yml`

### **🔄 SCHEMAS NEEDING REFACTOR**
These schemas exist but need to be updated to the "gold standard":

11. **Action.schema.json** 🔄
    - Status: Needs refactor to match Master_Action.schema.json
    - Current: Basic action schema
    - Needed: Skill check support, narrative blocks

12. **Combat.schema.json** 🔄
    - Status: Needs refactor to match Master_Action.schema.json
    - Current: Basic combat schema
    - Needed: Unified with Master_Action

13. **Species.schema.json** 🔄
    - Status: Needs narrative blocks, LLM guidance
    - Current: Basic species schema
    - Needed: Image generation, UI blocks

14. **CharacterClass.schema.json** 🔄
    - Status: Needs class_identity_profile, level_progression
    - Current: Basic class schema
    - Needed: Narrative integration

15. **CharacterSubclass.schema.json** 🔄
    - Status: Needs talent_tree, subclass_identity_profile
    - Current: Basic subclass schema
    - Needed: FFG-style talent trees

16. **CharacterClassFeature.schema.json** 🔄
    - Status: Needs grant_choice effect, narrative blocks
    - Current: Basic feature schema
    - Needed: Power acquisition support

17. **Companion.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic companion schema
    - Needed: Image generation, UI blocks

18. **CampaignState.schema.json** 🔄
    - Status: Needs registry integration, narrative blocks
    - Current: Basic campaign schema
    - Needed: LLM-GM integration

19. **Character.schema.json** 🔄
    - Status: Needs registry references, narrative blocks
    - Current: Basic character schema
    - Needed: Single source of truth integration

20. **Nemesis.schema.json** 🔄
    - Status: Needs registry integration, narrative blocks
    - Current: Basic nemesis schema
    - Needed: LLM-GM integration

21. **Adversary.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic adversary schema
    - Needed: Image generation, UI blocks

22. **Creature.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic creature schema
    - Needed: Image generation, UI blocks

23. **StarshipWeapon.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic starship weapon schema
    - Needed: Image generation, UI blocks

24. **Modification.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic modification schema
    - Needed: Image generation, UI blocks

### **❌ MISSING SCHEMAS**
These schemas are referenced but don't exist yet:

25. **Era.schema.json** ❌
    - Status: Missing
    - Needed: Era definitions with narrative blocks

26. **Location.schema.json** ❌
    - Status: Missing
    - Needed: Location definitions with narrative blocks

27. **Condition.schema.json** ❌
    - Status: Missing
    - Needed: Condition definitions (different from Status)

28. **Rules.schema.json** ❌
    - Status: Missing
    - Needed: Game rules and mechanics

29. **SkillTree.schema.json** ❌
    - Status: Missing
    - Needed: Skill tree definitions

30. **Synergy.schema.json** ❌
    - Status: Missing
    - Needed: Synergy definitions

31. **Trait.schema.json** ❌
    - Status: Missing
    - Needed: Trait definitions

32. **StarshipCareer.schema.json** ❌
    - Status: Missing
    - Needed: Starship career definitions

33. **StarshipAction.schema.json** ❌
    - Status: Missing
    - Needed: Starship action definitions

### **📁 FILE ORGANIZATION STATUS**

#### **✅ PROPERLY ORGANIZED**
- `schema/` - All JSON schemas
- `docs/` - All documentation files
- `validation/` - Validation results
- `data/objects/` - Object data files

#### **🔄 NEEDS ORGANIZATION**
- `data/` - Mixed content types
- `scripts/` - Validation and utility scripts
- `api/` - API routes and services

### **🎯 REFACTOR PRIORITIES**

#### **HIGH PRIORITY (Fix Immediately)**
1. **Species.schema.json** - Core system component
2. **CharacterClass.schema.json** - Core system component
3. **CharacterSubclass.schema.json** - Core system component
4. **CharacterClassFeature.schema.json** - Core system component

#### **MEDIUM PRIORITY (Refactor in Batches)**
5. **Companion.schema.json** - Important for gameplay
6. **Adversary.schema.json** - Important for gameplay
7. **Creature.schema.json** - Important for gameplay
8. **CampaignState.schema.json** - Important for campaigns

#### **LOW PRIORITY (Complete System)**
9. **Missing Schemas** - Create new schemas
10. **File Organization** - Final cleanup
11. **Performance Optimization** - Speed improvements

### **📊 VALIDATION STATUS**
- **Total Schemas**: 33
- **Completed**: 10 (30.3%)
- **Needs Refactor**: 14 (42.4%)
- **Missing**: 9 (27.3%)
- **Success Rate**: 30.3%

### **🚀 NEXT STEPS**
1. **Complete High Priority Refactors** (4 schemas)
2. **Create Missing Schemas** (9 schemas)
3. **Validate All Schemas** (33 schemas)
4. **Refactor Content Files** (832 data files)
5. **Final Integration Testing**

---

*Last Updated: 2025-09-06*
*Status: Schema refactor in progress*
