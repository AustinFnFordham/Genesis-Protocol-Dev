# Power System Refactor Documentation

## Overview

The Power system has been completely refactored to be more thematically appropriate for Star Wars, replacing the generic D&D-style `components` system with a more immersive and mechanically rich `power_cost` and `manifestation` system.

## Key Changes

### 1. Replaced `components` with `power_cost` and `manifestation`

**Old System:**
```yaml
components: 
  - "Somatic"
  - "Verbal"
  - type: "Material"
    item_id: "item_kyber_crystal"
```

**New System:**
```yaml
power_cost:
  - type: "Force_Points"
    amount: 2
manifestation:
  - "Somatic (a clear, forceful gesture)"
  - "Mental Focus"
```

### 2. Added `uses_per_rest` for High-Level Powers

For epic, game-changing powers that should have limited uses:

```yaml
uses_per_rest: "long"  # or "short" or "at_will"
```

### 3. Added Optional `material_components` for Rare Rituals

Only for powers that specifically require and/or consume physical items:

```yaml
material_components:
  - item_id: "item_slicing_tool"
    consumed: false
    narrative: "A specialized device for interfacing with computer systems."
    substitutes: ["item_datapad", "item_interface_glove"]
```

### 4. Added `modify_power_cost` Effect for Upgrades

Upgrades can now modify the cost of powers, creating interesting trade-offs:

```yaml
- effect: "modify_power_cost"
  description: "Channeling this much raw force is taxing."
  modification: "increase_cost"
  parameters:
    type: "Force_Points"
    amount: 1
```

## Resource Types

The new system supports multiple resource types:

- **Force_Points**: For Force powers
- **Tech_Points**: For Tech powers  
- **Strain**: For physically taxing abilities
- **Hit_Points**: For dangerous dark side powers

## Examples

### Basic Force Power (Force Push)
```yaml
power_cost:
  - type: "Force_Points"
    amount: 2
manifestation:
  - "Somatic (a clear, forceful gesture)"
  - "Mental Focus"
```

### Tech Power with Material Components (Hack Terminal)
```yaml
power_cost:
  - type: "Tech_Points"
    amount: 3
manifestation:
  - "Somatic (typing on interface)"
  - "Verbal (muttering commands)"
  - "Mental Focus (concentration on code)"
material_components:
  - item_id: "item_slicing_tool"
    consumed: false
    narrative: "A specialized device for interfacing with computer systems."
```

### Epic Power with Multiple Costs (Force Storm)
```yaml
power_cost:
  - type: "Force_Points"
    amount: 13
  - type: "Strain"
    amount: 5
manifestation:
  - "Somatic (raising both hands to the sky)"
  - "Verbal (dark incantations in ancient Sith tongue)"
  - "Mental Focus (channeling pure hatred and rage)"
uses_per_rest: "long"
```

## Benefits of the New System

### 1. Thematic Appropriateness
- **Force Powers**: Use Force Points and focus on mental/physical manifestation
- **Tech Powers**: Use Tech Points and require appropriate tools/equipment
- **Dark Side Powers**: Can cost Hit Points, representing the dangerous nature of dark side abilities

### 2. Rich Narration
The `manifestation` system provides detailed descriptions for LLM-GM narration:
- Instead of generic "You cast the spell," the GM can say "You extend your hand in a clear, forceful gesture, focusing your mind on your target..."

### 3. Strategic Depth
- **Cost Management**: Players must manage multiple resource types
- **Upgrade Trade-offs**: Powerful upgrades often increase costs
- **Material Requirements**: Some powers require specific equipment

### 4. Mechanical Integration
- **Direct Item Links**: Material components link directly to the item system
- **Resource Economy**: Creates meaningful choices about resource allocation
- **Progression Balance**: High-level powers have appropriate costs and limitations

## Migration Guide

### For Existing Power Files

1. **Replace `components` with `power_cost` and `manifestation`**
2. **Add `uses_per_rest` for high-level powers (level 7+)**
3. **Move material components to optional `material_components` block**
4. **Add `modify_power_cost` effects to upgrades where appropriate**
5. **Add `image_generation` and `ui` blocks if missing**

### Example Migration

**Before:**
```yaml
components: 
  - "Somatic"
  - type: "Material"
    item_id: "item_kyber_crystal"
    consumed: false
```

**After:**
```yaml
power_cost:
  - type: "Force_Points"
    amount: 2
manifestation:
  - "Somatic (a clear, forceful gesture)"
  - "Mental Focus"
# Only add material_components if the power specifically requires physical items
```

## Implementation Notes

### Engine Changes Required
- Update power casting logic to handle multiple resource types
- Implement `modify_power_cost` effect processing
- Add `uses_per_rest` tracking system
- Update LLM-GM prompts to use `manifestation` descriptions

### Validation Rules
- All powers must have `power_cost` and `manifestation`
- `material_components` is optional and only for rare rituals
- `uses_per_rest` is optional and only for high-level powers
- Upgrade effects can include `modify_power_cost`

## Conclusion

This refactor transforms the Power system from a generic D&D-style spell system into a thematically rich, mechanically deep system that truly captures the essence of Star Wars Force and Tech abilities. The new system provides better storytelling tools for LLM-GMs, more strategic depth for players, and stronger integration with the broader game systems.

## Corruption, Cross-Polar Access, and Percent-Based Costs

### Percent-Based and Max-HP Sacrifice Costs
- Add percent-based costs alongside flat costs in `power_cost`.
- Example (reduce max HP by 5% until long rest):
```yaml
power_cost:
  - type: "Hit_Points"
    cost_mode: "percent_of_max"
    percentage: 5
    apply_to: "max"
    recovery: "long_rest"
```
- Example (drain 5% of current HP immediately):
```yaml
power_cost:
  - type: "Hit_Points"
    cost_mode: "percent_of_current"
    percentage: 5
    apply_to: "current"
    rounding: "down"
```

### Access Rules for Opposite Alignment at Extremes
Add `access_rules` to control opposite-alignment use and penalties; allow clean access at extremes (e.g., Yoda using lightning, or a redeemed Sith using Heal):
```yaml
access_rules:
  alignment_required: "Light"
  opposite_alignment_access:
    allowed: true
    allowed_at_extremes: true
    threshold: 90
    penalties:
      cost_multiplier: 1.5
      dc_penalty: 2
```

### Power Corruption / Purification Mapping
Define how powers convert when a character crosses alignment thresholds. Example (Heal <-> Harm):
```yaml
corruption_transform:
  can_corrupt: true
  corrupts_to_power_id: "power_force_harm"
  can_purify: true
  purifies_to_power_id: "power_force_heal"
  retains_mastery: true
  mapping_notes: "Healing dice map 1:1 to damage dice; ally<->enemy target flip."
```

### Sample Powers
See:
- `SW5e_Data_Hub/data/powers/force_heal.yml` (Light, 5% max HP sacrifice with long-rest recovery; corrupts to Harm)
- `SW5e_Data_Hub/data/powers/force_harm.yml` (Dark, 5% current HP self-drain; purifies to Heal)
