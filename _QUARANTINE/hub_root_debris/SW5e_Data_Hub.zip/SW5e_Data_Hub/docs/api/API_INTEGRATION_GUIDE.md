# API Integration Guide

## Overview
This document provides comprehensive guidance for integrating the SW5e Data Hub with game engines, applications, and external systems.

## **1. Core API Endpoints**

### **Feature API**
```yaml
feature_endpoints:
  # Feature Lookup
  GET /api/features/{feature_id}:
    description: "Get specific feature by ID"
    parameters:
      - feature_id: "Unique feature identifier"
    response:
      - id: "Feature ID"
      - name: "Feature name"
      - xp_cost: "Experience cost"
      - narrative: "Rich description"
      - mechanics: "Mechanical effects array"
      - llm_guidance: "AI GM guidance"
      - image_generation: "Art generation prompts"
      - ui: "UI theming data"
  
  # Feature Discovery
  GET /api/features/class/{class_id}:
    description: "Get all features for a class"
    parameters:
      - class_id: "Class identifier"
    response: "Array of feature objects"
  
  GET /api/features/subclass/{subclass_id}:
    description: "Get all features for a subclass"
    parameters:
      - subclass_id: "Subclass identifier"
    response: "Array of feature objects"
  
  GET /api/features/level/{level}:
    description: "Get all features available at a level"
    parameters:
      - level: "Character level (1-20)"
    response: "Array of feature objects"
  
  # Feature Validation
  POST /api/features/validate:
    description: "Validate feature data"
    body: "Feature object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
  
  # Feature Discovery for Characters
  GET /api/features/available/{character_id}:
    description: "Get features available to a character"
    parameters:
      - character_id: "Character identifier"
    response: "Array of available feature objects"
  
  GET /api/features/purchasable/{character_id}:
    description: "Get features purchasable by a character"
    parameters:
      - character_id: "Character identifier"
    response: "Array of purchasable feature objects"
```

### **Class API**
```yaml
class_endpoints:
  # Class Lookup
  GET /api/classes/{class_id}:
    description: "Get specific class by ID"
    parameters:
      - class_id: "Unique class identifier"
    response:
      - id: "Class ID"
      - name: "Class name"
      - narrative: "Rich description"
      - class_identity_profile: "Identity and flavor data"
      - hit_die: "Hit die type"
      - proficiencies: "Proficiency arrays"
      - primary_ability: "Primary ability score"
      - primary_resource: "Primary resource type"
      - connections: "Unified connections array"
      - llm_guidance: "AI GM guidance"
      - image_generation: "Art generation prompts"
      - ui: "UI theming data"
  
  # Class Discovery
  GET /api/classes:
    description: "Get all classes"
    response: "Array of class objects"
  
  GET /api/classes/era/{era}:
    description: "Get classes by era"
    parameters:
      - era: "Era identifier (e.g., 'Galactic_Republic')"
    response: "Array of class objects"
  
  # Class Validation
  POST /api/classes/validate:
    description: "Validate class data"
    body: "Class object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
```

### **Subclass API**
```yaml
subclass_endpoints:
  # Subclass Lookup
  GET /api/subclasses/{subclass_id}:
    description: "Get specific subclass by ID"
    parameters:
      - subclass_id: "Unique subclass identifier"
    response:
      - id: "Subclass ID"
      - class_id: "Parent class ID"
      - name: "Subclass name"
      - alignment_theme: "Alignment theme"
      - talent_tree_theme: "UI theming data"
      - narrative: "Rich description"
      - subclass_identity_profile: "Identity and flavor data"
      - talent_tree: "Talent tree array"
      - llm_guidance: "AI GM guidance"
  
  # Subclass Discovery
  GET /api/subclasses/class/{class_id}:
    description: "Get all subclasses for a class"
    parameters:
      - class_id: "Class identifier"
    response: "Array of subclass objects"
  
  GET /api/subclasses/alignment/{alignment}:
    description: "Get subclasses by alignment theme"
    parameters:
      - alignment: "Alignment theme (e.g., 'light', 'dark')"
    response: "Array of subclass objects"
  
  # Subclass Validation
  POST /api/subclasses/validate:
    description: "Validate subclass data"
    body: "Subclass object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
```

### **Item API**
```yaml
item_endpoints:
  # Item Lookup
  GET /api/items/{item_id}:
    description: "Get specific item by ID"
    parameters:
      - item_id: "Unique item identifier"
    response:
      - id: "Item ID"
      - name: "Item name"
      - type: "Item type"
      - subtype: "Item subtype"
      - description: "Rich description"
      - cost: "Item cost"
      - rarity: "Item rarity"
      - weight: "Item weight"
      - tags: "Item tags array"
      - properties: "Item properties array"
      - mechanical_stats: "Mechanical data"
      - narrative: "Narrative description"
      - llm_guidance: "AI GM guidance"
      - image_generation: "Art generation prompts"
      - ui: "UI theming data"
  
  # Item Discovery
  GET /api/items/type/{type}:
    description: "Get items by type"
    parameters:
      - type: "Item type (weapon, armor, gear, etc.)"
    response: "Array of item objects"
  
  GET /api/items/class/{class_id}:
    description: "Get items for a class"
    parameters:
      - class_id: "Class identifier"
    response: "Array of item objects"
  
  GET /api/items/rarity/{rarity}:
    description: "Get items by rarity"
    parameters:
      - rarity: "Item rarity (common, uncommon, rare, etc.)"
    response: "Array of item objects"
  
  # Item Validation
  POST /api/items/validate:
    description: "Validate item data"
    body: "Item object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
```

## **2. Character Integration**

### **Character State API**
```yaml
character_endpoints:
  # Character Lookup
  GET /api/characters/{character_id}:
    description: "Get character data"
    parameters:
      - character_id: "Character identifier"
    response:
      - id: "Character ID"
      - name: "Character name"
      - class: "Character class"
      - subclass: "Character subclass"
      - level: "Character level"
      - features: "Array of feature IDs"
      - equipment: "Array of item IDs"
      - connections: "Unified connections array"
      - achieved_unlocks: "Array of unlock IDs"
      - narrative_tags: "Array of narrative tags"
  
  # Character Progression
  POST /api/characters/{character_id}/level_up:
    description: "Level up character"
    body:
      - new_level: "New character level"
      - feature_choices: "Array of selected features"
    response:
      - success: "Boolean success result"
      - new_features: "Array of new feature objects"
      - available_features: "Array of available feature objects"
  
  # Character Feature Management
  POST /api/characters/{character_id}/features:
    description: "Add feature to character"
    body:
      - feature_id: "Feature identifier"
    response:
      - success: "Boolean success result"
      - feature: "Feature object"
      - validation_errors: "Array of validation errors"
  
  DELETE /api/characters/{character_id}/features/{feature_id}:
    description: "Remove feature from character"
    parameters:
      - character_id: "Character identifier"
      - feature_id: "Feature identifier"
    response:
      - success: "Boolean success result"
      - removed_feature: "Removed feature object"
  
  # Character Equipment Management
  POST /api/characters/{character_id}/equipment:
    description: "Equip item on character"
    body:
      - item_id: "Item identifier"
      - slot: "Equipment slot"
    response:
      - success: "Boolean success result"
      - equipped_item: "Item object"
      - validation_errors: "Array of validation errors"
  
  DELETE /api/characters/{character_id}/equipment/{item_id}:
    description: "Unequip item from character"
    parameters:
      - character_id: "Character identifier"
      - item_id: "Item identifier"
    response:
      - success: "Boolean success result"
      - unequipped_item: "Item object"
```

## **3. Game Engine Integration**

### **Mechanical Effects Engine**
```yaml
effects_engine:
  # Effect Resolution
  POST /api/effects/resolve:
    description: "Resolve mechanical effects"
    body:
      - character_id: "Character identifier"
      - effect: "Effect object"
      - context: "Game context object"
    response:
      - resolved_effect: "Resolved effect object"
      - mechanical_changes: "Array of mechanical changes"
      - narrative_impact: "Narrative impact description"
  
  # Effect Validation
  POST /api/effects/validate:
    description: "Validate effect data"
    body: "Effect object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
  
  # Effect Discovery
  GET /api/effects/available/{character_id}:
    description: "Get available effects for character"
    parameters:
      - character_id: "Character identifier"
    response: "Array of available effect objects"
```

### **Action Economy Engine**
```yaml
action_economy:
  # Action Resolution
  POST /api/actions/resolve:
    description: "Resolve character action"
    body:
      - character_id: "Character identifier"
      - action: "Action object"
      - context: "Game context object"
    response:
      - resolved_action: "Resolved action object"
      - mechanical_changes: "Array of mechanical changes"
      - narrative_impact: "Narrative impact description"
  
  # Action Validation
  POST /api/actions/validate:
    description: "Validate action data"
    body: "Action object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
  
  # Available Actions
  GET /api/actions/available/{character_id}:
    description: "Get available actions for character"
    parameters:
      - character_id: "Character identifier"
    response: "Array of available action objects"
```

## **4. LLM-GM Integration**

### **Narrative Generation API**
```yaml
narrative_api:
  # Narrative Generation
  POST /api/narrative/generate:
    description: "Generate narrative content"
    body:
      - character_id: "Character identifier"
      - context: "Game context object"
      - narrative_type: "Type of narrative to generate"
    response:
      - generated_narrative: "Generated narrative content"
      - narrative_tags: "Array of narrative tags"
      - ui_effects: "UI effect recommendations"
  
  # Narrative Validation
  POST /api/narrative/validate:
    description: "Validate narrative content"
    body: "Narrative object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
  
  # Narrative Discovery
  GET /api/narrative/hooks/{character_id}:
    description: "Get narrative hooks for character"
    parameters:
      - character_id: "Character identifier"
    response: "Array of narrative hook objects"
```

### **Image Generation API**
```yaml
image_generation_api:
  # Image Generation
  POST /api/images/generate:
    description: "Generate image from prompt"
    body:
      - base_prompt: "Base image prompt"
      - contextual_modifiers: "Array of contextual modifiers"
      - target_type: "Target image type"
      - character_context: "Character context object"
    response:
      - generated_image: "Generated image data"
      - image_metadata: "Image metadata object"
      - generation_parameters: "Generation parameters used"
  
  # Image Validation
  POST /api/images/validate:
    description: "Validate image generation data"
    body: "Image generation object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
```

## **5. System Integration**

### **Registry API**
```yaml
registry_api:
  # Registry Lookup
  GET /api/registry/{registry_type}:
    description: "Get registry data"
    parameters:
      - registry_type: "Registry type (features, items, relationships, etc.)"
    response: "Registry data object"
  
  # Registry Validation
  POST /api/registry/validate:
    description: "Validate registry data"
    body:
      - registry_type: "Registry type"
      - registry_data: "Registry data object"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
  
  # Registry Discovery
  GET /api/registry/{registry_type}/search:
    description: "Search registry data"
    parameters:
      - registry_type: "Registry type"
      - query: "Search query"
      - filters: "Search filters"
    response: "Array of matching registry entries"
```

### **Validation API**
```yaml
validation_api:
  # System Validation
  POST /api/validation/system:
    description: "Validate entire system"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
      - validation_report: "Detailed validation report"
  
  # File Validation
  POST /api/validation/file:
    description: "Validate specific file"
    body:
      - file_path: "File path"
      - file_type: "File type"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
  
  # Cross-Reference Validation
  POST /api/validation/cross_references:
    description: "Validate cross-references"
    response:
      - valid: "Boolean validation result"
      - errors: "Array of validation errors"
      - warnings: "Array of validation warnings"
      - cross_reference_report: "Detailed cross-reference report"
```

## **6. Implementation Guidelines**

### **API Client Implementation**
```yaml
client_implementation:
  # Authentication
  authentication:
    - "Use API keys for authentication"
    - "Include API key in request headers"
    - "Implement rate limiting and throttling"
  
  # Error Handling
  error_handling:
    - "Handle HTTP status codes appropriately"
    - "Parse and display error messages"
    - "Implement retry logic for transient failures"
  
  # Caching
  caching:
    - "Cache frequently accessed data"
    - "Implement cache invalidation strategies"
    - "Use appropriate cache headers"
  
  # Performance
  performance:
    - "Use pagination for large result sets"
    - "Implement request batching where possible"
    - "Use compression for large responses"
```

### **Game Engine Integration**
```yaml
game_engine_integration:
  # Data Loading
  data_loading:
    - "Load character data on game start"
    - "Cache frequently used data"
    - "Implement lazy loading for large datasets"
  
  # Real-time Updates
  real_time_updates:
    - "Subscribe to character state changes"
    - "Update UI in real-time"
    - "Handle concurrent modifications"
  
  # Offline Support
  offline_support:
    - "Cache essential data locally"
    - "Queue updates for when online"
    - "Handle offline/online transitions"
```

This comprehensive API integration guide provides all the necessary endpoints and guidelines for integrating the SW5e Data Hub with any game engine, application, or external system.
