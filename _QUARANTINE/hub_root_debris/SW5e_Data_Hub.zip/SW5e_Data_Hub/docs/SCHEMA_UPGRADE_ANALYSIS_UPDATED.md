# Schema Upgrade Analysis - Updated

## Overview
This document analyzes all schema files to identify what needs to be updated to match the new "gold standard" structure. The new structure includes narrative blocks for LLM-GM integration, enhanced mechanics, and better organization.

## Key Findings from Current Schema Review

The schema system has evolved significantly with several major achievements:
- **35 total schemas** (not 33 as previously documented)
- **15 schemas completed** with gold standard implementation
- **9 specialized schemas** with advanced systems
- **11 schemas needing refactor** to gold standard
- **Perfect file organization** achieved

## Schema Analysis & Required Updates

### ✅ **COMPLETED SCHEMAS (Gold Standard)**

#### 1. **Power.schema.json** - ✅ **COMPLETED** 
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Comprehensive narrative blocks for LLM-GM integration
- ✅ Power cost and manifestation system
- ✅ Corruption and purification mechanics
- ✅ Example: `data/powers/force_push.yml`

#### 2. **Faction.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Comprehensive narrative blocks for LLM-GM integration
- ✅ Membership perks system
- ✅ Example: `data/factions/jedi_order.yml`

#### 3. **Lore.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Layered knowledge system
- ✅ Unified connections system
- ✅ Example: `data/lore/coruscant.yml`

#### 4. **Item.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Comprehensive narrative integration
- ✅ LLM guidance and image generation
- ✅ Example: `data/items/lightsaber.yml`

#### 5. **Background.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Narrative blocks and unified connections
- ✅ Example: `data/backgrounds/background_jedi.yml`

#### 6. **Starship.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Narrative integration and LLM guidance
- ✅ Example: `data/starships/millennium_falcon.yml`

#### 7. **CraftingRecipe.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Tag requirement system
- ✅ Example: `data/crafting/lightsaber_recipe.yml`

#### 8. **Object.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Hackable interface system
- ✅ Example: `data/objects/imperial_blast_door_controls.yml`

#### 9. **Action.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Narrative blocks and unified connections
- ✅ Example: `data/actions/attack_action.yml`

#### 10. **Status.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Dynamic scaling system
- ✅ Example: `data/status_effects/acid_corrosion.yml`

#### 11. **Combat.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Narrative blocks and LLM guidance
- ✅ Example: `data/combat_actions/lightsaber_parry.yml`

#### 12. **Master_Action.schema.json** - ✅ **COMPLETED**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Unified action system
- ✅ Example: `data/actions/hack_terminal_master.yml`

#### 13. **Species.schema.json** - ✅ **COMPLETED** ⭐ **NEW**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Comprehensive narrative blocks for LLM-GM integration
- ✅ Image generation and UI blocks
- ✅ Unified connections system
- ✅ LLM guidance and cultural significance
- ✅ Example: All 30 species files in `official_species_playable/`

#### 14. **Class.schema.json** - ✅ **COMPLETED** ⭐ **NEW**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Class identity profile with core fantasy and iconic gear
- ✅ Level progression system
- ✅ Narrative integration and LLM guidance
- ✅ Species and faction synergies
- ✅ Example: `data/classes/bounty_hunter.yml`, `data/classes/guardian.yml`

#### 15. **CharacterClassFeature.schema.json** - ✅ **COMPLETED** ⭐ **NEW**
- **Status: GOLD STANDARD IMPLEMENTED**
- ✅ Grant choice effect for power acquisition
- ✅ Comprehensive narrative blocks
- ✅ Power acquisition support with corruption mechanics
- ✅ LLM guidance and image generation
- ✅ Example: `data/features/consular/force_connection.yml`

### ✅ **SPECIALIZED SCHEMAS (Advanced Systems)**

#### 16. **SpeciesProgression.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Advanced progression system
- ✅ Cultural features integration

#### 17. **CulturalFeatures.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Cultural trait system
- ✅ Species cultural abilities

#### 18. **EnvironmentalAdaptations.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Environmental specialization
- ✅ Species adaptations

#### 19. **CharacterCreator.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Creation flow system
- ✅ Character creation process

#### 20. **Gameplay_Example.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Example system
- ✅ Gameplay scenarios

#### 21. **CombatRules.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Combat mechanics
- ✅ Combat system rules

#### 22. **StarshipAction.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Starship action system
- ✅ Starship-specific actions

#### 23. **StarshipCareer.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Career system
- ✅ Starship crew careers

#### 24. **CharacterClassFeature.v2.schema.json** - ✅ **COMPLETED**
- **Status: SPECIALIZED SYSTEM IMPLEMENTED**
- ✅ Enhanced feature system
- ✅ Advanced class features

### 🔄 **SCHEMAS NEEDING REFACTOR**

#### 25. **Companion.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic companion schema
- **Needed Updates:**
  - Add narrative integration
  - Add LLM guidance
  - Add image_generation and ui blocks
  - Add unified connections

#### 26. **CampaignState.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic campaign schema
- **Needed Updates:**
  - Add registry integration
  - Add narrative blocks
  - Add LLM-GM integration
  - Add unified connections

#### 27. **Character.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic character schema
- **Needed Updates:**
  - Add registry references
  - Add narrative blocks
  - Add single source of truth integration
  - Add LLM guidance

#### 28. **Nemesis.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic nemesis schema
- **Needed Updates:**
  - Add registry integration
  - Add narrative blocks
  - Add LLM-GM integration
  - Add unified connections

#### 29. **Adversary.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic adversary schema
- **Needed Updates:**
  - Add narrative integration
  - Add LLM guidance
  - Add image_generation and ui blocks
  - Add unified connections

#### 30. **Creature.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic creature schema
- **Needed Updates:**
  - Add narrative integration
  - Add LLM guidance
  - Add image_generation and ui blocks
  - Add unified connections

#### 31. **StarshipWeapon.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic starship weapon schema
- **Needed Updates:**
  - Add narrative integration
  - Add LLM guidance
  - Add image_generation and ui blocks
  - Add unified connections

#### 32. **Modification.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic modification schema
- **Needed Updates:**
  - Add narrative integration
  - Add LLM guidance
  - Add image_generation and ui blocks
  - Add unified connections

#### 33. **Property.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic property schema
- **Needed Updates:**
  - Add narrative integration
  - Add LLM guidance
  - Add image_generation and ui blocks
  - Add unified connections

#### 34. **Squad.schema.json** - MODERATE UPDATE NEEDED ⚠️
- **Current State:** Basic squad schema
- **Needed Updates:**
  - Add narrative integration
  - Add LLM guidance
  - Add image_generation and ui blocks
  - Add unified connections

## Updated Priority Order for Updates

### **HIGH PRIORITY (Core Systems)** - ✅ **COMPLETED**
1. **Species.schema.json** - ✅ **COMPLETED**
2. **Class.schema.json** - ✅ **COMPLETED**
3. **CharacterClassFeature.schema.json** - ✅ **COMPLETED**

### **MEDIUM PRIORITY (Important Systems)**
4. **Companion.schema.json** - Important for gameplay
5. **Adversary.schema.json** - Important for gameplay
6. **Creature.schema.json** - Important for gameplay
7. **CampaignState.schema.json** - Important for campaigns

### **LOW PRIORITY (Supporting Systems)**
8. **Character.schema.json** - Supporting system
9. **Nemesis.schema.json** - Supporting system
10. **StarshipWeapon.schema.json** - Supporting system
11. **Modification.schema.json** - Supporting system
12. **Property.schema.json** - Supporting system
13. **Squad.schema.json** - Supporting system

## Implementation Strategy

### Phase 1: Core Systems (High Priority) - ✅ **COMPLETED**
- ✅ Refactor Species, Class, and CharacterClassFeature schemas
- ✅ Add gold standard narrative blocks
- ✅ Enhance LLM-GM integration

### Phase 2: Important Systems (Medium Priority) - **NEXT**
- Refactor Companion, Adversary, Creature, and CampaignState schemas
- Add narrative guidance
- Improve LLM-GM integration

### Phase 3: Supporting Systems (Low Priority)
- Refactor remaining schemas
- Add narrative guidance
- Complete system integration

## Benefits of These Updates

1. **Enhanced LLM-GM Integration**: All schemas will have rich narrative content for AI game masters
2. **Better Player Experience**: More flavorful and thematic content
3. **Improved Consistency**: All schemas will follow the same "gold standard" structure
4. **Enhanced Storytelling**: Rich narrative hooks and examples from Star Wars lore
5. **Better Synergies**: Clear connections between different game elements

## Next Steps

1. **Begin Medium Priority Refactors** - Companion, Adversary, Creature, CampaignState
2. **Create example data files** - Show how the new schemas work in practice
3. **Update existing data files** - Refactor current data to match new schemas
4. **Test LLM-GM integration** - Verify that the narrative blocks work well with AI game masters

## Progress Summary

- ✅ **Power.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Faction.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Lore.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Item.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Background.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Starship.schema.json** - COMPLETED with full gold standard implementation
- ✅ **CraftingRecipe.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Object.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Action.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Status.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Combat.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Master_Action.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Species.schema.json** - COMPLETED with full gold standard implementation
- ✅ **Class.schema.json** - COMPLETED with full gold standard implementation
- ✅ **CharacterClassFeature.schema.json** - COMPLETED with full gold standard implementation
- 🔄 **Companion.schema.json** - MEDIUM PRIORITY
- 🔄 **Adversary.schema.json** - MEDIUM PRIORITY
- 🔄 **Creature.schema.json** - MEDIUM PRIORITY
- 🔄 **CampaignState.schema.json** - MEDIUM PRIORITY
- 🔄 **Character.schema.json** - LOW PRIORITY
- 🔄 **Nemesis.schema.json** - LOW PRIORITY
- 🔄 **StarshipWeapon.schema.json** - LOW PRIORITY
- 🔄 **Modification.schema.json** - LOW PRIORITY
- 🔄 **Property.schema.json** - LOW PRIORITY
- 🔄 **Squad.schema.json** - LOW PRIORITY

The schema upgrade analysis shows significant progress with 15 schemas completed to gold standard and 9 specialized schemas implemented. The remaining 11 schemas need refactoring to achieve full system consistency.

---

*Last Updated: 2025-01-27*
*Status: 68.6% complete - 24/35 schemas finished*
