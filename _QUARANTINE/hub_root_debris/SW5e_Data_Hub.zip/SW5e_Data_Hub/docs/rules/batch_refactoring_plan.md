# Batch Feature Refactoring Plan

## Overview
This document outlines the systematic approach to refactor 498 feature files from the old `level_requirement` structure to the new gold standard format.

## Current Analysis

### ✅ **Already Gold Standard** (12 files)
- `guardian/personal_protection.yml`
- `guardian/attack_interception.yml` 
- `guardian/defensive_stance.yml`
- `guardian/force_protection.yml`
- `engineer/overlord/tactical_telemetry.yml`
- `engineer/overlord/signal_booster.yml`
- `soldier/ranger/ranger_marksmanship.yml`
- `soldier/ranger/fieldcraft.yml`
- `mystic/apex_predator/stalker_gait.yml`
- `mystic/beast_warden/survivalist_instincts.yml`
- `mystic/apex_predator/blood_scent.yml`
- `mystic/beast_warden/shared_senses.yml`

### ✅ **Recently Converted** (2 files)
- `bounty_hunter/gadgeteer/tactical_scanner.yml`
- `engineer/rapid_prototyping.yml`

### 🔄 **Need Refactoring** (498 files)
All files with `level_requirement:` field

## Refactoring Patterns

### Pattern 1: Basic Structure Conversion
**Old:**
```yaml
id: "feature_name"
name: "Feature Name"
description: "Description"
level_requirement: X
xp_cost: Y
feature_type: "specialization"
source_class: "class_name"
source_specialization: "subclass_name"
```

**New:**
```yaml
id: "feature_feature_name"
name: "Feature Name"
xp_cost: Y

# --- NARRATIVE BLOCK (The "Soul") ---
narrative: "Rich, multi-sentence description..."
flavor_text: "'Iconic quote' - Character Type"
```

### Pattern 2: Activation → Grant Action
**Old:**
```yaml
activation:
  cost:
    type: "action"
    count: 1
  trigger: "manual"
  frequency: "at_will"
```

**New:**
```yaml
- effect: "grant_action"
  name: "Action Name"
  action_type: "action"
  cost: "1 action"
  description: "What the action does"
```

### Pattern 3: Targeting → Parameters
**Old:**
```yaml
targeting:
  type: "single_creature"
  range:
    value: 5
    unit: "feet"
```

**New:**
```yaml
parameters:
  range: "5 feet"
  target_type: "single_creature"
```

### Pattern 4: Effects → Mechanics
**Old:**
```yaml
effects:
  - type: "healing"
    value: "2d8 + wisdom_modifier"
    target_scopes: ["target"]
```

**New:**
```yaml
- effect: "grant_action"
  name: "Force Healing"
  action_type: "action"
  cost: "1 action"
  description: "Restore 2d8 + Wisdom modifier hit points to a creature you touch"
  parameters:
    healing_amount: "2d8 + wisdom_modifier"
    range: "touch"
```

## Batch Refactoring Strategy

### Phase 1: High-Priority Classes (Week 1)
**Target**: Core classes with most gameplay impact
1. **Guardian** (Jedi Guardian) - 15 files
2. **Consular** (Jedi Consular) - 12 files  
3. **Mystic** (Force Mystic) - 18 files
4. **Engineer** (Tech Engineer) - 10 files

**Total**: 55 files

### Phase 2: Combat Classes (Week 2)
**Target**: Combat-focused classes
1. **Warrior** (Lightsaber Warrior) - 25 files
2. **Bounty Hunter** - 20 files
3. **Soldier** - 15 files
4. **Sentinel** - 20 files

**Total**: 80 files

### Phase 3: Support Classes (Week 3)
**Target**: Support and utility classes
1. **Seeker** (Explorer) - 18 files
2. **Commander** (Leader) - 12 files
3. **Scout** (Ranger) - 10 files
4. **Operative** (Spy) - 15 files

**Total**: 55 files

### Phase 4: Remaining Classes (Week 4)
**Target**: All remaining classes
1. **Diplomat** - 8 files
2. **Smuggler** - 10 files
3. **Colonist** - 8 files
4. **Hired Gun** - 12 files
5. **All others** - 278 files

**Total**: 316 files

## Conversion Rules

### ✅ **Required Conversions**
1. **ID Format**: Add `feature_` prefix to all IDs
2. **Remove Fields**: `level_requirement`, `feature_type`, `source_class`, `source_specialization`
3. **Add Fields**: `narrative`, `flavor_text`, `llm_guidance`, `image_generation`, `ui`
4. **Convert Structure**: `activation` + `targeting` + `effects` → `mechanics` array

### ✅ **Effect Type Mappings**
- `restore_hit_points` → `grant_action` with healing parameters
- `apply_weapon_modification` → `grant_action` with modification parameters
- `area_scan` → `grant_action` with utility parameters
- `healing` → `grant_action` with healing parameters
- `weapon_modification` → `grant_action` with modification parameters

### ✅ **Parameter Standardization**
- `range.value` + `range.unit` → `range: "X feet"`
- `target` → `target_scopes`
- `uses_per_rest` → `parameters.uses_per_rest`
- `frequency` → `parameters.frequency`

## Quality Assurance

### ✅ **Validation Checklist**
For each converted file:
- [ ] ID has `feature_` prefix
- [ ] Has `narrative` and `flavor_text`
- [ ] Has `llm_guidance` block
- [ ] Has `image_generation` block
- [ ] Has `ui` block
- [ ] All effects use valid effect types
- [ ] All parameters use standardized format
- [ ] All conditions use proper format
- [ ] File validates against Feature.schema.json

### ✅ **Testing Strategy**
1. **Schema Validation**: Ensure all files pass schema validation
2. **Effect Resolution**: Test that game engine can resolve all effects
3. **Cross-Reference**: Verify all feature references still work
4. **Performance**: Ensure no performance degradation

## Automation Opportunities

### ✅ **Scriptable Conversions**
1. **ID Prefix Addition**: `id: "name"` → `id: "feature_name"`
2. **Field Removal**: Remove old structure fields
3. **Basic Structure**: Add gold standard template structure
4. **Effect Mapping**: Convert common effect types

### ✅ **Manual Review Required**
1. **Narrative Writing**: Rich descriptions and flavor text
2. **LLM Guidance**: Roleplay and tactical guidance
3. **Image Generation**: Art prompts and UI theming
4. **Complex Effects**: Multi-part or unique effects

## Success Metrics

### ✅ **Completion Targets**
- **Week 1**: 55 files (11% complete)
- **Week 2**: 135 files (27% complete)
- **Week 3**: 190 files (38% complete)
- **Week 4**: 498 files (100% complete)

### ✅ **Quality Targets**
- **Schema Compliance**: 100% of files pass validation
- **Effect Resolution**: 100% of effects can be resolved by engine
- **Cross-Reference Integrity**: 100% of references remain valid
- **Performance**: No degradation in system performance

This systematic approach ensures efficient, consistent refactoring while maintaining quality and preventing constant rework.
