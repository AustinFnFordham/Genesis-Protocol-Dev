# Narrative Tags & Diagetic UI Rules

## Overview
This document defines how narrative tags affect the diagetic UI and create immersive, story-driven user experiences.

## Narrative Tags System

### **Core Narrative Tags**

#### **Emotional State Tags**
- `calm` - Character is at peace, UI shows soft colors and gentle animations
- `focused` - Character is concentrating, UI shows sharp, precise elements
- `agitated` - Character is stressed, UI shows jittery animations and warning colors
- `determined` - Character is resolute, UI shows bold, confident styling
- `fearful` - Character is afraid, UI shows muted colors and defensive positioning
- `angry` - Character is enraged, UI shows aggressive colors and sharp edges
- `hopeful` - Character is optimistic, UI shows bright, uplifting colors
- `despairing` - Character is hopeless, UI shows dark, muted tones

#### **Force Alignment Tags**
- `light_side` - Character is aligned with the light, UI shows blue/white/gold colors
- `dark_side` - Character is aligned with the dark, UI shows red/black/purple colors
- `neutral_force` - Character is balanced, UI shows gray/silver colors
- `force_sensitive` - Character can use the Force, UI shows subtle Force energy effects
- `force_adept` - Character is skilled with the Force, UI shows stronger Force effects
- `force_master` - Character is a Force master, UI shows powerful Force manifestations

#### **Combat State Tags**
- `in_combat` - Character is fighting, UI shows combat-focused layout
- `defensive` - Character is protecting, UI shows shield and protective elements
- `aggressive` - Character is attacking, UI shows weapon and offensive elements
- `stealth` - Character is hidden, UI shows muted, shadowy elements
- `alert` - Character is watchful, UI shows heightened awareness indicators
- `wounded` - Character is injured, UI shows damage indicators and red elements
- `exhausted` - Character is tired, UI shows dimmed elements and fatigue indicators

#### **Social State Tags**
- `friendly` - Character is approachable, UI shows warm, inviting colors
- `hostile` - Character is aggressive, UI shows cold, threatening colors
- `neutral` - Character is indifferent, UI shows balanced, neutral colors
- `trusting` - Character is open, UI shows transparent, honest elements
- `suspicious` - Character is wary, UI shows guarded, defensive elements
- `charismatic` - Character is charming, UI shows attractive, appealing elements
- `intimidating` - Character is frightening, UI shows imposing, threatening elements

### **Diagetic UI Rules**

#### **Color Psychology**
```yaml
color_mapping:
  # Emotional Colors
  calm: "#87CEEB"      # Sky blue - peaceful, serene
  focused: "#4169E1"   # Royal blue - concentration, precision
  agitated: "#FF6347"  # Tomato - stress, urgency
  determined: "#FFD700" # Gold - resolve, strength
  fearful: "#708090"   # Slate gray - fear, uncertainty
  angry: "#DC143C"     # Crimson - rage, aggression
  hopeful: "#98FB98"   # Pale green - optimism, growth
  despairing: "#2F4F4F" # Dark slate gray - hopelessness
  
  # Force Colors
  light_side: "#00BFFF" # Deep sky blue - light side energy
  dark_side: "#8B0000"  # Dark red - dark side energy
  neutral_force: "#C0C0C0" # Silver - balanced Force
  force_sensitive: "#9370DB" # Medium purple - Force awareness
  force_adept: "#4B0082" # Indigo - Force skill
  force_master: "#FF1493" # Deep pink - Force mastery
  
  # Combat Colors
  in_combat: "#FF4500"  # Orange red - combat alert
  defensive: "#32CD32"  # Lime green - protection
  aggressive: "#B22222" # Fire brick - aggression
  stealth: "#696969"    # Dim gray - hidden
  alert: "#FFD700"      # Gold - awareness
  wounded: "#DC143C"    # Crimson - injury
  exhausted: "#2F4F4F"  # Dark slate gray - fatigue
```

#### **Animation Rules**
```yaml
animation_mapping:
  # Emotional Animations
  calm: "gentle_pulse"           # Soft, slow pulsing
  focused: "sharp_focus"         # Sharp, precise movements
  agitated: "jittery_movement"   # Quick, nervous movements
  determined: "bold_swipe"       # Strong, confident movements
  fearful: "defensive_shrink"    # Shrinking, defensive movements
  angry: "aggressive_shake"      # Violent, shaking movements
  hopeful: "uplifting_rise"      # Rising, uplifting movements
  despairing: "sinking_fade"     # Sinking, fading movements
  
  # Force Animations
  light_side: "gentle_glow"      # Soft, warm glow
  dark_side: "dark_pulse"        # Dark, menacing pulse
  neutral_force: "balanced_flow" # Balanced, flowing energy
  force_sensitive: "subtle_ripple" # Subtle energy ripples
  force_adept: "strong_flow"     # Strong energy flow
  force_master: "powerful_aura"  # Powerful energy aura
  
  # Combat Animations
  in_combat: "combat_alert"      # Alert, ready animations
  defensive: "shield_effect"     # Protective shield effects
  aggressive: "weapon_ready"     # Weapon preparation animations
  stealth: "shadow_movement"     # Shadowy, hidden movements
  alert: "heightened_awareness"  # Enhanced awareness indicators
  wounded: "damage_flash"        # Damage indication flashes
  exhausted: "fatigue_dimming"   # Dimming, fatigue effects
```

#### **Layout Rules**
```yaml
layout_mapping:
  # Emotional Layouts
  calm: "centered_balanced"      # Centered, balanced layout
  focused: "narrow_focused"      # Narrow, focused layout
  agitated: "scattered_chaotic"  # Scattered, chaotic layout
  determined: "bold_structured"  # Bold, structured layout
  fearful: "defensive_clustered" # Defensive, clustered layout
  angry: "aggressive_spread"     # Aggressive, spread layout
  hopeful: "uplifting_expanded"  # Uplifting, expanded layout
  despairing: "collapsed_minimal" # Collapsed, minimal layout
  
  # Force Layouts
  light_side: "radiant_centered" # Radiant, centered layout
  dark_side: "dark_cornered"     # Dark, cornered layout
  neutral_force: "balanced_symmetrical" # Balanced, symmetrical layout
  force_sensitive: "energy_flow" # Energy flowing layout
  force_adept: "powerful_structured" # Powerful, structured layout
  force_master: "transcendent_ethereal" # Transcendent, ethereal layout
  
  # Combat Layouts
  in_combat: "tactical_grid"     # Tactical, grid-based layout
  defensive: "protective_circle" # Protective, circular layout
  aggressive: "offensive_linear" # Offensive, linear layout
  stealth: "hidden_overlay"      # Hidden, overlay layout
  alert: "heightened_awareness"  # Heightened awareness layout
  wounded: "damage_indicators"   # Damage indicator layout
  exhausted: "minimal_essential" # Minimal, essential layout
```

### **Tag Combination Rules**

#### **Priority System**
1. **Combat State** (highest priority) - Overrides emotional and social states
2. **Force Alignment** (medium priority) - Influences but doesn't override combat
3. **Emotional State** (low priority) - Influences but doesn't override combat or Force
4. **Social State** (lowest priority) - Influences but doesn't override others

#### **Combination Examples**
```yaml
tag_combinations:
  # Combat + Force + Emotional
  "in_combat + light_side + determined":
    color: "#00BFFF"  # Light side blue
    animation: "combat_alert"
    layout: "tactical_grid"
    effect: "Light side energy flows through combat actions"
  
  # Force + Emotional + Social
  "dark_side + angry + hostile":
    color: "#8B0000"  # Dark red
    animation: "dark_pulse"
    layout: "dark_cornered"
    effect: "Dark side energy amplifies anger and hostility"
  
  # Emotional + Social
  "calm + friendly + trusting":
    color: "#87CEEB"  # Sky blue
    animation: "gentle_pulse"
    layout: "centered_balanced"
    effect: "Calm, friendly energy creates welcoming atmosphere"
```

### **UI Element Rules**

#### **Health/Status Bars**
- **Calm**: Soft blue, gentle pulsing
- **Focused**: Sharp blue, precise movements
- **Agitated**: Orange, jittery movements
- **Determined**: Gold, bold movements
- **Fearful**: Gray, defensive positioning
- **Angry**: Red, aggressive movements
- **Hopeful**: Green, uplifting movements
- **Despairing**: Dark gray, fading movements

#### **Action Buttons**
- **Calm**: Soft, rounded buttons with gentle hover effects
- **Focused**: Sharp, precise buttons with quick responses
- **Agitated**: Jittery buttons with nervous hover effects
- **Determined**: Bold, strong buttons with confident responses
- **Fearful**: Defensive buttons with protective hover effects
- **Angry**: Aggressive buttons with sharp hover effects
- **Hopeful**: Bright, uplifting buttons with positive responses
- **Despairing**: Dimmed buttons with minimal responses

#### **Navigation Elements**
- **Calm**: Smooth, flowing transitions
- **Focused**: Quick, precise transitions
- **Agitated**: Quick, nervous transitions
- **Determined**: Strong, confident transitions
- **Fearful**: Slow, cautious transitions
- **Angry**: Fast, aggressive transitions
- **Hopeful**: Uplifting, positive transitions
- **Despairing**: Slow, dragging transitions

### **Implementation Guidelines**

#### **Tag Application**
1. **Character State**: Apply tags based on current character state
2. **Context Awareness**: Consider environmental and situational factors
3. **Dynamic Updates**: Update tags as character state changes
4. **Consistency**: Maintain consistent tag application across all UI elements

#### **Performance Considerations**
1. **Tag Caching**: Cache frequently used tag combinations
2. **Animation Optimization**: Use efficient animations for mobile devices
3. **Color Accessibility**: Ensure color combinations are accessible
4. **Responsive Design**: Adapt tag effects for different screen sizes

#### **Accessibility**
1. **Color Blind Support**: Provide alternative indicators for color-based effects
2. **Motion Sensitivity**: Allow users to disable animations
3. **High Contrast**: Provide high contrast modes for better visibility
4. **Screen Reader**: Ensure tag effects are communicated to screen readers

This system creates a truly immersive, story-driven UI that responds to the character's emotional, Force, combat, and social states, making the interface feel like a natural extension of the character's experience.
