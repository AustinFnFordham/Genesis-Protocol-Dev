# Feature Refactoring Rules and Patterns
## The Definitive Unified Standard for SW5e Features

## Overview
This document outlines the **final, unified standard** for SW5e features that combines **engine clarity** with **LLM richness** - the perfect "middle ground" that serves both the game engine and AI-GM systems without compromise.

## The Final Unified Schema

### ✅ **Engine-First Mechanics**
The core mechanics are structured for unambiguous engine parsing:
- `mechanics` - Structured effects with `grant_action` pattern
- `action_name` - Clear identification of granted actions
- `skill_check` - Structured ability and skill requirements
- `on_success` - Nested effects and benefits
- `target` and `range` - Precise targeting specifications

### ✅ **LLM-Rich Narrative**
Rich context for AI-GM systems:
- `narrative` - The "Soul" - rich, multi-sentence descriptions
- `flavor_text` - Iconic quotes and flavor
- `llm_guidance` - Comprehensive AI guidance
- `image_generation` - Cinematic art prompts
- `ui` - Consistent theming and iconography

## Current Feature Analysis

### ✅ **Gold Standard Features** (Engine-First Structure)
These features follow the new `grant_action` pattern perfectly:
- `bounty_hunter/gadgeteer/tactical_scanner.yml` - ✅ **COMPLETED** - Uses `grant_action` with structured area scanning
- `engineer/rapid_prototyping.yml` - ✅ **COMPLETED** - Uses `grant_action` with prototyping mechanics
- `consular/sage/force_healing.yml` - ✅ **COMPLETED** - Uses `grant_action` with healing mechanics
- `mystic/prophet/spiritual_guidance.yml` - ✅ **COMPLETED** - Uses `grant_action` with guidance mechanics
- `engineer/scientist/experimental_methods.yml` - ✅ **COMPLETED** - Uses `grant_action` with experiment mechanics

### 🔄 **Needs Refactoring** (Older Structure)
These features use older patterns and need updating to the `grant_action` structure:
- `guardian/personal_protection.yml` - Uses old `modify_stat` structure
- `guardian/attack_interception.yml` - Uses old `modify_stat` structure
- `guardian/defensive_stance.yml` - Uses old `modify_stat` structure
- `guardian/force_protection.yml` - Uses old `modify_stat` structure

## Standardized Effect Types

### ✅ **Primary Effect Type** (Engine-First Standard)
1. **`grant_action`** - The definitive effect type for all features
   - **`action_name`** - Clear identification of the granted action
   - **`target`** - What the action targets (self, creature, area, etc.)
   - **`skill_check`** - Structured ability and skill requirements
   - **`on_success`** - Nested effects and benefits
   - **`frequency`** - Usage limitations (per_long_rest, etc.)
   - **`uses_per_rest`** - Number of uses per rest period

### ✅ **Nested Effect Types** (Within `on_success`)
- **`restore_hit_points`** - Healing effects
- **`area_scan`** - Information gathering
- **`create_prototype`** - Device creation
- **`provide_guidance`** - Spiritual/mental effects
- **`grant_advantage`** - Advantage/disadvantage effects
- **`modify_stat`** - Stat modifications

### ❌ **Deprecated Effect Types** (Convert to `grant_action`)
- Direct `modify_stat` → Convert to `grant_action` with nested `modify_stat`
- Direct `area_scan` → Convert to `grant_action` with nested `area_scan`
- Direct `create_device` → Convert to `grant_action` with nested `create_prototype`

## Standardized Parameters

### ✅ **Valid Parameters**
- `target_stat` - Must use standardized stat names
- `value` - Modification amount
- `target_scopes` - Who the effect applies to
- `duration` - How long the effect lasts
- `range` - Range or area of effect
- `radius` - Radius for area effects
- `trigger` - What triggers the effect
- `conditions` - Conditions that must be met

### ✅ **Valid Target Stats**
- Core: `strength`, `dexterity`, `constitution`, `intelligence`, `wisdom`, `charisma`
- Derived: `ac`, `hp`, `speed`
- Skills: `stealth_bonus`, `survival_bonus`, `perception_bonus`, `ranged_attack_bonus`, `melee_attack_bonus`
- Special: `control_range`, `tactical_awareness`

### ✅ **Valid Target Scopes**
- `self` - Only affects the character
- `bonded_companion` - Affects the character's companion
- `allies_within_radius` - Affects allies within specified range
- `enemies_within_radius` - Affects enemies within specified range

## Action Economy Standards

### ✅ **Action Types**
- `action` - Standard action
- `bonus_action` - Bonus action  
- `reaction` - Reaction
- `free_action` - Free action

### ✅ **Cost Format**
Always use: `"1 [action_type]"` (e.g., "1 bonus action", "1 reaction")

### ✅ **Consistency Rule**
- `action_type: "bonus_action"` AND `cost: "1 bonus action"` are equivalent
- Engine should interpret both as the same thing

## Condition Logic Standards

### ✅ **Condition Format**
```yaml
conditions:
  - key: "condition_name"
    op: "=="
    value: true
```

### ✅ **Valid Operators**
- `==` - Equals
- `!=` - Not equals
- `>` - Greater than
- `<` - Less than
- `>=` - Greater than or equal
- `<=` - Less than or equal
- `in` - Value is in array
- `contains` - Array contains value

## Refactoring Patterns

### Pattern 1: Activation 
```yaml
activation:
  cost:
    type: "action"
    count: 1
  trigger: "manual"
```

### Pattern 2:  Targeting 
```yaml
targeting:
  type: "area"
  range:
    value: 60
    unit: "feet"
```


### Pattern 3: Effects
**Old:**
```yaml
effects:
  - type: "area_scan"
    value: "tactical_information"
```

**New:**
```yaml
- effect: "grant_action"
  name: "Tactical Scan"
  action_type: "action"
  cost: "1 action"
  description: "Scan area for tactical information"
  parameters:
    range: "60 feet"
    information: ["creature_locations", "health_status", "weapons_equipment"]
```

## Validation Rules

### ✅ **Required Fields**
Every feature must have:
- `id` - Unique identifier
- `name` - Display name
- `xp_cost` - Experience cost
- `narrative` - Rich description
- `mechanics` - Array of effects

### ✅ **Mechanics Validation**
Every mechanic must have:
- `effect` - Valid effect type
- `description` - Human-readable description

### ✅ **Effect-Specific Validation**
- `modify_stat` must have `target_stat` and `value`
- `grant_action` must have `name`, `action_type`, and `cost`
- `grant_advantage` must have `type` and `condition`

## The Definitive Unified Structure

### ✅ **Complete Feature Template** (Engine-First Standard)
```yaml
id: "feature_example"
name: "Example Feature"
xp_cost: 25

# --- NARRATIVE BLOCK (The "Soul") ---
narrative: "Rich, multi-sentence description for the LLM-GM."
flavor_text: "'Iconic quote or flavor text.' - Source"

# --- THE ENGINE-READY MECHANICS ---
mechanics:
  - effect: "grant_action"
    description: "As an action, you can [describe what the action does]. Make a [Ability] ([Skill]) check; on a success, [describe the benefits]."
    action_name: "[Action Name]"
    target: "[target_type]"  # self, creature, area, etc.
    range:  # optional
      value: 60
      unit: "feet"
    frequency: "per_long_rest"  # optional
    uses_per_rest: 1  # optional
    skill_check:  # optional
      ability: "[Ability]"
      skill: "[skill]"
    on_success:
      effects:
        - type: "[nested_effect_type]"
          description: "[Description of the effect]"
          target: "[target]"
          parameters:
            [parameter_name]: "[value]"
          benefits:  # optional
            - type: "[benefit_type]"

# --- LLM-GM INTEGRATION ---
llm_guidance:
  roleplay_guidance: "How this ability should feel in roleplay."
  tactical_notes: "Tactical considerations and usage tips."
  narrative_hooks:
    - "Example narrative hook 1"
    - "Example narrative hook 2"

# --- IMAGE GENERATION & UI ---
image_generation:
  base_prompt: "Cinematic description for AI art generation."
  base_negative_keywords: ["unwanted", "elements"]

ui:
  image: "/assets/images/features/example.png"
  icon: "/assets/icons/features/example.svg"
  color: "#FF0000"
```

## Conversion Examples

### Example 1: Tactical Scanner - Final Unified Version
**The Perfect "Middle Ground":**
```yaml
id: "feature_tactical_scanner"
name: "Tactical Scanner"
xp_cost: 100

narrative: "Your advanced scanning technology allows you to quickly analyze an area and gather comprehensive tactical intelligence..."
flavor_text: "'Knowledge is power, and I have both.' - A Gadgeteer Bounty Hunter"

# --- THE ENGINE-READY MECHANICS ---
mechanics:
  - effect: "grant_action"
    description: "As an action, you can scan an area within 60 feet to gather tactical intelligence. The scan reveals the locations, health status, and equipment of all creatures in the area for 1 minute."
    action_name: "Tactical Scanner"
    target: "area"
    range:
      value: 60
      unit: "feet"
    on_success:
      effects:
        - type: "area_scan"
          description: "Reveals the locations, health status, and equipment of all creatures in the area for 1 minute."
          target: "area"
          parameters:
            duration_in_rounds: 10
            information_revealed: ["creature_locations", "health_status", "weapons_equipment"]

# --- ALL OTHER SYSTEMS ---
llm_guidance: # ... rich AI guidance
image_generation: # ... cinematic prompts
ui: # ... consistent theming
```

### Example 2: Rapid Prototyping Conversion
**Before (Old Structure):**
```yaml
mechanics:
  - effect: "grant_advantage"
    description: "You have advantage on Intelligence (Technology) checks when creating prototypes, modifying existing technology, or developing new solutions."
    parameters:
      skill: "Technology"
      condition: "prototyping_activities"
```

**After (New Structure):**
```yaml
mechanics:
  - effect: "grant_action"
    description: "As an action, you can rapidly prototype a technological device. Make an Intelligence (Technology) check; on a success, you create a simple technological device or modification that functions for 1 hour."
    action_name: "Rapid Prototyping"
    target: "self"
    skill_check:
      ability: "Intelligence"
      skill: "technology"
    on_success:
      effects:
        - type: "create_prototype"
          description: "Create a simple technological device or modification."
          target: "self"
          parameters:
            device_type: "simple_technological_device"
            duration_hours: 1
        - type: "grant_advantage"
          description: "You have advantage on Intelligence (Technology) checks when creating prototypes, modifying existing technology, or developing new solutions."
          target: "self"
          parameters:
            skill: "Technology"
            condition: "prototyping_activities"
```

## Key Benefits of the Unified Standard

### ✅ **Engine Clarity**
- **No Natural Language Parsing**: Engine reads structured data, not text
- **Unambiguous Actions**: `grant_action` with clear `action_name` and `target`
- **Structured Skill Checks**: `skill_check` with `ability` and `skill` fields
- **Nested Effects**: `on_success` with structured `effects` and `benefits`
- **Machine-Readable Parameters**: All data is structured and unambiguous

### ✅ **LLM Richness**
- **Rich Narrative**: Multi-sentence descriptions for AI-GM systems
- **Comprehensive Guidance**: Roleplay, tactical, and narrative hooks
- **Cinematic Art**: Detailed prompts for AI image generation
- **Consistent Theming**: UI colors and iconography

### ✅ **Perfect Middle Ground**
- **Engine-First Mechanics**: Structured for unambiguous parsing
- **LLM-Rich Context**: Rich narrative and guidance blocks
- **No Compromise**: Both systems get exactly what they need
- **Future-Proof**: Extensible and maintainable architecture

## Implementation Status

### ✅ **Completed Refactors** (Engine-First Standard)
- `tactical_scanner.yml` - ✅ **COMPLETED** - Uses `grant_action` with area scanning
- `rapid_prototyping.yml` - ✅ **COMPLETED** - Uses `grant_action` with prototyping mechanics
- `force_healing.yml` - ✅ **COMPLETED** - Uses `grant_action` with healing mechanics
- `spiritual_guidance.yml` - ✅ **COMPLETED** - Uses `grant_action` with guidance mechanics
- `experimental_methods.yml` - ✅ **COMPLETED** - Uses `grant_action` with experiment mechanics

### 🔄 **Next Steps**
1. **Apply `grant_action` standard** to remaining 471 features
2. **Update Feature.schema.json** to reflect the new structure
3. **Validate against schema** for consistency
4. **Test engine integration** with structured mechanics
5. **Document all nested effect types** for comprehensive coverage

This definitive unified standard represents the perfect balance between engine clarity and LLM richness - the final architecture that serves both systems without compromise.
