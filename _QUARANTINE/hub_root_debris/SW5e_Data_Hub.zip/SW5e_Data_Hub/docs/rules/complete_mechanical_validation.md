# Complete Mechanical Validation System

## Overview
This document provides comprehensive validation rules for all mechanical elements in the SW5e Data Hub system, ensuring game engine compatibility and preventing runtime errors.

## **1. Feature Validation**

### **Required Fields Validation**
```yaml
feature_validation:
  required_fields:
    - id: "Must be unique, follow naming convention"
    - name: "Must be human-readable display name"
    - xp_cost: "Must be non-negative integer"
    - narrative: "Must be rich, multi-sentence description"
    - mechanics: "Must be array of valid mechanical effects"
  
  optional_fields:
    - flavor_text: "Thematic quote or description"
    - corruption_transform: "Alignment transformation rules"
    - llm_guidance: "AI GM guidance and narrative hooks"
    - image_generation: "Art generation prompts and modifiers"
    - ui: "UI theming and visual elements"
```

### **Mechanics Validation**
```yaml
mechanics_validation:
  # Effect Type Validation
  valid_effects:
    - "modify_stat"      # Stat modifications
    - "grant_action"     # New actions
    - "grant_advantage"  # Advantage/disadvantage
    - "aura"            # Area effects
    - "field"           # Environmental effects
    - "utility"         # Utility abilities
    - "control_connection" # Companion control
    - "damage_sharing"  # Damage distribution
    - "summon_spirit"   # Summoned entities
  
  # Parameter Validation
  modify_stat_required:
    - "target_stat"     # Must be valid stat name
    - "value"           # Must be number or "+X" string
    - "target_scopes"   # Must be valid scope array
  
  grant_action_required:
    - "name"            # Action display name
    - "action_type"     # Must be: action, bonus_action, reaction, free_action
    - "cost"            # Must match action_type format
  
  # Stat Name Validation
  valid_stats:
    core_stats: ["strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma"]
    derived_stats: ["ac", "hp", "speed"]
    skill_bonuses: ["stealth_bonus", "survival_bonus", "perception_bonus", "ranged_attack_bonus", "melee_attack_bonus"]
    special_stats: ["control_range", "tactical_awareness"]
  
  # Target Scope Validation
  valid_scopes:
    - "self"                    # Only affects the character
    - "bonded_companion"        # Affects the character's companion
    - "allies_within_radius"    # Affects allies within specified range
    - "enemies_within_radius"   # Affects enemies within specified range
```

### **Action Economy Validation**
```yaml
action_economy_validation:
  # Action Type Consistency
  action_type_consistency:
    rule: "action_type and cost must match"
    examples:
      - action_type: "bonus_action" → cost: "1 bonus action"
      - action_type: "reaction" → cost: "1 reaction"
      - action_type: "action" → cost: "1 action"
      - action_type: "free_action" → cost: "1 free action"
  
  # Cost Format Validation
  cost_format:
    pattern: "^\\d+\\s+(action|bonus action|reaction|free action)$"
    examples:
      - "1 action" ✓
      - "1 bonus action" ✓
      - "1 reaction" ✓
      - "1 free action" ✓
      - "2 actions" ✓
      - "1 turn" ✗
      - "1 round" ✗
  
  # Duration Validation
  valid_durations:
    - "permanent"                    # Always active
    - "concentration, up to 1 minute"   # Requires concentration
    - "concentration, up to 10 minutes" # Requires concentration
    - "concentration, up to 1 hour"     # Requires concentration
    - "until end of turn"           # Lasts until end of current turn
    - "until start of next turn"    # Lasts until start of next turn
    - "1 minute"                    # Lasts for 1 minute
    - "1 hour"                      # Lasts for 1 hour
```

## **2. Class Validation**

### **Required Fields Validation**
```yaml
class_validation:
  required_fields:
    - id: "Must be unique, follow naming convention"
    - name: "Must be human-readable display name"
    - narrative: "Must be rich, multi-sentence description"
    - class_identity_profile: "Must contain all required sub-fields"
    - hit_die: "Must be valid dice format (e.g., '1d10')"
    - proficiencies: "Must contain valid proficiency arrays"
    - primary_ability: "Must be valid ability score or combination"
    - primary_resource: "Must be defined resource type"
  
  class_identity_profile_required:
    - core_fantasy: "Single sentence defining playstyle"
    - key_attributes: "Array of primary ability scores"
    - iconic_gear: "Array of associated equipment"
    - role_in_galaxy: "Description of galactic role"
    - famous_exemplars: "Array of famous characters"
    - species_synergies: "Array of species connections"
    - faction_synergies: "Array of faction connections"
```

### **Proficiency Validation**
```yaml
proficiency_validation:
  # Armor Proficiency
  valid_armor:
    - "light"
    - "medium"
    - "heavy"
    - "shields"
  
  # Weapon Proficiency
  valid_weapons:
    - "simple weapons"
    - "martial weapons"
    - "lightsabers"
    - "blaster pistols"
    - "blaster rifles"
    - "heavy weapons"
    - "vibroweapons"
  
  # Tool Proficiency
  valid_tools:
    - "meditation kit"
    - "force imbued items"
    - "protective gear"
    - "military kit"
    - "tactical equipment"
    - "heavy weapons"
    - "armor repair kit"
  
  # Saving Throw Proficiency
  valid_saving_throws:
    - "strength"
    - "dexterity"
    - "constitution"
    - "intelligence"
    - "wisdom"
    - "charisma"
  
  # Skill Proficiency
  valid_skills:
    - "athletics"
    - "insight"
    - "intimidation"
    - "perception"
    - "persuasion"
    - "survival"
    - "technology"
    - "vehicles"
    - "medicine"
    - "investigation"
    - "nature"
    - "stealth"
```

## **3. Subclass Validation**

### **Required Fields Validation**
```yaml
subclass_validation:
  required_fields:
    - id: "Must be unique, follow naming convention"
    - class_id: "Must reference valid class"
    - name: "Must be human-readable display name"
    - alignment_theme: "Must be valid alignment"
    - talent_tree_theme: "Must contain all required sub-fields"
    - narrative: "Must be rich, multi-sentence description"
    - subclass_identity_profile: "Must contain all required sub-fields"
    - talent_tree: "Must be array of valid talent nodes"
    - llm_guidance: "Must contain AI GM guidance"
  
  talent_tree_theme_required:
    - background_diorama: "Narrative description of background scene"
    - node_style: "Description of talent node appearance"
    - connection_style: "Description of connection lines"
    - color_palette: "Must contain primary and secondary colors"
    - ambient_audio: "Description of background audio"
  
  subclass_identity_profile_required:
    - core_fantasy: "Single sentence defining playstyle"
    - key_attributes: "Array of primary ability scores"
    - iconic_gear: "Array of associated equipment"
    - role_in_galaxy: "Description of galactic role"
    - famous_exemplars: "Array of famous characters"
    - species_synergies: "Array of species connections"
    - faction_synergies: "Array of faction connections"
```

### **Talent Tree Validation**
```yaml
talent_tree_validation:
  # Node Validation
  node_required_fields:
    - id: "Must be unique within subclass"
    - feature_id: "Must reference valid feature"
    - xp_cost: "Must be non-negative integer"
    - tier: "Must be integer 1-5"
    - column: "Must be integer 1-5"
  
  node_optional_fields:
    - prerequisites: "Array of prerequisite node IDs"
    - connections: "Array of connected node IDs"
  
  # Tier Validation
  tier_validation:
    tier_1: "Foundation talents, 5 XP each"
    tier_2: "Advanced techniques, 10 XP each"
    tier_3: "Mastery techniques, 15 XP each"
    tier_4: "Legendary techniques, 20 XP each"
    tier_5: "Legendary mastery, 25 XP each"
  
  # Prerequisite Validation
  prerequisite_validation:
    rule: "All prerequisites must exist in the same talent tree"
    validation: "Check that all prerequisite IDs exist in talent_tree array"
  
  # Connection Validation
  connection_validation:
    rule: "All connections must exist in the same talent tree"
    validation: "Check that all connection IDs exist in talent_tree array"
```

## **4. Item Validation**

### **Required Fields Validation**
```yaml
item_validation:
  required_fields:
    - id: "Must be unique, follow naming convention"
    - name: "Must be human-readable display name"
    - type: "Must be valid item type"
    - subtype: "Must be valid subtype for type"
    - description: "Must be rich, multi-sentence description"
    - cost: "Must be non-negative number"
    - rarity: "Must be valid rarity level"
    - weight: "Must be non-negative number"
    - tags: "Must be array of valid tags"
    - properties: "Must be array of valid properties"
    - mechanical_stats: "Must contain valid mechanical data"
  
  # Item Type Validation
  valid_types:
    - "weapon"
    - "armor"
    - "gear"
    - "consumable"
    - "focus"
    - "tool"
  
  # Rarity Validation
  valid_rarities:
    - "common"
    - "uncommon"
    - "rare"
    - "very_rare"
    - "legendary"
    - "artifact"
```

### **Mechanical Stats Validation**
```yaml
mechanical_stats_validation:
  # Weapon Stats
  weapon_stats_required:
    - damage: "Must be valid damage dice format"
    - damage_type: "Must be valid damage type"
    - range: "Must be valid range (melee, ranged, or specific distance)"
    - properties: "Must be array of valid weapon properties"
  
  # Armor Stats
  armor_stats_required:
    - ac: "Must be non-negative integer"
    - ac_type: "Must be valid AC type"
    - max_dex: "Must be non-negative integer"
  
  # Gear Stats
  gear_stats_required:
    - special: "Must describe special ability or effect"
  
  # Valid Damage Types
  valid_damage_types:
    - "force"
    - "kinetic"
    - "energy"
    - "thermal"
    - "ion"
    - "sonic"
    - "psychic"
    - "necrotic"
    - "radiant"
  
  # Valid Weapon Properties
  valid_weapon_properties:
    - "finesse"
    - "versatile"
    - "two-handed"
    - "light"
    - "heavy"
    - "thrown"
    - "reach"
    - "ammunition"
    - "loading"
    - "special"
```

## **5. Connection Validation**

### **Required Fields Validation**
```yaml
connection_validation:
  required_fields:
    - target_id: "Must reference valid entity"
    - target_type: "Must be valid entity type"
    - relationship_id: "Must reference valid relationship"
    - narrative: "Must be rich, multi-sentence description"
  
  # Target Type Validation
  valid_target_types:
    - "faction"
    - "species"
    - "class"
    - "subclass"
    - "location"
    - "item"
    - "power"
    - "background"
    - "starship"
    - "companion"
    - "adversary"
  
  # Relationship ID Validation
  relationship_id_validation:
    rule: "Must exist in data/registry/relationships.yml"
    validation: "Check that relationship_id exists in relationships registry"
```

## **6. Cross-Reference Validation**

### **Feature Cross-References**
```yaml
feature_cross_references:
  # Class References
  class_references:
    rule: "Feature class must exist in classes registry"
    validation: "Check that class_id exists in classes directory"
  
  # Subclass References
  subclass_references:
    rule: "Feature subclass must exist in subclasses registry"
    validation: "Check that subclass_id exists in subclasses directory"
  
  # Feature References
  feature_references:
    rule: "Referenced features must exist in features directory"
    validation: "Check that all feature_id references exist in features directory"
```

### **Item Cross-References**
```yaml
item_cross_references:
  # Class References
  class_references:
    rule: "Item class must exist in classes registry"
    validation: "Check that class_id exists in classes directory"
  
  # Subclass References
  subclass_references:
    rule: "Item subclass must exist in subclasses registry"
    validation: "Check that subclass_id exists in subclasses directory"
```

## **7. Validation Implementation**

### **Validation Script Structure**
```yaml
validation_script:
  # File Validation
  file_validation:
    - "Check required fields exist"
    - "Validate field types and formats"
    - "Check cross-references"
    - "Validate mechanical consistency"
  
  # System Validation
  system_validation:
    - "Check all feature IDs are unique"
    - "Check all class IDs are unique"
    - "Check all subclass IDs are unique"
    - "Check all item IDs are unique"
  
  # Cross-System Validation
  cross_system_validation:
    - "Check feature references in classes"
    - "Check feature references in subclasses"
    - "Check item references in classes"
    - "Check relationship references in connections"
```

### **Error Reporting**
```yaml
error_reporting:
  # Error Types
  error_types:
    - "missing_required_field"
    - "invalid_field_type"
    - "invalid_field_format"
    - "invalid_reference"
    - "duplicate_id"
    - "mechanical_inconsistency"
  
  # Error Messages
  error_messages:
    missing_required_field: "Required field '{field}' is missing from {file}"
    invalid_field_type: "Field '{field}' has invalid type. Expected {expected}, got {actual}"
    invalid_field_format: "Field '{field}' has invalid format. Expected {format}, got {value}"
    invalid_reference: "Reference '{reference}' in field '{field}' does not exist"
    duplicate_id: "ID '{id}' is duplicated in {file1} and {file2}"
    mechanical_inconsistency: "Mechanical inconsistency in {file}: {description}"
```

This comprehensive validation system ensures that all mechanical elements are properly defined, consistent, and compatible with the game engine, preventing runtime errors and ensuring a smooth gameplay experience.
