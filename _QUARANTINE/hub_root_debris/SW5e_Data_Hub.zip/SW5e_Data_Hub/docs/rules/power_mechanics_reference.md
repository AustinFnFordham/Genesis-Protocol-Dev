# Power Mechanics Reference Guide
## Gold Standard Mechanical Patterns for SW5e Data Hub

### Time Conversions for Engine
- **1 round** = 6 seconds
- **1 minute** = 10 rounds  
- **1 hour** = 600 rounds (60 minutes)
- **8 hours** = 4,800 rounds
- **24 hours** = 14,400 rounds

### Core Mechanical Types

#### Damage Mechanics
```yaml
mechanics:
  - type: apply_damage
    value: 1d4_[damage_type]  # fire, acid, lightning, force, psychic, necrotic, etc.
    target_scopes: [target]
    notes: "Deal 1d4 [type] damage to target"
    
  - type: area_damage
    value: 6d6_force
    target_scopes: [area]
    conditions:
      - key: within_20_foot_radius
        op: equals
        value: true
    notes: "Dexterity save or take 6d6 force damage"
    
  - type: single_target_damage
    value: 2d6_force
    target_scopes: [target]
    conditions:
      - key: target_failed_save
        op: equals
        value: true
```

#### Status Effects
```yaml
mechanics:
  - type: apply_status
    value: choked  # frightened, prone, disabled, fear, memory_wipe, etc.
    target_scopes: [target]
    duration: 1_round  # or specific round count
    conditions:
      - key: target_failed_save
        op: equals
        value: true
```

#### Movement Mechanics
```yaml
mechanics:
  - type: enhance_movement
    value: jump_distance_doubled  # +2_distance, omnidirectional_leap
    condition: non_combat_use
    
  - type: forced_movement
    value: 10_feet_away
    target_scopes: [target]
```

#### Advantage/Disadvantage
```yaml
mechanical_benefit:
  - type: grant_advantage
    condition: intimidation_attempts  # against_humans, against_electronic_devices_and_droids
    target_scopes: [self]
    
  - type: apply_disadvantage
    condition: next_attack_roll
    duration: 1_round
    target_scopes: [target]
```

#### Damage Enhancement
```yaml
mechanical_benefit:
  - type: enhance_damage
    value: +2_damage  # double_damage, +1_damage
    condition: melee_combat  # emotional_state, strong_negative_emotions, aggressive_use
    target_scopes: [target]
    notes: "Additional damage when condition met"
```

#### Attack Enhancement
```yaml
mechanical_benefit:
  - type: enhance_attack
    value: +2_attack_rolls
    condition: intimidation_attempts  # defensive_use, against_rebel_technology
    target_scopes: [self]
```

#### DC Enhancement
```yaml
mechanical_benefit:
  - type: enhance_dc
    value: +2_saving_throw_dc
    condition: diplomatic_use  # peaceful_purposes, defensive_use
    target_scopes: [target]
```

#### Action Economy
```yaml
mechanical_benefit:
  - type: additional_action
    action_type: bonus_action  # reaction, melee_attack
    timing: as_part_of_this_action
    condition: after_attack_action
    
  - type: reaction_trigger
    trigger: taking_damage  # ally_attacked_within_range, taking_damage_from_multiple_enemies
    action_type: reaction
```

#### Special Effects
```yaml
mechanical_benefit:
  - type: redirect_attack
    target_scopes: [original_attacker]
    
  - type: protect_ally
    range: adjacent
    
  - type: enhance_deflection
    value: omnidirectional  # +2_redirect_bonus
    
  - type: modify_effect
    value: 5_feet_push_distance
    condition: non_lethal_applications
    
  - type: reduce_requirement
    value: intelligence_4_instead_of_6
    
  - type: additional_effect
    value: disarm_attempt
    condition: on_successful_hit
```

#### Range Modifications
```yaml
mechanical_benefit:
  - type: enhance_range
    value: +10_feet
    target_scopes: [self]
    
  - type: area_effect
    value: intimidate
    range: 30_feet
```

### Power Cost Types
```yaml
power_cost:
  - type: Force_Points
    amount: 2
    
  - type: Tech_Points
    amount: 1
    
  - type: Hit_Points
    cost_mode: percent_of_max
    percentage: 5
    apply_to: max
    recovery: long_rest
```

### Durations
- **Instantaneous** - Effect happens once
- **Concentration, up to X** - Requires concentration
- **1_round** - 6 seconds
- **1_minute** - 10 rounds
- **1_hour** - 600 rounds
- **Permanent** - No end
- **Until_dismissed** - Player controlled

### Target Scopes
- `self` - Caster only
- `target` - Single target
- `area` - Area of effect
- `allies` - Allied creatures
- `enemies` - Enemy creatures
- `starship` - Ship systems
- `electronic_devices` - Tech targets
- `security_systems` - Specific tech
- `original_attacker` - Redirect target

### Conditions Keys
- `target_failed_save`
- `target_hostile`
- `within_range`
- `concentration_maintained`
- `target_is_droid`
- `target_is_electronic`
- `level_5_or_higher`

### Special Values
- `lightsaber_damage` - Uses weapon damage
- `intelligence_modifier` - Ability mod
- `1d4_shield_points` - Ship shields
- `silent_movement` - Stealth bonus
- `avoiding_opportunity_attacks` - Movement benefit

## Quality Comparison: Force Choke vs Combustive Shot

### Force Choke (Gold Standard)
✅ **Narrative**: Visceral, specific, terrifying - captures the dark essence
✅ **Flavor Text**: Iconic Vader quote perfectly matched
✅ **Synergies**: Deep thematic connections (Guardian's fall, human emotion)
✅ **Guidance**: Detailed, evocative, mechanically accurate
✅ **Image Prompt**: Cinematic quality with specific details

### Combustive Shot (Good but simpler)
✅ **Narrative**: Clear, practical, matches mechanics
✅ **Flavor Text**: Appropriate but less iconic
✅ **Synergies**: Logical but less emotionally resonant
✅ **Guidance**: Functional and accurate
⚠️ **Image Prompt**: Good but lacks cinematic quality markers

Force Choke demonstrates the full Gold Standard with emotional depth and cinematic quality, while Combustive Shot is mechanically correct but could benefit from more dramatic flair.

