# Mechanical Effects Engine

## Overview
This document defines how the game engine interprets and resolves mechanical effects from features, talents, and abilities.

## Core Effect Types

### 1. Stat Modifications (`modify_stat`)
**Purpose**: Permanently or temporarily modify character statistics.

**Parameters**:
- `target_stat`: The stat to modify (see Stat Types below)
- `value`: The modification amount (number or string like "+2")
- `target_scopes`: Who the effect applies to
- `duration`: How long the effect lasts (default: permanent)

**Examples**:
```yaml
effect: "modify_stat"
parameters:
  target_stat: "stealth_bonus"
  value: 2
  target_scopes: ["self"]
```

### 2. Action Grants (`grant_action`)
**Purpose**: Give characters new actions they can take.

**Parameters**:
- `name`: Display name of the action
- `action_type`: The type of action (see Action Types below)
- `cost`: The action economy cost
- `trigger`: When the action can be used
- `effects`: What the action does

**Action Types**:
- `action` - Standard action
- `bonus_action` - Bonus action
- `reaction` - Reaction
- `free_action` - Free action

**Cost Format**: Always use the format "1 [action_type]" for consistency.

**Examples**:
```yaml
effect: "grant_action"
name: "Shadow Stalk"
action_type: "bonus_action"
cost: "1 bonus action"
trigger: "On your turn"
```

### 3. Advantage/Disadvantage (`grant_advantage`)
**Purpose**: Grant advantage or disadvantage on specific rolls.

**Parameters**:
- `type`: The type of roll (attack_roll, skill_check, saving_throw)
- `condition`: When the advantage applies
- `skill`: Specific skill (for skill_check type)

**Examples**:
```yaml
effect: "grant_advantage"
parameters:
  type: "skill_check"
  skill: "Stealth"
  condition: "natural_environment"
```

### 4. Auras (`aura`)
**Purpose**: Create area effects around the character.

**Parameters**:
- `radius`: The radius of the aura
- `benefits`: What the aura provides
- `duration`: How long it lasts

**Examples**:
```yaml
effect: "aura"
parameters:
  radius: 10
  benefits:
    - "Allies gain +1 AC"
    - "Enemies have disadvantage on attacks"
```

## Stat Types

### Core Stats
- `strength`, `dexterity`, `constitution`, `intelligence`, `wisdom`, `charisma`

### Derived Stats
- `ac` - Armor Class
- `hp` - Hit Points
- `speed` - Movement Speed

### Skill Bonuses
- `stealth_bonus` - Stealth skill bonus
- `survival_bonus` - Survival skill bonus
- `perception_bonus` - Perception skill bonus
- `ranged_attack_bonus` - Ranged attack bonus
- `melee_attack_bonus` - Melee attack bonus

### Special Stats
- `control_range` - Range for controlling companions
- `tactical_awareness` - Tactical analysis bonus

## Action Economy Rules

### Standard Actions
- **Action**: 1 per turn
- **Bonus Action**: 1 per turn (if you have abilities that use them)
- **Reaction**: 1 per round
- **Free Action**: Unlimited (within reason)

### Cost Resolution
The engine should interpret:
- `action_type: "bonus_action"` AND `cost: "1 bonus action"` as the same thing
- `action_type: "reaction"` AND `cost: "1 reaction"` as the same thing

## Effect Resolution Order

1. **Permanent Modifications** (always active)
2. **Conditional Modifications** (when conditions are met)
3. **Temporary Modifications** (with duration)
4. **Action Grants** (available when conditions are met)

## Stacking Rules

### Stat Modifications
- **Same Source**: Do not stack (use highest)
- **Different Sources**: Stack additively
- **Advantage/Disadvantage**: Cancel out, then apply remaining

### Action Grants
- **Same Action Type**: Can have multiple options
- **Same Action Name**: Replace previous version

## Target Scopes

- `self` - Only affects the character
- `bonded_companion` - Affects the character's companion
- `allies_within_radius` - Affects allies within specified range
- `enemies_within_radius` - Affects enemies within specified range

## Duration Types

- `permanent` - Always active
- `concentration, up to X` - Requires concentration, lasts up to specified time
- `until end of turn` - Lasts until end of current turn
- `until start of next turn` - Lasts until start of next turn
- `1 minute` - Lasts for 1 minute
- `1 hour` - Lasts for 1 hour

## Validation Rules

1. **Required Fields**: Every effect must have `effect` and `description`
2. **Consistent Terminology**: Use standardized stat names and action types
3. **Valid Parameters**: All parameters must be defined in this document
4. **Logical Effects**: Effects must make mechanical sense

## Example Resolved Effect

```yaml
# Input Feature
effect: "grant_action"
name: "Shadow Stalk"
action_type: "bonus_action"
cost: "1 bonus action"
effects:
  - "Move up to half speed without provoking opportunity attacks"
  - "Gain advantage on the next attack roll this turn"

# Engine Interpretation
- Character gains a new bonus action called "Shadow Stalk"
- Can be used once per turn (bonus action limit)
- When used: move half speed without opportunity attacks, gain advantage on next attack
- Available every turn (no cooldown specified)
```

This engine provides the mechanical foundation for all our rich, narrative features!
