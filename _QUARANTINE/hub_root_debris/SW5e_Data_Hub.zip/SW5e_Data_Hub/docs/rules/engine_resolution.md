# Engine Resolution Contract

## Purpose
Define how the engine interprets `engine_resolution` steps in effect files and executes deterministic mechanical outcomes, while the LLM-GM handles narration.

## Execution Model
1. Locate `effect_ref` in a featureaction.
2. Load effect by id via `docs/registries/effects_registry.yml`.
3. Validate provided parameters against `parameters_schema` in the effect.
4. Execute `engine_resolution` steps in order; each step maps to a resolver function.

## Resolver Mapping
- "Apply ac_bonus and saving_throw_bonus ..." → resolver: `applyArmorEnhancement(params)`
- "Create area template ..." → resolver: `createBarrierArea(params)`
- "Attach aura instance ..." → resolver: `applyAura(params)`
- "Redirect split_fraction_to_self ..." → resolver: `enableDamageIntercept(params)`
- "Annotate creatures with hostility ..." → resolver: `identifyThreats(params)`

Implementations must be pure, idempotent per tick, and use the shared condition/stacking rules.

## Roll Modifier Contract
- roll_type: enum [attack, saving_throw, skill_check, ability_check]
- target_scope: enum [attacker, defender, self, ally, enemy]
- applies_to: enum [triggering_attack, next_attack, next_save, next_check]
- window: enum [this_resolution, this_turn, next_turn, scene]
- rules:
  - roll_two_keep_lowest: for disadvantage
  - roll_two_keep_highest: for advantage

Binding semantics:
- triggering_attack binds to the attack currently being resolved by the engine (reaction context). If absent, engine uses the next compatible roll within the specified window.

## Trigger Context
- Each resolver executes with a context object (actor, targets, triggering_event, pending_rolls).
- Effects that specify applies_to: "triggering_attack" attach to context.pending_rolls.current_attack.
- On context absence, the effect is a no-op with reason: "no_trigger_context".

## Formula Evaluation
- Supported tokens:
  - proficiency_bonus: derived from actor level per class progression
  - ability_mod: resolved from the specified ability in the local parameter (e.g., saving_throw.ability) or feature context; computed as floor((ability_score - 10) / 2)
  - constants and integers
- Example: "8 + proficiency_bonus + ability_mod" → compute in that order; engine logs the evaluated DC.

## Parameter Glossary
- `per_round_limit` (number): Max triggers per round for an effect instance.
- `split_fraction_to_self` (0–1 number): Damage portion redirected to protector.
- `engine_resolution` (string[]): Ordered, human-readable resolver hints. Must map to resolvers listed here.
- `duration_in_rounds` (number): Rounds until automatic expiry.
- `ally_cover` (enum): Cover grade applied to allies: none | half | three_quarters.
- `radius` (number): Feet radius for area effects.

## Glossary (Primitives referenced by effects)

apply_roll_modifier
- Type: effect
- Purpose: Register a dice behavior override for a specific upcoming roll (e.g., disadvantage/advantage).
- Parameters: { roll_type, target_scope, applies_to, window }
- Resolution: Attach a modifier token to the bound roll context; the roller computes the final effective state (advantage, disadvantage, neutral) before rolling.

triggering_attack
- Type: applies_to selector
- Meaning: Bind the modifier to the attack roll that caused the current resolver/ reaction to execute. If no such roll exists in context, no-op with reason "no_trigger_context".

this_resolution
- Type: window selector
- Meaning: Scope limited to the current resolution step(s) of the triggering event; the modifier is consumed immediately after the bound roll resolves (never persists to later turns).

roll_two_keep_lowest
- Type: dice rule tag
- Meaning: The roller must make two d20 rolls and select the lower result for the bound roll. If multiple modifiers exist, the engine reduces to a single effective state (advantage, disadvantage, neutral) using cancellation rules before rolling.
- Cancellation rules: If both advantage and disadvantage are present, they cancel to neutral (one roll). Multiple sources of the same state do not stack beyond a single effective state.

apply_team_buffs
- Type: effect
- Purpose: Apply one or more stat modifiers to allied units within a spatial window.
- Parameters: { radius, duration_in_rounds, ally_modifiers{ ac_bonus, saving_throw_bonus, saving_throw_advantage_vs?, skill_advantage? } }
- Resolution:
  1) Build an ally filter from team/faction and range.
  2) For each ally inside radius, attach temporary modifiers for duration.
  3) Apply stacking_behavior: team buffs from the same source do not stack; use highest magnitude, refresh duration.
  4) Respect cancellation rules with opposing effects (e.g., advantage vs disadvantage).

update_on_movement
- Type: rule tag
- Purpose: Re-evaluate area membership when relevant entities move.
- Triggers:
  - On any movement event for: aura/barrier owner, potential recipients entering/exiting area, or area center changes.
- Resolution:
  - On enter: apply relevant modifiers/effects.
  - On exit: remove relevant modifiers/effects.
  - On center move: recompute membership and apply/remove accordingly.

## Division of Responsibilities
- Engine: Applies exact mechanical changes, tracking durations, stacks, limits, targeting, and geometry.
- LLM-GM: Uses `narrative` sections for RP description, tactical framing, and hooks; does not alter mechanical outcomes.

## Validation
- Effects validated by `Effect.schema.json`.
- Features referencing effects validated by `FeatureValidation.schema.json` (accepts `effect_ref`).

## Extensibility
When a new resolver is needed:
1. Create a new effect file with mechanical+ narrative.
2. Document its resolver line and parameter schema.
3. Add a line here under Resolver Mapping.

