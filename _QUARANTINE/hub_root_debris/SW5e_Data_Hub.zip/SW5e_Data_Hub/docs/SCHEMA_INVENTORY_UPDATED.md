# SW5e Data Hub - Updated Schema Inventory

## **📊 COMPREHENSIVE SCHEMA STATUS (Updated)**

### **✅ COMPLETED SCHEMAS (Gold Standard)**
These schemas have been refactored to the "gold standard" with comprehensive narrative blocks, LLM-GM integration, and enhanced mechanics:

1. **Power.schema.json** ✅
   - Status: Complete with power_cost, manifestation, corruption_transform
   - Example: `data/powers/force_push.yml`

2. **Status.schema.json** ✅
   - Status: Complete with dynamic scaling, removal conditions, synergies
   - Example: `data/status_effects/acid_corrosion.yml`

3. **Master_Action.schema.json** ✅
   - Status: Complete unified action schema with skill_check support
   - Example: `data/actions/hack_terminal_master.yml`

4. **Faction.schema.json** ✅
   - Status: Complete with narrative blocks, relationships, membership_perks
   - Example: `data/factions/jedi_order.yml`

5. **Lore.schema.json** ✅
   - Status: Complete with layered knowledge, unified connections
   - Example: `data/lore/coruscant.yml`

6. **Item.schema.json** ✅
   - Status: Complete with narrative integration, LLM guidance
   - Example: `data/items/lightsaber.yml`

7. **Background.schema.json** ✅
   - Status: Complete with narrative blocks, unified connections
   - Example: `data/backgrounds/background_jedi.yml`

8. **Starship.schema.json** ✅
   - Status: Complete with narrative integration, LLM guidance
   - Example: `data/starships/millennium_falcon.yml`

9. **CraftingRecipe.schema.json** ✅
   - Status: Complete with tag_requirement, narrative integration
   - Example: `data/crafting/lightsaber_recipe.yml`

10. **Object.schema.json** ✅
    - Status: Complete with hackable_interface, interaction systems
    - Example: `data/objects/imperial_blast_door_controls.yml`

11. **Action.schema.json** ✅
    - Status: Complete with narrative blocks, unified connections
    - Example: `data/actions/attack_action.yml`

12. **Combat.schema.json** ✅
    - Status: Complete with narrative blocks, LLM guidance
    - Example: `data/combat_actions/lightsaber_parry.yml`

13. **Species.schema.json** ✅ ⭐ **NEW**
    - Status: Complete with narrative blocks, LLM guidance, image generation, UI blocks
    - Example: All 30 species files in `official_species_playable/`

14. **Class.schema.json** ✅ ⭐ **NEW**
    - Status: Complete with class_identity_profile, level_progression, narrative integration
    - Example: `data/classes/bounty_hunter.yml`, `data/classes/guardian.yml`

15. **CharacterClassFeature.schema.json** ✅ ⭐ **NEW**
    - Status: Complete with grant_choice effect, narrative blocks, power acquisition support
    - Example: `data/features/consular/force_connection.yml`

### **🔄 SCHEMAS NEEDING REFACTOR**
These schemas exist but need to be updated to the "gold standard":

16. **Companion.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic companion schema
    - Needed: Image generation, UI blocks

17. **CampaignState.schema.json** 🔄
    - Status: Needs registry integration, narrative blocks
    - Current: Basic campaign schema
    - Needed: LLM-GM integration

18. **Character.schema.json** 🔄
    - Status: Needs registry references, narrative blocks
    - Current: Basic character schema
    - Needed: Single source of truth integration

19. **Nemesis.schema.json** 🔄
    - Status: Needs registry integration, narrative blocks
    - Current: Basic nemesis schema
    - Needed: LLM-GM integration

20. **Adversary.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic adversary schema
    - Needed: Image generation, UI blocks

21. **Creature.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic creature schema
    - Needed: Image generation, UI blocks

22. **StarshipWeapon.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic starship weapon schema
    - Needed: Image generation, UI blocks

23. **Modification.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic modification schema
    - Needed: Image generation, UI blocks

24. **Property.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic property schema
    - Needed: Image generation, UI blocks

25. **Squad.schema.json** 🔄
    - Status: Needs narrative integration, LLM guidance
    - Current: Basic squad schema
    - Needed: Image generation, UI blocks

### **✅ SCHEMAS WITH SPECIALIZED SYSTEMS**
These schemas have specialized implementations:

26. **SpeciesProgression.schema.json** ✅
    - Status: Complete with advanced progression system
    - Purpose: Species advancement and cultural features

27. **CulturalFeatures.schema.json** ✅
    - Status: Complete with cultural trait system
    - Purpose: Species cultural abilities and traditions

28. **EnvironmentalAdaptations.schema.json** ✅
    - Status: Complete with environmental specialization
    - Purpose: Species environmental adaptations

29. **CharacterCreator.schema.json** ✅
    - Status: Complete with creation flow system
    - Purpose: Character creation process

30. **Gameplay_Example.schema.json** ✅
    - Status: Complete with example system
    - Purpose: Gameplay examples and scenarios

31. **CombatRules.schema.json** ✅
    - Status: Complete with combat mechanics
    - Purpose: Combat system rules

32. **StarshipAction.schema.json** ✅
    - Status: Complete with starship action system
    - Purpose: Starship-specific actions

33. **StarshipCareer.schema.json** ✅
    - Status: Complete with career system
    - Purpose: Starship crew careers

34. **CharacterClassFeature.v2.schema.json** ✅
    - Status: Complete with enhanced feature system
    - Purpose: Advanced class features

### **📁 FILE ORGANIZATION STATUS**

#### **✅ PROPERLY ORGANIZED**
- `schema/` - All 35 JSON schemas (clean)
- `docs/` - All documentation files (organized by category)
- `validation/` - Validation results
- `data/` - YAML data files only (clean)

#### **✅ ORGANIZATION COMPLETE**
- All development tools moved to `docs/`
- All registries consolidated in `docs/registries/`
- All templates organized in `docs/templates/`
- All rules organized in `docs/rules/`
- All integrations organized in `docs/integrations/`

### **🎯 REFACTOR PRIORITIES**

#### **HIGH PRIORITY (Core Systems)** - ✅ **COMPLETED**
1. **Species.schema.json** - ✅ **COMPLETED**
2. **Class.schema.json** - ✅ **COMPLETED**
3. **CharacterClassFeature.schema.json** - ✅ **COMPLETED**

#### **MEDIUM PRIORITY (Important Systems)** - **NEXT**
4. **Companion.schema.json** - Important for gameplay
5. **Adversary.schema.json** - Important for gameplay
6. **Creature.schema.json** - Important for gameplay
7. **CampaignState.schema.json** - Important for campaigns

#### **LOW PRIORITY (Supporting Systems)**
8. **Character.schema.json** - Supporting system
9. **Nemesis.schema.json** - Supporting system
10. **StarshipWeapon.schema.json** - Supporting system
11. **Modification.schema.json** - Supporting system
12. **Property.schema.json** - Supporting system
13. **Squad.schema.json** - Supporting system

### **📊 VALIDATION STATUS**
- **Total Schemas**: 35
- **Completed (Gold Standard)**: 15 (42.9%)
- **Specialized Systems**: 9 (25.7%)
- **Needs Refactor**: 11 (31.4%)
- **Success Rate**: 68.6% (including specialized systems)

### **🚀 NEXT STEPS**
1. **Complete Medium Priority Refactors** (4 schemas)
2. **Complete Low Priority Refactors** (7 schemas)
3. **Validate All Schemas** (35 schemas)
4. **Refactor Content Files** (832 data files)
5. **Final Integration Testing**

---

*Last Updated: 2025-01-27*
*Status: Schema refactor in progress - 68.6% complete*
