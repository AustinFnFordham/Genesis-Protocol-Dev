# Relationships Guide

## Overview
Use canonical relationship IDs to avoid ambiguity and ensure consistent mechanical and narrative behavior across the system.

## Registry
See `data/registry/relationships.yml` for the source of truth. Each relationship defines:
- id: Stable identifier (e.g., `rel_member_of`)
- name/description: Human-readable meaning
- mechanical_implications: Engine/GM hints
- llm_guidance: Narrative framing for the LLM-GM

## How to Use in Connections
Replace free-text `relationship` with `relationship_id`.

Example:
```yaml
connections:
  - target_id: "galactic_empire"
    target_type: "Faction"
    relationship_id: "rel_opposition"
    narrative: "Imperial loyalists fund, arm, and protect the remnant cell."
```

## Validation Guidelines
- Only use IDs present in `data/registry/relationships.yml`.
- Prefer narrow, precise IDs. If one does not exist, add it to the registry (with description, mechanics, and guidance) before use.
- Keep `narrative` concise; defer complex behavior to the registry’s guidance.

## Common IDs
- `rel_member_of`: Active affiliation
- `rel_former_member`: Past affiliation
- `rel_specialist_in`: Recognized expertise
- `rel_engineered_by`: Created/modified by
- `rel_habitat`: Common environment/location
- `rel_opposition`: In conflict with
- `rel_ideological_distance`: Belief systems strongly differ

## Adding New Relationships
1. Edit `data/registry/relationships.yml` and append a new entry with:
   - `id`, `name`, `description`
   - `mechanical_implications` (list)
   - `llm_guidance`
2. Reference the new `relationship_id` in your `connections` blocks.
3. Keep naming consistent: `rel_<short_description>`.

## Rationale
- Prevents hallucinated semantics by anchoring to documented definitions.
- Enables rules-driven behaviors and uniform GM guidance.
- Keeps refactors consistent across species, classes, items, powers, and more.

