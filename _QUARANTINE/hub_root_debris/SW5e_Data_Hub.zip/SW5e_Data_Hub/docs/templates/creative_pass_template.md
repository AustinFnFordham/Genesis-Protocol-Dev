# Creative Pass Template for Power Refinement

## Overview
This template documents the systematic process for transforming generic, templated power content into rich, cinematic, gold standard descriptions that capture the essence of Star Wars and provide meaningful gameplay experiences.

## The Creative Pass Process

### Phase 1: Assessment
Before beginning the creative pass, assess the current state of the power:

**Checklist:**
- [ ] Power has basic structural elements (id, name, power_type, alignment, level, power_cost)
- [ ] Power has templated narrative content
- [ ] Power has placeholder flavor text
- [ ] Power has generic synergies
- [ ] Power has basic LLM guidance
- [ ] Power has generic image generation prompts

### Phase 2: Narrative Transformation

#### 2.1 Core Narrative Rewrite
**Goal:** Transform generic templated narrative into rich, cinematic description

**Before (Generic):**
```yaml
narrative: "This power represents a mastery of the Force and years of dedicated training. When used, it demonstrates the character's expertise and connection to their chosen path, creating dramatic and memorable moments in the story."
```

**After (Gold Standard):**
```yaml
narrative: "You unleash a telekinetic burst, shoving creatures and objects away from you. A fundamental expression of the Force, it can be a simple nudge or a devastating wave of concussive energy. The power flows through you like an invisible hand, extending your will beyond your physical reach to reshape the battlefield itself. When used with precision, it can separate enemies from allies, create tactical advantages, or even save lives by pushing threats away from the innocent."
```

**Guidelines:**
- Start with the core mechanical effect
- Describe the power's essence and feel
- Explain how it manifests visually/physically
- Connect to tactical and narrative applications
- Use active, engaging language
- Avoid generic phrases like "mastery of the Force" or "years of training"

#### 2.2 Flavor Text Enhancement
**Goal:** Replace placeholder quotes with iconic Star Wars quotes that enhance immersion

**Before (Placeholder):**
```yaml
flavor_text: "Force Push represents the power of the Force." - Unknown Master'
```

**After (Gold Standard):**
```yaml
flavor_text: "'The ability to destroy a planet is insignificant next to the power of the Force.' - Darth Vader"
```

**Guidelines:**
- Use quotes from established Star Wars characters
- Choose quotes that relate to the power's theme or alignment
- Avoid generic "Unknown Master" or "Unknown Engineer" placeholders
- Consider the power's alignment (Light, Dark, Universal) when selecting quotes

#### 2.3 Manifestation Refinement
**Goal:** Make manifestation descriptions more specific and evocative

**Before (Generic):**
```yaml
manifestation:
- Somatic (Force gesture)
- Mental Focus (channeling the Force)
```

**After (Gold Standard):**
```yaml
manifestation:
- Somatic (a clear, forceful gesture)
- Mental Focus (channeling telekinetic energy)
```

**Guidelines:**
- Be specific about the somatic component
- Describe the mental/emotional state required
- Consider the power's alignment and theme
- Make it feel unique to this power

### Phase 3: Synergy Enhancement

#### 3.1 Class Synergies
**Goal:** Create meaningful, specific connections between classes and powers

**Before (Generic):**
```yaml
class_synergies:
- class_id: guardian
  narrative: "Guardians excel at using Force powers defensively and in combat."
  mechanical_benefit: "Guardians gain +1 to Force power attack rolls."
```

**After (Gold Standard):**
```yaml
class_synergies:
- class_id: guardian
  narrative: "Guardians excel at using Force Push defensively, protecting allies by pushing threats away and creating space for tactical repositioning."
  mechanical_benefit:
  - type: reaction_trigger
    trigger: ally_attacked_within_range
    action_type: reaction
    target_scopes:
    - attacker
    notes: Can use Force Push as a reaction when an ally is attacked within range
```

**Guidelines:**
- Make narrative specific to the power and class
- Provide meaningful mechanical benefits
- Use structured mechanics blocks (not free-form text)
- Consider the class's role and theme
- Ensure benefits are balanced and interesting

#### 3.2 Species Synergies
**Goal:** Create connections that reflect species characteristics and abilities

**Before (Generic):**
```yaml
species_synergies:
- species_id: human
  narrative: "Human adaptability allows them to quickly master new powers."
  mechanical_benefit: "Humans gain advantage on power learning checks."
```

**After (Gold Standard):**
```yaml
species_synergies:
- species_id: human
  narrative: "Human adaptability allows them to quickly master the fundamentals of Force Push, making it one of the first powers they learn."
  mechanical_benefit:
  - type: grant_advantage
    condition: against_targets_of_their_size_or_smaller
    target_scopes:
    - self
    notes: Gain advantage on Force Push saving throws against targets of their size or smaller
```

**Guidelines:**
- Connect to species' natural abilities or characteristics
- Make benefits specific to the power
- Use structured mechanics blocks
- Consider species' role in the Star Wars universe
- Ensure benefits are balanced

#### 3.3 Faction Synergies
**Goal:** Reflect how different factions teach and use the power

**Before (Generic):**
```yaml
faction_synergies:
- faction_id: jedi_order
  narrative: "The Jedi Order teaches the proper use of Force powers."
  mechanical_benefit: "Jedi gain +2 to Force power saving throw DCs."
```

**After (Gold Standard):**
```yaml
faction_synergies:
- faction_id: jedi_order
  narrative: "The Jedi Order teaches Force Push as a fundamental defensive technique, emphasizing its use for protection rather than aggression."
  mechanical_benefit:
  - type: enhance_dc
    value: +2_saving_throw_dc
    condition: defensive_use
    target_scopes:
    - target
    notes: Gain +2 to Force Push saving throw DCs when using it defensively
```

**Guidelines:**
- Reflect faction philosophy and teaching methods
- Consider alignment differences (Jedi vs Sith approaches)
- Make benefits conditional on faction values
- Use structured mechanics blocks
- Ensure benefits are balanced and thematic

### Phase 4: LLM Guidance Enhancement

#### 4.1 Roleplay Guidance
**Goal:** Provide specific, actionable guidance for describing the power in action

**Before (Generic):**
```yaml
roleplay_guidance: "When using Force Push, describe the character's expertise and the visible effects of their power. Focus on the narrative impact and how it affects the scene."
```

**After (Gold Standard):**
```yaml
roleplay_guidance: "Describe the visible ripple of Force energy extending from the caster's gesture, the way objects and creatures are lifted and propelled away with telekinetic force. Focus on the dramatic impact - enemies tumbling backward, debris scattering, allies being pushed to safety. The power should feel both mystical and physically tangible."
```

**Guidelines:**
- Be specific about visual and sensory details
- Describe the power's impact on the environment
- Focus on the dramatic and cinematic aspects
- Help the LLM create engaging descriptions
- Consider the power's theme and alignment

#### 4.2 Tactical Notes
**Goal:** Provide strategic guidance for using the power effectively

**Before (Generic):**
```yaml
tactical_notes: "Force Push should be used strategically to maximize its effectiveness. Consider the timing and positioning for optimal results."
```

**After (Gold Standard):**
```yaml
tactical_notes: "Force Push is excellent for controlling battlefield positioning, creating space between allies and enemies, and knocking opponents prone for advantage on follow-up attacks. Use it to separate dangerous enemies from vulnerable allies, or to push enemies into environmental hazards."
```

**Guidelines:**
- Provide specific tactical applications
- Explain when and how to use the power
- Consider positioning and timing
- Mention environmental interactions
- Help players make strategic decisions

#### 4.3 Narrative Hooks
**Goal:** Provide story hooks and dramatic moments for the power

**Before (Generic):**
```yaml
narrative_hooks:
- "The use of Force Push creates an opportunity for character development"
- "An enemy attempts to counter or resist Force Push"
- "The effects of Force Push have unexpected consequences"
```

**After (Gold Standard):**
```yaml
narrative_hooks:
- "A Jedi uses Force Push to save a civilian from falling debris"
- "A Sith uses Force Push to demonstrate their raw power and intimidate opponents"
- "A Force-sensitive character discovers their abilities when they unconsciously push away a threat"
- "The power is used to create dramatic entrances or exits in social situations"
```

**Guidelines:**
- Provide specific, actionable story hooks
- Consider different alignments and contexts
- Include character development opportunities
- Think about social and combat applications
- Make hooks memorable and dramatic

### Phase 5: Image Generation Enhancement

#### 5.1 Base Prompt Refinement
**Goal:** Create detailed, cinematic prompts for visual generation

**Before (Generic):**
```yaml
base_prompt: "A character using Force Push, with visible Force energy effects and dynamic action. The scene should convey the mystical power and mastery of the Force."
```

**After (Gold Standard):**
```yaml
base_prompt: "A detailed digital painting of Force Push in action. A Jedi or Force user extends their hand in a clear, forceful gesture, creating a visible wave of telekinetic energy that pushes objects and creatures away. The Force energy manifests as a translucent wave of blue-white energy, rippling through the air. The scene shows the dramatic effect of the power, with debris, enemies, or objects being pushed back by the invisible force. The mood is mystical and powerful, representing the raw telekinetic might of the Force."
```

**Guidelines:**
- Be specific about visual details
- Describe the power's manifestation
- Include environmental effects
- Set the mood and tone
- Consider the power's alignment and theme
- Make it cinematic and dramatic

#### 5.2 Negative Keywords Enhancement
**Goal:** Ensure the generated images avoid unwanted elements

**Before (Generic):**
```yaml
base_negative_keywords:
- static
- boring
- cartoonish
- blurry
- unclear
```

**After (Gold Standard):**
```yaml
base_negative_keywords:
- static
- boring
- cartoonish
- blurry
- unclear
- small
- weak
```

**Guidelines:**
- Add power-specific negative keywords
- Consider what you don't want to see
- Think about the power's theme and alignment
- Ensure the image conveys the right mood
- Avoid elements that contradict the power's nature

### Phase 6: Quality Assurance

#### 6.1 Consistency Check
**Checklist:**
- [ ] All mechanical_benefit sections use structured mechanics blocks
- [ ] Narrative aligns with power's theme and alignment
- [ ] Flavor text is iconic and relevant
- [ ] Synergies are meaningful and balanced
- [ ] LLM guidance is specific and actionable
- [ ] Image generation prompts are detailed and cinematic

#### 6.2 Balance Check
**Checklist:**
- [ ] Power cost is appropriate for level
- [ ] Mechanical benefits are balanced
- [ ] Synergies provide meaningful advantages without being overpowered
- [ ] Power fits within the pyramid distribution model
- [ ] Power has clear tactical applications

#### 6.3 Star Wars Authenticity Check
**Checklist:**
- [ ] Power feels authentic to Star Wars universe
- [ ] Flavor text uses established characters/quotes
- [ ] Power aligns with established Force/Tech themes
- [ ] Synergies reflect faction and species characteristics
- [ ] Power creates memorable, cinematic moments

## Creative Pass Checklist

### Pre-Pass Assessment
- [ ] Power has basic structural elements
- [ ] Power has templated content that needs enhancement
- [ ] Power is ready for creative transformation

### Narrative Transformation
- [ ] Core narrative rewritten with rich, cinematic description
- [ ] Flavor text replaced with iconic Star Wars quote
- [ ] Manifestation descriptions made specific and evocative

### Synergy Enhancement
- [ ] Class synergies made specific and meaningful
- [ ] Species synergies reflect natural characteristics
- [ ] Faction synergies reflect teaching methods and philosophy
- [ ] All mechanical_benefit sections use structured mechanics blocks

### LLM Guidance Enhancement
- [ ] Roleplay guidance made specific and actionable
- [ ] Tactical notes provide strategic guidance
- [ ] Narrative hooks provide story opportunities

### Image Generation Enhancement
- [ ] Base prompt made detailed and cinematic
- [ ] Negative keywords enhanced for power-specific elements

### Quality Assurance
- [ ] Consistency check passed
- [ ] Balance check passed
- [ ] Star Wars authenticity check passed

## Examples of Transformation

### Force Lightning (Dark Side Power)
**Before:** Generic templated content about "mastery of the Force"
**After:** "Pure, unfiltered hatred and rage channeled into a weapon of pure destruction. The lightning crackles with malevolent energy, its purple-white tendrils reaching out like the fingers of death itself."

### Mind Trick (Universal Power)
**Before:** Generic content about "influencing minds"
**After:** "A gentle nudge of the Force that can make the impossible seem reasonable, the dangerous seem safe, or the suspicious seem trustworthy. The power works by planting suggestions in the target's subconscious, making them believe the idea was their own."

### Ion Blast (Tech Power)
**Before:** Generic content about "technological mastery"
**After:** "A precise burst of electrical energy that can fry circuits, overload systems, and bring down even the most sophisticated technology. The projectile crackles with blue-white energy as it streaks toward its target, leaving a trail of sparks and smoke in its wake."

## Conclusion

The creative pass transforms generic, templated content into rich, cinematic descriptions that capture the essence of Star Wars and provide meaningful gameplay experiences. By following this systematic process, we ensure that every power becomes a memorable, authentic part of the Star Wars universe while maintaining mechanical balance and clarity.

This template should be used for all future power refinements to maintain consistency and quality across the entire power system.
