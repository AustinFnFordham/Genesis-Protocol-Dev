"""
Batch process PDF files into structured JSON using unstructured.io.

This script scans an input directory for .pdf files (non-recursive),
processes each file with unstructured's auto partitioner, and writes the
results to matching .json files in the output directory.

Usage example:
    python process_pdfs.py --input-dir ./pdfs --output-dir ./json

Requirements:
    - System deps: poppler, tesseract (see project setup instructions)
    - Python deps: unstructured[pdf], unstructured[local-inference], tqdm

Notes:
    - The script uses strategy="hi_res" to better handle scanned PDFs via OCR.
      This is slower but more robust across mixed document types.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import List

from tqdm import tqdm
from unstructured.partition.auto import partition


def parse_arguments() -> argparse.Namespace:
    """Parse command-line arguments for input and output directories."""
    parser = argparse.ArgumentParser(
        description=(
            "Batch-convert PDF files to structured JSON using unstructured.io. "
            "Scans a directory for .pdf files and writes matching .json outputs."
        )
    )
    parser.add_argument(
        "--input-dir",
        required=True,
        help="Path to the directory containing source PDF files.",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Path to the directory where JSON outputs will be written.",
    )
    return parser.parse_args()


def validate_and_prepare_directories(input_dir: Path, output_dir: Path) -> None:
    """Validate input directory and ensure output directory exists."""
    if not input_dir.exists() or not input_dir.is_dir():
        print(
            f"[ERROR] Input directory does not exist or is not a directory: {input_dir}",
            file=sys.stderr,
        )
        sys.exit(1)

    output_dir.mkdir(parents=True, exist_ok=True)


def collect_pdf_files(input_dir: Path) -> List[Path]:
    """Return a non-recursive list of .pdf files in the input directory (case-insensitive)."""
    pdf_files: List[Path] = [
        path
        for path in input_dir.iterdir()
        if path.is_file() and path.suffix.lower() == ".pdf"
    ]
    return sorted(pdf_files)


def process_single_pdf(pdf_path: Path, output_path: Path) -> None:
    """Partition a single PDF and write the structured JSON output.

    Tries OCR-capable "hi_res" first; if it fails (e.g., missing poppler/tesseract),
    falls back to the faster non-OCR strategy.
    """
    try:
        elements = partition(
            filename=str(pdf_path),
            strategy="hi_res",  # robust across digital + scanned PDFs (uses OCR if needed)
            ocr_languages="eng",
            infer_table_structure=True,
        )
    except Exception:
        # Fallback: non-OCR, faster path (works for born-digital PDFs)
        elements = partition(
            filename=str(pdf_path),
            strategy="fast",
            infer_table_structure=True,
        )

    records = [element.to_dict() for element in elements]

    with output_path.open("w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def main() -> None:
    args = parse_arguments()
    input_dir = Path(args.input_dir).resolve()
    output_dir = Path(args.output_dir).resolve()

    validate_and_prepare_directories(input_dir, output_dir)

    pdf_files = collect_pdf_files(input_dir)
    if not pdf_files:
        print(f"[INFO] No PDF files found in: {input_dir}")
        return

    failures = 0

    for pdf_path in tqdm(pdf_files, desc="Processing PDFs", unit="file"):
        output_path = output_dir / f"{pdf_path.stem}.json"
        try:
            process_single_pdf(pdf_path, output_path)
        except Exception as exc:  # noqa: BLE001 - surface any processing error and continue
            failures += 1
            print(
                f"[ERROR] Failed to process '{pdf_path.name}': {exc}",
                file=sys.stderr,
            )
            continue

    processed = len(pdf_files)
    succeeded = processed - failures
    print(
        f"[DONE] Processed: {processed}, Succeeded: {succeeded}, Failed: {failures}"
    )


if __name__ == "__main__":
    main()


