# Forge Run Summary

**Run ID**: `2026-01-04_032948__fac_crimson_dawn__faction_core__wip__online__3fe04309`
**Date**: 2026-01-04 03:30:44
**Root File**: `feat_pyke_syndicate_rank2_choice3.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 39
- **Blockers**: 9
- **Major Issues**: 152
- **Iterations**: 4
- **Duration**: 55800ms

## Top Blockers (Action Required)
- 'taxonomy' is a required property (planet_unknown.yml)
- 'structure' is a required property (planet_unknown.yml)
- 'essence' is a required property (planet_unknown.yml)
- 'connections' is a required property (planet_unknown.yml)
- 'ui' is a required property (planet_unknown.yml)
- Invalid URID format: npc_crimson_dawn_maul (npc_crimson_dawn_maul.yml)
- Invalid URID format: npc_crimson_dawn_dryden_vos (npc_crimson_dawn_dryden_vos.yml)
- Invalid URID format: npc_crimson_dawn_qira (npc_crimson_dawn_qira.yml)
- Invalid URID format: species_unknown (species_unknown.yml)

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
