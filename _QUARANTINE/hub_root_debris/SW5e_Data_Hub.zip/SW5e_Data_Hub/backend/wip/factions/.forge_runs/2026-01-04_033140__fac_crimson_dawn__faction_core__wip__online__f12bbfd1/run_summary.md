# Forge Run Summary

**Run ID**: `2026-01-04_033140__fac_crimson_dawn__faction_core__wip__online__f12bbfd1`
**Date**: 2026-01-04 03:32:27
**Root File**: `planet_unknown.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 39
- **Blockers**: 4
- **Major Issues**: 154
- **Iterations**: 4
- **Duration**: 46963ms

## Top Blockers (Action Required)
- Invalid URID format: npc_crimson_dawn_maul (npc_crimson_dawn_maul.yml)
- Invalid URID format: npc_crimson_dawn_qira (npc_crimson_dawn_qira.yml)
- Invalid URID format: npc_crimson_dawn_dryden_vos (npc_crimson_dawn_dryden_vos.yml)
- Invalid URID format: species_unknown (species_unknown.yml)

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
