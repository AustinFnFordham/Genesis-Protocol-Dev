# Forge Run Summary

**Run ID**: `2026-01-04_125229__fac_crimson_dawn__faction_core__wip__online__d98b62d4`
**Date**: 2026-01-04 12:52:30
**Root File**: `fac_crimson_dawn.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 4
- **Blockers**: 0
- **Major Issues**: 14
- **Iterations**: 3
- **Duration**: 495ms

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
