# Forge Run Summary

**Run ID**: `2026-01-04_033239__fac_crimson_dawn__faction_core__wip__online__fda3995c`
**Date**: 2026-01-04 03:32:49
**Root File**: `feat_pyke_syndicate_rank3_choice3.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 39
- **Blockers**: 1
- **Major Issues**: 154
- **Iterations**: 4
- **Duration**: 9869ms

## Top Blockers (Action Required)
- Invalid URID format: species_unknown (species_unknown.yml)

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
