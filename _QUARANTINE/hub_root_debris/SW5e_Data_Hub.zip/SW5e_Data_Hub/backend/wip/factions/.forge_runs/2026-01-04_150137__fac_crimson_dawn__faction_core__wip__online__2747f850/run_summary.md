# Forge Run Summary

**Run ID**: `2026-01-04_150137__fac_crimson_dawn__faction_core__wip__online__2747f850`
**Date**: 2026-01-04 15:01:37
**Root File**: `fac_crimson_dawn.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 4
- **Blockers**: 0
- **Major Issues**: 14
- **Iterations**: 3
- **Duration**: 353ms

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
