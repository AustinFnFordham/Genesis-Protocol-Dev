# Forge Run Summary

**Run ID**: `2026-01-04_033359__fac_crimson_dawn__faction_core__wip__online__f5e14544`
**Date**: 2026-01-04 03:34:02
**Root File**: `species_unknown.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 39
- **Blockers**: 0
- **Major Issues**: 155
- **Iterations**: 5
- **Duration**: 2617ms

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
