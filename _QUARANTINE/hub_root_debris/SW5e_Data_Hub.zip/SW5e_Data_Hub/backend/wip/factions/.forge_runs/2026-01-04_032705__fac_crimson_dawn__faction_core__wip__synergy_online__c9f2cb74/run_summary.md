# Forge Run Summary

**Run ID**: `2026-01-04_032705__fac_crimson_dawn__faction_core__wip__synergy_online__c9f2cb74`
**Date**: 2026-01-04 03:27:58
**Root File**: `species_unknown.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 9
- **Blockers**: 39
- **Major Issues**: 32
- **Iterations**: 5
- **Duration**: 52748ms

## Top Blockers (Action Required)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_0_3.yml (feat_crimson_dawn_0_3.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_0_2.yml (feat_crimson_dawn_0_2.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_2_2.yml (feat_crimson_dawn_2_2.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_4_1.yml (feat_crimson_dawn_4_1.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_2_1.yml (feat_crimson_dawn_2_1.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_3_1.yml (feat_crimson_dawn_3_1.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_1_2.yml (feat_crimson_dawn_1_2.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_4_2.yml (feat_crimson_dawn_4_2.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_3_2.yml (feat_crimson_dawn_3_2.yml)
- Referenced file does not exist: E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_0_1.yml (feat_crimson_dawn_0_1.yml)
... and 29 more.

## Unresolved URIDs (Missing Files)
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_0_3.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_0_2.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_2_2.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_4_1.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_2_1.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_3_1.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_1_2.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_4_2.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_3_2.yml
- E:\StarWars\SW5e_Data_Hub\SW5e_Data_Hub\data\wip\feats\feat_crimson_dawn_0_1.yml

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
3. Verify stub generation for missing URIDs.
