# Forge Run Summary

**Run ID**: `2026-01-04_142006__fac_children_of_the_watch__faction_core__wip__online__e0180bdd`
**Date**: 2026-01-04 14:20:07
**Root File**: `fac_jedi.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 2
- **Blockers**: 0
- **Major Issues**: 4
- **Iterations**: 2
- **Duration**: 244ms

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
