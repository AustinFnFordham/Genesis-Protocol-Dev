# Forge Run Summary

**Run ID**: `2026-01-04_151824__fac_children_of_the_watch__faction_core__wip__online__d3d94824`
**Date**: 2026-01-04 15:22:07
**Root File**: `fac_jedi.yml`
**Status**: ❌ FAIL

## Metrics
- **Files Validated**: 6
- **Blockers**: 8
- **Major Issues**: 25
- **Iterations**: 4
- **Duration**: 223477ms

## Top Blockers (Action Required)
- Missing id field (fac_children_of_the_watch.yml)
- 'id' is a required property (fac_children_of_the_watch.yml)
- 'structure' is a required property (fac_jedi.yml)
- 'ui' is a required property (fac_jedi.yml)
- 'tags' is a required property (fac_jedi.yml)
- 'ideology' is a required property (fac_jedi.yml)
- 'style_guide' is a required property (fac_jedi.yml)
- 'gm_guidance' is a required property (fac_jedi.yml)

## Rejected Patches (Regressions Prevented)
- fac_children_of_the_watch.yml (Iteration 1): no_improvement
- fac_children_of_the_watch.yml (Iteration 2): no_improvement
- fac_jedi.yml (Iteration 2): regression
- fac_children_of_the_watch.yml (Iteration 3): no_improvement
- fac_jedi.yml (Iteration 3): regression
- fac_jedi.yml (Iteration 4): regression

## Next Steps
1. Check `agent_reports/` for failed repairs.
2. Fix Blockers listed above.
