#!/usr/bin/env python3
"""
Power Gold Standard Validation Script
Validates that all power files conform to the gold standard template structure.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, List

class PowerGoldStandardValidator:
    def __init__(self, powers_dir: str):
        self.powers_dir = Path(powers_dir)
        self.required_keys = ['id', 'name', 'power_type', 'alignment', 'level', 'narrative', 'flavor_text', 'casting_time', 'range', 'duration', 'power_cost', 'manifestation', 'base_effect', 'class_synergies', 'species_synergies', 'faction_synergies', 'llm_guidance', 'image_generation', 'ui']
        self.validation_errors = []
        self.validation_warnings = []
        self.valid_count = 0
        self.total_count = 0
        
    def validate_file(self, file_path: Path) -> bool:
        """Validate a single power file against gold standard requirements."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            if not data:
                self.validation_errors.append(f"❌ {file_path}: Empty file")
                return False
            
            # Check required keys
            missing_keys = []
            for key in self.required_keys:
                if key not in data:
                    missing_keys.append(key)
            
            if missing_keys:
                self.validation_errors.append(f"❌ {file_path}: Missing required keys: {', '.join(missing_keys)}")
                return False
            
            # Validate specific fields
            self.validate_specific_fields(file_path, data)
            
            self.valid_count += 1
            return True
            
        except Exception as e:
            self.validation_errors.append(f"❌ {file_path}: YAML parsing error - {e}")
            return False
    
    def validate_specific_fields(self, file_path: Path, data: Dict[str, Any]):
        """Validate specific field requirements."""
        # Validate power_type
        if data.get('power_type') not in ['Force', 'Tech']:
            self.validation_warnings.append(f"⚠️  {file_path}: Invalid power_type '{data.get('power_type')}'")
        
        # Validate alignment
        if data.get('alignment') not in ['Light', 'Dark', 'Universal']:
            self.validation_warnings.append(f"⚠️  {file_path}: Invalid alignment '{data.get('alignment')}'")
        
        # Validate level
        level = data.get('level', 0)
        if not isinstance(level, int) or level < 0 or level > 9:
            self.validation_warnings.append(f"⚠️  {file_path}: Invalid level '{level}'")
        
        # Validate power_cost
        power_cost = data.get('power_cost', [])
        if not isinstance(power_cost, list):
            self.validation_warnings.append(f"⚠️  {file_path}: power_cost should be a list")
        
        # Validate manifestation
        manifestation = data.get('manifestation', [])
        if not isinstance(manifestation, list) or len(manifestation) == 0:
            self.validation_warnings.append(f"⚠️  {file_path}: manifestation should be a non-empty list")
        
        # Validate base_effect
        base_effect = data.get('base_effect', {})
        if not isinstance(base_effect, dict) or 'description' not in base_effect:
            self.validation_warnings.append(f"⚠️  {file_path}: base_effect should be a dict with 'description'")
        
        # Validate synergies
        for synergy_type in ['class_synergies', 'species_synergies', 'faction_synergies']:
            synergies = data.get(synergy_type, [])
            if not isinstance(synergies, list):
                self.validation_warnings.append(f"⚠️  {file_path}: {synergy_type} should be a list")
        
        # Validate llm_guidance
        llm_guidance = data.get('llm_guidance', {})
        if not isinstance(llm_guidance, dict):
            self.validation_warnings.append(f"⚠️  {file_path}: llm_guidance should be a dict")
        
        # Validate image_generation
        image_generation = data.get('image_generation', {})
        if not isinstance(image_generation, dict):
            self.validation_warnings.append(f"⚠️  {file_path}: image_generation should be a dict")
        
        # Validate ui
        ui = data.get('ui', {})
        if not isinstance(ui, dict):
            self.validation_warnings.append(f"⚠️  {file_path}: ui should be a dict")
    
    def validate_all_powers(self):
        """Validate all power files in the directory."""
        print(f"🔄 Validating all power files in {self.powers_dir}")
        
        power_files = list(self.powers_dir.glob("*.yml"))
        self.total_count = len(power_files)
        
        for file_path in power_files:
            self.validate_file(file_path)
        
        print(f"\n🎉 Power validation complete!")
        print(f"✅ Valid files: {self.valid_count}/{self.total_count}")
        print(f"❌ Errors: {len(self.validation_errors)}")
        print(f"⚠️  Warnings: {len(self.validation_warnings)}")
        
        if self.validation_errors:
            print("\n📋 Validation Errors:")
            for error in self.validation_errors:
                print(f"  {error}")
        
        if self.validation_warnings:
            print("\n📋 Validation Warnings:")
            for warning in self.validation_warnings:
                print(f"  {warning}")
        
        return len(self.validation_errors) == 0

def main():
    """Main function."""
    powers_dir = "data/powers"
    
    if not os.path.exists(powers_dir):
        print(f"❌ Powers directory not found: {powers_dir}")
        return
    
    validator = PowerGoldStandardValidator(powers_dir)
    validator.validate_all_powers()

if __name__ == "__main__":
    main()
