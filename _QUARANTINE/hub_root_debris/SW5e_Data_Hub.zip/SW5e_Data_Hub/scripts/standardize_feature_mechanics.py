#!/usr/bin/env python3
"""
Feature Mechanics Standardization Script

This script standardizes the mechanical terminology in feature files to match
the Mechanical Effects Engine rules.
"""

import os
import yaml
import re
from pathlib import Path

def standardize_mechanics(mechanics):
    """Standardize mechanics to follow the rules engine."""
    standardized = []
    
    for mechanic in mechanics:
        standardized_mechanic = mechanic.copy()
        
        # Standardize action_type and cost consistency
        if 'action_type' in mechanic and 'cost' in mechanic:
            action_type = mechanic['action_type']
            cost = mechanic['cost']
            
            # Ensure cost matches action_type
            if action_type == 'bonus_action' and not cost.endswith('bonus action'):
                standardized_mechanic['cost'] = f"1 {action_type.replace('_', ' ')}"
            elif action_type == 'reaction' and not cost.endswith('reaction'):
                standardized_mechanic['cost'] = f"1 {action_type}"
            elif action_type == 'action' and not cost.endswith('action'):
                standardized_mechanic['cost'] = f"1 {action_type}"
        
        # Standardize target_stat names
        if 'parameters' in standardized_mechanic:
            params = standardized_mechanic['parameters']
            if 'target_stat' in params:
                stat = params['target_stat']
                # Map common variations to standard names
                stat_mapping = {
                    'perception_bonus': 'perception_bonus',
                    'stealth_bonus': 'stealth_bonus', 
                    'survival_bonus': 'survival_bonus',
                    'ranged_attack_bonus': 'ranged_attack_bonus',
                    'melee_attack_bonus': 'melee_attack_bonus',
                    'control_range': 'control_range',
                    'tactical_awareness': 'tactical_awareness'
                }
                if stat in stat_mapping:
                    params['target_stat'] = stat_mapping[stat]
        
        # Standardize duration formats
        if 'duration' in standardized_mechanic:
            duration = standardized_mechanic['duration']
            # Map common variations to standard formats
            duration_mapping = {
                'concentration, up to 1 minute': 'concentration, up to 1 minute',
                'concentration, up to 10 minutes': 'concentration, up to 10 minutes',
                'concentration, up to 1 hour': 'concentration, up to 1 hour',
                'until end of turn': 'until end of turn',
                'until start of next turn': 'until start of next turn',
                '1 minute': '1 minute',
                '1 hour': '1 hour',
                'permanent': 'permanent'
            }
            if duration in duration_mapping:
                standardized_mechanic['duration'] = duration_mapping[duration]
        
        standardized.append(standardized_mechanic)
    
    return standardized

def process_feature_file(file_path):
    """Process a single feature file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Parse YAML
        data = yaml.safe_load(content)
        
        if 'mechanics' in data:
            data['mechanics'] = standardize_mechanics(data['mechanics'])
            
            # Write back to file
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
            
            print(f"✅ Standardized: {file_path}")
            return True
        else:
            print(f"⚠️  No mechanics found: {file_path}")
            return False
            
    except Exception as e:
        print(f"❌ Error processing {file_path}: {e}")
        return False

def main():
    """Main function to process all feature files."""
    features_dir = Path("data/features")
    
    if not features_dir.exists():
        print("❌ Features directory not found!")
        return
    
    processed = 0
    total = 0
    
    # Find all YAML files in features directory
    for yaml_file in features_dir.rglob("*.yml"):
        total += 1
        if process_feature_file(yaml_file):
            processed += 1
    
    print(f"\n🎉 Standardization complete!")
    print(f"📊 Processed: {processed}/{total} files")
    print(f"📋 See docs/rules/mechanical_effects_engine.md for rules")

if __name__ == "__main__":
    main()
