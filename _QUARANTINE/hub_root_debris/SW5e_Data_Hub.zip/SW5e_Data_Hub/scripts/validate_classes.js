#!/usr/bin/env node

/**
 * Class Validation Script
 * Validates all class files against the Class schema
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const Ajv = require('ajv');
const addFormats = require('ajv-formats');

// Initialize AJV with formats
const ajv = new Ajv({ allErrors: true });
addFormats(ajv);

// Load the Class schema
const schemaPath = path.join(__dirname, '..', 'schema', 'Class.schema.json');
const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
const validate = ajv.compile(schema);

// Get all class files
const classesDir = path.join(__dirname, '..', 'data', 'classes');
const classFiles = fs.readdirSync(classesDir).filter(file => file.endsWith('.yml'));

console.log('🔍 CLASS VALIDATION REPORT');
console.log('==================================================');
console.log(`📊 Testing ${classFiles.length} class files against enhanced schema`);
console.log(`📋 Schema has ${Object.keys(schema.properties).length} properties`);
console.log(`🎯 Required fields: ${schema.required.length}`);
console.log('');

let validCount = 0;
let invalidCount = 0;
const results = [];

for (const file of classFiles) {
  const filePath = path.join(classesDir, file);
  const content = fs.readFileSync(filePath, 'utf8');
  
  try {
    const data = yaml.load(content);
    const isValid = validate(data);
    
    if (isValid) {
      console.log(`✅ ${file} - VALID`);
      
      // Check for advanced features
      const features = [];
      if (data.class_identity_profile) features.push('Class Identity Profile');
      if (data.level_progression) features.push('Level Progression');
      if (data.connections) features.push('Connections');
      if (data.llm_guidance) features.push('LLM Guidance');
      if (data.image_generation) features.push('Image Generation');
      if (data.ui) features.push('UI Elements');
      
      if (features.length > 0) {
        console.log(`   🎨 Features: ${features.join(', ')}`);
      }
      
      // Check for narrative elements
      const narrativeElements = [];
      if (data.narrative) narrativeElements.push('Narrative');
      if (data.flavor_text) narrativeElements.push('Flavor Text');
      if (data.cultural_significance) narrativeElements.push('Cultural Significance');
      if (data.origin_story) narrativeElements.push('Origin Story');
      
      if (narrativeElements.length > 0) {
        console.log(`   📖 Narrative: ${narrativeElements.join(', ')}`);
      }
      
      validCount++;
    } else {
      console.log(`❌ ${file} - INVALID`);
      console.log('   Errors:');
      validate.errors.forEach(error => {
        console.log(`     - ${error.instancePath || 'root'}: ${error.message}`);
      });
      invalidCount++;
    }
    
    results.push({
      file,
      valid: isValid,
      errors: isValid ? [] : validate.errors
    });
    
  } catch (error) {
    console.log(`❌ ${file} - PARSE ERROR`);
    console.log(`   Error: ${error.message}`);
    invalidCount++;
    
    results.push({
      file,
      valid: false,
      errors: [{ message: error.message }]
    });
  }
  
  console.log('');
}

console.log('📊 VALIDATION SUMMARY');
console.log('==================================================');
console.log(`✅ Valid files: ${validCount}/${classFiles.length} (${Math.round(validCount/classFiles.length*100)}%)`);
console.log(`❌ Invalid files: ${invalidCount}/${classFiles.length} (${Math.round(invalidCount/classFiles.length*100)}%)`);
console.log('');

// Advanced features analysis
const advancedFeatures = {
  'Class Identity Profile': 0,
  'Level Progression': 0,
  'Connections': 0,
  'LLM Guidance': 0,
  'Image Generation': 0,
  'UI Elements': 0
};

const narrativeFeatures = {
  'Narrative': 0,
  'Flavor Text': 0,
  'Cultural Significance': 0,
  'Origin Story': 0
};

for (const result of results) {
  if (result.valid) {
    const filePath = path.join(classesDir, result.file);
    const content = fs.readFileSync(filePath, 'utf8');
    const data = yaml.load(content);
    
    if (data.class_identity_profile) advancedFeatures['Class Identity Profile']++;
    if (data.level_progression) advancedFeatures['Level Progression']++;
    if (data.connections) advancedFeatures['Connections']++;
    if (data.llm_guidance) advancedFeatures['LLM Guidance']++;
    if (data.image_generation) advancedFeatures['Image Generation']++;
    if (data.ui) advancedFeatures['UI Elements']++;
    
    if (data.narrative) narrativeFeatures['Narrative']++;
    if (data.flavor_text) narrativeFeatures['Flavor Text']++;
    if (data.cultural_significance) narrativeFeatures['Cultural Significance']++;
    if (data.origin_story) narrativeFeatures['Origin Story']++;
  }
}

console.log('🎨 ADVANCED FEATURES ANALYSIS');
console.log('==================================================');
Object.entries(advancedFeatures).forEach(([feature, count]) => {
  const percentage = Math.round(count/classFiles.length*100);
  console.log(`${feature}: ${count}/${classFiles.length} (${percentage}%)`);
});

console.log('');
console.log('📖 NARRATIVE FEATURES ANALYSIS');
console.log('==================================================');
Object.entries(narrativeFeatures).forEach(([feature, count]) => {
  const percentage = Math.round(count/classFiles.length*100);
  console.log(`${feature}: ${count}/${classFiles.length} (${percentage}%)`);
});

console.log('');
console.log('🎯 VALIDATION COMPLETE!');

// Exit with error code if any files are invalid
if (invalidCount > 0) {
  process.exit(1);
}
