#!/usr/bin/env node

/**
 * Species Validation Script
 * Validates all species files against the enhanced Species.schema.json
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const Ajv = require('ajv');

// Initialize AJV validator
const ajv = new Ajv({ allErrors: true, verbose: true });

// Load the schema
const schemaPath = path.join(__dirname, '../schema/Species.schema.json');
const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
const validate = ajv.compile(schema);

// Get all species files
const speciesDir = path.join(__dirname, '../official_species_playable');
const speciesFiles = fs.readdirSync(speciesDir)
  .filter(file => file.endsWith('.yml') && file !== 'SPECIES_REGISTRY.yml')
  .sort();

console.log('🔍 SPECIES VALIDATION REPORT');
console.log('=' .repeat(50));
console.log(`📊 Testing ${speciesFiles.length} species files against enhanced schema`);
console.log(`📋 Schema has ${Object.keys(schema.properties).length} properties`);
console.log(`🎯 Required fields: ${schema.required.length}`);
console.log('');

let totalFiles = 0;
let validFiles = 0;
let invalidFiles = 0;
const errors = [];

// Validate each species file
speciesFiles.forEach(file => {
  totalFiles++;
  const filePath = path.join(speciesDir, file);
  
  try {
    // Load and parse YAML
    const content = fs.readFileSync(filePath, 'utf8');
    const species = yaml.load(content);
    
    // Validate against schema
    const isValid = validate(species);
    
    if (isValid) {
      validFiles++;
      console.log(`✅ ${file} - VALID`);
      
      // Show key features
      const features = [];
      if (species.appearance_profile) features.push('Appearance Profile');
      if (species.class_synergies) features.push('Class Synergies');
      if (species.faction_synergies) features.push('Faction Synergies');
      if (species.species_progression) features.push('Species Progression');
      if (species.cultural_features) features.push('Cultural Features');
      if (species.environmental_adaptations) features.push('Environmental Adaptations');
      
      if (features.length > 0) {
        console.log(`   🎨 Features: ${features.join(', ')}`);
      }
      
      // Show trait count
      if (species.innate_traits) {
        console.log(`   🎯 Innate Traits: ${species.innate_traits.length}`);
      }
      
    } else {
      invalidFiles++;
      console.log(`❌ ${file} - INVALID`);
      
      // Show validation errors
      if (validate.errors) {
        validate.errors.forEach(error => {
          const errorMsg = `${error.instancePath || 'root'}: ${error.message}`;
          console.log(`   🔍 ${errorMsg}`);
          errors.push(`${file}: ${errorMsg}`);
        });
      }
    }
    
  } catch (error) {
    invalidFiles++;
    console.log(`❌ ${file} - ERROR: ${error.message}`);
    errors.push(`${file}: Parse error - ${error.message}`);
  }
  
  console.log('');
});

// Summary
console.log('📊 VALIDATION SUMMARY');
console.log('=' .repeat(50));
console.log(`✅ Valid files: ${validFiles}/${totalFiles} (${Math.round(validFiles/totalFiles*100)}%)`);
console.log(`❌ Invalid files: ${invalidFiles}/${totalFiles} (${Math.round(invalidFiles/totalFiles*100)}%)`);

if (errors.length > 0) {
  console.log('');
  console.log('🔍 DETAILED ERRORS:');
  errors.forEach(error => console.log(`   ${error}`));
}

// Check for missing advanced features
console.log('');
console.log('🎨 ADVANCED FEATURES ANALYSIS');
console.log('=' .repeat(50));

const featureStats = {
  'Appearance Profile': 0,
  'Class Synergies': 0,
  'Faction Synergies': 0,
  'Species Progression': 0,
  'Cultural Features': 0,
  'Environmental Adaptations': 0
};

speciesFiles.forEach(file => {
  const filePath = path.join(speciesDir, file);
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const species = yaml.load(content);
    
    if (species.appearance_profile) featureStats['Appearance Profile']++;
    if (species.class_synergies) featureStats['Class Synergies']++;
    if (species.faction_synergies) featureStats['Faction Synergies']++;
    if (species.species_progression) featureStats['Species Progression']++;
    if (species.cultural_features) featureStats['Cultural Features']++;
    if (species.environmental_adaptations) featureStats['Environmental Adaptations']++;
  } catch (error) {
    // Skip files with parse errors
  }
});

Object.entries(featureStats).forEach(([feature, count]) => {
  const percentage = Math.round(count/totalFiles*100);
  console.log(`${feature}: ${count}/${totalFiles} (${percentage}%)`);
});

console.log('');
console.log('🎯 VALIDATION COMPLETE!');
