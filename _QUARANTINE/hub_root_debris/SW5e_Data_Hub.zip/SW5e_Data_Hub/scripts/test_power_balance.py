#!/usr/bin/env python3
"""
Power Balance Testing Script

This script validates power balance, narrative-mechanics alignment, and quality
against the testing framework. It provides automated testing for the power system.
"""

import yaml
import os
import sys
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from enum import Enum

class TestResult(Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    WARNING = "WARNING"
    INFO = "INFO"

@dataclass
class TestIssue:
    power_id: str
    test_category: str
    test_name: str
    result: TestResult
    message: str
    severity: str = "medium"

class PowerTester:
    def __init__(self, powers_directory: str = "data/powers"):
        self.powers_directory = Path(powers_directory)
        self.issues: List[TestIssue] = []
        self.powers: Dict[str, Dict] = {}
        
    def load_powers(self) -> bool:
        """Load all power files from the directory."""
        try:
            for power_file in self.powers_directory.glob("*.yml"):
                if power_file.name.startswith("power_"):
                    with open(power_file, 'r', encoding='utf-8') as f:
                        power_data = yaml.safe_load(f)
                        if power_data and 'id' in power_data:
                            self.powers[power_data['id']] = power_data
            print(f"Loaded {len(self.powers)} powers for testing")
            return True
        except Exception as e:
            print(f"Error loading powers: {e}")
            return False
    
    def test_power_cost_balance(self, power_id: str, power_data: Dict) -> List[TestIssue]:
        """Test power cost balance against level."""
        issues = []
        
        level = power_data.get('level', 0)
        power_cost = power_data.get('power_cost', [])
        
        # Calculate total cost
        total_cost = 0
        for cost in power_cost:
            if isinstance(cost, dict) and 'amount' in cost:
                total_cost += cost['amount']
        
        # Validate cost-to-level ratio
        if level == 0 and total_cost > 0:
            issues.append(TestIssue(
                power_id, "cost_balance", "at_will_cost",
                TestResult.FAIL, f"At-will power (level 0) should cost 0, but costs {total_cost}",
                "high"
            ))
        elif level > 0 and total_cost != level:
            issues.append(TestIssue(
                power_id, "cost_balance", "level_cost_mismatch",
                TestResult.WARNING, f"Level {level} power costs {total_cost}, expected {level}",
                "medium"
            ))
        
        return issues
    
    def test_damage_scaling(self, power_id: str, power_data: Dict) -> List[TestIssue]:
        """Test damage scaling against level."""
        issues = []
        
        level = power_data.get('level', 0)
        base_effect = power_data.get('base_effect', {})
        mechanics = base_effect.get('mechanics', [])
        
        for mechanic in mechanics:
            if mechanic.get('type') == 'single_target_damage' or mechanic.get('type') == 'area_damage':
                damage_value = mechanic.get('value', '')
                
                # Parse damage dice
                if 'd' in damage_value:
                    try:
                        dice_count, dice_size = damage_value.split('d')
                        dice_count = int(dice_count)
                        dice_size = int(dice_size)
                        
                        # Validate damage scaling
                        expected_min = level + 1 if level > 0 else 1
                        expected_max = (level + 1) * 2 if level > 0 else 2
                        
                        if dice_count < expected_min or dice_count > expected_max:
                            issues.append(TestIssue(
                                power_id, "damage_scaling", "damage_out_of_range",
                                TestResult.WARNING, f"Level {level} power deals {dice_count}d{dice_size} damage, expected {expected_min}-{expected_max} dice",
                                "medium"
                            ))
                    except ValueError:
                        issues.append(TestIssue(
                            power_id, "damage_scaling", "damage_parse_error",
                            TestResult.FAIL, f"Could not parse damage value: {damage_value}",
                            "high"
                        ))
        
        return issues
    
    def test_mechanical_benefit_structure(self, power_id: str, power_data: Dict) -> List[TestIssue]:
        """Test that all mechanical_benefit sections use structured mechanics blocks."""
        issues = []
        
        for synergy_type in ['class_synergies', 'species_synergies', 'faction_synergies']:
            synergies = power_data.get(synergy_type, [])
            for synergy in synergies:
                mechanical_benefit = synergy.get('mechanical_benefit')
                if mechanical_benefit:
                    # Check if it's a string (old format) or list (new format)
                    if isinstance(mechanical_benefit, str):
                        issues.append(TestIssue(
                            power_id, "mechanical_structure", f"{synergy_type}_string_benefit",
                            TestResult.FAIL, f"{synergy_type} uses string format instead of structured mechanics block",
                            "high"
                        ))
                    elif isinstance(mechanical_benefit, list):
                        # Validate structure
                        for benefit in mechanical_benefit:
                            if not isinstance(benefit, dict):
                                issues.append(TestIssue(
                                    power_id, "mechanical_structure", f"{synergy_type}_invalid_benefit",
                                    TestResult.FAIL, f"{synergy_type} benefit is not a dictionary",
                                    "high"
                                ))
                            elif 'type' not in benefit:
                                issues.append(TestIssue(
                                    power_id, "mechanical_structure", f"{synergy_type}_missing_type",
                                    TestResult.FAIL, f"{synergy_type} benefit missing 'type' field",
                                    "high"
                                ))
                            elif 'target_scopes' not in benefit:
                                issues.append(TestIssue(
                                    power_id, "mechanical_structure", f"{synergy_type}_missing_target_scopes",
                                    TestResult.FAIL, f"{synergy_type} benefit missing 'target_scopes' field",
                                    "high"
                                ))
        
        return issues
    
    def test_narrative_quality(self, power_id: str, power_data: Dict) -> List[TestIssue]:
        """Test narrative quality and authenticity."""
        issues = []
        
        # Test narrative content
        narrative = power_data.get('narrative', '')
        if not narrative:
            issues.append(TestIssue(
                power_id, "narrative_quality", "missing_narrative",
                TestResult.FAIL, "Power is missing narrative description",
                "high"
            ))
        elif "mastery of the Force and years of dedicated training" in narrative:
            issues.append(TestIssue(
                power_id, "narrative_quality", "generic_narrative",
                TestResult.FAIL, "Power uses generic templated narrative",
                "high"
            ))
        
        # Test flavor text
        flavor_text = power_data.get('flavor_text', '')
        if not flavor_text:
            issues.append(TestIssue(
                power_id, "narrative_quality", "missing_flavor_text",
                TestResult.FAIL, "Power is missing flavor text",
                "high"
            ))
        elif "Unknown Master" in flavor_text or "Unknown Engineer" in flavor_text:
            issues.append(TestIssue(
                power_id, "narrative_quality", "placeholder_flavor_text",
                TestResult.FAIL, "Power uses placeholder flavor text",
                "high"
            ))
        
        # Test manifestation
        manifestation = power_data.get('manifestation', [])
        if not manifestation:
            issues.append(TestIssue(
                power_id, "narrative_quality", "missing_manifestation",
                TestResult.FAIL, "Power is missing manifestation description",
                "high"
            ))
        else:
            for manifest in manifestation:
                if isinstance(manifest, str):
                    issues.append(TestIssue(
                        power_id, "narrative_quality", "string_manifestation",
                        TestResult.FAIL, "Manifestation should be structured, not string",
                        "high"
                    ))
        
        return issues
    
    def test_llm_guidance_quality(self, power_id: str, power_data: Dict) -> List[TestIssue]:
        """Test LLM guidance quality and completeness."""
        issues = []
        
        llm_guidance = power_data.get('llm_guidance', {})
        if not llm_guidance:
            issues.append(TestIssue(
                power_id, "llm_guidance", "missing_llm_guidance",
                TestResult.FAIL, "Power is missing LLM guidance section",
                "high"
            ))
        else:
            # Test roleplay guidance
            roleplay_guidance = llm_guidance.get('roleplay_guidance', '')
            if not roleplay_guidance:
                issues.append(TestIssue(
                    power_id, "llm_guidance", "missing_roleplay_guidance",
                    TestResult.FAIL, "Power is missing roleplay guidance",
                    "high"
                ))
            elif "describe the character's expertise and the visible effects" in roleplay_guidance:
                issues.append(TestIssue(
                    power_id, "llm_guidance", "generic_roleplay_guidance",
                    TestResult.FAIL, "Power uses generic templated roleplay guidance",
                    "high"
                ))
            
            # Test tactical notes
            tactical_notes = llm_guidance.get('tactical_notes', '')
            if not tactical_notes:
                issues.append(TestIssue(
                    power_id, "llm_guidance", "missing_tactical_notes",
                    TestResult.FAIL, "Power is missing tactical notes",
                    "high"
                ))
            elif "should be used strategically to maximize its effectiveness" in tactical_notes:
                issues.append(TestIssue(
                    power_id, "llm_guidance", "generic_tactical_notes",
                    TestResult.FAIL, "Power uses generic templated tactical notes",
                    "high"
                ))
            
            # Test narrative hooks
            narrative_hooks = llm_guidance.get('narrative_hooks', [])
            if not narrative_hooks:
                issues.append(TestIssue(
                    power_id, "llm_guidance", "missing_narrative_hooks",
                    TestResult.FAIL, "Power is missing narrative hooks",
                    "high"
                ))
            elif any("creates an opportunity for character development" in hook for hook in narrative_hooks):
                issues.append(TestIssue(
                    power_id, "llm_guidance", "generic_narrative_hooks",
                    TestResult.FAIL, "Power uses generic templated narrative hooks",
                    "high"
                ))
        
        return issues
    
    def test_image_generation_quality(self, power_id: str, power_data: Dict) -> List[TestIssue]:
        """Test image generation prompt quality."""
        issues = []
        
        image_generation = power_data.get('image_generation', {})
        if not image_generation:
            issues.append(TestIssue(
                power_id, "image_generation", "missing_image_generation",
                TestResult.FAIL, "Power is missing image generation section",
                "high"
            ))
        else:
            base_prompt = image_generation.get('base_prompt', '')
            if not base_prompt:
                issues.append(TestIssue(
                    power_id, "image_generation", "missing_base_prompt",
                    TestResult.FAIL, "Power is missing base prompt",
                    "high"
                ))
            elif "with visible Force energy effects and dynamic action" in base_prompt:
                issues.append(TestIssue(
                    power_id, "image_generation", "generic_base_prompt",
                    TestResult.FAIL, "Power uses generic templated base prompt",
                    "high"
                ))
            
            base_negative_keywords = image_generation.get('base_negative_keywords', [])
            if not base_negative_keywords:
                issues.append(TestIssue(
                    power_id, "image_generation", "missing_negative_keywords",
                    TestResult.WARNING, "Power is missing negative keywords",
                    "low"
                ))
        
        return issues
    
    def test_power_completeness(self, power_id: str, power_data: Dict) -> List[TestIssue]:
        """Test that power has all required fields."""
        issues = []
        
        required_fields = [
            'id', 'name', 'power_type', 'alignment', 'level', 'power_cost',
            'narrative', 'flavor_text', 'manifestation', 'casting_time', 'range',
            'duration', 'base_effect', 'llm_guidance', 'image_generation', 'ui'
        ]
        
        for field in required_fields:
            if field not in power_data:
                issues.append(TestIssue(
                    power_id, "completeness", f"missing_{field}",
                    TestResult.FAIL, f"Power is missing required field: {field}",
                    "high"
                ))
        
        return issues
    
    def test_all_powers(self) -> Dict[str, List[TestIssue]]:
        """Run all tests on all powers."""
        results = {}
        
        for power_id, power_data in self.powers.items():
            power_issues = []
            
            # Run all tests
            power_issues.extend(self.test_power_completeness(power_id, power_data))
            power_issues.extend(self.test_power_cost_balance(power_id, power_data))
            power_issues.extend(self.test_damage_scaling(power_id, power_data))
            power_issues.extend(self.test_mechanical_benefit_structure(power_id, power_data))
            power_issues.extend(self.test_narrative_quality(power_id, power_data))
            power_issues.extend(self.test_llm_guidance_quality(power_id, power_data))
            power_issues.extend(self.test_image_generation_quality(power_id, power_data))
            
            results[power_id] = power_issues
            self.issues.extend(power_issues)
        
        return results
    
    def generate_report(self, results: Dict[str, List[TestIssue]]) -> str:
        """Generate a comprehensive test report."""
        report = []
        report.append("=" * 80)
        report.append("POWER BALANCE TESTING REPORT")
        report.append("=" * 80)
        report.append("")
        
        # Summary statistics
        total_powers = len(results)
        total_issues = len(self.issues)
        
        issues_by_severity = {"high": 0, "medium": 0, "low": 0}
        issues_by_result = {"FAIL": 0, "WARNING": 0, "PASS": 0, "INFO": 0}
        
        for issue in self.issues:
            issues_by_severity[issue.severity] += 1
            issues_by_result[issue.result.value] += 1
        
        report.append(f"Total Powers Tested: {total_powers}")
        report.append(f"Total Issues Found: {total_issues}")
        report.append("")
        report.append("Issues by Severity:")
        report.append(f"  High: {issues_by_severity['high']}")
        report.append(f"  Medium: {issues_by_severity['medium']}")
        report.append(f"  Low: {issues_by_severity['low']}")
        report.append("")
        report.append("Issues by Result:")
        report.append(f"  FAIL: {issues_by_result['FAIL']}")
        report.append(f"  WARNING: {issues_by_result['WARNING']}")
        report.append(f"  PASS: {issues_by_result['PASS']}")
        report.append(f"  INFO: {issues_by_result['INFO']}")
        report.append("")
        
        # Powers with issues
        powers_with_issues = {power_id: issues for power_id, issues in results.items() if issues}
        
        if powers_with_issues:
            report.append("POWERS WITH ISSUES:")
            report.append("-" * 40)
            report.append("")
            
            for power_id, issues in powers_with_issues.items():
                report.append(f"Power: {power_id}")
                report.append(f"  Issues: {len(issues)}")
                
                # Group issues by category
                issues_by_category = {}
                for issue in issues:
                    if issue.test_category not in issues_by_category:
                        issues_by_category[issue.test_category] = []
                    issues_by_category[issue.test_category].append(issue)
                
                for category, category_issues in issues_by_category.items():
                    report.append(f"  {category}:")
                    for issue in category_issues:
                        report.append(f"    [{issue.result.value}] {issue.test_name}: {issue.message}")
                
                report.append("")
        else:
            report.append("ALL POWERS PASSED ALL TESTS!")
            report.append("")
        
        # Detailed issue breakdown
        if self.issues:
            report.append("DETAILED ISSUE BREAKDOWN:")
            report.append("-" * 40)
            report.append("")
            
            # Group issues by category
            issues_by_category = {}
            for issue in self.issues:
                if issue.test_category not in issues_by_category:
                    issues_by_category[issue.test_category] = []
                issues_by_category[issue.test_category].append(issue)
            
            for category, category_issues in issues_by_category.items():
                report.append(f"{category.upper()}:")
                for issue in category_issues:
                    report.append(f"  [{issue.result.value}] {issue.power_id}: {issue.message}")
                report.append("")
        
        return "\n".join(report)
    
    def run_tests(self) -> bool:
        """Run all tests and generate report."""
        print("Loading powers...")
        if not self.load_powers():
            return False
        
        print("Running tests...")
        results = self.test_all_powers()
        
        print("Generating report...")
        report = self.generate_report(results)
        
        # Save report to file
        report_file = Path("power_testing_report.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"Report saved to {report_file}")
        print("\n" + report)
        
        # Return success if no high-severity issues
        high_severity_issues = [issue for issue in self.issues if issue.severity == "high"]
        return len(high_severity_issues) == 0

def main():
    """Main function to run power testing."""
    tester = PowerTester()
    success = tester.run_tests()
    
    if success:
        print("\n✅ All tests passed! No high-severity issues found.")
        sys.exit(0)
    else:
        print("\n❌ Tests failed! High-severity issues found.")
        sys.exit(1)

if __name__ == "__main__":
    main()
