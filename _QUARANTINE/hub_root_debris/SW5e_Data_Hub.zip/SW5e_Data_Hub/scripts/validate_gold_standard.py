#!/usr/bin/env python3
"""
Gold Standard Validation Script
Validates that all feature and effect files conform to the gold standard template structure.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, List

class GoldStandardValidator:
    def __init__(self, features_dir: str, effects_dir: str):
        self.features_dir = Path(features_dir)
        self.effects_dir = Path(effects_dir)
        self.required_keys = ['id', 'name', 'category', 'narrative', 'flavor_text', 'mechanics', 'llm_guidance', 'image_generation', 'ui']
        self.validation_errors = []
        self.validation_warnings = []
        
    def validate_file(self, file_path: Path) -> bool:
        """Validate a single file against gold standard requirements."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            if not data:
                self.validation_errors.append(f"Empty file: {file_path}")
                return False
            
            # Check required keys
            missing_keys = [key for key in self.required_keys if key not in data]
            if missing_keys:
                self.validation_errors.append(f"Missing required keys in {file_path}: {missing_keys}")
                return False
            
            # Validate specific fields
            self.validate_id(data, file_path)
            self.validate_name(data, file_path)
            self.validate_category(data, file_path)
            self.validate_narrative(data, file_path)
            self.validate_flavor_text(data, file_path)
            self.validate_mechanics(data, file_path)
            self.validate_llm_guidance(data, file_path)
            self.validate_image_generation(data, file_path)
            self.validate_ui(data, file_path)
            
            return True
            
        except Exception as e:
            self.validation_errors.append(f"Error parsing {file_path}: {e}")
            return False
    
    def validate_id(self, data: Dict[str, Any], file_path: Path):
        """Validate ID field."""
        feature_id = data.get('id', '')
        if not feature_id.startswith('feature_') and not feature_id.startswith('effect_'):
            self.validation_warnings.append(f"ID should start with 'feature_' or 'effect_' in {file_path}: {feature_id}")
    
    def validate_name(self, data: Dict[str, Any], file_path: Path):
        """Validate name field."""
        name = data.get('name', '')
        if not name or len(name) < 2:
            self.validation_errors.append(f"Name is too short or empty in {file_path}")
    
    def validate_category(self, data: Dict[str, Any], file_path: Path):
        """Validate category field."""
        category = data.get('category', '')
        valid_categories = ['combat', 'movement', 'utility', 'defensive', 'status', 'protection']
        if category not in valid_categories:
            self.validation_warnings.append(f"Category '{category}' in {file_path} is not in standard categories: {valid_categories}")
    
    def validate_narrative(self, data: Dict[str, Any], file_path: Path):
        """Validate narrative field."""
        narrative = data.get('narrative', '')
        if len(narrative) < 50:
            self.validation_warnings.append(f"Narrative is too short in {file_path} (should be at least 50 characters)")
    
    def validate_flavor_text(self, data: Dict[str, Any], file_path: Path):
        """Validate flavor_text field."""
        flavor_text = data.get('flavor_text', '')
        if not flavor_text or len(flavor_text) < 10:
            self.validation_warnings.append(f"Flavor text is too short in {file_path}")
    
    def validate_mechanics(self, data: Dict[str, Any], file_path: Path):
        """Validate mechanics field."""
        mechanics = data.get('mechanics', [])
        if not isinstance(mechanics, list) or len(mechanics) == 0:
            self.validation_errors.append(f"Mechanics must be a non-empty list in {file_path}")
            return
        
        for i, mechanic in enumerate(mechanics):
            if not isinstance(mechanic, dict):
                self.validation_errors.append(f"Mechanic {i} in {file_path} must be a dictionary")
                continue
            
            if 'effect' not in mechanic:
                self.validation_errors.append(f"Mechanic {i} in {file_path} missing 'effect' field")
            
            if 'description' not in mechanic:
                self.validation_errors.append(f"Mechanic {i} in {file_path} missing 'description' field")
    
    def validate_llm_guidance(self, data: Dict[str, Any], file_path: Path):
        """Validate llm_guidance field."""
        llm_guidance = data.get('llm_guidance', {})
        if not isinstance(llm_guidance, dict):
            self.validation_errors.append(f"llm_guidance must be a dictionary in {file_path}")
            return
        
        required_guidance_keys = ['roleplay_guidance', 'tactical_notes', 'narrative_hooks']
        for key in required_guidance_keys:
            if key not in llm_guidance:
                self.validation_errors.append(f"llm_guidance missing '{key}' in {file_path}")
    
    def validate_image_generation(self, data: Dict[str, Any], file_path: Path):
        """Validate image_generation field."""
        image_gen = data.get('image_generation', {})
        if not isinstance(image_gen, dict):
            self.validation_errors.append(f"image_generation must be a dictionary in {file_path}")
            return
        
        if 'base_prompt' not in image_gen:
            self.validation_errors.append(f"image_generation missing 'base_prompt' in {file_path}")
    
    def validate_ui(self, data: Dict[str, Any], file_path: Path):
        """Validate ui field."""
        ui = data.get('ui', {})
        if not isinstance(ui, dict):
            self.validation_errors.append(f"ui must be a dictionary in {file_path}")
            return
        
        if 'icon' not in ui:
            self.validation_errors.append(f"ui missing 'icon' in {file_path}")
        
        if 'color' not in ui:
            self.validation_errors.append(f"ui missing 'color' in {file_path}")
    
    def validate_all_files(self):
        """Validate all feature and effect files."""
        print("🔍 Starting gold standard validation...")
        
        # Validate feature files
        feature_files = list(self.features_dir.rglob("*.yml"))
        print(f"📊 Found {len(feature_files)} feature files to validate")
        
        valid_features = 0
        for file_path in feature_files:
            if self.validate_file(file_path):
                valid_features += 1
        
        # Validate effect files
        effect_files = list(self.effects_dir.rglob("*.yml"))
        print(f"📊 Found {len(effect_files)} effect files to validate")
        
        valid_effects = 0
        for file_path in effect_files:
            if self.validate_file(file_path):
                valid_effects += 1
        
        # Print results
        print(f"\n🎉 Validation complete!")
        print(f"✅ Valid feature files: {valid_features}/{len(feature_files)}")
        print(f"✅ Valid effect files: {valid_effects}/{len(effect_files)}")
        
        if self.validation_errors:
            print(f"\n❌ Validation Errors ({len(self.validation_errors)}):")
            for error in self.validation_errors[:10]:  # Show first 10 errors
                print(f"  {error}")
            if len(self.validation_errors) > 10:
                print(f"  ... and {len(self.validation_errors) - 10} more errors")
        
        if self.validation_warnings:
            print(f"\n⚠️  Validation Warnings ({len(self.validation_warnings)}):")
            for warning in self.validation_warnings[:10]:  # Show first 10 warnings
                print(f"  {warning}")
            if len(self.validation_warnings) > 10:
                print(f"  ... and {len(self.validation_warnings) - 10} more warnings")
        
        return len(self.validation_errors) == 0

def main():
    """Main function."""
    features_dir = "data/features"
    effects_dir = "docs/systems/effects"
    
    if not os.path.exists(features_dir):
        print(f"❌ Features directory not found: {features_dir}")
        return
    
    if not os.path.exists(effects_dir):
        print(f"❌ Effects directory not found: {effects_dir}")
        return
    
    validator = GoldStandardValidator(features_dir, effects_dir)
    success = validator.validate_all_files()
    
    if success:
        print("\n🎉 All files conform to gold standard!")
    else:
        print("\n❌ Some files do not conform to gold standard. See errors above.")

if __name__ == "__main__":
    main()
