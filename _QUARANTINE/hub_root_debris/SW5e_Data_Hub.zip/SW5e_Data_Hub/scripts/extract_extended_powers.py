#!/usr/bin/env python3
"""
Extended Power Extraction Script
Extracts individual powers from extended catalog files and converts them to gold standard format.
"""

import os
import yaml
import re
from pathlib import Path
from typing import Dict, Any, List

class ExtendedPowerExtractor:
    def __init__(self, powers_dir: str):
        self.powers_dir = Path(powers_dir)
        self.extracted_count = 0
        self.error_count = 0
        self.errors = []
        
    def extract_extended_powers(self, catalog_file: Path) -> bool:
        """Extract individual powers from an extended catalog file."""
        try:
            with open(catalog_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse YAML
            data = yaml.safe_load(content)
            if not data:
                print(f"⚠️  Empty file: {catalog_file}")
                return False
            
            # Determine the catalog type
            if 'force_powers_extended' in data:
                powers = data['force_powers_extended']
                power_type = 'Force'
            elif 'tech_powers_extended' in data:
                powers = data['tech_powers_extended']
                power_type = 'Tech'
            else:
                print(f"⚠️  Unknown extended catalog format: {catalog_file}")
                return False
            
            print(f"🔄 Extracting {len(powers)} extended {power_type} powers from {catalog_file}")
            
            # Extract each power
            for power_data in powers:
                if self.extract_single_extended_power(power_data, power_type, catalog_file):
                    self.extracted_count += 1
            
            return True
            
        except Exception as e:
            error_msg = f"❌ Error processing {catalog_file}: {e}"
            print(error_msg)
            self.errors.append(error_msg)
            self.error_count += 1
            return False
    
    def extract_single_extended_power(self, power_data: Dict[str, Any], power_type: str, source_file: Path) -> bool:
        """Extract a single extended power and convert to gold standard format."""
        try:
            # Get basic info
            power_id = power_data.get('id', '')
            power_name = power_data.get('name', '')
            
            if not power_id or not power_name:
                print(f"⚠️  Skipping power with missing id or name: {power_data}")
                return False
            
            # Skip scaling entries
            if 'scaling' in power_id.lower():
                print(f"⚠️  Skipping scaling entry: {power_id}")
                return False
            
            # Ensure proper power ID format
            if not power_id.startswith('power_'):
                power_id = f"power_{power_id}"
            
            # Convert to gold standard format
            gold_standard_power = self.convert_extended_to_gold_standard(power_data, power_type)
            
            # Create output file
            output_file = self.powers_dir / f"{power_id}.yml"
            
            # Write to file
            with open(output_file, 'w', encoding='utf-8') as f:
                yaml.dump(gold_standard_power, f, default_flow_style=False, sort_keys=False, 
                         allow_unicode=True, width=1000)
            
            print(f"✅ Extracted: {power_id} -> {output_file}")
            return True
            
        except Exception as e:
            error_msg = f"❌ Error extracting power {power_data.get('id', 'unknown')}: {e}"
            print(error_msg)
            self.errors.append(error_msg)
            self.error_count += 1
            return False
    
    def convert_extended_to_gold_standard(self, power_data: Dict[str, Any], power_type: str) -> Dict[str, Any]:
        """Convert extended power format to gold standard format."""
        gold_standard = {}
        
        # Basic fields
        gold_standard['id'] = f"power_{power_data.get('id', '').replace('power_', '')}"
        gold_standard['name'] = power_data.get('name', '')
        gold_standard['power_type'] = power_type
        gold_standard['alignment'] = power_data.get('alignment', 'Universal')
        gold_standard['level'] = power_data.get('level', 6)
        
        # Narrative block
        gold_standard['narrative'] = self.create_extended_narrative(power_data)
        gold_standard['flavor_text'] = self.create_extended_flavor_text(power_data)
        
        # Mechanics block
        gold_standard['casting_time'] = self.convert_casting_time(power_data)
        gold_standard['range'] = self.convert_range(power_data)
        gold_standard['duration'] = self.convert_duration(power_data)
        
        # Power cost (higher for extended powers)
        gold_standard['power_cost'] = self.create_extended_power_cost(power_data)
        
        # Manifestation
        gold_standard['manifestation'] = self.create_extended_manifestation(power_data, power_type)
        
        # Base effect
        gold_standard['base_effect'] = self.create_base_effect(power_data)
        
        # Upgrades (if any)
        if 'upgrades' in power_data:
            gold_standard['upgrades'] = power_data['upgrades']
        
        # Synergies
        gold_standard['class_synergies'] = self.create_extended_class_synergies(power_data)
        gold_standard['species_synergies'] = self.create_species_synergies(power_data)
        gold_standard['faction_synergies'] = self.create_faction_synergies(power_data)
        
        # LLM guidance
        gold_standard['llm_guidance'] = self.create_extended_llm_guidance(power_data)
        
        # Image generation
        gold_standard['image_generation'] = self.create_extended_image_generation(power_data, power_type)
        
        # UI
        gold_standard['ui'] = self.create_ui(power_data)
        
        return gold_standard
    
    def create_extended_narrative(self, power_data: Dict[str, Any]) -> str:
        """Create rich narrative description for extended powers."""
        description = power_data.get('description', '')
        name = power_data.get('name', '')
        level = power_data.get('level', 6)
        
        if description:
            # Enhance the description for extended powers
            enhanced = f"{description} This is a legendary {level}th-level power that represents the pinnacle of mastery. Only the most experienced and powerful individuals can hope to wield such incredible abilities. When used, it demonstrates the character's absolute mastery and creates truly epic, world-changing moments in the story."
            return enhanced
        
        return f"{name} represents the ultimate expression of power, a legendary ability that few can master and fewer still can control. This is the power that legends are made of."
    
    def create_extended_flavor_text(self, power_data: Dict[str, Any]) -> str:
        """Create flavor text quote for extended powers."""
        name = power_data.get('name', '')
        power_type = power_data.get('type', 'Force')
        level = power_data.get('level', 6)
        
        # Generate appropriate flavor text based on the power name and type
        if power_type == 'Force':
            if level >= 9:
                return "'I am the Force.' - Ancient Master"
            elif level >= 7:
                return "'The Force flows through me like a river.' - Legendary Jedi"
            else:
                return f"'{name} represents the power of legends.' - Unknown Master"
        else:  # Tech
            if level >= 9:
                return "'Technology is the ultimate expression of intelligence.' - Ancient Engineer"
            elif level >= 7:
                return "'With technology, all things are possible.' - Legendary Engineer"
            else:
                return f"'{name} represents technological transcendence.' - Unknown Engineer"
    
    def convert_casting_time(self, power_data: Dict[str, Any]) -> str:
        """Convert casting time to string format."""
        casting_time = power_data.get('casting_time', {})
        if isinstance(casting_time, dict):
            value = casting_time.get('value', 1)
            unit = casting_time.get('unit', 'action')
            return f"{value} {unit.title()}"
        return "1 Action"
    
    def convert_range(self, power_data: Dict[str, Any]) -> str:
        """Convert range to string format."""
        range_data = power_data.get('range', {})
        if isinstance(range_data, dict):
            value = range_data.get('value', 300)
            unit = range_data.get('unit', 'feet')
            return f"{value} {unit}"
        return "300 feet"
    
    def convert_duration(self, power_data: Dict[str, Any]) -> str:
        """Convert duration to string format."""
        duration = power_data.get('duration', {})
        if isinstance(duration, dict):
            duration_type = duration.get('type', 'concentration')
            value = duration.get('value', 10)
            unit = duration.get('unit', 'minute')
            
            if duration_type == 'concentration':
                return f"Concentration, up to {value} {unit}"
            elif duration_type == 'instantaneous':
                return "Instantaneous"
            else:
                return f"{value} {unit}"
        return "Concentration, up to 10 minutes"
    
    def create_extended_power_cost(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create power cost array for extended powers."""
        level = power_data.get('level', 6)
        power_type = power_data.get('type', 'Force')
        
        if power_type == 'Force':
            cost_type = 'Force_Points'
        else:
            cost_type = 'Tech_Points'
        
        # Higher cost for extended powers
        base_cost = level * 2
        
        return [
            {
                'type': cost_type,
                'amount': base_cost
            }
        ]
    
    def create_extended_manifestation(self, power_data: Dict[str, Any], power_type: str) -> List[str]:
        """Create manifestation array for extended powers."""
        if power_type == 'Force':
            return [
                "Somatic (complex Force gestures)",
                "Verbal (ancient incantations)",
                "Mental Focus (deep meditation and concentration)"
            ]
        else:
            return [
                "Somatic (complex interface manipulation)",
                "Verbal (technical commands)",
                "Mental Focus (deep concentration on systems)"
            ]
    
    def create_base_effect(self, power_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create base effect structure."""
        effects = power_data.get('effects', [])
        
        return {
            'description': power_data.get('description', 'This power has a specific effect.'),
            'mechanics': effects
        }
    
    def create_extended_class_synergies(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create class synergies for extended powers."""
        power_type = power_data.get('type', 'Force')
        level = power_data.get('level', 6)
        
        if power_type == 'Force':
            return [
                {
                    'class_id': 'guardian',
                    'narrative': f'Guardians of {level}th level and above can channel these legendary powers with devastating effect.',
                    'mechanical_benefit': f'Guardians gain +{level//2} to Force power attack rolls with this power.'
                }
            ]
        else:
            return [
                {
                    'class_id': 'engineer',
                    'narrative': f'Engineers of {level}th level and above can wield these legendary technologies with incredible precision.',
                    'mechanical_benefit': f'Engineers gain +{level//2} to Tech power attack rolls with this power.'
                }
            ]
    
    def create_species_synergies(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create species synergies."""
        return [
            {
                'species_id': 'human',
                'narrative': 'Human ambition and determination allows them to master even the most legendary powers.',
                'mechanical_benefit': 'Humans gain advantage on power learning checks for extended powers.'
            }
        ]
    
    def create_faction_synergies(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create faction synergies."""
        power_type = power_data.get('type', 'Force')
        
        if power_type == 'Force':
            return [
                {
                    'faction_id': 'jedi_order',
                    'narrative': 'The Jedi Order has preserved the ancient techniques for wielding legendary Force powers.',
                    'mechanical_benefit': 'Jedi gain +3 to Force power saving throw DCs with extended powers.'
                }
            ]
        else:
            return [
                {
                    'faction_id': 'rebel_alliance',
                    'narrative': 'The Rebel Alliance values technological innovation and mastery.',
                    'mechanical_benefit': 'Rebels gain +3 to Tech power saving throw DCs with extended powers.'
                }
            ]
    
    def create_extended_llm_guidance(self, power_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create LLM guidance for extended powers."""
        name = power_data.get('name', '')
        level = power_data.get('level', 6)
        
        return {
            'roleplay_guidance': f"When using {name}, describe the character's legendary mastery and the world-changing effects of their power. This is a {level}th-level ability that should feel truly epic and transformative.",
            'tactical_notes': f"{name} is a legendary power that should be used sparingly and strategically. Its effects are world-changing and should be treated as such in the narrative.",
            'narrative_hooks': [
                f"The use of {name} creates an opportunity for legendary character development",
                f"An enemy attempts to counter or resist {name} with their own legendary abilities",
                f"The effects of {name} have world-changing consequences that ripple through the galaxy"
            ]
        }
    
    def create_extended_image_generation(self, power_data: Dict[str, Any], power_type: str) -> Dict[str, Any]:
        """Create image generation for extended powers."""
        name = power_data.get('name', '')
        level = power_data.get('level', 6)
        
        if power_type == 'Force':
            base_prompt = f"A character using the legendary {name}, with massive, world-changing Force energy effects and epic, cinematic action. The scene should convey the absolute mastery and legendary power of this {level}th-level ability, with dramatic lighting and scale."
        else:
            base_prompt = f"A character using the legendary {name}, with massive, world-changing technological effects and epic, cinematic action. The scene should convey the absolute mastery and legendary power of this {level}th-level ability, with dramatic lighting and scale."
        
        return {
            'base_prompt': base_prompt,
            'base_negative_keywords': ['static', 'boring', 'cartoonish', 'blurry', 'unclear', 'small', 'weak']
        }
    
    def create_ui(self, power_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create UI section."""
        power_id = power_data.get('id', 'unknown').replace('power_', '')
        level = power_data.get('level', 6)
        
        # Different colors for different power levels
        if level >= 9:
            color = "#FF0000"  # Red for transcendent
        elif level >= 7:
            color = "#FF6600"  # Orange for divine
        else:
            color = "#FFAA00"  # Yellow for legendary
        
        return {
            'icon': f"/assets/icons/powers/{power_id}.svg",
            'color': color
        }
    
    def process_extended_catalog_files(self):
        """Process all extended catalog files in the powers directory."""
        print(f"🔄 Starting extended power extraction from catalog files in {self.powers_dir}")
        
        # Find extended catalog files
        catalog_files = [
            self.powers_dir / "force_powers_extended.yml",
            self.powers_dir / "tech_powers_extended.yml"
        ]
        
        for catalog_file in catalog_files:
            if catalog_file.exists():
                print(f"📊 Processing extended catalog: {catalog_file}")
                self.extract_extended_powers(catalog_file)
            else:
                print(f"⚠️  Extended catalog file not found: {catalog_file}")
        
        print(f"\n🎉 Extended power extraction complete!")
        print(f"✅ Successfully extracted: {self.extracted_count} extended powers")
        print(f"❌ Errors: {self.error_count}")
        
        if self.errors:
            print("\n📋 Errors encountered:")
            for error in self.errors:
                print(f"  {error}")

def main():
    """Main function."""
    powers_dir = "data/powers"
    
    if not os.path.exists(powers_dir):
        print(f"❌ Powers directory not found: {powers_dir}")
        return
    
    extractor = ExtendedPowerExtractor(powers_dir)
    extractor.process_extended_catalog_files()

if __name__ == "__main__":
    main()
