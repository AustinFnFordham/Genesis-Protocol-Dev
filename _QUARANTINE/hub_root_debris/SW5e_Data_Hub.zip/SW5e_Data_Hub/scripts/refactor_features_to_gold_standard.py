#!/usr/bin/env python3
"""
Feature Refactoring Script - Gold Standard Schema
Refactors all feature files to conform to the new gold standard template structure.
"""

import os
import yaml
import re
from pathlib import Path
from typing import Dict, Any, List, Optional

class FeatureRefactorer:
    def __init__(self, features_dir: str):
        self.features_dir = Path(features_dir)
        self.processed_count = 0
        self.error_count = 0
        self.errors = []
        
    def refactor_file(self, file_path: Path) -> bool:
        """Refactor a single feature file to gold standard format."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse YAML
            data = yaml.safe_load(content)
            if not data:
                print(f"⚠️  Empty file: {file_path}")
                return False
            
            # Check if already in gold standard format
            if self.is_gold_standard(data):
                print(f"✅ Already gold standard: {file_path}")
                return True
            
            # Refactor to gold standard
            refactored_data = self.convert_to_gold_standard(data, file_path)
            
            # Write back to file
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(refactored_data, f, default_flow_style=False, sort_keys=False, 
                         allow_unicode=True, width=1000)
            
            print(f"✅ Refactored: {file_path}")
            return True
            
        except Exception as e:
            error_msg = f"❌ Error processing {file_path}: {e}"
            print(error_msg)
            self.errors.append(error_msg)
            self.error_count += 1
            return False
    
    def is_gold_standard(self, data: Dict[str, Any]) -> bool:
        """Check if file is already in gold standard format."""
        required_keys = ['id', 'name', 'category', 'narrative', 'flavor_text', 'mechanics', 'llm_guidance', 'image_generation', 'ui']
        return all(key in data for key in required_keys)
    
    def convert_to_gold_standard(self, data: Dict[str, Any], file_path: Path) -> Dict[str, Any]:
        """Convert old format to gold standard format."""
        refactored = {}
        
        # Basic fields
        refactored['id'] = self.ensure_feature_prefix(data.get('id', ''))
        refactored['name'] = data.get('name', '')
        refactored['category'] = self.determine_category(data, file_path)
        refactored['xp_cost'] = data.get('xp_cost', 0)
        
        # Narrative block
        refactored['narrative'] = self.create_narrative(data)
        refactored['flavor_text'] = self.create_flavor_text(data)
        
        # Mechanics block
        refactored['mechanics'] = self.convert_mechanics(data)
        
        # LLM guidance
        refactored['llm_guidance'] = self.create_llm_guidance(data)
        
        # Image generation
        refactored['image_generation'] = self.create_image_generation(data)
        
        # UI
        refactored['ui'] = self.create_ui(data)
        
        return refactored
    
    def ensure_feature_prefix(self, feature_id: str) -> str:
        """Ensure feature ID has proper prefix."""
        if not feature_id.startswith('feature_'):
            return f"feature_{feature_id}"
        return feature_id
    
    def determine_category(self, data: Dict[str, Any], file_path: Path) -> str:
        """Determine the category based on content and file path."""
        name = data.get('name', '').lower()
        description = data.get('description', '').lower()
        
        # Combat-related keywords
        combat_keywords = ['attack', 'strike', 'damage', 'weapon', 'combat', 'battle', 'fight', 'kill', 'death', 'assassin', 'berserker', 'warrior']
        if any(keyword in name or keyword in description for keyword in combat_keywords):
            return 'combat'
        
        # Movement-related keywords
        movement_keywords = ['move', 'speed', 'teleport', 'jump', 'fly', 'dash', 'step', 'travel']
        if any(keyword in name or keyword in description for keyword in movement_keywords):
            return 'movement'
        
        # Utility-related keywords
        utility_keywords = ['heal', 'cure', 'restore', 'utility', 'tool', 'craft', 'create', 'repair', 'modify']
        if any(keyword in name or keyword in description for keyword in utility_keywords):
            return 'utility'
        
        # Defensive keywords
        defensive_keywords = ['defense', 'protect', 'shield', 'armor', 'guard', 'ward', 'barrier', 'resistance']
        if any(keyword in name or keyword in description for keyword in defensive_keywords):
            return 'defensive'
        
        # Default to utility
        return 'utility'
    
    def create_narrative(self, data: Dict[str, Any]) -> str:
        """Create rich narrative description."""
        existing_narrative = data.get('narrative', '')
        description = data.get('description', '')
        
        if existing_narrative and len(existing_narrative) > 50:
            return existing_narrative
        
        # Enhance the description into a rich narrative
        if description:
            # Add more narrative flair
            enhanced = f"{description} This ability represents a mastery of the Force and years of dedicated training. When used, it demonstrates the character's expertise and connection to their chosen path."
            return enhanced
        
        return "This feature represents a significant advancement in the character's abilities, granting them new powers and capabilities that reflect their growing mastery."
    
    def create_flavor_text(self, data: Dict[str, Any]) -> str:
        """Create flavor text quote."""
        name = data.get('name', '')
        
        # Generate appropriate flavor text based on the feature name
        flavor_quotes = {
            'heal': "'The Force flows through all living things. Let it flow through you to heal.' - Master Yoda",
            'attack': "'Strike with precision, strike with purpose.' - Jedi Code",
            'defense': "'The best defense is a calm mind and a steady blade.' - Obi-Wan Kenobi",
            'stealth': "'In the shadows, we find our strength.' - Assassin's Creed",
            'force': "'Feel the Force flow through you.' - Luke Skywalker"
        }
        
        name_lower = name.lower()
        for keyword, quote in flavor_quotes.items():
            if keyword in name_lower:
                return quote
        
        return f"'{name} represents the pinnacle of mastery.' - Unknown Master"
    
    def convert_mechanics(self, data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Convert old mechanics format to new format."""
        mechanics = []
        
        # Handle old activation/targeting/mechanics structure
        if 'activation' in data and 'targeting' in data:
            mechanics.append(self.convert_activation_to_mechanics(data))
        
        # Handle old mechanics array
        elif 'mechanics' in data:
            for mechanic in data['mechanics']:
                converted = self.convert_single_mechanic(mechanic)
                if converted:
                    mechanics.append(converted)
        
        # Handle old effects array
        elif 'effects' in data:
            for effect in data['effects']:
                converted = self.convert_old_effect(effect)
                if converted:
                    mechanics.append(converted)
        
        # If no mechanics found, create a basic one
        if not mechanics:
            mechanics.append({
                'effect': 'grant_ability',
                'description': data.get('description', 'Grants a special ability'),
                'parameters': {
                    'ability_name': data.get('name', 'Special Ability'),
                    'action_type': 'passive'
                }
            })
        
        return mechanics
    
    def convert_activation_to_mechanics(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Convert old activation/targeting structure to new mechanics format."""
        activation = data.get('activation', {})
        targeting = data.get('targeting', {})
        
        cost = activation.get('cost', {})
        action_type = cost.get('type', 'action')
        count = cost.get('count', 1)
        
        return {
            'effect': 'grant_action',
            'description': f"As a {action_type}, you can use this ability.",
            'parameters': {
                'action_name': data.get('name', 'Special Action'),
                'action_type': action_type,
                'cost': f"{count} {action_type}",
                'range': targeting.get('range', {}).get('value', 0),
                'frequency': activation.get('frequency', 'at_will')
            }
        }
    
    def convert_single_mechanic(self, mechanic: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert a single mechanic to new format."""
        effect_type = mechanic.get('effect', '')
        
        if effect_type == 'grant_ability':
            return {
                'effect': 'grant_action',
                'description': mechanic.get('description', 'Grants an ability'),
                'parameters': {
                    'action_name': mechanic.get('parameters', {}).get('ability_name', 'Special Ability'),
                    'action_type': mechanic.get('parameters', {}).get('action_type', 'action'),
                    'frequency': mechanic.get('parameters', {}).get('frequency', 'at_will')
                }
            }
        elif effect_type == 'modify_stat':
            return {
                'effect': 'modify_stat',
                'description': mechanic.get('description', 'Modifies a statistic'),
                'parameters': {
                    'target_stat': mechanic.get('parameters', {}).get('stat', 'unknown'),
                    'value': mechanic.get('parameters', {}).get('modifier', 0)
                }
            }
        
        return None
    
    def convert_old_effect(self, effect: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert old effects format to new mechanics format."""
        effect_type = effect.get('type', '')
        
        if effect_type == 'action_ability':
            return {
                'effect': 'grant_action',
                'description': effect.get('notes', 'Grants an action ability'),
                'parameters': {
                    'action_name': effect.get('value', 'Special Action'),
                    'action_type': 'action',
                    'frequency': effect.get('frequency', 'at_will')
                }
            }
        elif effect_type == 'passive_aura':
            return {
                'effect': 'apply_aura',
                'description': effect.get('notes', 'Applies an aura effect'),
                'parameters': {
                    'aura_name': effect.get('value', 'Special Aura'),
                    'radius': effect.get('range', 10)
                }
            }
        
        return None
    
    def create_llm_guidance(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create LLM guidance section."""
        existing_guidance = data.get('llm_guidance', {})
        
        if existing_guidance:
            return existing_guidance
        
        # Create default guidance
        return {
            'roleplay_guidance': f"When using {data.get('name', 'this ability')}, describe the character's expertise and the visible effects of their power. Focus on the narrative impact and how it affects the scene.",
            'tactical_notes': f"{data.get('name', 'This ability')} should be used strategically to maximize its effectiveness. Consider the timing and positioning for optimal results.",
            'narrative_hooks': [
                f"The use of {data.get('name', 'this ability')} creates an opportunity for character development",
                f"An enemy attempts to counter or resist {data.get('name', 'this ability')}",
                f"The effects of {data.get('name', 'this ability')} have unexpected consequences"
            ]
        }
    
    def create_image_generation(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create image generation section."""
        existing_image = data.get('image_generation', {})
        
        if existing_image:
            return existing_image
        
        # Create default image generation
        name = data.get('name', 'Special Ability')
        return {
            'base_prompt': f"A character using {name}, with visible energy effects and dynamic action. The scene should convey the power and mastery of the ability.",
            'base_negative_keywords': ['static', 'boring', 'cartoonish', 'blurry', 'unclear']
        }
    
    def create_ui(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create UI section."""
        existing_ui = data.get('ui', {})
        
        if existing_ui:
            return existing_ui
        
        # Create default UI
        feature_id = data.get('id', 'unknown').replace('feature_', '')
        return {
            'icon': f"/assets/icons/features/{feature_id}.svg",
            'color': "#0066CC"  # Default blue color
        }
    
    def process_all_files(self):
        """Process all feature files in the directory."""
        print(f"🔄 Starting refactoring of feature files in {self.features_dir}")
        
        # Find all YAML files
        yaml_files = list(self.features_dir.rglob("*.yml"))
        total_files = len(yaml_files)
        
        print(f"📊 Found {total_files} YAML files to process")
        
        for file_path in yaml_files:
            if self.refactor_file(file_path):
                self.processed_count += 1
        
        print(f"\n🎉 Refactoring complete!")
        print(f"✅ Successfully processed: {self.processed_count}/{total_files} files")
        print(f"❌ Errors: {self.error_count}")
        
        if self.errors:
            print("\n📋 Errors encountered:")
            for error in self.errors:
                print(f"  {error}")

def main():
    """Main function."""
    features_dir = "data/features"
    
    if not os.path.exists(features_dir):
        print(f"❌ Features directory not found: {features_dir}")
        return
    
    refactorer = FeatureRefactorer(features_dir)
    refactorer.process_all_files()

if __name__ == "__main__":
    main()
