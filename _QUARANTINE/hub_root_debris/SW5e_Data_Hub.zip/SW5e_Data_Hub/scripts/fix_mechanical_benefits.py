#!/usr/bin/env python3
"""
Mechanical Benefit Structure Fix Script

This script systematically converts all mechanical_benefit sections from legacy
string format to the new Gold Standard structured mechanics block format.
This is a purely structural operation - no narrative content is changed.
"""

import yaml
import os
import sys
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from enum import Enum

class BenefitType(Enum):
    ENHANCE_ATTACK = "enhance_attack"
    ENHANCE_DAMAGE = "enhance_damage"
    ENHANCE_DC = "enhance_dc"
    GRANT_ADVANTAGE = "grant_advantage"
    APPLY_STATUS = "apply_status"
    ADDITIONAL_ACTION = "additional_action"
    REACTION_TRIGGER = "reaction_trigger"
    AREA_EFFECT = "area_effect"
    MODIFY_EFFECT = "modify_effect"
    REDUCE_REQUIREMENT = "reduce_requirement"
    ENHANCE_MOVEMENT = "enhance_movement"
    ENHANCE_RANGE = "enhance_range"
    ENHANCE_DEFLECTION = "enhance_deflection"
    PROTECT_ALLY = "protect_ally"
    REDIRECT_ATTACK = "redirect_attack"
    ENVIRONMENTAL_EFFECT = "environmental_effect"
    GRANT_CONDITION = "grant_condition"

@dataclass
class ParsedBenefit:
    benefit_type: BenefitType
    value: str
    condition: str = ""
    target_scopes: List[str] = None
    duration: str = ""
    notes: str = ""

class MechanicalBenefitConverter:
    def __init__(self, powers_directory: str = "data/powers"):
        self.powers_directory = Path(powers_directory)
        self.powers: Dict[str, Dict] = {}
        self.fixed_powers = 0
        self.errors = []

    def load_powers(self) -> bool:
        """Load all power files from the directory."""
        try:
            for power_file in self.powers_directory.glob("*.yml"):
                if power_file.name.startswith("power_"):
                    with open(power_file, 'r', encoding='utf-8') as f:
                        power_data = yaml.safe_load(f)
                        if power_data and 'id' in power_data:
                            self.powers[power_data['id']] = power_data
            print(f"Loaded {len(self.powers)} powers for conversion")
            return True
        except Exception as e:
            print(f"Error loading powers: {e}")
            return False

    def parse_mechanical_benefit_string(self, benefit_string: str) -> ParsedBenefit:
        """Parse a mechanical benefit string into structured components."""
        benefit_string = benefit_string.strip()

        # Pattern 1: Class-based damage bonuses
        if re.search(r'(gain|deal|inflict).*(?:\+|increased?|more|bonus).*damage', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.ENHANCE_DAMAGE,
                value="+2_damage",
                condition="",
                target_scopes=["target"],
                notes=benefit_string
            )

        # Pattern 2: Attack roll bonuses
        elif re.search(r'(gain|increase|get).*(?:\+|bonus|advantage).*(?:attack|hit|roll)', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.ENHANCE_ATTACK,
                value="+2_attack_rolls",
                condition="",
                target_scopes=["self"],
                notes=benefit_string
            )

        # Pattern 3: DC bonuses
        elif re.search(r'(gain|increase|get).*(?:\+|bonus).*DC', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.ENHANCE_DC,
                value="+2_saving_throw_dc",
                condition="",
                target_scopes=["target"],
                notes=benefit_string
            )

        # Pattern 4: Advantage on attacks or saves
        elif re.search(r'advantage.*(?:attack|roll|save|check)', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.GRANT_ADVANTAGE,
                value="",
                condition="",
                target_scopes=["self"],
                notes=benefit_string
            )

        # Pattern 5: Status effects
        elif re.search(r'apply|cause|inflict.*(?:condition|status|effect)', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.APPLY_STATUS,
                value="",
                condition="",
                target_scopes=["target"],
                notes=benefit_string
            )

        # Pattern 6: Additional actions
        elif re.search(r'use.*as.*(?:bonus|reaction|free)', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.ADDITIONAL_ACTION,
                value="",
                condition="",
                target_scopes=["target"],
                notes=benefit_string
            )

        # Pattern 7: Reaction triggers
        elif re.search(r'reaction.*(?:when|if|triggered)', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.REACTION_TRIGGER,
                value="",
                condition="",
                target_scopes=["target"],
                notes=benefit_string
            )

        # Pattern 8: Area effects
        elif re.search(r'area|all.*(?:within|in range)', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.AREA_EFFECT,
                value="",
                condition="",
                target_scopes=["enemies_in_area"],
                notes=benefit_string
            )

        # Pattern 9: Effect modifications
        elif re.search(r'(reduce|increase|modify).*effect', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.MODIFY_EFFECT,
                value="",
                condition="",
                target_scopes=["target"],
                notes=benefit_string
            )

        # Pattern 10: Requirement reduction
        elif re.search(r'(reduce|ignore|lower).*requirement', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.REDUCE_REQUIREMENT,
                value="",
                condition="",
                target_scopes=["target"],
                notes=benefit_string
            )

        # Pattern 11: Movement enhancements
        elif re.search(r'(increase|enhance|double).*movement|range|distance', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.ENHANCE_MOVEMENT,
                value="",
                condition="",
                target_scopes=["self"],
                notes=benefit_string
            )

        # Pattern 12: Deflection enhancements
        elif re.search(r'(deflect|redirect|reflect)', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.ENHANCE_DEFLECTION,
                value="",
                condition="",
                target_scopes=["self"],
                notes=benefit_string
            )

        # Pattern 13: Ally protection
        elif re.search(r'protect.*ally|adjacent.*ally', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.PROTECT_ALLY,
                value="",
                condition="",
                target_scopes=["ally"],
                notes=benefit_string
            )

        # Pattern 14: Attack redirection
        elif re.search(r'redirect.*attack|deflect.*enemy', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.REDIRECT_ATTACK,
                value="",
                target_scopes=["original_attacker"],
                notes=benefit_string
            )

        # Pattern 15: Environmental effects
        elif re.search(r'environmental|terrain|area.*destruction', benefit_string, re.IGNORECASE):
            return ParsedBenefit(
                benefit_type=BenefitType.ENVIRONMENTAL_EFFECT,
                value="",
                target_scopes=["environment"],
                notes=benefit_string
            )

        # Default case: Generic benefit
        else:
            return ParsedBenefit(
                benefit_type=BenefitType.APPLY_STATUS,
                value="",
                target_scopes=["target"],
                notes=benefit_string
            )

    def convert_to_structured_benefit(self, parsed: ParsedBenefit) -> Dict:
        """Convert a parsed benefit to structured mechanics format."""
        result = {
            "type": parsed.benefit_type.value,
            "target_scopes": parsed.target_scopes or ["target"],
            "notes": parsed.notes
        }

        # Add value if present
        if parsed.value:
            result["value"] = parsed.value

        # Add condition if present
        if parsed.condition:
            result["condition"] = parsed.condition

        # Add duration if present
        if parsed.duration:
            result["duration"] = parsed.duration

        return result

    def fix_mechanical_benefits_in_power(self, power_data: Dict) -> bool:
        """Fix all mechanical_benefit sections in a single power."""
        modified = False

        for synergy_type in ['class_synergies', 'species_synergies', 'faction_synergies']:
            synergies = power_data.get(synergy_type, [])
            for i, synergy in enumerate(synergies):
                mechanical_benefit = synergy.get('mechanical_benefit')

                # Check if it's a string that needs conversion
                if isinstance(mechanical_benefit, str):
                    parsed = self.parse_mechanical_benefit_string(mechanical_benefit)
                    structured_benefit = self.convert_to_structured_benefit(parsed)

                    # Replace string with structured benefit
                    synergies[i]['mechanical_benefit'] = [structured_benefit]
                    modified = True

        return modified

    def process_all_powers(self) -> Dict[str, bool]:
        """Process all powers and fix mechanical benefits."""
        results = {}

        for power_id, power_data in self.powers.items():
            try:
                modified = self.fix_mechanical_benefits_in_power(power_data)
                results[power_id] = modified

                if modified:
                    self.fixed_powers += 1
                    # Save the updated power
                    self.save_power(power_id, power_data)

            except Exception as e:
                self.errors.append(f"Error processing {power_id}: {e}")
                results[power_id] = False

        return results

    def save_power(self, power_id: str, power_data: Dict):
        """Save a power back to its file."""
        # Find the file by ID
        for power_file in self.powers_directory.glob("*.yml"):
            if power_file.name.startswith("power_"):
                with open(power_file, 'r', encoding='utf-8') as f:
                    file_data = yaml.safe_load(f)
                    if file_data and file_data.get('id') == power_id:
                        # Save updated data
                        with open(power_file, 'w', encoding='utf-8') as f:
                            yaml.dump(power_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
                        break

    def generate_report(self, results: Dict[str, bool]) -> str:
        """Generate a comprehensive report of the conversion process."""
        report = []
        report.append("=" * 80)
        report.append("MECHANICAL BENEFIT STRUCTURE FIX REPORT")
        report.append("=" * 80)
        report.append("")

        # Summary statistics
        total_powers = len(results)
        powers_fixed = sum(1 for fixed in results.values() if fixed)
        powers_unchanged = total_powers - powers_fixed

        report.append(f"Total Powers Processed: {total_powers}")
        report.append(f"Powers Fixed: {powers_fixed}")
        report.append(f"Powers Unchanged: {powers_unchanged}")
        report.append("")

        if self.errors:
            report.append("ERRORS ENCOUNTERED:")
            report.append("-" * 40)
            for error in self.errors:
                report.append(f"❌ {error}")
            report.append("")

        # Powers fixed
        if powers_fixed > 0:
            report.append("POWERS SUCCESSFULLY FIXED:")
            report.append("-" * 40)
            for power_id, was_fixed in results.items():
                if was_fixed:
                    report.append(f"✅ {power_id}")
            report.append("")

        # Powers unchanged
        if powers_unchanged > 0:
            report.append("POWERS ALREADY CORRECT:")
            report.append("-" * 40)
            for power_id, was_fixed in results.items():
                if not was_fixed:
                    report.append(f"✅ {power_id}")
            report.append("")

        report.append("=" * 80)
        report.append("CONVERSION COMPLETE")
        report.append("=" * 80)

        return "\n".join(report)

    def run_conversion(self) -> bool:
        """Run the complete mechanical benefit conversion process."""
        print("Loading powers...")
        if not self.load_powers():
            return False

        print("Converting mechanical benefits...")
        results = self.process_all_powers()

        print("Generating report...")
        report = self.generate_report(results)

        # Save report to file
        report_file = Path("mechanical_benefit_fix_report.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)

        print(f"Report saved to {report_file}")
        print("\n" + report)

        # Return success if no errors
        return len(self.errors) == 0

def main():
    """Main function to run mechanical benefit conversion."""
    converter = MechanicalBenefitConverter()
    success = converter.run_conversion()

    if success:
        print("\n✅ Mechanical benefit conversion completed successfully!")
        sys.exit(0)
    else:
        print("\n❌ Mechanical benefit conversion completed with errors.")
        sys.exit(1)

if __name__ == "__main__":
    main()
