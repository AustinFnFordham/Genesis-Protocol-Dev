#!/usr/bin/env python3
"""
Creative Pass Automation Script

This script helps automate the creative pass process by identifying powers that need
creative enhancement and providing templates for common transformations.
"""

import yaml
import os
import sys
import random
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from enum import Enum

class CreativePassStatus(Enum):
    NEEDS_CREATIVE_PASS = "needs_creative_pass"
    PARTIALLY_COMPLETE = "partially_complete"
    COMPLETE = "complete"

@dataclass
class CreativePassIssue:
    power_id: str
    issue_type: str
    description: str
    severity: str
    suggested_fix: str = ""

class CreativePassAnalyzer:
    def __init__(self, powers_directory: str = "data/powers"):
        self.powers_directory = Path(powers_directory)
        self.issues: List[CreativePassIssue] = []
        self.powers: Dict[str, Dict] = {}

        # Load templates from external file
        self._load_templates()

    def _load_templates(self):
        """Load templates from external YAML file."""
        template_file = Path(__file__).parent / "creative_pass_templates.yml"

        try:
            with open(template_file, 'r', encoding='utf-8') as f:
                templates = yaml.safe_load(f)
                self.narrative_templates = templates.get('narrative_templates', {})
                self.flavor_text_templates = templates.get('flavor_text_templates', {})
                self.manifestation_templates = templates.get('manifestation_templates', {})
        except Exception as e:
            print(f"Warning: Could not load templates from {template_file}: {e}")
            # Fallback to empty templates
            self.narrative_templates = {}
            self.flavor_text_templates = {}
            self.manifestation_templates = {}

    def _get_power_archetype(self, power_data: Dict) -> str:
        """Helper method to determine power archetype from power characteristics."""
        power_type = power_data.get('power_type', '')
        alignment = power_data.get('alignment', '')
        name = power_data.get('name', '').lower()

        # Determine template based on power characteristics
        if power_type == 'Force':
            if alignment == 'Light':
                if 'heal' in name or 'restore' in name:
                    return 'force_healing'
                elif 'mind' in name or 'trick' in name:
                    return 'force_mental'
                else:
                    return 'force_telekinetic'
            elif alignment == 'Dark':
                return 'force_destructive'
            else:
                return 'force_telekinetic'
        elif power_type == 'Tech':
            if 'ion' in name or 'electronic' in name or 'hack' in name:
                return 'tech_electronic'
            else:
                return 'tech_combat'
        else:
            return 'maneuver_tactical'
    
    def load_powers(self) -> bool:
        """Load all power files from the directory."""
        try:
            for power_file in self.powers_directory.glob("*.yml"):
                if power_file.name.startswith("power_"):
                    with open(power_file, 'r', encoding='utf-8') as f:
                        power_data = yaml.safe_load(f)
                        if power_data and 'id' in power_data:
                            self.powers[power_data['id']] = power_data
            print(f"Loaded {len(self.powers)} powers for analysis")
            return True
        except Exception as e:
            print(f"Error loading powers: {e}")
            return False
    
    def analyze_narrative_quality(self, power_id: str, power_data: Dict) -> List[CreativePassIssue]:
        """Analyze narrative quality and identify issues."""
        issues = []
        
        narrative = power_data.get('narrative', '')
        if not narrative:
            issues.append(CreativePassIssue(
                power_id, "missing_narrative", "Power is missing narrative description",
                "high", "Add rich, cinematic narrative description"
            ))
        elif "mastery of the Force and years of dedicated training" in narrative:
            issues.append(CreativePassIssue(
                power_id, "generic_narrative", "Power uses generic templated narrative",
                "high", "Replace with power-specific, cinematic description"
            ))
        elif len(narrative) < 100:
            issues.append(CreativePassIssue(
                power_id, "short_narrative", "Narrative is too short and lacks detail",
                "medium", "Expand narrative with rich, descriptive content"
            ))
        
        return issues
    
    def analyze_flavor_text_quality(self, power_id: str, power_data: Dict) -> List[CreativePassIssue]:
        """Analyze flavor text quality and identify issues."""
        issues = []
        
        flavor_text = power_data.get('flavor_text', '')
        if not flavor_text:
            issues.append(CreativePassIssue(
                power_id, "missing_flavor_text", "Power is missing flavor text",
                "high", "Add iconic Star Wars quote"
            ))
        elif "Unknown Master" in flavor_text or "Unknown Engineer" in flavor_text:
            issues.append(CreativePassIssue(
                power_id, "placeholder_flavor_text", "Power uses placeholder flavor text",
                "high", "Replace with iconic Star Wars quote from established character"
            ))
        
        return issues
    
    def analyze_manifestation_quality(self, power_id: str, power_data: Dict) -> List[CreativePassIssue]:
        """Analyze manifestation quality and identify issues."""
        issues = []
        
        manifestation = power_data.get('manifestation', [])
        if not manifestation:
            issues.append(CreativePassIssue(
                power_id, "missing_manifestation", "Power is missing manifestation description",
                "high", "Add specific manifestation components"
            ))
        else:
            for manifest in manifestation:
                if isinstance(manifest, str):
                    issues.append(CreativePassIssue(
                        power_id, "string_manifestation", "Manifestation should be structured",
                        "high", "Convert to structured format with type and description"
                    ))
                elif isinstance(manifest, dict) and 'type' in manifest:
                    description = manifest.get('description', '')
                    if not description or len(description) < 10:
                        issues.append(CreativePassIssue(
                            power_id, "vague_manifestation", "Manifestation description is too vague",
                            "medium", "Add specific, evocative description"
                        ))
        
        return issues
    
    def analyze_synergy_quality(self, power_id: str, power_data: Dict) -> List[CreativePassIssue]:
        """Analyze synergy quality and identify issues."""
        issues = []
        
        for synergy_type in ['class_synergies', 'species_synergies', 'faction_synergies']:
            synergies = power_data.get(synergy_type, [])
            if not synergies:
                issues.append(CreativePassIssue(
                    power_id, f"missing_{synergy_type}", f"Power is missing {synergy_type}",
                    "medium", f"Add meaningful {synergy_type} with structured mechanics"
                ))
            else:
                for synergy in synergies:
                    narrative = synergy.get('narrative', '')
                    if not narrative:
                        issues.append(CreativePassIssue(
                            power_id, f"missing_{synergy_type}_narrative", f"{synergy_type} missing narrative",
                            "medium", f"Add specific narrative for {synergy_type}"
                        ))
                    elif "excel at using" in narrative and "powers" in narrative:
                        issues.append(CreativePassIssue(
                            power_id, f"generic_{synergy_type}_narrative", f"{synergy_type} uses generic narrative",
                            "medium", f"Replace with power-specific {synergy_type} narrative"
                        ))
                    
                    mechanical_benefit = synergy.get('mechanical_benefit')
                    if isinstance(mechanical_benefit, str):
                        issues.append(CreativePassIssue(
                            power_id, f"string_{synergy_type}_benefit", f"{synergy_type} uses string format",
                            "high", f"Convert {synergy_type} mechanical_benefit to structured format"
                        ))
        
        return issues
    
    def analyze_llm_guidance_quality(self, power_id: str, power_data: Dict) -> List[CreativePassIssue]:
        """Analyze LLM guidance quality and identify issues."""
        issues = []
        
        llm_guidance = power_data.get('llm_guidance', {})
        if not llm_guidance:
            issues.append(CreativePassIssue(
                power_id, "missing_llm_guidance", "Power is missing LLM guidance section",
                "high", "Add comprehensive LLM guidance with roleplay, tactical, and narrative elements"
            ))
        else:
            # Check roleplay guidance
            roleplay_guidance = llm_guidance.get('roleplay_guidance', '')
            if not roleplay_guidance:
                issues.append(CreativePassIssue(
                    power_id, "missing_roleplay_guidance", "Power is missing roleplay guidance",
                    "high", "Add specific roleplay guidance for describing the power"
                ))
            elif "describe the character's expertise and the visible effects" in roleplay_guidance:
                issues.append(CreativePassIssue(
                    power_id, "generic_roleplay_guidance", "Power uses generic roleplay guidance",
                    "high", "Replace with power-specific roleplay guidance"
                ))
            
            # Check tactical notes
            tactical_notes = llm_guidance.get('tactical_notes', '')
            if not tactical_notes:
                issues.append(CreativePassIssue(
                    power_id, "missing_tactical_notes", "Power is missing tactical notes",
                    "high", "Add specific tactical guidance for using the power"
                ))
            elif "should be used strategically to maximize its effectiveness" in tactical_notes:
                issues.append(CreativePassIssue(
                    power_id, "generic_tactical_notes", "Power uses generic tactical notes",
                    "high", "Replace with power-specific tactical guidance"
                ))
            
            # Check narrative hooks
            narrative_hooks = llm_guidance.get('narrative_hooks', [])
            if not narrative_hooks:
                issues.append(CreativePassIssue(
                    power_id, "missing_narrative_hooks", "Power is missing narrative hooks",
                    "high", "Add specific narrative hooks for storytelling"
                ))
            elif any("creates an opportunity for character development" in hook for hook in narrative_hooks):
                issues.append(CreativePassIssue(
                    power_id, "generic_narrative_hooks", "Power uses generic narrative hooks",
                    "high", "Replace with power-specific narrative hooks"
                ))
        
        return issues
    
    def analyze_image_generation_quality(self, power_id: str, power_data: Dict) -> List[CreativePassIssue]:
        """Analyze image generation quality and identify issues."""
        issues = []
        
        image_generation = power_data.get('image_generation', {})
        if not image_generation:
            issues.append(CreativePassIssue(
                power_id, "missing_image_generation", "Power is missing image generation section",
                "high", "Add detailed image generation prompts"
            ))
        else:
            base_prompt = image_generation.get('base_prompt', '')
            if not base_prompt:
                issues.append(CreativePassIssue(
                    power_id, "missing_base_prompt", "Power is missing base prompt",
                    "high", "Add detailed, cinematic base prompt"
                ))
            elif "with visible Force energy effects and dynamic action" in base_prompt:
                issues.append(CreativePassIssue(
                    power_id, "generic_base_prompt", "Power uses generic base prompt",
                    "high", "Replace with power-specific, detailed base prompt"
                ))
            elif len(base_prompt) < 100:
                issues.append(CreativePassIssue(
                    power_id, "short_base_prompt", "Base prompt is too short",
                    "medium", "Expand base prompt with detailed visual descriptions"
                ))
        
        return issues
    
    def analyze_all_powers(self) -> Dict[str, List[CreativePassIssue]]:
        """Analyze all powers for creative pass needs."""
        results = {}
        
        for power_id, power_data in self.powers.items():
            power_issues = []
            
            # Run all analyses
            power_issues.extend(self.analyze_narrative_quality(power_id, power_data))
            power_issues.extend(self.analyze_flavor_text_quality(power_id, power_data))
            power_issues.extend(self.analyze_manifestation_quality(power_id, power_data))
            power_issues.extend(self.analyze_synergy_quality(power_id, power_data))
            power_issues.extend(self.analyze_llm_guidance_quality(power_id, power_data))
            power_issues.extend(self.analyze_image_generation_quality(power_id, power_data))
            
            results[power_id] = power_issues
            self.issues.extend(power_issues)
        
        return results
    
    def get_creative_pass_status(self, power_id: str, issues: List[CreativePassIssue]) -> CreativePassStatus:
        """Determine the creative pass status of a power."""
        high_severity_issues = [issue for issue in issues if issue.severity == "high"]
        medium_severity_issues = [issue for issue in issues if issue.severity == "medium"]
        
        if len(high_severity_issues) > 0:
            return CreativePassStatus.NEEDS_CREATIVE_PASS
        elif len(medium_severity_issues) > 0:
            return CreativePassStatus.PARTIALLY_COMPLETE
        else:
            return CreativePassStatus.COMPLETE
    
    def suggest_narrative_template(self, power_id: str, power_data: Dict) -> str:
        """Suggest a narrative template based on power characteristics."""
        archetype = self._get_power_archetype(power_data)
        return self.narrative_templates.get(archetype, self.narrative_templates.get('force_telekinetic', ''))
    
    def suggest_flavor_text_template(self, power_id: str, power_data: Dict) -> str:
        """Suggest a flavor text template based on power characteristics."""
        power_type = power_data.get('power_type', '')
        alignment = power_data.get('alignment', '')

        if power_type == 'Force':
            if alignment == 'Light':
                return random.choice(self.flavor_text_templates.get('force_light', []))
            elif alignment == 'Dark':
                return random.choice(self.flavor_text_templates.get('force_dark', []))
            else:
                return random.choice(self.flavor_text_templates.get('force_universal', []))
        elif power_type == 'Tech':
            return random.choice(self.flavor_text_templates.get('tech', []))
        else:
            return random.choice(self.flavor_text_templates.get('maneuver', []))
    
    def suggest_manifestation_template(self, power_id: str, power_data: Dict) -> List[Dict]:
        """Suggest a manifestation template based on power characteristics."""
        archetype = self._get_power_archetype(power_data)

        # Convert template to structured format
        template = self.manifestation_templates.get(archetype, self.manifestation_templates.get('force_telekinetic', []))
        return [
            {"type": "Somatic", "description": template[0].split(" (")[1].rstrip(")")},
            {"type": "Mental Focus", "description": template[1].split(" (")[1].rstrip(")")}
        ]
    
    def generate_creative_pass_report(self, results: Dict[str, List[CreativePassIssue]]) -> str:
        """Generate a comprehensive creative pass report."""
        report = []
        report.append("=" * 80)
        report.append("CREATIVE PASS ANALYSIS REPORT")
        report.append("=" * 80)
        report.append("")
        
        # Summary statistics
        total_powers = len(results)
        total_issues = len(self.issues)
        
        issues_by_severity = {"high": 0, "medium": 0, "low": 0}
        powers_by_status = {"needs_creative_pass": 0, "partially_complete": 0, "complete": 0}
        
        for issue in self.issues:
            issues_by_severity[issue.severity] += 1
        
        for power_id, issues in results.items():
            status = self.get_creative_pass_status(power_id, issues)
            powers_by_status[status.value] += 1
        
        report.append(f"Total Powers Analyzed: {total_powers}")
        report.append(f"Total Issues Found: {total_issues}")
        report.append("")
        report.append("Issues by Severity:")
        report.append(f"  High: {issues_by_severity['high']}")
        report.append(f"  Medium: {issues_by_severity['medium']}")
        report.append(f"  Low: {issues_by_severity['low']}")
        report.append("")
        report.append("Powers by Creative Pass Status:")
        report.append(f"  Needs Creative Pass: {powers_by_status['needs_creative_pass']}")
        report.append(f"  Partially Complete: {powers_by_status['partially_complete']}")
        report.append(f"  Complete: {powers_by_status['complete']}")
        report.append("")
        
        # Powers needing creative pass
        powers_needing_pass = {power_id: issues for power_id, issues in results.items() 
                              if self.get_creative_pass_status(power_id, issues) == CreativePassStatus.NEEDS_CREATIVE_PASS}
        
        if powers_needing_pass:
            report.append("POWERS NEEDING CREATIVE PASS:")
            report.append("-" * 40)
            report.append("")
            
            for power_id, issues in powers_needing_pass.items():
                power_data = self.powers[power_id]
                report.append(f"Power: {power_id}")
                report.append(f"  Name: {power_data.get('name', 'Unknown')}")
                report.append(f"  Type: {power_data.get('power_type', 'Unknown')}")
                report.append(f"  Alignment: {power_data.get('alignment', 'Unknown')}")
                report.append(f"  Issues: {len(issues)}")
                
                # Group issues by type
                issues_by_type = {}
                for issue in issues:
                    if issue.issue_type not in issues_by_type:
                        issues_by_type[issue.issue_type] = []
                    issues_by_type[issue.issue_type].append(issue)
                
                for issue_type, type_issues in issues_by_type.items():
                    report.append(f"  {issue_type}:")
                    for issue in type_issues:
                        report.append(f"    [{issue.severity}] {issue.description}")
                        if issue.suggested_fix:
                            report.append(f"      Suggested Fix: {issue.suggested_fix}")
                
                # Suggest templates
                report.append("  Suggested Templates:")
                narrative_template = self.suggest_narrative_template(power_id, power_data)
                report.append(f"    Narrative: {narrative_template[:100]}...")
                
                flavor_template = self.suggest_flavor_text_template(power_id, power_data)
                report.append(f"    Flavor Text: {flavor_template}")
                
                manifestation_template = self.suggest_manifestation_template(power_id, power_data)
                report.append(f"    Manifestation: {manifestation_template}")
                
                report.append("")
        
        # Powers partially complete
        powers_partial = {power_id: issues for power_id, issues in results.items() 
                         if self.get_creative_pass_status(power_id, issues) == CreativePassStatus.PARTIALLY_COMPLETE}
        
        if powers_partial:
            report.append("POWERS PARTIALLY COMPLETE:")
            report.append("-" * 40)
            report.append("")
            
            for power_id, issues in powers_partial.items():
                power_data = self.powers[power_id]
                report.append(f"Power: {power_id} ({power_data.get('name', 'Unknown')})")
                report.append(f"  Issues: {len(issues)}")
                
                for issue in issues:
                    report.append(f"    [{issue.severity}] {issue.description}")
                    if issue.suggested_fix:
                        report.append(f"      Suggested Fix: {issue.suggested_fix}")
                
                report.append("")
        
        # Powers complete
        powers_complete = {power_id: issues for power_id, issues in results.items() 
                          if self.get_creative_pass_status(power_id, issues) == CreativePassStatus.COMPLETE}
        
        if powers_complete:
            report.append("POWERS COMPLETE:")
            report.append("-" * 40)
            report.append("")
            
            for power_id in powers_complete.keys():
                power_data = self.powers[power_id]
                report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            
            report.append("")
        
        return "\n".join(report)
    
    def run_analysis(self) -> bool:
        """Run creative pass analysis and generate report."""
        print("Loading powers...")
        if not self.load_powers():
            return False
        
        print("Analyzing powers for creative pass needs...")
        results = self.analyze_all_powers()
        
        print("Generating report...")
        report = self.generate_creative_pass_report(results)
        
        # Save report to file
        report_file = Path("creative_pass_analysis_report.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"Report saved to {report_file}")
        print("\n" + report)
        
        # Return success if no high-severity issues
        high_severity_issues = [issue for issue in self.issues if issue.severity == "high"]
        return len(high_severity_issues) == 0

def main():
    """Main function to run creative pass analysis."""
    analyzer = CreativePassAnalyzer()
    success = analyzer.run_analysis()
    
    if success:
        print("\n✅ All powers have completed creative pass!")
        sys.exit(0)
    else:
        print("\n❌ Some powers need creative pass work.")
        sys.exit(1)

if __name__ == "__main__":
    main()
