#!/usr/bin/env node

/**
 * SW5e Data Hub - Quick Schema Validation Test
 * Tests our schemas against existing example files
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

class SchemaTester {
    constructor() {
        this.schemaDir = path.join(__dirname, '../schema');
        this.dataDir = path.join(__dirname, '../data');
        this.testResults = {
            timestamp: new Date().toISOString(),
            tests: [],
            summary: { total: 0, passed: 0, failed: 0 }
        };
    }

    async run() {
        console.log('🧪 Starting Schema Validation Tests\n');
        
        try {
            await this.testPowerSchema();
            await this.testStatusSchema();
            await this.testMasterActionSchema();
            await this.testFactionSchema();
            
            this.printSummary();
            await this.saveResults();
            
        } catch (error) {
            console.error('❌ Test failed:', error);
        }
    }

    async testPowerSchema() {
        console.log('⚡ Testing Power Schema...');
        
        const testFiles = [
            'data/powers/force_push.yml',
            'data/powers/force_heal.yml',
            'data/powers/tech_hack_terminal.yml'
        ];
        
        for (const file of testFiles) {
            await this.testFileAgainstSchema(file, 'Power');
        }
    }

    async testStatusSchema() {
        console.log('📊 Testing Status Schema...');
        
        const testFiles = [
            'data/status_effects/force_choke.yml',
            'data/status_effects/battle_meditation.yml',
            'data/status_effects/acid_corrosion.yml'
        ];
        
        for (const file of testFiles) {
            await this.testFileAgainstSchema(file, 'Status');
        }
    }

    async testMasterActionSchema() {
        console.log('🎯 Testing Master Action Schema...');
        
        const testFiles = [
            'data/actions/hack_terminal_master.yml',
            'data/combat_actions/lightsaber_parry.yml',
            'data/combat_actions/tech_overload.yml'
        ];
        
        for (const file of testFiles) {
            await this.testFileAgainstSchema(file, 'Master_Action');
        }
    }

    async testFactionSchema() {
        console.log('🏛️ Testing Faction Schema...');
        
        const testFiles = [
            'data/factions/jedi_order.yml',
            'data/factions/galactic_empire.yml'
        ];
        
        for (const file of testFiles) {
            await this.testFileAgainstSchema(file, 'Faction');
        }
    }

    async testFileAgainstSchema(dataFile, schemaName) {
        const filePath = path.join(__dirname, '..', dataFile);
        const schemaPath = path.join(this.schemaDir, `${schemaName}.schema.json`);
        
        this.testResults.summary.total++;
        
        try {
            // Check if files exist
            if (!fs.existsSync(filePath)) {
                this.addTestResult(dataFile, schemaName, false, `Data file not found: ${dataFile}`);
                return;
            }
            
            if (!fs.existsSync(schemaPath)) {
                this.addTestResult(dataFile, schemaName, false, `Schema file not found: ${schemaName}.schema.json`);
                return;
            }
            
            // Load and parse files
            const dataContent = fs.readFileSync(filePath, 'utf8');
            const schemaContent = fs.readFileSync(schemaPath, 'utf8');
            
            const data = yaml.load(dataContent);
            const schema = JSON.parse(schemaContent);
            
            // Basic validation
            const hasRequiredFields = this.checkRequiredFields(data, schema);
            const hasValidStructure = this.checkStructure(data, schema);
            
            if (hasRequiredFields && hasValidStructure) {
                this.addTestResult(dataFile, schemaName, true, 'Validation passed');
                console.log(`  ✅ ${dataFile} → ${schemaName}`);
            } else {
                this.addTestResult(dataFile, schemaName, false, 'Structure validation failed');
                console.log(`  ❌ ${dataFile} → ${schemaName}`);
            }
            
        } catch (error) {
            this.addTestResult(dataFile, schemaName, false, `Error: ${error.message}`);
            console.log(`  ❌ ${dataFile} → ${schemaName}: ${error.message}`);
        }
    }

    checkRequiredFields(data, schema) {
        if (!schema.required) return true;
        
        for (const field of schema.required) {
            if (!(field in data)) {
                return false;
            }
        }
        
        return true;
    }

    checkStructure(data, schema) {
        // Basic structure validation
        if (typeof data !== 'object') return false;
        
        // Check for required top-level fields
        const requiredFields = ['id', 'name'];
        for (const field of requiredFields) {
            if (!(field in data)) return false;
        }
        
        return true;
    }

    addTestResult(dataFile, schemaName, passed, message) {
        this.testResults.tests.push({
            dataFile,
            schemaName,
            passed,
            message,
            timestamp: new Date().toISOString()
        });
        
        if (passed) {
            this.testResults.summary.passed++;
        } else {
            this.testResults.summary.failed++;
        }
    }

    printSummary() {
        console.log('\n📊 Test Summary:');
        console.log(`  Total Tests: ${this.testResults.summary.total}`);
        console.log(`  ✅ Passed: ${this.testResults.summary.passed}`);
        console.log(`  ❌ Failed: ${this.testResults.summary.failed}`);
        
        const successRate = (this.testResults.summary.passed / this.testResults.summary.total * 100).toFixed(1);
        console.log(`  📈 Success Rate: ${successRate}%`);
        
        if (this.testResults.summary.failed > 0) {
            console.log('\n❌ Failed Tests:');
            this.testResults.tests
                .filter(test => !test.passed)
                .forEach(test => {
                    console.log(`  - ${test.dataFile} → ${test.schemaName}: ${test.message}`);
                });
        }
    }

    async saveResults() {
        const resultsFile = path.join(__dirname, '../schema_test_results.json');
        fs.writeFileSync(resultsFile, JSON.stringify(this.testResults, null, 2));
        console.log(`\n💾 Test results saved to ${resultsFile}`);
    }
}

if (require.main === module) {
    new SchemaTester().run();
}

module.exports = SchemaTester;
