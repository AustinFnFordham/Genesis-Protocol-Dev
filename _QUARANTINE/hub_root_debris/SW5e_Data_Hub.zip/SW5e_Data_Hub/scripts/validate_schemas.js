#!/usr/bin/env node

/**
 * SW5e Data Hub - Comprehensive Schema Validation System
 * 
 * This script validates all JSON schemas and their corresponding data files
 * to ensure consistency, proper structure, and cross-reference integrity.
 */

const fs = require('fs');
const path = require('path');
const Ajv = require('ajv');
const yaml = require('js-yaml');

// Configuration
const SCHEMA_DIR = path.join(__dirname, '../schema');
const DATA_DIR = path.join(__dirname, '../data');
const RESULTS_FILE = path.join(__dirname, '../validation_results.json');

// Initialize AJV for JSON Schema validation
const ajv = new Ajv({ allErrors: true, verbose: true });

class SchemaValidator {
    constructor() {
        this.schemas = new Map();
        this.dataFiles = new Map();
        this.validationResults = {
            timestamp: new Date().toISOString(),
            summary: {
                total_schemas: 0,
                valid_schemas: 0,
                total_data_files: 0,
                valid_data_files: 0,
                cross_reference_errors: 0,
                schema_errors: 0
            },
            schema_validation: {},
            data_validation: {},
            cross_references: {},
            recommendations: []
        };
    }

    /**
     * Load all JSON schemas from the schema directory
     */
    async loadSchemas() {
        console.log('🔍 Loading JSON schemas...');
        
        const schemaFiles = fs.readdirSync(SCHEMA_DIR)
            .filter(file => file.endsWith('.schema.json'));
        
        for (const file of schemaFiles) {
            const schemaPath = path.join(SCHEMA_DIR, file);
            const schemaName = file.replace('.schema.json', '');
            
            try {
                const schemaContent = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
                this.schemas.set(schemaName, schemaContent);
                console.log(`  ✅ Loaded ${schemaName} schema`);
            } catch (error) {
                console.error(`  ❌ Failed to load ${schemaName} schema:`, error.message);
                this.validationResults.summary.schema_errors++;
            }
        }
        
        this.validationResults.summary.total_schemas = this.schemas.size;
        console.log(`📊 Loaded ${this.schemas.size} schemas`);
    }

    /**
     * Validate all schemas against JSON Schema specification
     */
    async validateSchemas() {
        console.log('\n🔧 Validating schema structure...');
        
        for (const [schemaName, schema] of this.schemas) {
            try {
                // Compile schema to check for structural issues
                const validate = ajv.compile(schema);
                
                this.validationResults.schema_validation[schemaName] = {
                    valid: true,
                    errors: [],
                    warnings: []
                };
                
                this.validationResults.summary.valid_schemas++;
                console.log(`  ✅ ${schemaName} schema is valid`);
                
            } catch (error) {
                this.validationResults.schema_validation[schemaName] = {
                    valid: false,
                    errors: [error.message],
                    warnings: []
                };
                
                console.error(`  ❌ ${schemaName} schema has errors:`, error.message);
            }
        }
    }

    /**
     * Load and validate all YAML data files
     */
    async loadAndValidateDataFiles() {
        console.log('\n📁 Loading and validating data files...');
        
        const dataFiles = this.findYamlFiles(DATA_DIR);
        
        for (const filePath of dataFiles) {
            const relativePath = path.relative(DATA_DIR, filePath);
            
            try {
                const content = fs.readFileSync(filePath, 'utf8');
                const data = yaml.load(content);
                
                this.dataFiles.set(relativePath, data);
                
                // Determine which schema this file should use
                const schemaName = this.determineSchemaForFile(relativePath);
                
                if (schemaName && this.schemas.has(schemaName)) {
                    const isValid = this.validateDataAgainstSchema(data, schemaName, relativePath);
                    
                    if (isValid) {
                        this.validationResults.summary.valid_data_files++;
                    }
                }
                
                this.validationResults.summary.total_data_files++;
                
            } catch (error) {
                console.error(`  ❌ Failed to load ${relativePath}:`, error.message);
            }
        }
        
        console.log(`📊 Loaded ${this.dataFiles.size} data files`);
    }

    /**
     * Find all YAML files recursively
     */
    findYamlFiles(dir) {
        const files = [];
        
        const scanDir = (currentDir) => {
            const items = fs.readdirSync(currentDir);
            
            for (const item of items) {
                const itemPath = path.join(currentDir, item);
                const stat = fs.statSync(itemPath);
                
                if (stat.isDirectory()) {
                    scanDir(itemPath);
                } else if (item.endsWith('.yml') || item.endsWith('.yaml')) {
                    files.push(itemPath);
                }
            }
        };
        
        scanDir(dir);
        return files;
    }

    /**
     * Determine which schema a data file should use based on its path
     */
    determineSchemaForFile(filePath) {
        const pathParts = filePath.split(path.sep);
        
        // Map directory names to schema names
        const schemaMapping = {
            'powers': 'Power',
            'status_effects': 'Status',
            'actions': 'Master_Action',
            'combat_actions': 'Master_Action',
            'items': 'Item',
            'factions': 'Faction',
            'lore': 'Lore',
            'backgrounds': 'Background',
            'starships': 'Starship',
            'crafting': 'CraftingRecipe',
            'classes': 'CharacterClass',
            'subclasses': 'CharacterSubclass',
            'features': 'CharacterClassFeature',
            'species': 'Species',
            'companions': 'Companion',
            'campaigns': 'CampaignState',
            'characters': 'Character',
            'nemeses': 'Nemesis'
        };
        
        // Check each directory level for a match
        for (const part of pathParts) {
            if (schemaMapping[part]) {
                return schemaMapping[part];
            }
        }
        
        return null;
    }

    /**
     * Validate data against its corresponding schema
     */
    validateDataAgainstSchema(data, schemaName, filePath) {
        const schema = this.schemas.get(schemaName);
        const validate = ajv.compile(schema);
        
        const isValid = validate(data);
        
        if (!this.validationResults.data_validation[filePath]) {
            this.validationResults.data_validation[filePath] = {
                schema: schemaName,
                valid: isValid,
                errors: validate.errors || [],
                warnings: []
            };
        }
        
        if (!isValid) {
            console.error(`  ❌ ${filePath} failed validation against ${schemaName}:`);
            validate.errors.forEach(error => {
                console.error(`    - ${error.instancePath}: ${error.message}`);
            });
        } else {
            console.log(`  ✅ ${filePath} is valid against ${schemaName}`);
        }
        
        return isValid;
    }

    /**
     * Validate cross-references between data files
     */
    async validateCrossReferences() {
        console.log('\n🔗 Validating cross-references...');
        
        const idRegistry = new Map();
        const references = [];
        
        // Build ID registry
        for (const [filePath, data] of this.dataFiles) {
            if (data.id) {
                idRegistry.set(data.id, {
                    file: filePath,
                    type: this.determineSchemaForFile(filePath),
                    data: data
                });
            }
        }
        
        // Find all references
        for (const [filePath, data] of this.dataFiles) {
            this.findReferences(data, filePath, references);
        }
        
        // Validate references
        for (const ref of references) {
            const targetExists = idRegistry.has(ref.targetId);
            
            if (!targetExists) {
                this.validationResults.summary.cross_reference_errors++;
                console.error(`  ❌ ${ref.sourceFile}:${ref.path} references non-existent ID "${ref.targetId}"`);
                
                if (!this.validationResults.cross_references[ref.sourceFile]) {
                    this.validationResults.cross_references[ref.sourceFile] = [];
                }
                this.validationResults.cross_references[ref.sourceFile].push({
                    path: ref.path,
                    targetId: ref.targetId,
                    error: 'Target ID does not exist'
                });
            } else {
                console.log(`  ✅ ${ref.sourceFile}:${ref.path} → ${ref.targetId}`);
            }
        }
        
        console.log(`📊 Validated ${references.length} cross-references`);
    }

    /**
     * Recursively find all ID references in data
     */
    findReferences(obj, filePath, references, currentPath = '') {
        if (typeof obj === 'object' && obj !== null) {
            for (const [key, value] of Object.entries(obj)) {
                const newPath = currentPath ? `${currentPath}.${key}` : key;
                
                if (typeof value === 'string' && this.looksLikeId(value)) {
                    references.push({
                        sourceFile: filePath,
                        path: newPath,
                        targetId: value
                    });
                } else if (typeof value === 'object') {
                    this.findReferences(value, filePath, references, newPath);
                } else if (Array.isArray(value)) {
                    value.forEach((item, index) => {
                        if (typeof item === 'string' && this.looksLikeId(item)) {
                            references.push({
                                sourceFile: filePath,
                                path: `${newPath}[${index}]`,
                                targetId: item
                            });
                        } else if (typeof item === 'object') {
                            this.findReferences(item, filePath, references, `${newPath}[${index}]`);
                        }
                    });
                }
            }
        }
    }

    /**
     * Check if a string looks like an ID reference
     */
    looksLikeId(str) {
        // Common ID patterns in our system
        const idPatterns = [
            /^[a-z_]+_[a-z_]+$/,  // snake_case with underscores
            /^[a-z]+[A-Z][a-z]+$/, // camelCase
            /^[a-z]+_[a-z]+$/,     // simple snake_case
        ];
        
        return idPatterns.some(pattern => pattern.test(str)) && str.length > 3;
    }

    /**
     * Generate recommendations based on validation results
     */
    generateRecommendations() {
        console.log('\n💡 Generating recommendations...');
        
        const recommendations = [];
        
        // Schema recommendations
        if (this.validationResults.summary.schema_errors > 0) {
            recommendations.push({
                type: 'schema',
                priority: 'high',
                message: 'Fix schema structural errors before proceeding with data validation',
                count: this.validationResults.summary.schema_errors
            });
        }
        
        // Cross-reference recommendations
        if (this.validationResults.summary.cross_reference_errors > 0) {
            recommendations.push({
                type: 'cross_reference',
                priority: 'high',
                message: 'Fix broken cross-references to ensure data integrity',
                count: this.validationResults.summary.cross_reference_errors
            });
        }
        
        // Data validation recommendations
        const invalidDataFiles = Object.values(this.validationResults.data_validation)
            .filter(result => !result.valid).length;
        
        if (invalidDataFiles > 0) {
            recommendations.push({
                type: 'data_validation',
                priority: 'medium',
                message: 'Refactor data files to match new schema structures',
                count: invalidDataFiles
            });
        }
        
        // Success recommendations
        if (this.validationResults.summary.cross_reference_errors === 0 && 
            this.validationResults.summary.schema_errors === 0) {
            recommendations.push({
                type: 'success',
                priority: 'low',
                message: 'All schemas and cross-references are valid! Ready for content refactor.',
                count: 0
            });
        }
        
        this.validationResults.recommendations = recommendations;
        
        recommendations.forEach(rec => {
            const emoji = rec.priority === 'high' ? '🔴' : rec.priority === 'medium' ? '🟡' : '🟢';
            console.log(`  ${emoji} ${rec.message} (${rec.count} issues)`);
        });
    }

    /**
     * Save validation results to file
     */
    async saveResults() {
        fs.writeFileSync(RESULTS_FILE, JSON.stringify(this.validationResults, null, 2));
        console.log(`\n💾 Validation results saved to ${RESULTS_FILE}`);
    }

    /**
     * Run the complete validation process
     */
    async run() {
        console.log('🚀 Starting SW5e Data Hub Schema Validation\n');
        
        try {
            await this.loadSchemas();
            await this.validateSchemas();
            await this.loadAndValidateDataFiles();
            await this.validateCrossReferences();
            this.generateRecommendations();
            await this.saveResults();
            
            console.log('\n✅ Validation complete!');
            console.log(`📊 Summary:`);
            console.log(`  - Schemas: ${this.validationResults.summary.valid_schemas}/${this.validationResults.summary.total_schemas} valid`);
            console.log(`  - Data Files: ${this.validationResults.summary.valid_data_files}/${this.validationResults.summary.total_data_files} valid`);
            console.log(`  - Cross-References: ${this.validationResults.summary.cross_reference_errors} errors`);
            
        } catch (error) {
            console.error('❌ Validation failed:', error);
            process.exit(1);
        }
    }
}

// Run validation if this script is executed directly
if (require.main === module) {
    const validator = new SchemaValidator();
    validator.run();
}

module.exports = SchemaValidator;
