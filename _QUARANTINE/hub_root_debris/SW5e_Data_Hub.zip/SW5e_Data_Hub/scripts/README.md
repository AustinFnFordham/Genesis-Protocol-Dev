# SW5e Data Hub - Validation Scripts

This directory contains validation scripts for the SW5e Data Hub system to ensure schema integrity, data consistency, and proper registry integration.

## Scripts Overview

### 1. `validate_schemas.js` - Comprehensive Schema Validation
**Purpose**: Validates all JSON schemas and their corresponding data files

**Features**:
- ✅ JSON Schema structure validation
- ✅ Data file validation against schemas
- ✅ Cross-reference validation
- ✅ Comprehensive error reporting
- ✅ Recommendations generation

**Usage**:
```bash
cd scripts
npm install
node validate_schemas.js
```

### 2. `validate_registry.js` - Registry Integration Validation
**Purpose**: Validates the "single source of truth" principle for registry references

**Features**:
- ✅ Registry file loading and validation
- ✅ Cross-reference validation between data files and registries
- ✅ ID reference validation
- ✅ Broken reference detection

**Usage**:
```bash
node validate_registry.js
```

### 3. `test_schema_validation.js` - Quick Schema Tests
**Purpose**: Quick validation tests for our example files against schemas

**Features**:
- ✅ Tests example files against their schemas
- ✅ Basic structure validation
- ✅ Required field validation
- ✅ Quick feedback for development

**Usage**:
```bash
node test_schema_validation.js
```

## Installation

1. Install dependencies:
```bash
cd scripts
npm install
```

2. Run validation:
```bash
# Full schema validation
node validate_schemas.js

# Registry validation only
node validate_registry.js

# Quick tests
node test_schema_validation.js
```

## Output Files

The scripts generate the following output files:

- `validation_results.json` - Comprehensive schema validation results
- `registry_validation_results.json` - Registry integration validation results
- `schema_test_results.json` - Quick test results

## Validation Process

### Phase 1: Schema Structure Validation
- Validates JSON Schema syntax and structure
- Checks for required fields and proper typing
- Ensures schemas follow our "gold standard" format

### Phase 2: Data File Validation
- Validates all YAML data files against their schemas
- Checks for required fields and proper data types
- Ensures data follows schema specifications

### Phase 3: Cross-Reference Validation
- Validates all ID references between files
- Ensures registry references are valid
- Checks for broken links and orphaned references

### Phase 4: Registry Integration Validation
- Validates "single source of truth" principle
- Ensures all registry references point to valid entries
- Checks for missing registries or broken references

## Expected Results

### ✅ Success Criteria
- All schemas pass JSON Schema validation
- All data files validate against their schemas
- All cross-references are valid
- All registry references point to existing entries
- No broken links or orphaned references

### ❌ Common Issues
- **Schema Errors**: Invalid JSON Schema syntax
- **Data Validation Errors**: Data files don't match schema structure
- **Cross-Reference Errors**: ID references point to non-existent entries
- **Registry Errors**: Registry references are broken or missing

## Recommendations

The validation scripts generate recommendations based on findings:

- 🔴 **High Priority**: Fix schema structural errors
- 🟡 **Medium Priority**: Refactor data files to match schemas
- 🟢 **Low Priority**: All validations passed

## Integration with Development

These validation scripts are designed to be run:

1. **During Development**: Quick tests to catch issues early
2. **Before Commits**: Full validation to ensure quality
3. **In CI/CD**: Automated validation in deployment pipeline
4. **After Schema Changes**: Validate all data files still work

## Troubleshooting

### Common Issues

**"Module not found" errors**:
```bash
cd scripts
npm install
```

**"Schema not found" errors**:
- Ensure schema files exist in `../schema/` directory
- Check file naming convention (e.g., `Power.schema.json`)

**"Data file not found" errors**:
- Ensure data files exist in `../data/` directory
- Check file paths and naming

**"Registry not found" errors**:
- Ensure registry files exist in `../data/registry/` directory
- Check registry file naming and structure

## Next Steps

After running validation:

1. **Fix Critical Issues**: Address high-priority validation errors
2. **Refactor Data Files**: Update data files to match new schemas
3. **Validate Cross-References**: Ensure all ID references are valid
4. **Test Integration**: Run end-to-end tests
5. **Deploy**: Proceed with confidence that the system is validated

## Support

For issues with validation scripts:

1. Check the output files for detailed error information
2. Review the console output for specific error messages
3. Ensure all dependencies are installed
4. Verify file paths and naming conventions
