#!/usr/bin/env python3
"""
Power Catalog Extraction Script
Extracts individual powers from catalog files and converts them to gold standard format.
"""

import os
import yaml
import re
from pathlib import Path
from typing import Dict, Any, List

class PowerExtractor:
    def __init__(self, powers_dir: str):
        self.powers_dir = Path(powers_dir)
        self.extracted_count = 0
        self.error_count = 0
        self.errors = []
        
    def extract_powers_from_catalog(self, catalog_file: Path) -> bool:
        """Extract individual powers from a catalog file."""
        try:
            with open(catalog_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse YAML
            data = yaml.safe_load(content)
            if not data:
                print(f"⚠️  Empty file: {catalog_file}")
                return False
            
            # Determine the catalog type
            if 'force_powers' in data:
                powers = data['force_powers']
                power_type = 'Force'
            elif 'tech_powers' in data:
                powers = data['tech_powers']
                power_type = 'Tech'
            else:
                print(f"⚠️  Unknown catalog format: {catalog_file}")
                return False
            
            print(f"🔄 Extracting {len(powers)} {power_type} powers from {catalog_file}")
            
            # Extract each power
            for power_data in powers:
                if self.extract_single_power(power_data, power_type, catalog_file):
                    self.extracted_count += 1
            
            return True
            
        except Exception as e:
            error_msg = f"❌ Error processing {catalog_file}: {e}"
            print(error_msg)
            self.errors.append(error_msg)
            self.error_count += 1
            return False
    
    def extract_single_power(self, power_data: Dict[str, Any], power_type: str, source_file: Path) -> bool:
        """Extract a single power and convert to gold standard format."""
        try:
            # Get basic info
            power_id = power_data.get('id', '')
            power_name = power_data.get('name', '')
            
            if not power_id or not power_name:
                print(f"⚠️  Skipping power with missing id or name: {power_data}")
                return False
            
            # Ensure proper power ID format
            if not power_id.startswith('power_'):
                power_id = f"power_{power_id}"
            
            # Convert to gold standard format
            gold_standard_power = self.convert_to_gold_standard(power_data, power_type)
            
            # Create output file
            output_file = self.powers_dir / f"{power_id}.yml"
            
            # Write to file
            with open(output_file, 'w', encoding='utf-8') as f:
                yaml.dump(gold_standard_power, f, default_flow_style=False, sort_keys=False, 
                         allow_unicode=True, width=1000)
            
            print(f"✅ Extracted: {power_id} -> {output_file}")
            return True
            
        except Exception as e:
            error_msg = f"❌ Error extracting power {power_data.get('id', 'unknown')}: {e}"
            print(error_msg)
            self.errors.append(error_msg)
            self.error_count += 1
            return False
    
    def convert_to_gold_standard(self, power_data: Dict[str, Any], power_type: str) -> Dict[str, Any]:
        """Convert old power format to gold standard format."""
        gold_standard = {}
        
        # Basic fields
        gold_standard['id'] = f"power_{power_data.get('id', '').replace('power_', '')}"
        gold_standard['name'] = power_data.get('name', '')
        gold_standard['power_type'] = power_type
        gold_standard['alignment'] = power_data.get('alignment', 'Universal')
        gold_standard['level'] = power_data.get('level', 0)
        
        # Narrative block
        gold_standard['narrative'] = self.create_narrative(power_data)
        gold_standard['flavor_text'] = self.create_flavor_text(power_data)
        
        # Mechanics block
        gold_standard['casting_time'] = self.convert_casting_time(power_data)
        gold_standard['range'] = self.convert_range(power_data)
        gold_standard['duration'] = self.convert_duration(power_data)
        
        # Power cost (default for at-will powers)
        if power_data.get('level', 0) == 0:
            gold_standard['power_cost'] = []  # At-will powers have no cost
        else:
            gold_standard['power_cost'] = self.create_power_cost(power_data)
        
        # Manifestation
        gold_standard['manifestation'] = self.create_manifestation(power_data, power_type)
        
        # Base effect
        gold_standard['base_effect'] = self.create_base_effect(power_data)
        
        # Upgrades (if any)
        if 'upgrades' in power_data:
            gold_standard['upgrades'] = power_data['upgrades']
        
        # Synergies
        gold_standard['class_synergies'] = self.create_class_synergies(power_data)
        gold_standard['species_synergies'] = self.create_species_synergies(power_data)
        gold_standard['faction_synergies'] = self.create_faction_synergies(power_data)
        
        # LLM guidance
        gold_standard['llm_guidance'] = self.create_llm_guidance(power_data)
        
        # Image generation
        gold_standard['image_generation'] = self.create_image_generation(power_data, power_type)
        
        # UI
        gold_standard['ui'] = self.create_ui(power_data)
        
        return gold_standard
    
    def create_narrative(self, power_data: Dict[str, Any]) -> str:
        """Create rich narrative description."""
        description = power_data.get('description', '')
        name = power_data.get('name', '')
        
        if description:
            # Enhance the description into a rich narrative
            enhanced = f"{description} This power represents a mastery of the {power_data.get('type', 'Force')} and years of dedicated training. When used, it demonstrates the character's expertise and connection to their chosen path, creating dramatic and memorable moments in the story."
            return enhanced
        
        return f"{name} represents a significant advancement in the character's abilities, granting them new powers and capabilities that reflect their growing mastery of the {power_data.get('type', 'Force')}."
    
    def create_flavor_text(self, power_data: Dict[str, Any]) -> str:
        """Create flavor text quote."""
        name = power_data.get('name', '')
        power_type = power_data.get('type', 'Force')
        
        # Generate appropriate flavor text based on the power name and type
        if power_type == 'Force':
            if 'mind' in name.lower():
                return "'The mind is a powerful weapon.' - Jedi Master"
            elif 'battle' in name.lower() or 'combat' in name.lower():
                return "'In battle, the Force guides your hand.' - Jedi Knight"
            elif 'heal' in name.lower():
                return "'To heal is to give of oneself.' - Jedi Healer"
            else:
                return f"'{name} represents the power of the Force.' - Unknown Master"
        else:  # Tech
            if 'hack' in name.lower() or 'terminal' in name.lower():
                return "'I'll bypass the security system.' - R2-D2"
            elif 'scan' in name.lower():
                return "'Scanning for life forms.' - C-3PO"
            else:
                return f"'{name} represents technological mastery.' - Unknown Engineer"
    
    def convert_casting_time(self, power_data: Dict[str, Any]) -> str:
        """Convert casting time to string format."""
        casting_time = power_data.get('casting_time', {})
        if isinstance(casting_time, dict):
            value = casting_time.get('value', 1)
            unit = casting_time.get('unit', 'action')
            return f"{value} {unit.title()}"
        return "1 Action"
    
    def convert_range(self, power_data: Dict[str, Any]) -> str:
        """Convert range to string format."""
        range_data = power_data.get('range', {})
        if isinstance(range_data, dict):
            value = range_data.get('value', 30)
            unit = range_data.get('unit', 'feet')
            return f"{value} {unit}"
        return "30 feet"
    
    def convert_duration(self, power_data: Dict[str, Any]) -> str:
        """Convert duration to string format."""
        duration = power_data.get('duration', {})
        if isinstance(duration, dict):
            duration_type = duration.get('type', 'instantaneous')
            value = duration.get('value', 1)
            unit = duration.get('unit', 'round')
            
            if duration_type == 'concentration':
                return f"Concentration, up to {value} {unit}"
            elif duration_type == 'instantaneous':
                return "Instantaneous"
            else:
                return f"{value} {unit}"
        return "Instantaneous"
    
    def create_power_cost(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create power cost array."""
        level = power_data.get('level', 1)
        power_type = power_data.get('type', 'Force')
        
        if power_type == 'Force':
            cost_type = 'Force_Points'
        else:
            cost_type = 'Tech_Points'
        
        # Base cost based on level
        base_cost = max(1, level)
        
        return [
            {
                'type': cost_type,
                'amount': base_cost
            }
        ]
    
    def create_manifestation(self, power_data: Dict[str, Any], power_type: str) -> List[str]:
        """Create manifestation array."""
        if power_type == 'Force':
            return [
                "Somatic (Force gesture)",
                "Mental Focus (channeling the Force)"
            ]
        else:
            return [
                "Somatic (using interface)",
                "Mental Focus (concentration on code)"
            ]
    
    def create_base_effect(self, power_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create base effect structure."""
        effects = power_data.get('effects', [])
        
        return {
            'description': power_data.get('description', 'This power has a specific effect.'),
            'mechanics': effects
        }
    
    def create_class_synergies(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create class synergies."""
        power_type = power_data.get('type', 'Force')
        
        if power_type == 'Force':
            return [
                {
                    'class_id': 'guardian',
                    'narrative': 'Guardians excel at using Force powers defensively and in combat.',
                    'mechanical_benefit': 'Guardians gain +1 to Force power attack rolls.'
                }
            ]
        else:
            return [
                {
                    'class_id': 'engineer',
                    'narrative': 'Engineers are masters of technological powers and systems.',
                    'mechanical_benefit': 'Engineers gain +1 to Tech power attack rolls.'
                }
            ]
    
    def create_species_synergies(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create species synergies."""
        return [
            {
                'species_id': 'human',
                'narrative': 'Human adaptability allows them to quickly master new powers.',
                'mechanical_benefit': 'Humans gain advantage on power learning checks.'
            }
        ]
    
    def create_faction_synergies(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create faction synergies."""
        power_type = power_data.get('type', 'Force')
        
        if power_type == 'Force':
            return [
                {
                    'faction_id': 'jedi_order',
                    'narrative': 'The Jedi Order teaches the proper use of Force powers.',
                    'mechanical_benefit': 'Jedi gain +2 to Force power saving throw DCs.'
                }
            ]
        else:
            return [
                {
                    'faction_id': 'rebel_alliance',
                    'narrative': 'The Rebel Alliance values technological expertise.',
                    'mechanical_benefit': 'Rebels gain +2 to Tech power saving throw DCs.'
                }
            ]
    
    def create_llm_guidance(self, power_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create LLM guidance."""
        name = power_data.get('name', '')
        
        return {
            'roleplay_guidance': f"When using {name}, describe the character's expertise and the visible effects of their power. Focus on the narrative impact and how it affects the scene.",
            'tactical_notes': f"{name} should be used strategically to maximize its effectiveness. Consider the timing and positioning for optimal results.",
            'narrative_hooks': [
                f"The use of {name} creates an opportunity for character development",
                f"An enemy attempts to counter or resist {name}",
                f"The effects of {name} have unexpected consequences"
            ]
        }
    
    def create_image_generation(self, power_data: Dict[str, Any], power_type: str) -> Dict[str, Any]:
        """Create image generation."""
        name = power_data.get('name', '')
        
        if power_type == 'Force':
            base_prompt = f"A character using {name}, with visible Force energy effects and dynamic action. The scene should convey the mystical power and mastery of the Force."
        else:
            base_prompt = f"A character using {name}, with visible technological effects and dynamic action. The scene should convey the technical expertise and mastery of technology."
        
        return {
            'base_prompt': base_prompt,
            'base_negative_keywords': ['static', 'boring', 'cartoonish', 'blurry', 'unclear']
        }
    
    def create_ui(self, power_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create UI section."""
        power_id = power_data.get('id', 'unknown').replace('power_', '')
        
        return {
            'icon': f"/assets/icons/powers/{power_id}.svg",
            'color': "#0066CC"  # Default blue color
        }
    
    def process_catalog_files(self):
        """Process all catalog files in the powers directory."""
        print(f"🔄 Starting power extraction from catalog files in {self.powers_dir}")
        
        # Find catalog files
        catalog_files = [
            self.powers_dir / "force_powers.yml",
            self.powers_dir / "force_powers_extended.yml",
            self.powers_dir / "tech_powers.yml",
            self.powers_dir / "tech_powers_extended.yml"
        ]
        
        for catalog_file in catalog_files:
            if catalog_file.exists():
                print(f"📊 Processing catalog: {catalog_file}")
                self.extract_powers_from_catalog(catalog_file)
            else:
                print(f"⚠️  Catalog file not found: {catalog_file}")
        
        print(f"\n🎉 Power extraction complete!")
        print(f"✅ Successfully extracted: {self.extracted_count} powers")
        print(f"❌ Errors: {self.error_count}")
        
        if self.errors:
            print("\n📋 Errors encountered:")
            for error in self.errors:
                print(f"  {error}")

def main():
    """Main function."""
    powers_dir = "data/powers"
    
    if not os.path.exists(powers_dir):
        print(f"❌ Powers directory not found: {powers_dir}")
        return
    
    extractor = PowerExtractor(powers_dir)
    extractor.process_catalog_files()

if __name__ == "__main__":
    main()
