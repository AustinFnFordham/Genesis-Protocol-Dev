#!/usr/bin/env python3
"""
Artisanal Synergy Pass - Gold Standard Script

This script applies the Artisanal Algorithm to class_synergies narratives for all powers.
It deconstructs the soul of both the power and the class, then generates narratives that
fuse them to explain why their connection grants the specific mechanical benefit.
"""

import yaml
import os
import sys
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass

@dataclass
class ClassIdentity:
    id: str
    name: str
    core_concept: str
    philosophy: str
    approach: str
    strengths: List[str]
    mechanics_style: str

@dataclass
class PowerIdentity:
    name: str
    power_type: str
    alignment: str
    unique_identity: str
    sensory_elements: List[str]
    emotional_tone: str
    core_mechanics: str

class ArtisanalSynergyProcessor:
    def __init__(self, powers_directory: str = "data/powers"):
        self.powers_directory = Path(powers_directory)
        self.powers: Dict[str, Dict] = {}
        self.class_identities: Dict[str, ClassIdentity] = {}
        self.processed_synergies = 0
        self.errors = []
        self._load_class_identities()

    def _load_class_identities(self):
        """Load class identities for synergy analysis."""
        self.class_identities = {
            'guardian': ClassIdentity(
                id='guardian',
                name='Guardian',
                core_concept='protection',
                philosophy='defensive combat and protection of others',
                approach='stands between danger and the innocent',
                strengths=['defensive fighting', 'protective instincts', 'combat resilience'],
                mechanics_style='defensive bonuses and protective mechanics'
            ),
            'consular': ClassIdentity(
                id='consular',
                name='Consular',
                core_concept='diplomacy',
                philosophy='peaceful resolution and wisdom',
                approach='seeks to avoid violence through understanding',
                strengths=['diplomatic skills', 'mental resilience', 'conflict resolution'],
                mechanics_style='mental effects and non-violent solutions'
            ),
            'sentinel': ClassIdentity(
                id='sentinel',
                name='Sentinel',
                core_concept='balance',
                philosophy='vigilance and measured action',
                approach='watches from the shadows, strikes when needed',
                strengths=['stealth', 'investigation', 'precise strikes'],
                mechanics_style='tactical advantages and conditional bonuses'
            ),
            'engineer': ClassIdentity(
                id='engineer',
                name='Engineer',
                core_concept='creation',
                philosophy='building and repairing through technology',
                approach='solves problems with mechanical ingenuity',
                strengths=['technical expertise', 'problem-solving', 'repair skills'],
                mechanics_style='technological bonuses and repair mechanics'
            ),
            'operative': ClassIdentity(
                id='operative',
                name='Operative',
                core_concept='precision',
                philosophy='calculated strikes and efficiency',
                approach='eliminates threats with surgical precision',
                strengths=['accuracy', 'tactical awareness', 'execution'],
                mechanics_style='precision damage and tactical advantages'
            ),
            'scholar': ClassIdentity(
                id='scholar',
                name='Scholar',
                core_concept='knowledge',
                philosophy='understanding through study and analysis',
                approach='approaches problems through research and intellect',
                strengths=['analysis', 'comprehension', 'strategic thinking'],
                mechanics_style='knowledge-based bonuses and analytical mechanics'
            )
        }

    def load_powers(self) -> bool:
        """Load all power files from the directory."""
        try:
            for power_file in self.powers_directory.glob("*.yml"):
                if power_file.name.startswith("power_"):
                    with open(power_file, 'r', encoding='utf-8') as f:
                        power_data = yaml.safe_load(f)
                        if power_data and 'id' in power_data:
                            self.powers[power_data['id']] = power_data
            print(f"Loaded {len(self.powers)} powers for synergy transformation")
            return True
        except Exception as e:
            print(f"Error loading powers: {e}")
            return False

    def analyze_power_identity(self, power_data: Dict) -> PowerIdentity:
        """Analyze a power's unique identity for synergy generation."""
        name = power_data.get('name', '').lower()
        power_type = power_data.get('power_type', '')
        alignment = power_data.get('alignment', '')

        # Determine unique identity
        unique_identity = self._get_unique_identity(name, power_type, alignment)

        # Extract sensory elements
        sensory_elements = self._get_sensory_elements(name, power_type)

        # Determine emotional tone
        emotional_tone = self._get_emotional_tone(power_type, alignment, name)

        # Determine core mechanics
        core_mechanics = self._get_core_mechanics(power_data)

        return PowerIdentity(
            name=power_data.get('name', 'Unknown'),
            power_type=power_type,
            alignment=alignment,
            unique_identity=unique_identity,
            sensory_elements=sensory_elements,
            emotional_tone=emotional_tone,
            core_mechanics=core_mechanics
        )

    def _get_unique_identity(self, name: str, power_type: str, alignment: str) -> str:
        """Get the unique identity of a power."""
        name_lower = name.lower()

        if power_type == 'Force':
            if 'choke' in name_lower:
                return "constricting throats with invisible Force pressure"
            elif 'lightning' in name_lower:
                return "channeling raw electrical fury through fingertips"
            elif 'heal' in name_lower:
                return "knitting flesh and restoring life energy"
            elif 'mind' in name_lower:
                return "whispering suggestions into subconscious minds"
            elif 'push' in name_lower:
                return "extending invisible hands of Force energy"
            elif 'pull' in name_lower:
                return "drawing targets with irresistible telekinetic force"
            elif 'storm' in name_lower:
                return "summoning cataclysmic dark side energy"
            elif 'leap' in name_lower:
                return "propelling through air with enhanced agility"
            elif 'barrier' in name_lower:
                return "creating walls of invisible Force energy"
            elif 'sever' in name_lower:
                return "tearing Force connection from living beings"
            else:
                return "manipulating the Force to achieve the impossible"
        elif power_type == 'Tech':
            if 'ion' in name_lower:
                return "frying electronic systems with electromagnetic pulses"
            elif 'hack' in name_lower:
                return "infiltrating systems with digital expertise"
            elif 'overload' in name_lower:
                return "pushing machines beyond their breaking point"
            elif 'scan' in name_lower:
                return "analyzing targets with precision sensors"
            else:
                return "harnessing technology for mechanical superiority"
        else:  # Maneuver
            if 'trip' in name_lower:
                return "sweeping legs and unbalancing foes"
            elif 'disarm' in name_lower:
                return "striking weapons from enemies' hands"
            elif 'feint' in name_lower:
                return "deceiving with false movements"
            elif 'leap' in name_lower:
                return "propelling through air with athletic grace"
            else:
                return "executing tactical movements"

    def _get_sensory_elements(self, name: str, power_type: str) -> List[str]:
        """Get sensory elements for a power."""
        name_lower = name.lower()

        if power_type == 'Force':
            if 'lightning' in name_lower:
                return ["crackling electricity", "burning ozone", "purple-white arcs"]
            elif 'choke' in name_lower:
                return ["desperate gasping", "invisible constriction", "bulging veins"]
            elif 'heal' in name_lower:
                return ["warm golden light", "soothing energy", "flesh knitting"]
            elif 'mind' in name_lower:
                return ["subtle mental pressure", "compelling gaze", "whispered thoughts"]
            else:
                return ["vibrating air", "inner warmth", "subtle glow"]
        elif power_type == 'Tech':
            if 'ion' in name_lower:
                return ["electrical crackling", "sparks flying", "systems sputtering"]
            elif 'hack' in name_lower:
                return ["rapid data streams", "glowing interfaces", "electronic beeps"]
            else:
                return ["mechanical whirring", "electronic hum", "digital display"]
        else:  # Maneuver
            if 'trip' in name_lower:
                return ["sweeping motion", "impact thud", "falling body"]
            elif 'leap' in name_lower:
                return ["rushing air", "graceful arc", "enhanced momentum"]
            else:
                return ["calculated movement", "precise positioning", "combat rhythm"]

    def _get_emotional_tone(self, power_type: str, alignment: str, name: str) -> str:
        """Get the emotional tone of a power."""
        if power_type == 'Force':
            if alignment == 'Light':
                return "compassionate determination"
            elif alignment == 'Dark':
                return "corrupting rage"
            else:
                return "focused resolve"
        elif power_type == 'Tech':
            return "calculated precision"
        else:
            return "tactical awareness"

    def _get_core_mechanics(self, power_data: Dict) -> str:
        """Get the core mechanics summary of a power."""
        mechanics = power_data.get('base_effect', {}).get('mechanics', [])

        if not mechanics:
            return "utility"

        # Look for key mechanics
        damage_mechanics = [m for m in mechanics if 'damage' in m.get('type', '')]
        status_mechanics = [m for m in mechanics if 'status' in m.get('type', '')]
        movement_mechanics = [m for m in mechanics if 'movement' in m.get('type', '')]

        if damage_mechanics:
            damage_type = damage_mechanics[0].get('value', 'damage').split('_')[0]
            return f"damage_{damage_type}"
        elif status_mechanics:
            status_value = status_mechanics[0].get('value', 'condition')
            return f"status_{status_value}"
        elif movement_mechanics:
            return "movement_enhancement"
        else:
            return "utility"

    def craft_artisanal_synergy_narrative(self, power_identity: PowerIdentity,
                                         class_identity: ClassIdentity,
                                         mechanical_benefit: str) -> str:
        """Craft an artisanal synergy narrative that fuses power and class identities."""

        # Analyze the synergy relationship
        synergy_analysis = self._analyze_synergy_relationship(power_identity, class_identity, mechanical_benefit)

        # Generate the narrative based on the relationship type
        if synergy_analysis['relationship'] == 'complementary':
            return self._craft_complementary_synergy_narrative(power_identity, class_identity, synergy_analysis)
        elif synergy_analysis['relationship'] == 'tension':
            return self._craft_tension_synergy_narrative(power_identity, class_identity, synergy_analysis)
        elif synergy_analysis['relationship'] == 'enhancement':
            return self._craft_enhancement_synergy_narrative(power_identity, class_identity, synergy_analysis)
        else:
            return self._craft_neutral_synergy_narrative(power_identity, class_identity, synergy_analysis)

    def _analyze_synergy_relationship(self, power: PowerIdentity, class_obj: ClassIdentity,
                                    mechanical_benefit: str) -> Dict:
        """Analyze the relationship between power and class for synergy narrative."""

        # Check for complementary relationships
        if (power.alignment == 'Light' and class_obj.core_concept in ['protection', 'diplomacy', 'balance']) or \
           (power.alignment == 'Dark' and class_obj.core_concept in ['precision', 'creation']) or \
           (power.power_type == 'Tech' and class_obj.core_concept == 'creation') or \
           (power.power_type == 'Maneuver' and class_obj.core_concept in ['precision', 'balance']):
            return {
                'relationship': 'complementary',
                'reason': f"{class_obj.name}'s {class_obj.core_concept} naturally aligns with {power.name}'s purpose",
                'emotional_connection': 'harmony'
            }

        # Check for tension relationships
        elif (power.alignment == 'Dark' and class_obj.core_concept in ['protection', 'diplomacy']) or \
             (power.alignment == 'Light' and class_obj.core_concept in ['precision']) or \
             ('damage' in power.core_mechanics and class_obj.core_concept == 'diplomacy'):
            return {
                'relationship': 'tension',
                'reason': f"{class_obj.name}'s {class_obj.core_concept} creates inner conflict with {power.name}'s nature",
                'emotional_connection': 'conflict'
            }

        # Check for enhancement relationships
        elif 'enhance' in mechanical_benefit or 'bonus' in mechanical_benefit:
            return {
                'relationship': 'enhancement',
                'reason': f"{class_obj.name}'s {class_obj.core_concept} enhances the effectiveness of {power.name}",
                'emotional_connection': 'mastery'
            }

        else:
            return {
                'relationship': 'neutral',
                'reason': f"{class_obj.name} approaches {power.name} through their unique perspective",
                'emotional_connection': 'understanding'
            }

    def _craft_complementary_synergy_narrative(self, power: PowerIdentity, class_obj: ClassIdentity,
                                              analysis: Dict) -> str:
        """Craft a narrative for complementary power-class relationships."""
        sensory_element = power.sensory_elements[0] if power.sensory_elements else power.unique_identity

        return f"{class_obj.name} naturally embodies {power.name}'s essence, channeling {power.unique_identity} with instinctive grace. Their {class_obj.core_concept} philosophy aligns perfectly with {power.name}'s purpose, allowing them to {sensory_element} with enhanced {power.emotional_tone}."

    def _craft_tension_synergy_narrative(self, power: PowerIdentity, class_obj: ClassIdentity,
                                       analysis: Dict) -> str:
        """Craft a narrative for tense power-class relationships."""
        sensory_element = power.sensory_elements[0] if power.sensory_elements else power.unique_identity

        return f"For a {class_obj.name} to embrace {power.name} requires confronting their deepest instincts, transforming {class_obj.core_concept} into something darker. This inner conflict fuels their {power.unique_identity}, allowing them to {sensory_element} with a {power.emotional_tone} born of personal struggle."

    def _craft_enhancement_synergy_narrative(self, power: PowerIdentity, class_obj: ClassIdentity,
                                           analysis: Dict) -> str:
        """Craft a narrative for enhancement power-class relationships."""
        sensory_element = power.sensory_elements[0] if power.sensory_elements else power.unique_identity

        return f"{class_obj.name}'s {class_obj.core_concept} mastery elevates {power.name} from mere technique to art form. Their {class_obj.philosophy} guides the {power.unique_identity}, allowing them to {sensory_element} with a {power.emotional_tone} that comes from complete understanding."

    def _craft_neutral_synergy_narrative(self, power: PowerIdentity, class_obj: ClassIdentity,
                                        analysis: Dict) -> str:
        """Craft a narrative for neutral power-class relationships."""
        sensory_element = power.sensory_elements[0] if power.sensory_elements else power.unique_identity

        return f"{class_obj.name} approaches {power.name} through the lens of {class_obj.core_concept}, finding unexpected harmony in the {power.unique_identity}. Their {class_obj.philosophy} guides them to {sensory_element} with a {power.emotional_tone} that reflects their unique perspective."

    def _parse_mechanical_benefit_description(self, synergy_data: Dict) -> str:
        """Parse mechanical benefit into human-readable description."""
        mechanical_benefit = synergy_data.get('mechanical_benefit', [])

        if not mechanical_benefit:
            return "enhanced effectiveness"

        # Extract key information from structured mechanics
        benefit_descriptions = []

        for benefit in mechanical_benefit:
            benefit_type = benefit.get('type', '')
            notes = benefit.get('notes', '')

            if 'enhance' in benefit_type:
                if 'damage' in benefit_type:
                    benefit_descriptions.append("increased damage")
                elif 'attack' in benefit_type:
                    benefit_descriptions.append("improved accuracy")
                elif 'dc' in benefit_type:
                    benefit_descriptions.append("stronger effects")
                else:
                    benefit_descriptions.append("enhanced power")
            elif 'grant' in benefit_type:
                benefit_descriptions.append("special advantages")
            elif 'apply' in benefit_type:
                benefit_descriptions.append("additional effects")
            elif 'reduce' in benefit_type:
                benefit_descriptions.append("reduced requirements")
            elif 'area' in benefit_type:
                benefit_descriptions.append("area effects")
            else:
                benefit_descriptions.append("unique benefits")

        return ", ".join(benefit_descriptions) if benefit_descriptions else "enhanced effectiveness"

    def apply_synergy_transformation(self, power_id: str, power_data: Dict) -> bool:
        """Apply artisanal transformation to all class synergies in a power."""
        try:
            power_identity = self.analyze_power_identity(power_data)
            class_synergies = power_data.get('class_synergies', [])

            if not class_synergies:
                return False

            modified = False

            for synergy in class_synergies:
                class_id = synergy.get('class_id', '')

                if class_id not in self.class_identities:
                    continue

                class_identity = self.class_identities[class_id]

                # Check if synergy needs transformation
                current_narrative = synergy.get('narrative', '')
                if self._is_generic_synergy_narrative(current_narrative, power_identity, class_identity):
                    # Generate new artisanal narrative
                    mechanical_desc = self._parse_mechanical_benefit_description(synergy)
                    new_narrative = self.craft_artisanal_synergy_narrative(
                        power_identity, class_identity, mechanical_desc
                    )

                    synergy['narrative'] = new_narrative
                    modified = True
                    self.processed_synergies += 1

            if modified:
                self.save_power(power_id, power_data)
                return True

        except Exception as e:
            self.errors.append(f"Error processing synergies for {power_id}: {e}")
            return False

    def _is_generic_synergy_narrative(self, narrative: str, power: PowerIdentity,
                                    class_obj: ClassIdentity) -> bool:
        """Check if a synergy narrative is generic and needs transformation."""
        generic_phrases = [
            "excel at using",
            "adept at",
            "skilled at",
            "particularly good at",
            "master",
            "embrace",
            "fall to the dark side",
            "use for",
            "channel their",
            "finds harmony",
            "approaches through"
        ]

        # Check for generic phrases
        for phrase in generic_phrases:
            if phrase in narrative:
                return True

        # Check if narrative is too short or lacks depth
        if len(narrative.split()) < 10:
            return True

        # Check if narrative lacks power-specific or class-specific language
        power_name_mentioned = power.name.lower() in narrative.lower()
        class_name_mentioned = class_obj.name.lower() in narrative.lower()

        if not power_name_mentioned or not class_name_mentioned:
            return True

        return False

    def save_power(self, power_id: str, power_data: Dict):
        """Save a power back to its file."""
        for power_file in self.powers_directory.glob("*.yml"):
            if power_file.name.startswith("power_"):
                with open(power_file, 'r', encoding='utf-8') as f:
                    file_data = yaml.safe_load(f)
                    if file_data and file_data.get('id') == power_id:
                        with open(power_file, 'w', encoding='utf-8') as f:
                            yaml.dump(power_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
                        break

    def process_all_powers(self) -> Dict[str, bool]:
        """Process all powers and apply artisanal synergy transformations."""
        results = {}

        for power_id in self.powers.keys():
            try:
                modified = self.apply_synergy_transformation(power_id, self.powers[power_id])
                results[power_id] = modified

            except Exception as e:
                self.errors.append(f"Error processing {power_id}: {e}")
                results[power_id] = False

        return results

    def generate_report(self, results: Dict[str, bool]) -> str:
        """Generate a comprehensive report of the synergy transformation process."""
        report = []
        report.append("=" * 80)
        report.append("ARTISANAL SYNERGY PASS - GOLD STANDARD REPORT")
        report.append("=" * 80)
        report.append("")

        # Summary statistics
        total_powers = len(results)
        powers_processed = sum(1 for processed in results.values() if processed)
        powers_skipped = total_powers - powers_processed

        report.append(f"Total Powers Analyzed: {total_powers}")
        report.append(f"Powers with Synergies Transformed: {powers_processed}")
        report.append(f"Synergies Elevated to Gold Standard: {self.processed_synergies}")
        report.append("")

        if self.errors:
            report.append("ERRORS ENCOUNTERED:")
            report.append("-" * 40)
            for error in self.errors:
                report.append(f"❌ {error}")
            report.append("")

        # Powers processed
        if powers_processed > 0:
            report.append("POWERS WITH TRANSFORMED SYNERGIES:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if was_processed:
                    power_data = self.powers[power_id]
                    synergy_count = len(power_data.get('class_synergies', []))
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')}) - {synergy_count} synergies transformed")
            report.append("")

        # Powers skipped
        if powers_skipped > 0:
            report.append("POWERS WITH ALREADY-EXCELLENT SYNERGIES:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if not was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        report.append("=" * 80)
        report.append("ARTISANAL SYNERGY PASS COMPLETE")
        report.append("All class synergy narratives now reflect the deep fusion of power and class identities")
        report.append("=" * 80)

        return "\n".join(report)

    def run_synergy_pass(self) -> bool:
        """Run the complete artisanal synergy transformation."""
        print("Loading powers...")
        if not self.load_powers():
            return False

        print("Analyzing class synergies for Gold Standard transformation...")
        powers_with_synergies = []
        for power_id, power_data in self.powers.items():
            if power_data.get('class_synergies', []):
                powers_with_synergies.append(power_id)

        print(f"Found {len(powers_with_synergies)} powers with class synergies")
        if len(powers_with_synergies) <= 5:
            print(f"Powers with synergies: {', '.join(powers_with_synergies)}")
        else:
            print(f"Powers with synergies: {', '.join(powers_with_synergies[:5])} and {len(powers_with_synergies) - 5} more...")

        print("Applying Artisanal Synergy Pass - fusing power and class identities...")
        results = self.process_all_powers()

        print("Generating report...")
        report = self.generate_report(results)

        # Save report to file
        report_file = Path("artisanal_synergy_pass_report.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)

        print(f"Report saved to {report_file}")
        print("\n" + report)

        return len(self.errors) == 0

def main():
    """Main function to run Artisanal Synergy Pass."""
    processor = ArtisanalSynergyProcessor()
    success = processor.run_synergy_pass()

    if success:
        print("\n✅ Artisanal Synergy Pass completed successfully!")
        print("All class synergy narratives now reflect the deep fusion of power and class identities.")
        sys.exit(0)
    else:
        print("\n❌ Artisanal Synergy Pass completed with errors.")
        sys.exit(1)

if __name__ == "__main__":
    main()
