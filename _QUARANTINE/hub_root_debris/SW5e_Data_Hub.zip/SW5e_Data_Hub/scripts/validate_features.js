#!/usr/bin/env node

/**
 * CharacterClassFeature Validation Script
 * Validates feature files against the CharacterClassFeature schema
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const Ajv = require('ajv');
const addFormats = require('ajv-formats');

// Initialize AJV with formats
const ajv = new Ajv({ allErrors: true });
addFormats(ajv);

// Load the CharacterClassFeature schema
const schemaPath = path.join(__dirname, '..', 'schema', 'CharacterClassFeature.schema.json');
const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
const validate = ajv.compile(schema);

// Test specific feature files
const testFeatures = [
  'consular/force_connection.yml',
  'bounty_hunter/assassin/death_strike.yml', 
  'engineer/technical_expertise.yml',
  'guardian/defensive_stance.yml'
];

console.log('🔍 CHARACTER CLASS FEATURE VALIDATION REPORT');
console.log('==================================================');
console.log(`📊 Testing ${testFeatures.length} feature files against CharacterClassFeature schema`);
console.log(`📋 Schema has ${Object.keys(schema.properties).length} properties`);
console.log(`🎯 Required fields: ${schema.required.join(', ')}`);
console.log('');

let validCount = 0;
let invalidCount = 0;
const results = [];

for (const featurePath of testFeatures) {
  const filePath = path.join(__dirname, '..', 'data', 'features', featurePath);
  
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const data = yaml.load(content);
    const isValid = validate(data);
    
    if (isValid) {
      console.log(`✅ ${featurePath} - VALID`);
      
      // Check for advanced features
      const features = [];
      if (data.connections) features.push('Connections');
      if (data.llm_guidance) features.push('LLM Guidance');
      if (data.image_generation) features.push('Image Generation');
      if (data.ui) features.push('UI Elements');
      if (data.effects) features.push('Effects System');
      if (data.iconic_examples) features.push('Iconic Examples');
      if (data.famous_users) features.push('Famous Users');
      
      if (features.length > 0) {
        console.log(`   🎨 Features: ${features.join(', ')}`);
      }
      
      // Check for narrative elements
      const narrativeElements = [];
      if (data.narrative) narrativeElements.push('Narrative');
      if (data.flavor_text) narrativeElements.push('Flavor Text');
      if (data.cultural_significance) narrativeElements.push('Cultural Significance');
      if (data.origin_story) narrativeElements.push('Origin Story');
      
      if (narrativeElements.length > 0) {
        console.log(`   📖 Narrative: ${narrativeElements.join(', ')}`);
      }
      
      // Check for mechanics
      const mechanics = [];
      if (data.effects) mechanics.push(`Effects (${data.effects.length})`);
      if (data.mechanics) mechanics.push(`Mechanics (${data.mechanics.length})`);
      if (data.level_requirement) mechanics.push(`Level ${data.level_requirement}`);
      if (data.xp_cost) mechanics.push(`${data.xp_cost} XP`);
      
      if (mechanics.length > 0) {
        console.log(`   ⚙️  Mechanics: ${mechanics.join(', ')}`);
      }
      
      validCount++;
    } else {
      console.log(`❌ ${featurePath} - INVALID`);
      console.log('   Errors:');
      validate.errors.forEach(error => {
        console.log(`     - ${error.instancePath || 'root'}: ${error.message}`);
      });
      invalidCount++;
    }
    
    results.push({
      file: featurePath,
      valid: isValid,
      errors: isValid ? [] : validate.errors
    });
    
  } catch (error) {
    console.log(`❌ ${featurePath} - PARSE ERROR`);
    console.log(`   Error: ${error.message}`);
    invalidCount++;
    
    results.push({
      file: featurePath,
      valid: false,
      errors: [{ message: error.message }]
    });
  }
  
  console.log('');
}

console.log('📊 VALIDATION SUMMARY');
console.log('==================================================');
console.log(`✅ Valid files: ${validCount}/${testFeatures.length} (${Math.round(validCount/testFeatures.length*100)}%)`);
console.log(`❌ Invalid files: ${invalidCount}/${testFeatures.length} (${Math.round(invalidCount/testFeatures.length*100)}%)`);
console.log('');

// Advanced features analysis
const advancedFeatures = {
  'Connections': 0,
  'LLM Guidance': 0,
  'Image Generation': 0,
  'UI Elements': 0,
  'Effects System': 0,
  'Iconic Examples': 0,
  'Famous Users': 0
};

const narrativeFeatures = {
  'Narrative': 0,
  'Flavor Text': 0,
  'Cultural Significance': 0,
  'Origin Story': 0
};

for (const result of results) {
  if (result.valid) {
    const filePath = path.join(__dirname, '..', 'data', 'features', result.file);
    const content = fs.readFileSync(filePath, 'utf8');
    const data = yaml.load(content);
    
    if (data.connections) advancedFeatures['Connections']++;
    if (data.llm_guidance) advancedFeatures['LLM Guidance']++;
    if (data.image_generation) advancedFeatures['Image Generation']++;
    if (data.ui) advancedFeatures['UI Elements']++;
    if (data.effects) advancedFeatures['Effects System']++;
    if (data.iconic_examples) advancedFeatures['Iconic Examples']++;
    if (data.famous_users) advancedFeatures['Famous Users']++;
    
    if (data.narrative) narrativeFeatures['Narrative']++;
    if (data.flavor_text) narrativeFeatures['Flavor Text']++;
    if (data.cultural_significance) narrativeFeatures['Cultural Significance']++;
    if (data.origin_story) narrativeFeatures['Origin Story']++;
  }
}

console.log('🎨 ADVANCED FEATURES ANALYSIS');
console.log('==================================================');
Object.entries(advancedFeatures).forEach(([feature, count]) => {
  const percentage = Math.round(count/testFeatures.length*100);
  console.log(`${feature}: ${count}/${testFeatures.length} (${percentage}%)`);
});

console.log('');
console.log('📖 NARRATIVE FEATURES ANALYSIS');
console.log('==================================================');
Object.entries(narrativeFeatures).forEach(([feature, count]) => {
  const percentage = Math.round(count/testFeatures.length*100);
  console.log(`${feature}: ${count}/${testFeatures.length} (${percentage}%)`);
});

console.log('');
console.log('🎯 VALIDATION COMPLETE!');

// Exit with error code if any files are invalid
if (invalidCount > 0) {
  process.exit(1);
}
