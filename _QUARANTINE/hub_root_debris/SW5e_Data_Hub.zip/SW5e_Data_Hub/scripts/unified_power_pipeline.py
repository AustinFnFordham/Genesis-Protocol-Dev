#!/usr/bin/env python3
"""
Unified Power Pipeline - Professional Content Ingestion and Validation
Combines power extraction, refactoring, and validation into a single, efficient pipeline.
"""

import os
import yaml
import re
from pathlib import Path
from typing import Dict, Any, List, Tuple
from datetime import datetime

class UnifiedPowerPipeline:
    def __init__(self, powers_dir: str, catalogs_dir: str):
        self.powers_dir = Path(powers_dir)
        self.catalogs_dir = Path(catalogs_dir)
        self.required_keys = [
            'id', 'name', 'power_type', 'alignment', 'level', 'narrative', 'flavor_text',
            'casting_time', 'range', 'duration', 'power_cost', 'manifestation', 'base_effect',
            'class_synergies', 'species_synergies', 'faction_synergies', 'llm_guidance',
            'image_generation', 'ui'
        ]
        
        # Pipeline statistics
        self.processed_count = 0
        self.successful_count = 0
        self.failed_count = 0
        self.validation_errors = []
        self.validation_warnings = []
        self.processing_log = []
        
    def process_all_catalogs(self) -> Dict[str, Any]:
        """Process all catalog files and return comprehensive results."""
        print(f"🚀 Starting Unified Power Pipeline")
        print(f"📁 Powers Directory: {self.powers_dir}")
        print(f"📁 Catalogs Directory: {self.catalogs_dir}")
        print(f"⏰ Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)
        
        # Find all catalog files
        catalog_files = [
            self.catalogs_dir / "force_powers.yml",
            self.catalogs_dir / "force_powers_extended.yml",
            self.catalogs_dir / "force_powers_comprehensive.yml",
            self.catalogs_dir / "tech_powers.yml",
            self.catalogs_dir / "tech_powers_extended.yml",
            self.catalogs_dir / "tech_powers_comprehensive.yml",
            self.catalogs_dir / "maneuvers_comprehensive.yml"
        ]
        
        for catalog_file in catalog_files:
            if catalog_file.exists():
                print(f"📊 Processing catalog: {catalog_file.name}")
                self.process_catalog_file(catalog_file)
            else:
                print(f"⚠️  Catalog file not found: {catalog_file}")
        
        # Generate final report
        return self.generate_final_report()
    
    def process_catalog_file(self, catalog_file: Path) -> bool:
        """Process a single catalog file."""
        try:
            with open(catalog_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            data = yaml.safe_load(content)
            if not data:
                print(f"⚠️  Empty file: {catalog_file}")
                return False
            
            # Determine catalog type and extract powers
            if 'force_powers' in data:
                powers = data['force_powers']
                power_type = 'Force'
            elif 'force_powers_extended' in data:
                powers = data['force_powers_extended']
                power_type = 'Force'
            elif 'force_powers_comprehensive' in data:
                powers = data['force_powers_comprehensive']
                power_type = 'Force'
            elif 'tech_powers' in data:
                powers = data['tech_powers']
                power_type = 'Tech'
            elif 'tech_powers_extended' in data:
                powers = data['tech_powers_extended']
                power_type = 'Tech'
            elif 'tech_powers_comprehensive' in data:
                powers = data['tech_powers_comprehensive']
                power_type = 'Tech'
            elif 'maneuvers_comprehensive' in data:
                powers = data['maneuvers_comprehensive']
                power_type = 'Maneuver'
            else:
                print(f"⚠️  Unknown catalog format: {catalog_file}")
                return False
            
            print(f"🔄 Found {len(powers)} {power_type} powers")
            
            # Process each power
            for power_data in powers:
                self.process_single_power(power_data, power_type, catalog_file)
            
            return True
            
        except Exception as e:
            error_msg = f"❌ Error processing {catalog_file}: {e}"
            print(error_msg)
            self.validation_errors.append(error_msg)
            self.failed_count += 1
            return False
    
    def process_single_power(self, power_data: Dict[str, Any], power_type: str, source_file: Path) -> bool:
        """Process a single power through the complete pipeline."""
        self.processed_count += 1
        
        try:
            # Step 1: Extract and validate basic info
            power_id = power_data.get('id', '')
            power_name = power_data.get('name', '')
            
            if not power_id or not power_name:
                error_msg = f"❌ {source_file.name}: Power missing id or name: {power_data}"
                print(f"  {error_msg}")
                self.validation_errors.append(error_msg)
                self.failed_count += 1
                return False
            
            # Skip scaling entries
            if 'scaling' in power_id.lower():
                print(f"  ⚠️  Skipping scaling entry: {power_id}")
                return False
            
            # Step 2: Convert to gold standard format
            gold_standard_power = self.convert_to_gold_standard(power_data, power_type, source_file)
            
            # Step 3: Validate the converted power
            validation_result = self.validate_power_data(gold_standard_power, power_id)
            
            if validation_result['valid']:
                # Step 4: Write the validated power to file
                output_file = self.powers_dir / f"power_{power_id}.yml"
                
                with open(output_file, 'w', encoding='utf-8') as f:
                    yaml.dump(gold_standard_power, f, default_flow_style=False, sort_keys=False, 
                             allow_unicode=True, width=1000)
                
                print(f"  ✅ {power_id} -> {output_file.name}")
                self.successful_count += 1
                self.processing_log.append({
                    'power_id': power_id,
                    'status': 'success',
                    'source_file': source_file.name,
                    'output_file': output_file.name
                })
                return True
            else:
                # Step 5: Log validation failures
                error_msg = f"❌ {source_file.name}: {power_id} - {validation_result['error']}"
                print(f"  {error_msg}")
                self.validation_errors.append(error_msg)
                self.failed_count += 1
                self.processing_log.append({
                    'power_id': power_id,
                    'status': 'failed',
                    'source_file': source_file.name,
                    'error': validation_result['error']
                })
                return False
                
        except Exception as e:
            error_msg = f"❌ {source_file.name}: Error processing {power_data.get('id', 'unknown')}: {e}"
            print(f"  {error_msg}")
            self.validation_errors.append(error_msg)
            self.failed_count += 1
            return False
    
    def convert_to_gold_standard(self, power_data: Dict[str, Any], power_type: str, source_file: Path) -> Dict[str, Any]:
        """Convert power data to gold standard format with intelligent defaults."""
        gold_standard = {}
        
        # Basic fields
        power_id = power_data.get('id', '').replace('power_', '')
        gold_standard['id'] = f"power_{power_id}"
        gold_standard['name'] = power_data.get('name', '')
        gold_standard['power_type'] = power_type
        gold_standard['alignment'] = power_data.get('alignment', 'Universal')
        
        # Intelligent level and cost handling based on source file
        source_file_name = source_file.name.lower()
        if "extended" in source_file_name:
            # Epic-level defaults for extended powers
            level = power_data.get('level', 6)
            gold_standard['level'] = level
            gold_standard['power_cost'] = self.create_extended_power_cost(power_data, level)
            gold_standard['narrative'] = self.create_extended_narrative(power_data)
            gold_standard['flavor_text'] = self.create_extended_flavor_text(power_data, level)
            gold_standard['manifestation'] = self.create_extended_manifestation(power_data, power_type)
        else:
            # Standard-level defaults
            level = power_data.get('level', 1)
            gold_standard['level'] = level
            gold_standard['power_cost'] = self.create_standard_power_cost(power_data, level)
            gold_standard['narrative'] = self.create_standard_narrative(power_data)
            gold_standard['flavor_text'] = self.create_standard_flavor_text(power_data)
            gold_standard['manifestation'] = self.create_standard_manifestation(power_data, power_type)
        
        # Common fields
        gold_standard['casting_time'] = self.convert_casting_time(power_data)
        gold_standard['range'] = self.convert_range(power_data)
        gold_standard['duration'] = self.convert_duration(power_data)
        gold_standard['base_effect'] = self.create_base_effect(power_data)
        
        # Synergies
        gold_standard['class_synergies'] = self.create_class_synergies(power_data, power_type, level)
        gold_standard['species_synergies'] = self.create_species_synergies(power_data)
        gold_standard['faction_synergies'] = self.create_faction_synergies(power_data, power_type)
        
        # LLM guidance
        gold_standard['llm_guidance'] = self.create_llm_guidance(power_data, level)
        
        # Image generation
        gold_standard['image_generation'] = self.create_image_generation(power_data, power_type, level)
        
        # UI
        gold_standard['ui'] = self.create_ui(power_data, level)
        
        return gold_standard
    
    def validate_power_data(self, power_data: Dict[str, Any], power_id: str) -> Dict[str, Any]:
        """Validate power data against gold standard requirements."""
        # Check required keys
        missing_keys = []
        for key in self.required_keys:
            if key not in power_data:
                missing_keys.append(key)
        
        if missing_keys:
            return {
                'valid': False,
                'error': f"Missing required keys: {', '.join(missing_keys)}"
            }
        
        # Validate specific fields
        validation_issues = []
        
        # Validate power_type
        if power_data.get('power_type') not in ['Force', 'Tech', 'Maneuver']:
            validation_issues.append(f"Invalid power_type '{power_data.get('power_type')}'")
        
        # Validate alignment
        if power_data.get('alignment') not in ['Light', 'Dark', 'Universal']:
            validation_issues.append(f"Invalid alignment '{power_data.get('alignment')}'")
        
        # Validate level
        level = power_data.get('level', 0)
        if not isinstance(level, int) or level < 0 or level > 9:
            validation_issues.append(f"Invalid level '{level}'")
        
        # Validate power_cost
        power_cost = power_data.get('power_cost', [])
        if not isinstance(power_cost, list):
            validation_issues.append("power_cost should be a list")
        
        # Validate manifestation
        manifestation = power_data.get('manifestation', [])
        if not isinstance(manifestation, list) or len(manifestation) == 0:
            validation_issues.append("manifestation should be a non-empty list")
        
        # Validate base_effect
        base_effect = power_data.get('base_effect', {})
        if not isinstance(base_effect, dict) or 'description' not in base_effect:
            validation_issues.append("base_effect should be a dict with 'description'")
        
        if validation_issues:
            return {
                'valid': False,
                'error': f"Validation issues: {'; '.join(validation_issues)}"
            }
        
        return {'valid': True, 'error': None}
    
    # Standard power creation methods
    def create_standard_power_cost(self, power_data: Dict[str, Any], level: int) -> List[Dict[str, Any]]:
        """Create power cost for standard powers."""
        if level == 0:
            return []  # At-will powers have no cost
        
        power_type = power_data.get('type', 'Force')
        cost_type = 'Force_Points' if power_type == 'Force' else 'Tech_Points'
        
        return [{'type': cost_type, 'amount': level}]
    
    def create_standard_narrative(self, power_data: Dict[str, Any]) -> str:
        """Create narrative for standard powers."""
        description = power_data.get('description', '')
        name = power_data.get('name', '')
        
        if description:
            return f"{description} This power represents a mastery of the {power_data.get('type', 'Force')} and years of dedicated training. When used, it demonstrates the character's expertise and connection to their chosen path, creating dramatic and memorable moments in the story."
        
        return f"{name} represents a significant advancement in the character's abilities, granting them new powers and capabilities that reflect their growing mastery of the {power_data.get('type', 'Force')}."
    
    def create_standard_flavor_text(self, power_data: Dict[str, Any]) -> str:
        """Create flavor text for standard powers."""
        name = power_data.get('name', '')
        power_type = power_data.get('type', 'Force')
        
        if power_type == 'Force':
            if 'mind' in name.lower():
                return "'The mind is a powerful weapon.' - Jedi Master"
            elif 'battle' in name.lower() or 'combat' in name.lower():
                return "'In battle, the Force guides your hand.' - Jedi Knight"
            elif 'heal' in name.lower():
                return "'To heal is to give of oneself.' - Jedi Healer"
            else:
                return f"'{name} represents the power of the Force.' - Unknown Master"
        else:  # Tech
            if 'hack' in name.lower() or 'terminal' in name.lower():
                return "'I'll bypass the security system.' - R2-D2"
            elif 'scan' in name.lower():
                return "'Scanning for life forms.' - C-3PO"
            else:
                return f"'{name} represents technological mastery.' - Unknown Engineer"
    
    def create_standard_manifestation(self, power_data: Dict[str, Any], power_type: str) -> List[str]:
        """Create manifestation for standard powers."""
        if power_type == 'Force':
            return [
                "Somatic (Force gesture)",
                "Mental Focus (channeling the Force)"
            ]
        else:
            return [
                "Somatic (using interface)",
                "Mental Focus (concentration on code)"
            ]
    
    # Extended power creation methods
    def create_extended_power_cost(self, power_data: Dict[str, Any], level: int) -> List[Dict[str, Any]]:
        """Create power cost for extended powers."""
        power_type = power_data.get('type', 'Force')
        cost_type = 'Force_Points' if power_type == 'Force' else 'Tech_Points'
        
        # Higher cost for extended powers
        base_cost = level * 2
        
        return [{'type': cost_type, 'amount': base_cost}]
    
    def create_extended_narrative(self, power_data: Dict[str, Any]) -> str:
        """Create narrative for extended powers."""
        description = power_data.get('description', '')
        name = power_data.get('name', '')
        level = power_data.get('level', 6)
        
        if description:
            return f"{description} This is a legendary {level}th-level power that represents the pinnacle of mastery. Only the most experienced and powerful individuals can hope to wield such incredible abilities. When used, it demonstrates the character's absolute mastery and creates truly epic, world-changing moments in the story."
        
        return f"{name} represents the ultimate expression of power, a legendary ability that few can master and fewer still can control. This is the power that legends are made of."
    
    def create_extended_flavor_text(self, power_data: Dict[str, Any], level: int) -> str:
        """Create flavor text for extended powers."""
        name = power_data.get('name', '')
        power_type = power_data.get('type', 'Force')
        
        if power_type == 'Force':
            if level >= 9:
                return "'I am the Force.' - Ancient Master"
            elif level >= 7:
                return "'The Force flows through me like a river.' - Legendary Jedi"
            else:
                return f"'{name} represents the power of legends.' - Unknown Master"
        else:  # Tech
            if level >= 9:
                return "'Technology is the ultimate expression of intelligence.' - Ancient Engineer"
            elif level >= 7:
                return "'With technology, all things are possible.' - Legendary Engineer"
            else:
                return f"'{name} represents technological transcendence.' - Unknown Engineer"
    
    def create_extended_manifestation(self, power_data: Dict[str, Any], power_type: str) -> List[str]:
        """Create manifestation for extended powers."""
        if power_type == 'Force':
            return [
                "Somatic (complex Force gestures)",
                "Verbal (ancient incantations)",
                "Mental Focus (deep meditation and concentration)"
            ]
        else:
            return [
                "Somatic (complex interface manipulation)",
                "Verbal (technical commands)",
                "Mental Focus (deep concentration on systems)"
            ]
    
    # Common utility methods
    def convert_casting_time(self, power_data: Dict[str, Any]) -> str:
        """Convert casting time to string format."""
        casting_time = power_data.get('casting_time', {})
        if isinstance(casting_time, dict):
            value = casting_time.get('value', 1)
            unit = casting_time.get('unit', 'action')
            return f"{value} {unit.title()}"
        return "1 Action"
    
    def convert_range(self, power_data: Dict[str, Any]) -> str:
        """Convert range to string format."""
        range_data = power_data.get('range', {})
        if isinstance(range_data, dict):
            value = range_data.get('value', 30)
            unit = range_data.get('unit', 'feet')
            return f"{value} {unit}"
        return "30 feet"
    
    def convert_duration(self, power_data: Dict[str, Any]) -> str:
        """Convert duration to string format."""
        duration = power_data.get('duration', {})
        if isinstance(duration, dict):
            duration_type = duration.get('type', 'instantaneous')
            value = duration.get('value', 1)
            unit = duration.get('unit', 'round')
            
            if duration_type == 'concentration':
                return f"Concentration, up to {value} {unit}"
            elif duration_type == 'instantaneous':
                return "Instantaneous"
            else:
                return f"{value} {unit}"
        return "Instantaneous"
    
    def create_base_effect(self, power_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create base effect structure."""
        effects = power_data.get('effects', [])
        
        return {
            'description': power_data.get('description', 'This power has a specific effect.'),
            'mechanics': effects
        }
    
    def create_class_synergies(self, power_data: Dict[str, Any], power_type: str, level: int) -> List[Dict[str, Any]]:
        """Create class synergies."""
        if power_type == 'Force':
            return [
                {
                    'class_id': 'guardian',
                    'narrative': f'Guardians excel at using Force powers defensively and in combat.',
                    'mechanical_benefit': f'Guardians gain +{max(1, level//2)} to Force power attack rolls.'
                }
            ]
        else:
            return [
                {
                    'class_id': 'engineer',
                    'narrative': f'Engineers are masters of technological powers and systems.',
                    'mechanical_benefit': f'Engineers gain +{max(1, level//2)} to Tech power attack rolls.'
                }
            ]
    
    def create_species_synergies(self, power_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create species synergies."""
        return [
            {
                'species_id': 'human',
                'narrative': 'Human adaptability allows them to quickly master new powers.',
                'mechanical_benefit': 'Humans gain advantage on power learning checks.'
            }
        ]
    
    def create_faction_synergies(self, power_data: Dict[str, Any], power_type: str) -> List[Dict[str, Any]]:
        """Create faction synergies."""
        if power_type == 'Force':
            return [
                {
                    'faction_id': 'jedi_order',
                    'narrative': 'The Jedi Order teaches the proper use of Force powers.',
                    'mechanical_benefit': 'Jedi gain +2 to Force power saving throw DCs.'
                }
            ]
        else:
            return [
                {
                    'faction_id': 'rebel_alliance',
                    'narrative': 'The Rebel Alliance values technological expertise.',
                    'mechanical_benefit': 'Rebels gain +2 to Tech power saving throw DCs.'
                }
            ]
    
    def create_llm_guidance(self, power_data: Dict[str, Any], level: int) -> Dict[str, Any]:
        """Create LLM guidance."""
        name = power_data.get('name', '')
        
        if level >= 6:
            return {
                'roleplay_guidance': f"When using {name}, describe the character's legendary mastery and the world-changing effects of their power. This is a {level}th-level ability that should feel truly epic and transformative.",
                'tactical_notes': f"{name} is a legendary power that should be used sparingly and strategically. Its effects are world-changing and should be treated as such in the narrative.",
                'narrative_hooks': [
                    f"The use of {name} creates an opportunity for legendary character development",
                    f"An enemy attempts to counter or resist {name} with their own legendary abilities",
                    f"The effects of {name} have world-changing consequences that ripple through the galaxy"
                ]
            }
        else:
            return {
                'roleplay_guidance': f"When using {name}, describe the character's expertise and the visible effects of their power. Focus on the narrative impact and how it affects the scene.",
                'tactical_notes': f"{name} should be used strategically to maximize its effectiveness. Consider the timing and positioning for optimal results.",
                'narrative_hooks': [
                    f"The use of {name} creates an opportunity for character development",
                    f"An enemy attempts to counter or resist {name}",
                    f"The effects of {name} have unexpected consequences"
                ]
            }
    
    def create_image_generation(self, power_data: Dict[str, Any], power_type: str, level: int) -> Dict[str, Any]:
        """Create image generation."""
        name = power_data.get('name', '')
        
        if level >= 6:
            if power_type == 'Force':
                base_prompt = f"A character using the legendary {name}, with massive, world-changing Force energy effects and epic, cinematic action. The scene should convey the absolute mastery and legendary power of this {level}th-level ability, with dramatic lighting and scale."
            else:
                base_prompt = f"A character using the legendary {name}, with massive, world-changing technological effects and epic, cinematic action. The scene should convey the absolute mastery and legendary power of this {level}th-level ability, with dramatic lighting and scale."
        else:
            if power_type == 'Force':
                base_prompt = f"A character using {name}, with visible Force energy effects and dynamic action. The scene should convey the mystical power and mastery of the Force."
            else:
                base_prompt = f"A character using {name}, with visible technological effects and dynamic action. The scene should convey the technical expertise and mastery of technology."
        
        return {
            'base_prompt': base_prompt,
            'base_negative_keywords': ['static', 'boring', 'cartoonish', 'blurry', 'unclear']
        }
    
    def create_ui(self, power_data: Dict[str, Any], level: int) -> Dict[str, Any]:
        """Create UI section."""
        power_id = power_data.get('id', 'unknown').replace('power_', '')
        
        # Different colors for different power levels
        if level >= 9:
            color = "#FF0000"  # Red for transcendent
        elif level >= 7:
            color = "#FF6600"  # Orange for divine
        elif level >= 6:
            color = "#FFAA00"  # Yellow for legendary
        else:
            color = "#0066CC"  # Blue for standard
        
        return {
            'icon': f"/assets/icons/powers/{power_id}.svg",
            'color': color
        }
    
    def generate_final_report(self) -> Dict[str, Any]:
        """Generate comprehensive final report."""
        print("\n" + "=" * 80)
        print("🎉 UNIFIED POWER PIPELINE COMPLETE!")
        print("=" * 80)
        print(f"⏰ Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"📊 Total Powers Processed: {self.processed_count}")
        print(f"✅ Successfully Created: {self.successful_count}")
        print(f"❌ Failed: {self.failed_count}")
        print(f"⚠️  Validation Warnings: {len(self.validation_warnings)}")
        
        if self.validation_errors:
            print(f"\n📋 VALIDATION ERRORS ({len(self.validation_errors)}):")
            for error in self.validation_errors:
                print(f"  {error}")
        
        if self.validation_warnings:
            print(f"\n📋 VALIDATION WARNINGS ({len(self.validation_warnings)}):")
            for warning in self.validation_warnings:
                print(f"  {warning}")
        
        # Success rate calculation
        success_rate = (self.successful_count / self.processed_count * 100) if self.processed_count > 0 else 0
        print(f"\n📈 SUCCESS RATE: {success_rate:.1f}%")
        
        return {
            'processed_count': self.processed_count,
            'successful_count': self.successful_count,
            'failed_count': self.failed_count,
            'success_rate': success_rate,
            'validation_errors': self.validation_errors,
            'validation_warnings': self.validation_warnings,
            'processing_log': self.processing_log
        }

def main():
    """Main function."""
    powers_dir = "data/powers"
    catalogs_dir = "data/powers/catalogs"
    
    if not os.path.exists(powers_dir):
        print(f"❌ Powers directory not found: {powers_dir}")
        return
    
    if not os.path.exists(catalogs_dir):
        print(f"❌ Catalogs directory not found: {catalogs_dir}")
        return
    
    pipeline = UnifiedPowerPipeline(powers_dir, catalogs_dir)
    results = pipeline.process_all_catalogs()
    
    # Return exit code based on success rate
    if results['success_rate'] >= 95:
        print("\n🎯 PIPELINE STATUS: EXCELLENT")
        return 0
    elif results['success_rate'] >= 80:
        print("\n🎯 PIPELINE STATUS: GOOD")
        return 1
    else:
        print("\n🎯 PIPELINE STATUS: NEEDS ATTENTION")
        return 2

if __name__ == "__main__":
    exit(main())
