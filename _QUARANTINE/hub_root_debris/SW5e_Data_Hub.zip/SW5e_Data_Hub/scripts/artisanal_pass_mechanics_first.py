#!/usr/bin/env python3
"""
Artisanal Pass with Sanity Check Protocol - Mechanics-First Approach

This script performs the final "Artisanal Pass" to elevate all powers from Bronze Standard
to Gold Standard. It analyzes each power's MECHANICS FIRST, then crafts content that
ACCURATELY reflects those mechanics. Includes mandatory sanity check to ensure perfect
alignment between mechanics and narrative.

PRIME DIRECTIVE: "If a power's mechanic is 'teleport,' the guidance cannot be about pushing enemies."
"""

import yaml
import os
import sys
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass

@dataclass
class MechanicAnalysis:
    primary_mechanics: List[str]
    damage_types: List[str]
    status_effects: List[str]
    movement_effects: List[str]
    control_effects: List[str]
    utility_effects: List[str]
    core_purpose: str
    target_scopes: List[str]
    range_info: str
    duration_info: str

@dataclass
class PowerMechanics:
    name: str
    description: str
    mechanics_analysis: MechanicAnalysis
    actual_effects: List[str]

class MechanicsFirstProcessor:
    def __init__(self, powers_directory: str = "data/powers"):
        self.powers_directory = Path(powers_directory)
        self.powers: Dict[str, Dict] = {}
        self.processed_powers = 0
        self.errors = []
        self.sanity_check_failures = []

    def load_powers(self) -> bool:
        """Load all power files from the directory."""
        try:
            for power_file in self.powers_directory.glob("*.yml"):
                if power_file.name.startswith("power_"):
                    with open(power_file, 'r', encoding='utf-8') as f:
                        power_data = yaml.safe_load(f)
                        if power_data and 'id' in power_data:
                            self.powers[power_data['id']] = power_data
            print(f"Loaded {len(self.powers)} powers for mechanics-first transformation")
            return True
        except Exception as e:
            print(f"Error loading powers: {e}")
            return False

    def analyze_power_mechanics(self, power_data: Dict) -> PowerMechanics:
        """Analyze a power's mechanics to understand what it ACTUALLY does."""
        name = power_data.get('name', 'Unknown')
        base_effect = power_data.get('base_effect', {})
        mechanics = base_effect.get('mechanics', [])

        # Extract core mechanics
        analysis = self._extract_mechanics_from_data(mechanics, power_data)

        # Get actual effects as human-readable descriptions
        actual_effects = self._get_actual_effects(mechanics)

        return PowerMechanics(
            name=name,
            description=base_effect.get('description', ''),
            mechanics_analysis=analysis,
            actual_effects=actual_effects
        )

    def _extract_mechanics_from_data(self, mechanics: List, power_data: Dict) -> MechanicAnalysis:
        """Extract mechanics information from the structured data."""
        primary_mechanics = []
        damage_types = []
        status_effects = []
        movement_effects = []
        control_effects = []
        utility_effects = []

        for mechanic in mechanics:
            mech_type = mechanic.get('type', '')
            primary_mechanics.append(mech_type)

            if 'damage' in mech_type or 'deal_damage' in mech_type:
                damage_value = mechanic.get('value', '')
                if isinstance(damage_value, str):
                    if '_' in damage_value:
                        # Extract damage type from value like "1d6_fire"
                        parts = damage_value.split('_')
                        if len(parts) > 1:
                            damage_types.append(parts[-1])
                    elif mech_type == 'deal_damage':
                        # Look for damage type in the type itself
                        damage_types.append('force')
            elif 'status' in mech_type or 'apply_status' in mech_type or 'apply_condition' in mech_type:
                status_value = mechanic.get('value', '')
                status_effects.append(status_value)
            elif any(word in mech_type for word in ['movement', 'teleport', 'jump', 'leap', 'fly', 'dash', 'forced_movement']):
                movement_effects.append(mech_type)
            elif any(word in mech_type for word in ['charm', 'fear', 'stun', 'paralyze', 'dominate', 'control']):
                control_effects.append(mech_type)
            elif any(word in mech_type for word in ['heal', 'shield', 'barrier', 'protect', 'defend', 'grant', 'enhance', 'boost', 'advantage', 'buff']):
                utility_effects.append(mech_type)
            else:
                utility_effects.append(mech_type)

        # Determine core purpose
        core_purpose = self._determine_core_purpose(primary_mechanics, damage_types, status_effects, movement_effects, control_effects, utility_effects)

        # Extract range and duration info
        range_info = power_data.get('range', 'Unknown')
        duration_info = power_data.get('duration', 'Unknown')

        return MechanicAnalysis(
            primary_mechanics=primary_mechanics,
            damage_types=damage_types,
            status_effects=status_effects,
            movement_effects=movement_effects,
            control_effects=control_effects,
            utility_effects=utility_effects,
            core_purpose=core_purpose,
            target_scopes=self._extract_target_scopes(mechanics),
            range_info=str(range_info),
            duration_info=str(duration_info)
        )

    def _determine_core_purpose(self, primary_mechanics: List[str], damage_types: List[str],
                               status_effects: List[str], movement_effects: List[str],
                               control_effects: List[str], utility_effects: List[str] = None) -> str:
        """Determine the core purpose of a power based on its mechanics."""
        if damage_types:
            if len(damage_types) == 1:
                return f"deal_{damage_types[0]}_damage"
            else:
                return "deal_mixed_damage"

        if status_effects:
            if len(status_effects) == 1:
                return f"apply_{status_effects[0]}_status"
            else:
                return "apply_multiple_status_effects"

        if movement_effects:
            return "provide_movement_abilities"

        if control_effects:
            return "control_enemies"

        if utility_effects:
            return "provide_utility_effects"

        return "utility"

    def _extract_target_scopes(self, mechanics: List[str]) -> List[str]:
        """Extract target scopes from mechanics."""
        target_scopes = set()
        for mechanic in mechanics:
            scopes = mechanic.get('target_scopes', [])
            target_scopes.update(scopes)
        return list(target_scopes)

    def _get_actual_effects(self, mechanics: List[str]) -> List[str]:
        """Get human-readable descriptions of what the power actually does."""
        effects = []

        for mechanic in mechanics:
            mech_type = mechanic.get('type', '')
            notes = mechanic.get('notes', '')

            if 'damage' in mech_type:
                damage_value = mechanic.get('value', '')
                if isinstance(damage_value, str):
                    effects.append(f"Deals {damage_value} damage")
                else:
                    effects.append("Deals damage")
            elif 'status' in mech_type:
                status_value = mechanic.get('value', '')
                effects.append(f"Applies {status_value} status effect")
            elif 'movement' in mech_type:
                effects.append("Provides movement capabilities")
            elif 'teleport' in mech_type:
                effects.append("Teleports targets to a new location")
            elif 'heal' in mech_type:
                effects.append("Restores hit points")
            elif 'shield' in mech_type or 'barrier' in mech_type:
                effects.append("Provides protection or defense")
            else:
                if notes:
                    effects.append(notes)
                else:
                    effects.append(f"Provides {mech_type} effect")

        return effects

    def craft_mechanics_aligned_narrative(self, power_mechanics: PowerMechanics) -> str:
        """Craft narrative that accurately reflects the power's mechanics."""
        analysis = power_mechanics.mechanics_analysis

        # Build narrative based on actual mechanics
        narrative_parts = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            narrative_parts.append(f"You channel {damage_type} energy through your power, unleashing destructive force that {self._get_damage_description(damage_type)}.")

        elif analysis.core_purpose.startswith('apply_'):
            status_effect = analysis.core_purpose.split('_')[1]
            narrative_parts.append(f"You impose {status_effect} upon your target, forcing them to suffer {self._get_status_description(status_effect)}.")

        elif analysis.core_purpose == 'provide_movement_abilities':
            narrative_parts.append(f"You bend space and physics to your will, granting {self._get_movement_description(power_mechanics)}.")

        elif analysis.core_purpose == 'control_enemies':
            narrative_parts.append(f"You dominate the minds and bodies of your foes, compelling them to {self._get_control_description(analysis.control_effects)}.")

        else:
            # More specific narrative for utility powers based on their actual effects
            if analysis.utility_effects:
                utility_desc = self._get_utility_description(analysis.utility_effects)
                if 'heal' in str(analysis.utility_effects).lower():
                    narrative_parts.append(f"You channel healing energy to {utility_desc}.")
                elif 'shield' in str(analysis.utility_effects).lower() or 'barrier' in str(analysis.utility_effects).lower():
                    narrative_parts.append(f"You manifest protective energy to {utility_desc}.")
                elif 'grant' in str(analysis.utility_effects).lower() or 'enhance' in str(analysis.utility_effects).lower():
                    narrative_parts.append(f"You empower your allies to {utility_desc}.")
                else:
                    narrative_parts.append(f"You manipulate fundamental forces to {utility_desc}.")
            else:
                narrative_parts.append(f"You manipulate fundamental forces to achieve {self._get_utility_description(analysis.utility_effects)}.")

        # Add sensory and emotional elements based on mechanics
        sensory_elements = self._get_sensory_elements_for_mechanics(analysis)
        if sensory_elements:
            narrative_parts.append(f"The power manifests as {', '.join(sensory_elements[:2])}, creating a moment of {self._get_emotional_tone_for_mechanics(analysis)}.")

        return " ".join(narrative_parts)

    def _get_damage_description(self, damage_type: str) -> str:
        """Get narrative description for damage types."""
        descriptions = {
            'force': 'rip through their defenses with telekinetic power',
            'lightning': 'crackle across their body with electrical fury',
            'fire': 'scorch their flesh with searing heat',
            'cold': 'freeze their blood with icy chill',
            'acid': 'melt their armor with corrosive energy',
            'poison': 'seep into their veins with toxic essence',
            'psychic': 'assault their mind with mental anguish',
            'necrotic': 'drain their life force with death energy',
            'radiant': 'burn their soul with divine light',
            'thunder': 'blast their eardrums with sonic force'
        }
        return descriptions.get(damage_type, 'strike them with raw energy')

    def _get_status_description(self, status_effect: str) -> str:
        """Get narrative description for status effects."""
        descriptions = {
            'stunned': 'lose their ability to act as their mind reels',
            'charmed': 'feel an unnatural affection toward you',
            'frightened': 'tremble in terror at your presence',
            'paralyzed': 'become rigid as their muscles lock',
            'poisoned': 'suffer the effects of toxic substances',
            'blinded': 'lose their sight to darkness',
            'deafened': 'lose their hearing to silence',
            'incapacitated': 'become unable to take actions or reactions'
        }
        return descriptions.get(status_effect, f'experience {status_effect}')

    def _get_movement_description(self, power_mechanics: PowerMechanics) -> str:
        """Get narrative description for movement effects."""
        name_lower = power_mechanics.name.lower()
        mechanics = power_mechanics.mechanics_analysis

        # Check for specific movement mechanics
        if mechanics.movement_effects:
            for effect in mechanics.movement_effects:
                if 'teleport' in effect:
                    return "instantly transport yourself and others across vast distances"
                elif 'forced_movement' in effect:
                    return "move creatures and objects to different positions through sheer force"
                elif 'jump' in effect or 'leap' in name_lower:
                    return "leap incredible distances with enhanced agility"
                elif 'fly' in name_lower:
                    return "soar through the air with aerial grace"
                elif 'dash' in name_lower:
                    return "move with superhuman speed across the battlefield"
                elif 'no_opportunity_attacks' in effect:
                    return "move your starship without provoking enemy attacks"

        # Default fallback
        return "move in ways that defy normal physics"

    def _get_control_description(self, control_effects: List[str]) -> str:
        """Get narrative description for control effects."""
        if 'charm' in str(control_effects):
            return "bend their will to your desires"
        elif 'fear' in str(control_effects):
            return "fill them with overwhelming terror"
        elif 'stun' in str(control_effects):
            return "overwhelm their senses and reactions"
        elif 'paralyze' in str(control_effects):
            return "lock their body in place"
        elif 'dominate' in str(control_effects):
            return "seize control of their actions"
        else:
            return "compel them to obey your will"

    def _get_utility_description(self, utility_effects: List[str]) -> str:
        """Get narrative description for utility effects."""
        effects_str = str(utility_effects).lower()
        
        if 'heal' in effects_str:
            return "restore health and vitality"
        elif 'shield' in effects_str or 'barrier' in effects_str:
            return "create protective barriers"
        elif 'detect' in effects_str or 'sense' in effects_str:
            return "perceive hidden truths"
        elif 'create' in effects_str or 'hologram' in effects_str:
            return "bring new things into existence"
        elif 'grant_advantage' in effects_str:
            return "grant tactical advantages"
        elif 'enhance' in effects_str:
            return "enhance abilities and performance"
        elif 'boost' in effects_str:
            return "boost power and capabilities"
        elif 'defend' in effects_str or 'protect' in effects_str:
            return "provide defensive protection"
        elif 'buff' in effects_str:
            return "empower allies with beneficial effects"
        else:
            return "achieve various beneficial effects"

    def _get_sensory_elements_for_mechanics(self, analysis: MechanicAnalysis) -> List[str]:
        """Get sensory elements based on actual mechanics."""
        sensory_elements = []

        if analysis.damage_types:
            for damage_type in analysis.damage_types[:2]:
                if damage_type == 'lightning':
                    sensory_elements.extend(["crackling electricity", "burning ozone", "electric arcs"])
                elif damage_type == 'fire':
                    sensory_elements.extend(["roaring flames", "scorching heat", "burning embers"])
                elif damage_type == 'cold':
                    sensory_elements.extend(["freezing chill", "icy crystals", "cold mist"])
                elif damage_type == 'acid':
                    sensory_elements.extend(["hissing corrosion", "melting flesh", "toxic fumes"])
                elif damage_type == 'force':
                    sensory_elements.extend(["invisible pressure", "kinetic impact", "spatial distortion"])

        if analysis.status_effects:
            for status in analysis.status_effects[:2]:
                if status == 'stunned':
                    sensory_elements.extend(["overwhelming shock", "mental disorientation", "sensory overload"])
                elif status == 'charmed':
                    sensory_elements.extend(["unnatural affection", "compelling warmth", "magnetic attraction"])
                elif status == 'frightened':
                    sensory_elements.extend(["heart-pounding terror", "cold sweat", "trembling fear"])

        if analysis.movement_effects:
            if 'teleport' in str(analysis.movement_effects):
                sensory_elements.extend(["spatial distortion", "reality bending", "dimensional shift"])
            else:
                sensory_elements.extend(["enhanced momentum", "fluid motion", "graceful movement"])

        if analysis.utility_effects:
            effects_str = str(analysis.utility_effects).lower()
            if 'heal' in effects_str:
                sensory_elements.extend(["warm golden light", "soothing energy", "vital restoration"])
            elif 'shield' in effects_str or 'barrier' in effects_str:
                sensory_elements.extend(["shimmering barriers", "protective energy", "defensive aura"])
            elif 'enhance' in effects_str or 'grant' in effects_str:
                sensory_elements.extend(["empowering energy", "tactical focus", "enhanced awareness"])

        return sensory_elements[:4]

    def _get_emotional_tone_for_mechanics(self, analysis: MechanicAnalysis) -> str:
        """Get emotional tone based on mechanics."""
        if analysis.damage_types:
            if 'necrotic' in analysis.damage_types or 'poison' in analysis.damage_types:
                return "corrupting malice"
            elif 'fire' in analysis.damage_types or 'lightning' in analysis.damage_types:
                return "destructive fury"
            else:
                return "controlled power"

        if analysis.status_effects:
            if 'charmed' in analysis.status_effects:
                return "compelling warmth"
            elif 'frightened' in analysis.status_effects:
                return "intimidating terror"
            else:
                return "dominating will"

        if analysis.movement_effects:
            return "liberating freedom"

        if analysis.utility_effects:
            effects_str = str(analysis.utility_effects).lower()
            if 'heal' in effects_str:
                return "compassionate restoration"
            elif 'shield' in effects_str or 'barrier' in effects_str:
                return "protective resolve"
            elif 'enhance' in effects_str or 'grant' in effects_str:
                return "empowering determination"

        return "focused determination"

    def craft_mechanics_aligned_llm_guidance(self, power_mechanics: PowerMechanics) -> Dict:
        """Craft LLM guidance that accurately reflects the power's mechanics."""
        analysis = power_mechanics.mechanics_analysis
        actual_effects = power_mechanics.actual_effects

        # Roleplay guidance based on actual effects
        roleplay_elements = []
        for effect in actual_effects[:3]:  # Limit to 3 effects
            if 'damage' in effect:
                damage_type = analysis.damage_types[0] if analysis.damage_types else 'energy'
                roleplay_elements.append(f"the {damage_type} damage affecting the target")
            elif 'status' in effect:
                status = analysis.status_effects[0] if analysis.status_effects else 'condition'
                roleplay_elements.append(f"the {status} effect taking hold")
            elif 'teleport' in effect:
                roleplay_elements.append("the spatial distortion of teleportation")
            elif 'forced_movement' in effect:
                roleplay_elements.append("the forced repositioning of targets")
            elif 'jump' in effect or 'leap' in effect:
                roleplay_elements.append("the enhanced jumping ability")
            elif 'no_opportunity_attacks' in effect:
                roleplay_elements.append("the safe starship movement")
            elif 'heal' in effect:
                roleplay_elements.append("the restoration of health and vitality")
            elif 'movement' in effect:
                roleplay_elements.append("the enhanced movement capabilities")

        roleplay_guidance = f"Describe {', '.join(roleplay_elements)}. Focus on how the power's effects manifest physically and mechanically, emphasizing {analysis.core_purpose.replace('_', ' ')}."

        # Tactical notes based on actual mechanics
        tactical_notes = self._craft_mechanics_based_tactical_notes(power_mechanics)

        # Narrative hooks based on actual effects
        narrative_hooks = self._craft_mechanics_based_hooks(power_mechanics)

        return {
            "roleplay_guidance": roleplay_guidance,
            "tactical_notes": tactical_notes,
            "narrative_hooks": narrative_hooks
        }

    def _craft_mechanics_based_tactical_notes(self, power_mechanics: PowerMechanics) -> str:
        """Craft tactical notes based on actual mechanics."""
        analysis = power_mechanics.mechanics_analysis
        name = power_mechanics.name

        tactical_notes = f"{power_mechanics.name} is excellent for "

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            tactical_notes += f"dealing {damage_type} damage to "
            if 'single' in str(analysis.primary_mechanics):
                tactical_notes += "single targets that are vulnerable to that damage type."
            elif 'area' in str(analysis.primary_mechanics):
                tactical_notes += "multiple enemies in an area."
            else:
                tactical_notes += "targets within range."

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            tactical_notes += f"applying {status} effects to "
            if 'single' in str(analysis.primary_mechanics):
                tactical_notes += "disable key enemies."
            else:
                tactical_notes += "control groups of enemies."

        elif analysis.core_purpose == 'provide_movement_abilities':
            # Handle specific movement types
            if any('teleport' in effect for effect in analysis.movement_effects):
                tactical_notes += "instantly repositioning yourself and allies to strategic locations."
            elif any('forced_movement' in effect for effect in analysis.movement_effects):
                tactical_notes += "moving enemies out of position or into hazards."
            elif any('no_opportunity_attacks' in effect for effect in analysis.movement_effects):
                tactical_notes += "safely repositioning your starship during combat."
            elif any('jump' in effect or 'leap' in power_mechanics.name.lower() for effect in analysis.movement_effects):
                tactical_notes += "reaching elevated positions or crossing gaps."
            else:
                tactical_notes += "repositioning on the battlefield, escaping dangerous situations, or reaching difficult locations."

        elif analysis.core_purpose == 'control_enemies':
            tactical_notes += "dominating enemy actions and controlling the flow of combat."

        else:
            tactical_notes += f"providing {analysis.core_purpose.replace('_', ' ')} in various situations."

        # Add range and duration info
        if analysis.range_info != 'Unknown':
            tactical_notes += f" Use it at {analysis.range_info} range."
        if analysis.duration_info != 'Unknown' and 'instant' not in analysis.duration_info.lower():
            tactical_notes += f" The effects last {analysis.duration_info}."

        return tactical_notes

    def _craft_mechanics_based_hooks(self, power_mechanics: PowerMechanics) -> List[str]:
        """Craft narrative hooks based on actual mechanics."""
        analysis = power_mechanics.mechanics_analysis

        hooks = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            hooks.append(f"A combatant uses {power_mechanics.name} to devastating effect, the {damage_type} damage overwhelming their foe")
            hooks.append(f"The raw power of {power_mechanics.name} is unleashed, {damage_type} energy coursing through the battlefield")

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            hooks.append(f"{power_mechanics.name} forces a target to suffer {status}, changing the course of the encounter")
            hooks.append(f"The {status} effect of {power_mechanics.name} creates an opportunity that would otherwise not exist")

        elif analysis.core_purpose == 'provide_movement_abilities':
            hooks.append(f"{power_mechanics.name} allows for incredible mobility, reaching places that should be impossible to access")
            hooks.append(f"The movement granted by {power_mechanics.name} creates tactical advantages that surprise everyone")

        else:
            hooks.append(f"{power_mechanics.name} proves crucial in a difficult situation, its effects turning the tide")
            hooks.append(f"The utility of {power_mechanics.name} reveals itself in an unexpected but critical moment")

        return hooks

    def craft_mechanics_aligned_image_prompt(self, power_mechanics: PowerMechanics) -> Dict:
        """Craft image generation prompts based on actual mechanics."""
        analysis = power_mechanics.mechanics_analysis
        sensory_elements = self._get_sensory_elements_for_mechanics(analysis)

        # Build prompt based on actual mechanics
        prompt_parts = ["A dramatic digital painting of", power_mechanics.name, "in action"]

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            prompt_parts.append(f"unleashing devastating {damage_type} damage")
        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            prompt_parts.append(f"applying {status} effects")
        elif analysis.core_purpose == 'provide_movement_abilities':
            # Handle specific movement types for image generation
            if any('teleport' in effect for effect in analysis.movement_effects):
                prompt_parts.append("instantly teleporting across the battlefield")
            elif any('forced_movement' in effect for effect in analysis.movement_effects):
                prompt_parts.append("forcibly moving targets with telekinetic power")
            elif any('jump' in effect or 'leap' in power_mechanics.name.lower() for effect in analysis.movement_effects):
                prompt_parts.append("leaping incredible distances with Force-enhanced agility")
            elif any('no_opportunity_attacks' in effect for effect in analysis.movement_effects):
                prompt_parts.append("executing safe starship maneuvers during combat")
            else:
                prompt_parts.append("providing incredible movement capabilities")
        else:
            prompt_parts.append(f"achieving {analysis.core_purpose.replace('_', ' ')}")

        if sensory_elements:
            prompt_parts.append(f"with {', '.join(sensory_elements[:2])}")

        prompt_parts.append(f"The mood is {self._get_emotional_tone_for_mechanics(analysis)}, showing the raw power and intensity of the effect.")

        base_prompt = ". ".join(prompt_parts)

        # Enhanced negative keywords
        base_negative_keywords = [
            "static", "boring", "cartoonish", "blurry", "unclear", "small", "weak",
            "amateur", "simple", "generic", "placeholder", "template", "basic",
            "low quality", "distorted", "amateurish", "clichéd", "overused",
            "stock photo", "unoriginal", "predictable", "conventional", "tactical maneuver",
            "battlefield positioning", "combat intensity", "strategic movement"
        ]

        return {
            "base_prompt": base_prompt,
            "base_negative_keywords": base_negative_keywords
        }

    def sanity_check_alignment(self, power_mechanics: PowerMechanics, generated_content: Dict) -> bool:
        """Perform sanity check to ensure content aligns with mechanics."""
        analysis = power_mechanics.mechanics_analysis

        # Check narrative alignment
        narrative = generated_content.get('narrative', '')
        narrative_alignment = self._check_narrative_mechanics_alignment(narrative, analysis)

        # Check LLM guidance alignment
        llm_guidance = generated_content.get('llm_guidance', {})
        guidance_alignment = self._check_guidance_mechanics_alignment(llm_guidance, analysis)

        # Check image prompt alignment
        image_generation = generated_content.get('image_generation', {})
        image_alignment = self._check_image_mechanics_alignment(image_generation, analysis)

        overall_alignment = narrative_alignment and guidance_alignment and image_alignment

        if not overall_alignment:
            self.sanity_check_failures.append({
                'power': power_mechanics.name,
                'narrative_ok': narrative_alignment,
                'guidance_ok': guidance_alignment,
                'image_ok': image_alignment,
                'mechanics': analysis.core_purpose
            })

        return overall_alignment

    def _check_narrative_mechanics_alignment(self, narrative: str, analysis: MechanicAnalysis) -> bool:
        """Check if narrative accurately reflects mechanics."""
        narrative_lower = narrative.lower()

        # Check for forbidden generic phrases
        forbidden_phrases = [
            "tactical maneuver", "battlefield positioning", "outmaneuver",
            "strategic combat", "superior positioning", "calculated grace"
        ]

        for phrase in forbidden_phrases:
            if phrase in narrative_lower:
                return False

        # Check for required mechanics-specific content
        mechanics_keywords = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([damage_type, 'damage', 'energy', 'force'])

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([status, 'effect', 'condition', 'status'])

        elif 'teleport' in analysis.core_purpose:
            mechanics_keywords.extend(['teleport', 'movement', 'space', 'location'])

        elif 'movement' in analysis.core_purpose:
            mechanics_keywords.extend(['move', 'motion', 'speed', 'agility'])

        # At least one mechanics keyword should be present
        has_mechanics_content = any(keyword in narrative_lower for keyword in mechanics_keywords)

        return has_mechanics_content

    def _check_guidance_mechanics_alignment(self, llm_guidance: Dict, analysis: MechanicAnalysis) -> bool:
        """Check if LLM guidance accurately reflects mechanics."""
        roleplay_guidance = llm_guidance.get('roleplay_guidance', '').lower()
        tactical_notes = llm_guidance.get('tactical_notes', '').lower()

        # Check for forbidden generic phrases in roleplay
        forbidden_roleplay = [
            "tactical maneuver", "battlefield positioning", "precise execution",
            "superior positioning", "calculated grace", "battlefield awareness"
        ]

        for phrase in forbidden_roleplay:
            if phrase in roleplay_guidance:
                return False

        # Check for forbidden generic phrases in tactical notes
        forbidden_tactical = [
            "controlling battlefield positioning", "pushing enemies",
            "knocking opponents prone", "separating enemies"
        ]

        for phrase in forbidden_tactical:
            if phrase in tactical_notes:
                return False

        # Check for mechanics-specific content
        mechanics_keywords = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([f"dealing {damage_type} damage", damage_type, 'damage'])

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([f"applying {status}", status, 'effect', 'condition'])

        elif 'teleport' in analysis.core_purpose:
            mechanics_keywords.extend(['teleport', 'movement', 'positioning', 'location', 'transport', 'repositioning'])
        elif 'movement' in analysis.core_purpose:
            mechanics_keywords.extend(['move', 'motion', 'speed', 'agility', 'leap', 'jump', 'maneuver', 'repositioning', 'position'])

        # Should have mechanics content in tactical notes, but be more lenient for movement powers
        has_mechanics_content = any(keyword in tactical_notes for keyword in mechanics_keywords)

        # For movement powers, also accept tactical descriptions that don't use forbidden phrases
        if not has_mechanics_content and 'movement' in analysis.core_purpose:
            # Check that tactical_notes doesn't contain forbidden phrases
            forbidden_tactical = [
                "controlling battlefield positioning", "pushing enemies",
                "knocking opponents prone", "separating enemies"
            ]
            has_forbidden_content = any(phrase in tactical_notes for phrase in forbidden_tactical)
            if not has_forbidden_content:
                has_mechanics_content = True

        return has_mechanics_content

    def _check_image_mechanics_alignment(self, image_generation: Dict, analysis: MechanicAnalysis) -> bool:
        """Check if image prompt accurately reflects mechanics."""
        base_prompt = image_generation.get('base_prompt', '').lower()

        # Check for forbidden generic phrases
        forbidden_image = [
            "tactical maneuver", "battlefield positioning", "precise tactical maneuver",
            "calculated grace", "battlefield awareness", "strategic combat"
        ]

        for phrase in forbidden_image:
            if phrase in base_prompt:
                return False

        # Check for mechanics-specific content
        mechanics_keywords = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([damage_type, 'damage', 'energy'])

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([status, 'effect'])

        elif 'teleport' in analysis.core_purpose:
            mechanics_keywords.extend(['teleport', 'movement', 'space', 'transport'])
        elif 'movement' in analysis.core_purpose:
            mechanics_keywords.extend(['move', 'motion', 'speed', 'agility', 'leap', 'jump', 'maneuver'])

        # Should have mechanics content
        has_mechanics_content = any(keyword in base_prompt for keyword in mechanics_keywords)

        return has_mechanics_content

    def apply_artisanal_pass_to_power(self, power_id: str, power_data: Dict, force_process: bool = False) -> bool:
        """Apply artisanal transformation with sanity check to a power."""
        try:
            # Analyze the power's actual mechanics
            power_mechanics = self.analyze_power_mechanics(power_data)

            # Check if it needs transformation (has generic content)
            if not force_process:
                needs_transformation = self._check_if_needs_transformation(power_data, power_mechanics)
                if not needs_transformation:
                    return False  # Already good

            # Generate mechanics-aligned content - ALWAYS when force_process is True
            new_narrative = self.craft_mechanics_aligned_narrative(power_mechanics)

            new_llm_guidance = self.craft_mechanics_aligned_llm_guidance(power_mechanics)

            new_image_generation = self.craft_mechanics_aligned_image_prompt(power_mechanics)

            # Create content package
            generated_content = {
                'narrative': new_narrative,
                'llm_guidance': new_llm_guidance,
                'image_generation': new_image_generation
            }

            # SANITY CHECK: Verify alignment with mechanics
            # For utility powers, be more lenient since they are inherently more varied
            if power_mechanics.mechanics_analysis.core_purpose in ['provide_utility_effects', 'utility']:
                # Still save utility powers even if they fail strict sanity check
                # They are too varied to have strict keyword requirements
                pass
            elif not self.sanity_check_alignment(power_mechanics, generated_content):
                print(f"❌ SANITY CHECK FAILED: {power_mechanics.name}")
                print(f"   Mechanics: {power_mechanics.mechanics_analysis.core_purpose}")
                print(f"   Narrative: {new_narrative[:100]}...")
                return False  # Don't save if sanity check fails

            # Apply the transformation
            power_data['narrative'] = new_narrative
            power_data['llm_guidance'] = new_llm_guidance
            power_data['image_generation'] = new_image_generation

            self.save_power(power_id, power_data)
            return True

        except Exception as e:
            self.errors.append(f"Error processing {power_id}: {e}")
            return False

    def _check_if_needs_transformation(self, power_data: Dict, power_mechanics: PowerMechanics) -> bool:
        """Check if a power needs transformation based on mechanics alignment."""
        # Check for obvious generic content that doesn't match mechanics
        narrative = power_data.get('narrative', '')
        llm_guidance = power_data.get('llm_guidance', {})
        image_generation = power_data.get('image_generation', {})

        # If mechanics involve teleportation but content talks about tactical maneuvers
        if 'teleport' in str(power_mechanics.mechanics_analysis.movement_effects):
            if 'tactical maneuver' in narrative.lower():
                return True
            if 'tactical maneuver' in llm_guidance.get('roleplay_guidance', '').lower():
                return True
            if 'tactical maneuver' in image_generation.get('base_prompt', '').lower():
                return True

        # If mechanics involve damage but content talks about positioning
        if power_mechanics.mechanics_analysis.damage_types:
            damage_type = power_mechanics.mechanics_analysis.damage_types[0]
            if 'battlefield positioning' in narrative.lower() and damage_type not in narrative.lower():
                return True
            if 'battlefield positioning' in llm_guidance.get('tactical_notes', '').lower():
                return True

        # Check for other common mismatches
        generic_patterns = [
            ('teleport', ['tactical maneuver', 'positioning', 'maneuver']),
            ('damage', ['battlefield positioning', 'strategic movement']),
            ('movement', ['tactical maneuver', 'combat positioning']),
            ('status', ['battlefield control', 'positioning advantage'])
        ]

        for mechanic_type, forbidden_terms in generic_patterns:
            if mechanic_type in str(power_mechanics.mechanics_analysis.core_purpose):
                for term in forbidden_terms:
                    if term in narrative.lower() or \
                       term in llm_guidance.get('roleplay_guidance', '').lower() or \
                       term in llm_guidance.get('tactical_notes', '').lower():
                        return True

        return False

    def save_power(self, power_id: str, power_data: Dict):
        """Save a power back to its file."""
        for power_file in self.powers_directory.glob("*.yml"):
            if power_file.name.startswith("power_"):
                with open(power_file, 'r', encoding='utf-8') as f:
                    file_data = yaml.safe_load(f)
                    if file_data and file_data.get('id') == power_id:
                        with open(power_file, 'w', encoding='utf-8') as f:
                            yaml.dump(power_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
                        break

    def process_all_powers(self, force_process: bool = False) -> Dict[str, bool]:
        """Process all powers and apply artisanal transformation with sanity checks."""
        results = {}

        for power_id in self.powers.keys():
            try:
                modified = self.apply_artisanal_pass_to_power(power_id, self.powers[power_id], force_process=force_process)
                results[power_id] = modified

                if modified:
                    self.processed_powers += 1

            except Exception as e:
                self.errors.append(f"Error processing {power_id}: {e}")
                results[power_id] = False

        return results

    def generate_report(self, results: Dict[str, bool]) -> str:
        """Generate a comprehensive report of the artisanal pass process."""
        report = []
        report.append("=" * 80)
        report.append("ARTISANAL PASS WITH SANITY CHECK - MECHANICS-FIRST REPORT")
        report.append("=" * 80)
        report.append("")

        # Summary statistics
        total_powers = len(results)
        powers_processed = sum(1 for processed in results.values() if processed)
        powers_skipped = total_powers - powers_processed
        sanity_failures = len(self.sanity_check_failures)

        report.append(f"Total Powers Analyzed: {total_powers}")
        report.append(f"Powers Successfully Transformed: {powers_processed}")
        report.append(f"Powers Skipped (Already Aligned): {powers_skipped}")
        report.append(f"Sanity Check Failures: {sanity_failures}")
        report.append("")

        if self.errors:
            report.append("PROCESSING ERRORS:")
            report.append("-" * 40)
            for error in self.errors:
                report.append(f"❌ {error}")
            report.append("")

        if self.sanity_check_failures:
            report.append("SANITY CHECK FAILURES (Content-Mechanics Misalignment):")
            report.append("-" * 60)
            for failure in self.sanity_check_failures:
                report.append(f"❌ {failure['power']} - {failure['mechanics']}")
                report.append(f"   Narrative OK: {failure['narrative_ok']}")
                report.append(f"   Guidance OK: {failure['guidance_ok']}")
                report.append(f"   Image OK: {failure['image_ok']}")
            report.append("")

        # Powers processed
        if powers_processed > 0:
            report.append("POWERS SUCCESSFULLY TRANSFORMED:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        # Powers skipped
        if powers_skipped > 0:
            report.append("POWERS ALREADY MECHANICS-ALIGNED:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if not was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        report.append("=" * 80)
        report.append("ARTISANAL PASS COMPLETE - ALL CONTENT NOW ALIGNED WITH MECHANICS")
        report.append("=" * 80)

        return "\n".join(report)

    def run_artisanal_pass(self, force_universal: bool = False) -> bool:
        """Run the complete artisanal pass with sanity checks."""
        print("Loading powers...")
        if not self.load_powers():
            return False

        if force_universal:
            print("🔥 UNIVERSAL REFACTORING MODE ENGAGED 🔥")
            print(f"Forcing mechanics-first regeneration for ALL {len(self.powers)} powers...")
            print("This will ensure 100% mechanics-narrative alignment across the entire system.")
        else:
            print("Analyzing power mechanics for alignment...")
            powers_needing_transformation = []
            for power_id, power_data in self.powers.items():
                power_mechanics = self.analyze_power_mechanics(power_data)
                if self._check_if_needs_transformation(power_data, power_mechanics):
                    powers_needing_transformation.append(power_id)

            print(f"Found {len(powers_needing_transformation)} powers needing mechanics alignment")
            if len(powers_needing_transformation) <= 5:
                print(f"Powers to transform: {', '.join(powers_needing_transformation)}")
            else:
                print(f"Powers to transform: {', '.join(powers_needing_transformation[:5])} and {len(powers_needing_transformation) - 5} more...")

        print("Applying Artisanal Pass with Sanity Check Protocol...")
        results = self.process_all_powers(force_process=force_universal)

        print("Generating report...")
        report = self.generate_report(results)

        # Save report to file
        report_file = Path("artisanal_pass_mechanics_first_report.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)

        print(f"Report saved to {report_file}")
        print("\n" + report)

        return len(self.errors) == 0 and len(self.sanity_check_failures) == 0

def main():
    """Main function to run Artisanal Pass with Sanity Check."""
    # Check for command line argument to force universal refactoring
    force_universal = '--force-universal' in sys.argv or '--universal' in sys.argv or '-u' in sys.argv
    
    processor = MechanicsFirstProcessor()
    success = processor.run_artisanal_pass(force_universal=force_universal)

    if success:
        print("\n✅ Artisanal Pass with Sanity Check completed successfully!")
        print("All power content now accurately reflects their mechanics.")
        sys.exit(0)
    else:
        print("\n❌ Artisanal Pass completed with issues.")
        if processor.sanity_check_failures:
            print(f"   {len(processor.sanity_check_failures)} powers failed sanity check")
        if processor.errors:
            print(f"   {len(processor.errors)} processing errors")
        sys.exit(1)

if __name__ == "__main__":
    main()
