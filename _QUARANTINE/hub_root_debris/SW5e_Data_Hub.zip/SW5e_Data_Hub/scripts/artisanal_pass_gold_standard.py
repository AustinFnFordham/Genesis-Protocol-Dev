#!/usr/bin/env python3
"""
Artisanal Pass with Sanity Check Protocol - Gold Standard Script

This script performs the final "Artisanal Pass" to elevate all powers from Bronze Standard
to Gold Standard. It analyzes each power's MECHANICS FIRST, then crafts content that
ACCURATELY reflects those mechanics. Includes mandatory sanity check to ensure perfect
alignment between mechanics and narrative.
"""

import yaml
import os
import sys
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass

@dataclass
class MechanicAnalysis:
    primary_mechanics: List[str]
    damage_types: List[str]
    status_effects: List[str]
    movement_effects: List[str]
    control_effects: List[str]
    utility_effects: List[str]
    core_purpose: str
    target_scopes: List[str]
    range_info: str
    duration_info: str

@dataclass
class PowerMechanics:
    name: str
    description: str
    mechanics_analysis: MechanicAnalysis
    actual_effects: List[str]

class ArtisanalPassProcessor:
    def __init__(self, powers_directory: str = "data/powers"):
        self.powers_directory = Path(powers_directory)
        self.powers: Dict[str, Dict] = {}
        self.processed_powers = 0
        self.errors = []
        self.sanity_check_failures = []

    def load_powers(self) -> bool:
        """Load all power files from the directory."""
        try:
            for power_file in self.powers_directory.glob("*.yml"):
                if power_file.name.startswith("power_"):
                    with open(power_file, 'r', encoding='utf-8') as f:
                        power_data = yaml.safe_load(f)
                        if power_data and 'id' in power_data:
                            self.powers[power_data['id']] = power_data
            print(f"Loaded {len(self.powers)} powers for artisanal transformation")
            return True
        except Exception as e:
            print(f"Error loading powers: {e}")
            return False

    def analyze_power_mechanics(self, power_data: Dict) -> PowerMechanics:
        """Analyze a power's mechanics to understand what it ACTUALLY does."""
        name = power_data.get('name', 'Unknown')
        base_effect = power_data.get('base_effect', {})
        mechanics = base_effect.get('mechanics', [])

        # Extract core mechanics
        analysis = self._extract_mechanics_from_data(mechanics, base_effect)

        # Get actual effects as human-readable descriptions
        actual_effects = self._get_actual_effects(mechanics)

        return PowerMechanics(
            name=name,
            description=base_effect.get('description', ''),
            mechanics_analysis=analysis,
            actual_effects=actual_effects
        )

    def _extract_mechanics_from_data(self, mechanics: List, base_effect: Dict) -> MechanicAnalysis:
        """Extract mechanics information from the structured data."""
        primary_mechanics = []
        damage_types = []
        status_effects = []
        movement_effects = []
        control_effects = []
        utility_effects = []

        for mechanic in mechanics:
            mech_type = mechanic.get('type', '')
            primary_mechanics.append(mech_type)

            if 'damage' in mech_type:
                damage_value = mechanic.get('value', '')
                if isinstance(damage_value, str) and '_' in damage_value:
                    damage_type = damage_value.split('_')[-1]
                    damage_types.append(damage_type)
            elif 'status' in mech_type:
                status_value = mechanic.get('value', '')
                status_effects.append(status_value)
            elif 'movement' in mech_type or 'teleport' in mech_type:
                movement_effects.append(mech_type)
            elif any(word in mech_type for word in ['charm', 'fear', 'stun', 'paralyze', 'dominate']):
                control_effects.append(mech_type)
            else:
                utility_effects.append(mech_type)

        # Determine core purpose
        core_purpose = self._determine_core_purpose(primary_mechanics, damage_types, status_effects, movement_effects, control_effects)

        # Extract range and duration info
        range_info = power_data.get('range', 'Unknown')
        duration_info = power_data.get('duration', 'Unknown')

        return MechanicAnalysis(
            primary_mechanics=primary_mechanics,
            damage_types=damage_types,
            status_effects=status_effects,
            movement_effects=movement_effects,
            control_effects=control_effects,
            utility_effects=utility_effects,
            core_purpose=core_purpose,
            target_scopes=self._extract_target_scopes(mechanics),
            range_info=str(range_info),
            duration_info=str(duration_info)
        )

    def _determine_core_purpose(self, primary_mechanics: List[str], damage_types: List[str],
                               status_effects: List[str], movement_effects: List[str],
                               control_effects: List[str]) -> str:
        """Determine the core purpose of a power based on its mechanics."""
        if damage_types:
            if len(damage_types) == 1:
                return f"deal_{damage_types[0]}_damage"
            else:
                return "deal_mixed_damage"

        if status_effects:
            if len(status_effects) == 1:
                return f"apply_{status_effects[0]}_status"
            else:
                return "apply_multiple_status_effects"

        if movement_effects:
            return "provide_movement_abilities"

        if control_effects:
            return "control_enemies"

        if utility_effects:
            return "provide_utility_effects"

        return "utility"

    def _extract_target_scopes(self, mechanics: List[str]) -> List[str]:
        """Extract target scopes from mechanics."""
        target_scopes = set()
        for mechanic in mechanics:
            scopes = mechanic.get('target_scopes', [])
            target_scopes.update(scopes)
        return list(target_scopes)

    def _get_actual_effects(self, mechanics: List[str]) -> List[str]:
        """Get human-readable descriptions of what the power actually does."""
        effects = []

        for mechanic in mechanics:
            mech_type = mechanic.get('type', '')
            notes = mechanic.get('notes', '')

            if 'damage' in mech_type:
                damage_value = mechanic.get('value', '')
                if isinstance(damage_value, str):
                    effects.append(f"Deals {damage_value} damage")
                else:
                    effects.append("Deals damage")
            elif 'status' in mech_type:
                status_value = mechanic.get('value', '')
                effects.append(f"Applies {status_value} status effect")
            elif 'movement' in mech_type:
                effects.append("Provides movement capabilities")
            elif 'teleport' in mech_type:
                effects.append("Teleports targets to a new location")
            elif 'heal' in mech_type:
                effects.append("Restores hit points")
            elif 'shield' in mech_type or 'barrier' in mech_type:
                effects.append("Provides protection or defense")
            else:
                if notes:
                    effects.append(notes)
                else:
                    effects.append(f"Provides {mech_type} effect")

        return effects

    def craft_mechanics_aligned_narrative(self, power_mechanics: PowerMechanics) -> str:
        """Craft narrative that accurately reflects the power's mechanics."""
        analysis = power_mechanics.mechanics_analysis

        # Build narrative based on actual mechanics
        narrative_parts = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            narrative_parts.append(f"You channel {damage_type} energy through your power, unleashing destructive force that {self._get_damage_description(damage_type)}.")

        elif analysis.core_purpose.startswith('apply_'):
            status_effect = analysis.core_purpose.split('_')[1]
            narrative_parts.append(f"You impose {status_effect} upon your target, forcing them to suffer {self._get_status_description(status_effect)}.")

        elif analysis.core_purpose == 'provide_movement_abilities':
            narrative_parts.append(f"You bend space and physics to your will, granting {self._get_movement_description(power_mechanics)}.")

        elif analysis.core_purpose == 'control_enemies':
            narrative_parts.append(f"You dominate the minds and bodies of your foes, compelling them to {self._get_control_description(analysis.control_effects)}.")

        else:
            narrative_parts.append(f"You manipulate fundamental forces to achieve {self._get_utility_description(analysis.utility_effects)}.")

        # Add sensory and emotional elements based on mechanics
        sensory_elements = self._get_sensory_elements_for_mechanics(analysis)
        if sensory_elements:
            narrative_parts.append(f"The power manifests as {', '.join(sensory_elements[:2])}, creating a moment of {self._get_emotional_tone_for_mechanics(analysis)}.")

        return " ".join(narrative_parts)

    def _get_damage_description(self, damage_type: str) -> str:
        """Get narrative description for damage types."""
        descriptions = {
            'force': 'rip through their defenses with telekinetic power',
            'lightning': 'crackle across their body with electrical fury',
            'fire': 'scorch their flesh with searing heat',
            'cold': 'freeze their blood with icy chill',
            'acid': 'melt their armor with corrosive energy',
            'poison': 'seep into their veins with toxic essence',
            'psychic': 'assault their mind with mental anguish',
            'necrotic': 'drain their life force with death energy',
            'radiant': 'burn their soul with divine light',
            'thunder': 'blast their eardrums with sonic force'
        }
        return descriptions.get(damage_type, 'strike them with raw energy')

    def _get_status_description(self, status_effect: str) -> str:
        """Get narrative description for status effects."""
        descriptions = {
            'stunned': 'lose their ability to act as their mind reels',
            'charmed': 'feel an unnatural affection toward you',
            'frightened': 'tremble in terror at your presence',
            'paralyzed': 'become rigid as their muscles lock',
            'poisoned': 'suffer the effects of toxic substances',
            'blinded': 'lose their sight to darkness',
            'deafened': 'lose their hearing to silence',
            'incapacitated': 'become unable to take actions or reactions'
        }
        return descriptions.get(status_effect, f'experience {status_effect}')

    def _get_movement_description(self, power_mechanics: PowerMechanics) -> str:
        """Get narrative description for movement effects."""
        name = power_mechanics.name.lower()

        if 'teleport' in name or 'movement' in str(power_mechanics.mechanics_analysis.movement_effects):
            return "instantly transport yourself and others across vast distances"
        elif 'leap' in name:
            return "leap incredible distances with enhanced agility"
        elif 'fly' in name:
            return "soar through the air with aerial grace"
        elif 'dash' in name:
            return "move with superhuman speed across the battlefield"
        else:
            return "move in ways that defy normal physics"

    def _get_control_description(self, control_effects: List[str]) -> str:
        """Get narrative description for control effects."""
        if 'charm' in str(control_effects):
            return "bend their will to your desires"
        elif 'fear' in str(control_effects):
            return "fill them with overwhelming terror"
        elif 'stun' in str(control_effects):
            return "overwhelm their senses and reactions"
        elif 'paralyze' in str(control_effects):
            return "lock their body in place"
        elif 'dominate' in str(control_effects):
            return "seize control of their actions"
        else:
            return "compel them to obey your will"

    def _get_utility_description(self, utility_effects: List[str]) -> str:
        """Get narrative description for utility effects."""
        if 'heal' in str(utility_effects):
            return "restore health and vitality"
        elif 'shield' in str(utility_effects):
            return "create protective barriers"
        elif 'detect' in str(utility_effects) or 'sense' in str(utility_effects):
            return "perceive hidden truths"
        elif 'create' in str(utility_effects):
            return "bring new things into existence"
        else:
            return "achieve various beneficial effects"

    def _get_sensory_elements_for_mechanics(self, analysis: MechanicAnalysis) -> List[str]:
        """Get sensory elements based on actual mechanics."""
        sensory_elements = []

        if analysis.damage_types:
            for damage_type in analysis.damage_types[:2]:
                if damage_type == 'lightning':
                    sensory_elements.extend(["crackling electricity", "burning ozone", "electric arcs"])
                elif damage_type == 'fire':
                    sensory_elements.extend(["roaring flames", "scorching heat", "burning embers"])
                elif damage_type == 'cold':
                    sensory_elements.extend(["freezing chill", "icy crystals", "cold mist"])
                elif damage_type == 'acid':
                    sensory_elements.extend(["hissing corrosion", "melting flesh", "toxic fumes"])
                elif damage_type == 'force':
                    sensory_elements.extend(["invisible pressure", "kinetic impact", "spatial distortion"])

        if analysis.status_effects:
            for status in analysis.status_effects[:2]:
                if status == 'stunned':
                    sensory_elements.extend(["overwhelming shock", "mental disorientation", "sensory overload"])
                elif status == 'charmed':
                    sensory_elements.extend(["unnatural affection", "compelling warmth", "magnetic attraction"])
                elif status == 'frightened':
                    sensory_elements.extend(["heart-pounding terror", "cold sweat", "trembling fear"])

        if analysis.movement_effects:
            if 'teleport' in str(analysis.movement_effects):
                sensory_elements.extend(["spatial distortion", "reality bending", "dimensional shift"])
            else:
                sensory_elements.extend(["enhanced momentum", "fluid motion", "graceful movement"])

        return sensory_elements[:4]

    def _get_emotional_tone_for_mechanics(self, analysis: MechanicAnalysis) -> str:
        """Get emotional tone based on mechanics."""
        if analysis.damage_types:
            if 'necrotic' in analysis.damage_types or 'poison' in analysis.damage_types:
                return "corrupting malice"
            elif 'fire' in analysis.damage_types or 'lightning' in analysis.damage_types:
                return "destructive fury"
            else:
                return "controlled power"

        if analysis.status_effects:
            if 'charmed' in analysis.status_effects:
                return "compelling warmth"
            elif 'frightened' in analysis.status_effects:
                return "intimidating terror"
            else:
                return "dominating will"

        if analysis.movement_effects:
            return "liberating freedom"

        return "focused determination"

    def craft_mechanics_aligned_llm_guidance(self, power_mechanics: PowerMechanics) -> Dict:
        """Craft LLM guidance that accurately reflects the power's mechanics."""
        analysis = power_mechanics.mechanics_analysis
        actual_effects = power_mechanics.actual_effects

        # Roleplay guidance based on actual effects
        roleplay_elements = []
        for effect in actual_effects[:3]:  # Limit to 3 effects
            if 'damage' in effect:
                damage_type = analysis.damage_types[0] if analysis.damage_types else 'energy'
                roleplay_elements.append(f"the {damage_type} damage affecting the target")
            elif 'status' in effect:
                status = analysis.status_effects[0] if analysis.status_effects else 'condition'
                roleplay_elements.append(f"the {status} effect taking hold")
            elif 'teleport' in effect:
                roleplay_elements.append("the spatial distortion of teleportation")
            elif 'heal' in effect:
                roleplay_elements.append("the restoration of health and vitality")
            elif 'movement' in effect:
                roleplay_elements.append("the enhanced movement capabilities")

        roleplay_guidance = f"Describe {', '.join(roleplay_elements)}. Focus on how the power's effects manifest physically and mechanically, emphasizing {analysis.core_purpose.replace('_', ' ')}."

        # Tactical notes based on actual mechanics
        tactical_notes = self._craft_mechanics_based_tactical_notes(power_mechanics)

        # Narrative hooks based on actual effects
        narrative_hooks = self._craft_mechanics_based_hooks(power_mechanics)

        return {
            "roleplay_guidance": roleplay_guidance,
            "tactical_notes": tactical_notes,
            "narrative_hooks": narrative_hooks
        }

    def _craft_mechanics_based_tactical_notes(self, power_mechanics: PowerMechanics) -> str:
        """Craft tactical notes based on actual mechanics."""
        analysis = power_mechanics.mechanics_analysis
        name = power_mechanics.name

        tactical_notes = f"{name} is excellent for "

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            tactical_notes += f"dealing {damage_type} damage to "
            if 'single' in str(analysis.primary_mechanics):
                tactical_notes += "single targets that are vulnerable to that damage type."
            elif 'area' in str(analysis.primary_mechanics):
                tactical_notes += "multiple enemies in an area."
            else:
                tactical_notes += "targets within range."

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            tactical_notes += f"applying {status} effects to "
            if 'single' in str(analysis.primary_mechanics):
                tactical_notes += "disable key enemies."
            else:
                tactical_notes += "control groups of enemies."

        elif analysis.core_purpose == 'provide_movement_abilities':
            tactical_notes += "repositioning on the battlefield, escaping dangerous situations, or reaching difficult locations."

        elif analysis.core_purpose == 'control_enemies':
            tactical_notes += "dominating enemy actions and controlling the flow of combat."

        else:
            tactical_notes += f"providing {analysis.core_purpose.replace('_', ' ')} in various situations."

        # Add range and duration info
        if analysis.range_info != 'Unknown':
            tactical_notes += f" Use it at {analysis.range_info} range."
        if analysis.duration_info != 'Unknown' and 'instant' not in analysis.duration_info.lower():
            tactical_notes += f" The effects last {analysis.duration_info}."

        return tactical_notes

    def _craft_mechanics_based_hooks(self, power_mechanics: PowerMechanics) -> List[str]:
        """Craft narrative hooks based on actual mechanics."""
        analysis = power_mechanics.mechanics_analysis
        name = power_mechanics.name

        hooks = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            hooks.append(f"A combatant uses {name} to devastating effect, the {damage_type} damage overwhelming their foe")
            hooks.append(f"The raw power of {name} is unleashed, {damage_type} energy coursing through the battlefield")

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            hooks.append(f"{name} forces a target to suffer {status}, changing the course of the encounter")
            hooks.append(f"The {status} effect of {name} creates an opportunity that would otherwise not exist")

        elif analysis.core_purpose == 'provide_movement_abilities':
            hooks.append(f"{name} allows for incredible mobility, reaching places that should be impossible to access")
            hooks.append(f"The movement granted by {name} creates tactical advantages that surprise everyone")

        else:
            hooks.append(f"{name} proves crucial in a difficult situation, its effects turning the tide")
            hooks.append(f"The utility of {name} reveals itself in an unexpected but critical moment")

        return hooks

    def craft_mechanics_aligned_image_prompt(self, power_mechanics: PowerMechanics) -> Dict:
        """Craft image generation prompts based on actual mechanics."""
        analysis = power_mechanics.mechanics_analysis
        sensory_elements = self._get_sensory_elements_for_mechanics(analysis)

        # Build prompt based on actual mechanics
        prompt_parts = ["A dramatic digital painting of", power_mechanics.name, "in action"]

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            prompt_parts.append(f"unleashing devastating {damage_type} damage")
        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            prompt_parts.append(f"applying {status} effects")
        elif analysis.core_purpose == 'provide_movement_abilities':
            prompt_parts.append("providing incredible movement capabilities")
        else:
            prompt_parts.append(f"achieving {analysis.core_purpose.replace('_', ' ')}")

        if sensory_elements:
            prompt_parts.append(f"with {', '.join(sensory_elements[:2])}")

        prompt_parts.append(f"The mood is {self._get_emotional_tone_for_mechanics(analysis)}, showing the raw power and intensity of the effect.")

        base_prompt = ". ".join(prompt_parts)

        # Enhanced negative keywords
        base_negative_keywords = [
            "static", "boring", "cartoonish", "blurry", "unclear", "small", "weak",
            "amateur", "simple", "generic", "placeholder", "template", "basic",
            "low quality", "distorted", "amateurish", "clichéd", "overused",
            "stock photo", "unoriginal", "predictable", "conventional", "tactical maneuver",
            "battlefield positioning", "combat intensity", "strategic movement"
        ]

        return {
            "base_prompt": base_prompt,
            "base_negative_keywords": base_negative_keywords
        }

    def sanity_check_alignment(self, power_mechanics: PowerMechanics, generated_content: Dict) -> bool:
        """Perform sanity check to ensure content aligns with mechanics."""
        analysis = power_mechanics.mechanics_analysis

        # Check narrative alignment
        narrative = generated_content.get('narrative', '')
        narrative_alignment = self._check_narrative_mechanics_alignment(narrative, analysis)

        # Check LLM guidance alignment
        llm_guidance = generated_content.get('llm_guidance', {})
        guidance_alignment = self._check_guidance_mechanics_alignment(llm_guidance, analysis)

        # Check image prompt alignment
        image_generation = generated_content.get('image_generation', {})
        image_alignment = self._check_image_mechanics_alignment(image_generation, analysis)

        overall_alignment = narrative_alignment and guidance_alignment and image_alignment

        if not overall_alignment:
            self.sanity_check_failures.append({
                'power': power_mechanics.name,
                'narrative_ok': narrative_alignment,
                'guidance_ok': guidance_alignment,
                'image_ok': image_alignment,
                'mechanics': analysis.core_purpose
            })

        return overall_alignment

    def _check_narrative_mechanics_alignment(self, narrative: str, analysis: MechanicAnalysis) -> bool:
        """Check if narrative accurately reflects mechanics."""
        narrative_lower = narrative.lower()

        # Check for forbidden generic phrases
        forbidden_phrases = [
            "tactical maneuver", "battlefield positioning", "outmaneuver",
            "strategic combat", "superior positioning", "calculated grace"
        ]

        for phrase in forbidden_phrases:
            if phrase in narrative_lower:
                return False

        # Check for required mechanics-specific content
        mechanics_keywords = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([damage_type, 'damage', 'energy', 'force'])

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([status, 'effect', 'condition', 'status'])

        elif 'teleport' in analysis.core_purpose:
            mechanics_keywords.extend(['teleport', 'movement', 'space', 'location'])

        elif 'movement' in analysis.core_purpose:
            mechanics_keywords.extend(['move', 'motion', 'speed', 'agility'])

        # At least one mechanics keyword should be present
        has_mechanics_content = any(keyword in narrative_lower for keyword in mechanics_keywords)

        return has_mechanics_content

    def _check_guidance_mechanics_alignment(self, llm_guidance: Dict, analysis: MechanicAnalysis) -> bool:
        """Check if LLM guidance accurately reflects mechanics."""
        roleplay_guidance = llm_guidance.get('roleplay_guidance', '').lower()
        tactical_notes = llm_guidance.get('tactical_notes', '').lower()

        # Check for forbidden generic phrases in roleplay
        forbidden_roleplay = [
            "tactical maneuver", "battlefield positioning", "precise execution",
            "superior positioning", "calculated grace", "battlefield awareness"
        ]

        for phrase in forbidden_roleplay:
            if phrase in roleplay_guidance:
                return False

        # Check for forbidden generic phrases in tactical notes
        forbidden_tactical = [
            "controlling battlefield positioning", "pushing enemies",
            "knocking opponents prone", "separating enemies"
        ]

        for phrase in forbidden_tactical:
            if phrase in tactical_notes:
                return False

        # Check for mechanics-specific content
        mechanics_keywords = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([f"dealing {damage_type} damage", damage_type, 'damage'])

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([f"applying {status}", status, 'effect', 'condition'])

        elif 'teleport' in analysis.core_purpose:
            mechanics_keywords.extend(['teleport', 'movement', 'positioning', 'location'])

        # Should have mechanics content in tactical notes
        has_mechanics_content = any(keyword in tactical_notes for keyword in mechanics_keywords)

        return has_mechanics_content

    def _check_image_mechanics_alignment(self, image_generation: Dict, analysis: MechanicAnalysis) -> bool:
        """Check if image prompt accurately reflects mechanics."""
        base_prompt = image_generation.get('base_prompt', '').lower()

        # Check for forbidden generic phrases
        forbidden_image = [
            "tactical maneuver", "battlefield positioning", "precise tactical maneuver",
            "calculated grace", "battlefield awareness", "strategic combat"
        ]

        for phrase in forbidden_image:
            if phrase in base_prompt:
                return False

        # Check for mechanics-specific content
        mechanics_keywords = []

        if analysis.core_purpose.startswith('deal_'):
            damage_type = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([damage_type, 'damage', 'energy'])

        elif analysis.core_purpose.startswith('apply_'):
            status = analysis.core_purpose.split('_')[1]
            mechanics_keywords.extend([status, 'effect'])

        elif 'teleport' in analysis.core_purpose:
            mechanics_keywords.extend(['teleport', 'movement', 'space'])

        # Should have mechanics content
        has_mechanics_content = any(keyword in base_prompt for keyword in mechanics_keywords)

        return has_mechanics_content

    def apply_artisanal_pass_to_power(self, power_id: str, power_data: Dict) -> bool:
        """Apply artisanal transformation with sanity check to a power."""
        try:
            # Analyze the power's actual mechanics
            power_mechanics = self.analyze_power_mechanics(power_data)

            # Check if it needs transformation (has generic content)
            needs_transformation = self._check_if_needs_transformation(power_data, power_mechanics)

            if not needs_transformation:
                return False  # Already good

            # Generate mechanics-aligned content
            new_narrative = self.craft_mechanics_aligned_narrative(power_mechanics)

            new_llm_guidance = self.craft_mechanics_aligned_llm_guidance(power_mechanics)

            new_image_generation = self.craft_mechanics_aligned_image_prompt(power_mechanics)

            # Create content package
            generated_content = {
                'narrative': new_narrative,
                'llm_guidance': new_llm_guidance,
                'image_generation': new_image_generation
            }

            # SANITY CHECK: Verify alignment with mechanics
            if not self.sanity_check_alignment(power_mechanics, generated_content):
                print(f"❌ SANITY CHECK FAILED: {power_mechanics.name}")
                print(f"   Mechanics: {power_mechanics.mechanics_analysis.core_purpose}")
                print(f"   Narrative: {new_narrative[:100]}...")
                return False  # Don't save if sanity check fails

            # Apply the transformation
            power_data['narrative'] = new_narrative
            power_data['llm_guidance'] = new_llm_guidance
            power_data['image_generation'] = new_image_generation

            self.save_power(power_id, power_data)
            return True

        except Exception as e:
            self.errors.append(f"Error processing {power_id}: {e}")
            return False

    def _check_if_needs_transformation(self, power_data: Dict, power_mechanics: PowerMechanics) -> bool:
        """Check if a power needs transformation based on mechanics alignment."""
        # Check for obvious generic content that doesn't match mechanics
        narrative = power_data.get('narrative', '')
        llm_guidance = power_data.get('llm_guidance', {})
        image_generation = power_data.get('image_generation', {})

        # If mechanics involve teleportation but content talks about tactical maneuvers
        if 'teleport' in str(power_mechanics.mechanics_analysis.movement_effects):
            if 'tactical maneuver' in narrative.lower():
                return True
            if 'tactical maneuver' in llm_guidance.get('roleplay_guidance', '').lower():
                return True
            if 'tactical maneuver' in image_generation.get('base_prompt', '').lower():
                return True

        # If mechanics involve damage but content talks about positioning
        if power_mechanics.mechanics_analysis.damage_types:
            damage_type = power_mechanics.mechanics_analysis.damage_types[0]
            if 'battlefield positioning' in narrative.lower() and damage_type not in narrative.lower():
                return True
            if 'battlefield positioning' in llm_guidance.get('tactical_notes', '').lower():
                return True

        # Check for other common mismatches
        generic_patterns = [
            ('teleport', ['tactical maneuver', 'positioning', 'maneuver']),
            ('damage', ['battlefield positioning', 'strategic movement']),
            ('movement', ['tactical maneuver', 'combat positioning']),
            ('status', ['battlefield control', 'positioning advantage'])
        ]

        for mechanic_type, forbidden_terms in generic_patterns:
            if mechanic_type in str(power_mechanics.mechanics_analysis.core_purpose):
                for term in forbidden_terms:
                    if term in narrative.lower() or \
                       term in llm_guidance.get('roleplay_guidance', '').lower() or \
                       term in llm_guidance.get('tactical_notes', '').lower():
                        return True

        return False

    def save_power(self, power_id: str, power_data: Dict):
        """Save a power back to its file."""
        for power_file in self.powers_directory.glob("*.yml"):
            if power_file.name.startswith("power_"):
                with open(power_file, 'r', encoding='utf-8') as f:
                    file_data = yaml.safe_load(f)
                    if file_data and file_data.get('id') == power_id:
                        with open(power_file, 'w', encoding='utf-8') as f:
                            yaml.dump(power_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
                        break

    def process_all_powers(self) -> Dict[str, bool]:
        """Process all powers and apply artisanal transformation with sanity checks."""
        results = {}

        for power_id in self.powers.keys():
            try:
                modified = self.apply_artisanal_pass_to_power(power_id, self.powers[power_id])
                results[power_id] = modified

                if modified:
                    self.processed_powers += 1

            except Exception as e:
                self.errors.append(f"Error processing {power_id}: {e}")
                results[power_id] = False

        return results

    def generate_report(self, results: Dict[str, bool]) -> str:
        """Generate a comprehensive report of the artisanal pass process."""
        report = []
        report.append("=" * 80)
        report.append("ARTISANAL PASS WITH SANITY CHECK - GOLD STANDARD REPORT")
        report.append("=" * 80)
        report.append("")

        # Summary statistics
        total_powers = len(results)
        powers_processed = sum(1 for processed in results.values() if processed)
        powers_skipped = total_powers - powers_processed
        sanity_failures = len(self.sanity_check_failures)

        report.append(f"Total Powers Analyzed: {total_powers}")
        report.append(f"Powers Successfully Transformed: {powers_processed}")
        report.append(f"Powers Skipped (Already Aligned): {powers_skipped}")
        report.append(f"Sanity Check Failures: {sanity_failures}")
        report.append("")

        if self.errors:
            report.append("PROCESSING ERRORS:")
            report.append("-" * 40)
            for error in self.errors:
                report.append(f"❌ {error}")
            report.append("")

        if self.sanity_check_failures:
            report.append("SANITY CHECK FAILURES (Content-Mechanics Misalignment):")
            report.append("-" * 60)
            for failure in self.sanity_check_failures:
                report.append(f"❌ {failure['power']} - {failure['mechanics']}")
                report.append(f"   Narrative OK: {failure['narrative_ok']}")
                report.append(f"   Guidance OK: {failure['guidance_ok']}")
                report.append(f"   Image OK: {failure['image_ok']}")
            report.append("")

        # Powers processed
        if powers_processed > 0:
            report.append("POWERS SUCCESSFULLY TRANSFORMED:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        # Powers skipped
        if powers_skipped > 0:
            report.append("POWERS ALREADY MECHANICS-ALIGNED:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if not was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        report.append("=" * 80)
        report.append("ARTISANAL PASS COMPLETE - ALL CONTENT NOW ALIGNED WITH MECHANICS")
        report.append("=" * 80)

        return "\n".join(report)

    def run_artisanal_pass(self) -> bool:
        """Run the complete artisanal pass with sanity checks."""
        print("Loading powers...")
        if not self.load_powers():
            return False

        print("Analyzing power mechanics for alignment...")
        powers_needing_transformation = []
        for power_id, power_data in self.powers.items():
            power_mechanics = self.analyze_power_mechanics(power_data)
            if self._check_if_needs_transformation(power_data, power_mechanics):
                powers_needing_transformation.append(power_id)

        print(f"Found {len(powers_needing_transformation)} powers needing mechanics alignment")
        if len(powers_needing_transformation) <= 5:
            print(f"Powers to transform: {', '.join(powers_needing_transformation)}")
        else:
            print(f"Powers to transform: {', '.join(powers_needing_transformation[:5])} and {len(powers_needing_transformation) - 5} more...")

        print("Applying Artisanal Pass with Sanity Check Protocol...")
        results = self.process_all_powers()

        print("Generating report...")
        report = self.generate_report(results)

        # Save report to file
        report_file = Path("artisanal_pass_sanity_check_report.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)

        print(f"Report saved to {report_file}")
        print("\n" + report)

        return len(self.errors) == 0 and len(self.sanity_check_failures) == 0

def main():
    """Main function to run Artisanal Pass with Sanity Check."""
    processor = ArtisanalPassProcessor()
    success = processor.run_artisanal_pass()

    if success:
        print("\n✅ Artisanal Pass with Sanity Check completed successfully!")
        print("All power content now accurately reflects their mechanics.")
        sys.exit(0)
    else:
        print("\n❌ Artisanal Pass completed with issues.")
        if processor.sanity_check_failures:
            print(f"   {len(processor.sanity_check_failures)} powers failed sanity check")
        if processor.errors:
            print(f"   {len(processor.errors)} processing errors")
        sys.exit(1)

if __name__ == "__main__":
    main()
        alignment = power_data.get('alignment', '')
        level = power_data.get('level', 0)

        # Analyze mechanics to understand core function
        mechanics_summary = self._analyze_mechanics(power_data)

        # Determine unique identity based on name and mechanics
        unique_identity = self._determine_unique_identity(name, mechanics_summary, power_type, alignment)

        # Extract sensory and emotional elements
        sensory_elements = self._extract_sensory_elements(name, mechanics_summary, power_type)
        emotional_tone = self._determine_emotional_tone(power_type, alignment, name)
        narrative_focus = self._determine_narrative_focus(name, mechanics_summary, power_type)

        return PowerAnalysis(
            name=power_data.get('name', 'Unknown'),
            power_type=power_type,
            alignment=alignment,
            level=level,
            mechanics_summary=mechanics_summary,
            unique_identity=unique_identity,
            sensory_elements=sensory_elements,
            emotional_tone=emotional_tone,
            narrative_focus=narrative_focus
        )

    def _analyze_mechanics(self, power_data: Dict) -> str:
        """Analyze the power's mechanics to understand its core function."""
        mechanics = power_data.get('base_effect', {}).get('mechanics', [])

        if not mechanics:
            return "utility"

        # Look for key mechanics
        damage_mechanics = [m for m in mechanics if 'damage' in m.get('type', '')]
        status_mechanics = [m for m in mechanics if 'status' in m.get('type', '')]
        movement_mechanics = [m for m in mechanics if 'movement' in m.get('type', '')]
        control_mechanics = [m for m in mechanics if any(x in m.get('type', '') for x in ['charm', 'fear', 'stun', 'paralyze'])]

        if damage_mechanics:
            damage_type = damage_mechanics[0].get('value', 'damage').split('_')[0]
            return f"damage_{damage_type}"
        elif status_mechanics:
            status_value = status_mechanics[0].get('value', 'condition')
            return f"status_{status_value}"
        elif movement_mechanics:
            return "movement_enhancement"
        elif control_mechanics:
            return "crowd_control"
        else:
            return "utility"

    def _determine_unique_identity(self, name: str, mechanics: str, power_type: str, alignment: str) -> str:
        """Determine the unique identity of a power beyond its archetype."""
        name_lower = name.lower()

        # Force powers
        if power_type == 'Force':
            if 'push' in name_lower:
                return "extending invisible hands of Force energy to shove targets away"
            elif 'pull' in name_lower:
                return "drawing targets toward you with irresistible telekinetic force"
            elif 'throw' in name_lower:
                return "hurling objects through the air with devastating telekinetic power"
            elif 'crush' in name_lower:
                return "compressing targets with overwhelming telekinetic pressure"
            elif 'lightning' in name_lower:
                return "channeling raw electrical fury through your fingertips"
            elif 'storm' in name_lower:
                return "summoning a cataclysm of dark side energy from the skies"
            elif 'choke' in name_lower:
                return "constricting throats with invisible Force pressure"
            elif 'heal' in name_lower:
                return "knitting flesh and restoring life energy with healing light"
            elif 'mind' in name_lower:
                return "whispering suggestions directly into the minds of others"
            elif 'fear' in name_lower:
                return "instilling terror that paralyzes the heart and mind"
            elif 'barrier' in name_lower:
                return "creating walls of invisible Force energy"
            elif 'sever' in name_lower:
                return "tearing the connection between a target and the living Force"
            elif 'burst' in name_lower:
                return "releasing a sudden explosion of raw Force energy"
            elif 'wave' in name_lower:
                return "sending ripples of Force energy through multiple targets"
            elif alignment == 'Dark':
                return "corrupting the Force itself to fuel destructive power"
            else:
                return "channeling the Force to achieve the impossible"

        # Tech powers
        elif power_type == 'Tech':
            if 'ion' in name_lower:
                return "frying electronic systems with targeted electromagnetic pulses"
            elif 'hack' in name_lower:
                return "infiltrating computer systems with digital expertise"
            elif 'overload' in name_lower:
                return "pushing machines beyond their limits until they break"
            elif 'shield' in name_lower:
                return "projecting protective energy barriers through technology"
            elif 'scan' in name_lower:
                return "analyzing targets with precision sensors and displays"
            elif 'drone' in name_lower or 'probe' in name_lower:
                return "deploying autonomous machines to scout and attack"
            elif 'grenade' in name_lower or 'explosive' in name_lower:
                return "launching area-effect munitions with deadly precision"
            elif 'target' in name_lower:
                return "marking enemies for precision strikes"
            else:
                return "harnessing technology to achieve mechanical superiority"

        # Maneuver powers
        else:
            if 'trip' in name_lower:
                return "sweeping legs and unbalancing foes with martial skill"
            elif 'disarm' in name_lower:
                return "striking weapons from hands with calculated precision"
            elif 'feint' in name_lower:
                return "deceiving enemies with false movements and openings"
            elif 'leap' in name_lower:
                return "propelling yourself through the air with enhanced agility"
            elif 'dash' in name_lower:
                return "moving with superhuman speed across the battlefield"
            elif 'hide' in name_lower or 'stealth' in name_lower:
                return "blending into shadows and becoming one with the environment"
            else:
                return "executing tactical movements that turn the tide of battle"

    def _extract_sensory_elements(self, name: str, mechanics: str, power_type: str) -> List[str]:
        """Extract sensory elements that make the power unique."""
        name_lower = name.lower()
        sensory_elements = []

        if power_type == 'Force':
            if 'lightning' in name_lower:
                sensory_elements.extend(["crackling electricity", "burning ozone", "purple-white arcs", "hissing discharge"])
            elif 'push' in name_lower or 'pull' in name_lower:
                sensory_elements.extend(["invisible pressure", "rippling air", "telekinetic hum", "spatial distortion"])
            elif 'choke' in name_lower:
                sensory_elements.extend(["gasping breaths", "invisible constriction", "bulging veins", "desperate wheezing"])
            elif 'heal' in name_lower:
                sensory_elements.extend(["warm golden light", "soothing energy", "flesh knitting", "vitality returning"])
            elif 'mind' in name_lower:
                sensory_elements.extend(["subtle glow in eyes", "whispered thoughts", "mental pressure", "compelling gaze"])
            elif 'storm' in name_lower:
                sensory_elements.extend(["thunderous cracks", "raging winds", "dark clouds gathering", "atmospheric pressure"])
            else:
                sensory_elements.extend(["vibrating air", "subtle glow", "inner warmth", "distant hum"])

        elif power_type == 'Tech':
            if 'ion' in name_lower:
                sensory_elements.extend(["electrical crackling", "sparks flying", "systems sputtering", "overheated components"])
            elif 'hack' in name_lower:
                sensory_elements.extend(["rapid data streams", "glowing interfaces", "electronic beeps", "holographic displays"])
            elif 'shield' in name_lower:
                sensory_elements.extend(["hum of generators", "blue energy field", "distorted air", "protective shimmer"])
            elif 'explosive' in name_lower or 'grenade' in name_lower:
                sensory_elements.extend(["sharp explosion", "shrapnel flying", "concussive blast", "deafening boom"])
            else:
                sensory_elements.extend(["mechanical whirring", "electronic beeps", "hydraulic hiss", "digital display"])

        else:  # Maneuver
            if 'trip' in name_lower:
                sensory_elements.extend(["sweeping motion", "impact thud", "falling body", "scrambling recovery"])
            elif 'leap' in name_lower:
                sensory_elements.extend(["rushing air", "impact landing", "graceful arc", "enhanced momentum"])
            elif 'dash' in name_lower:
                sensory_elements.extend(["wind whipping", "speed blur", "rapid footsteps", "dust trailing"])
            else:
                sensory_elements.extend(["calculated movement", "precise positioning", "tactical awareness", "combat rhythm"])

        return sensory_elements[:4]  # Limit to 4 elements

    def _determine_emotional_tone(self, power_type: str, alignment: str, name: str) -> str:
        """Determine the emotional tone and feeling of using this power."""
        name_lower = name.lower()

        if power_type == 'Force':
            if alignment == 'Light':
                return "compassionate determination"
            elif alignment == 'Dark':
                return "corrupting rage"
            else:
                return "focused resolve"
        elif power_type == 'Tech':
            return "calculated precision"
        else:  # Maneuver
            return "tactical awareness"

    def _determine_narrative_focus(self, name: str, mechanics: str, power_type: str) -> str:
        """Determine what aspect of the power should be the narrative focus."""
        name_lower = name.lower()

        if 'choke' in name_lower:
            return "the desperation and suffocation of the victim"
        elif 'lightning' in name_lower:
            return "the raw fury and electrical destruction"
        elif 'mind' in name_lower:
            return "the subtle violation of personal thoughts"
        elif 'heal' in name_lower:
            return "the restoration and relief of suffering"
        elif 'ion' in name_lower:
            return "the technological failure and overload"
        elif 'trip' in name_lower:
            return "the loss of balance and control"
        elif 'leap' in name_lower:
            return "the freedom and grace of enhanced movement"
        else:
            return "the transformation of potential energy into kinetic power"

    def craft_gold_standard_narrative(self, analysis: PowerAnalysis) -> str:
        """Craft a Gold Standard narrative that captures the power's unique soul."""
        name = analysis.name
        unique_identity = analysis.unique_identity
        sensory_elements = analysis.sensory_elements
        emotional_tone = analysis.emotional_tone
        narrative_focus = analysis.narrative_focus

        # Build the narrative with power-specific language
        narrative_parts = []

        if analysis.power_type == 'Force':
            narrative_parts.append(f"You {unique_identity}.")
            narrative_parts.append(f"This is not mere destruction or manipulation, but {narrative_focus}.")
            narrative_parts.append(f"The power manifests as {', '.join(sensory_elements[:2])}, creating a moment that is both {emotional_tone} and profoundly personal.")
            if len(sensory_elements) > 2:
                narrative_parts.append(f"When cast, the Force responds to your will, {sensory_elements[2]} as the {analysis.alignment.lower()} side flows through you.")
            else:
                narrative_parts.append(f"When cast, the Force responds to your will as the {analysis.alignment.lower()} side flows through you.")

        elif analysis.power_type == 'Tech':
            narrative_parts.append(f"You {unique_identity}.")
            narrative_parts.append(f"This represents the pinnacle of technological warfare, where machines become extensions of your will.")
            narrative_parts.append(f"The {sensory_elements[0]} fills the air as {sensory_elements[1]}, demonstrating the raw power of machine mastery.")
            narrative_parts.append(f"In that moment, you become one with the technology, {emotional_tone} as you bend systems to your will.")

        else:  # Maneuver
            narrative_parts.append(f"You {unique_identity}.")
            narrative_parts.append(f"This is the art of tactical mastery made manifest, where training becomes instinct and instinct becomes victory.")
            narrative_parts.append(f"Your training and experience flow through you like {sensory_elements[0]}, {emotional_tone} as you execute the perfect maneuver.")
            if len(sensory_elements) > 1:
                narrative_parts.append(f"The battlefield seems to slow down as {sensory_elements[1]}, giving you the opening you need.")
            else:
                narrative_parts.append("The battlefield seems to slow down, giving you the opening you need.")

        return " ".join(narrative_parts)

    def craft_gold_standard_llm_guidance(self, analysis: PowerAnalysis) -> Dict:
        """Craft Gold Standard LLM guidance with power-specific details."""

        # Roleplay guidance - specific to the power's unique identity
        if analysis.power_type == 'Force':
            if 'choke' in analysis.name.lower():
                roleplay_guidance = f"Describe the victim's desperate gasping, the way their face turns red and their eyes bulge with terror. Focus on the {analysis.sensory_elements[0]} as invisible pressure crushes their windpipe, the {analysis.sensory_elements[1]} as they claw at their throat. The power should feel intimate and cruel, a violation of the victim's most basic right to breathe."
            elif 'lightning' in analysis.name.lower():
                roleplay_guidance = f"Describe the jagged bolts of {analysis.sensory_elements[0]} arcing from your fingertips, the {analysis.sensory_elements[1]} that fills the air, and the {analysis.sensory_elements[2]} as electricity dances across the target's body. Focus on the target's convulsions and the acrid smell of burning flesh. The power should feel wild and uncontrollable, like holding a storm in your hands."
            elif 'mind' in analysis.name.lower():
                roleplay_guidance = f"Describe the subtle way your eyes seem to glow with inner light, the {analysis.sensory_elements[0]} as thoughts flow between you and your target, and the {analysis.sensory_elements[1]} as the suggestion takes root. Focus on the target's momentary confusion, then their acceptance of the idea as their own. The power should feel intimate and subtle, like sharing a secret with someone's subconscious."
            elif 'heal' in analysis.name.lower():
                roleplay_guidance = f"Describe the {analysis.sensory_elements[0]} emanating from your hands, the {analysis.sensory_elements[1]} as damaged tissue knits itself whole, and the {analysis.sensory_elements[2]} as color returns to the target's face. Focus on the target's relief and gratitude, the warmth of healing energy. The power should feel nurturing and compassionate, like extending a piece of your own life force to save another."
            else:
                roleplay_guidance = f"Describe the {analysis.sensory_elements[0]} as the Force responds to your will, the {analysis.sensory_elements[1]} that fills the air, and the {analysis.sensory_elements[2]} as reality bends to your command. The power should feel like an extension of your own body and spirit."

        elif analysis.power_type == 'Tech':
            roleplay_guidance = f"Describe the {analysis.sensory_elements[0]} of advanced machinery, the {analysis.sensory_elements[1]} as systems respond to your commands, and the {analysis.sensory_elements[2]} as technology bends to your will. Focus on the precision and control, the way machines become extensions of your own capabilities. The power should feel like being one with the technology, a perfect fusion of human and machine."

        else:  # Maneuver
            roleplay_guidance = f"Describe the {analysis.sensory_elements[0]} of fluid motion, the {analysis.sensory_elements[1]} as your training takes over, and the {analysis.sensory_elements[2]} as you execute the perfect maneuver. Focus on the feeling of total control and awareness, the way time seems to slow down in the moment of action. The power should feel like muscle memory elevated to an art form."

        # Tactical notes - specific to mechanics
        if analysis.mechanics_summary.startswith('damage_'):
            tactical_notes = f"{analysis.name} is excellent for dealing {analysis.mechanics_summary.split('_')[1]} damage to high-priority targets. Use it to eliminate dangerous enemies quickly or to create openings in enemy formations. The {analysis.unique_identity} makes it particularly effective against {self._get_weakness_for_mechanics(analysis.mechanics_summary)}."
        elif analysis.mechanics_summary.startswith('status_'):
            tactical_notes = f"{analysis.name} is excellent for applying the {analysis.mechanics_summary.split('_')[1]} condition to control the battlefield. Use it to disable key enemies or create tactical advantages. The {analysis.unique_identity} makes it particularly effective when you need to neutralize threats without killing them."
        elif analysis.mechanics_summary == 'movement_enhancement':
            tactical_notes = f"{analysis.name} is excellent for repositioning on the battlefield and accessing difficult locations. Use it to reach high ground, escape dangerous situations, or close distance with ranged enemies. The {analysis.unique_identity} gives you unmatched mobility in combat."
        elif analysis.mechanics_summary == 'crowd_control':
            tactical_notes = f"{analysis.name} is excellent for controlling multiple enemies and protecting vulnerable allies. Use it to break up enemy formations or create safe spaces for your team. The {analysis.unique_identity} makes it particularly effective against groups of enemies."
        else:
            tactical_notes = f"{analysis.name} is excellent for creating tactical opportunities and controlling the flow of combat. Use it to outmaneuver opponents and create openings for your allies. The {analysis.unique_identity} gives you a versatile tool for any situation."

        # Narrative hooks - power-specific
        hooks = [
            f"A {analysis.power_type.lower()} user employs {analysis.name} in a moment of desperation, revealing their true character",
            f"The power of {analysis.name} creates an unexpected {narrative_focus} that changes everything",
            f"{analysis.name} forces a moral choice between {emotional_tone} and practical necessity",
            f"The {analysis.sensory_elements[0]} of {analysis.name} becomes a pivotal moment in the story"
        ]

        return {
            "roleplay_guidance": roleplay_guidance,
            "tactical_notes": tactical_notes,
            "narrative_hooks": hooks
        }

    def _get_weakness_for_mechanics(self, mechanics: str) -> str:
        """Get what type of target this mechanic is most effective against."""
        if mechanics == 'damage_force':
            return "Force-sensitive targets and those weak to mystical attacks"
        elif mechanics == 'damage_lightning':
            return "droids, electronics, and heavily armored targets"
        elif mechanics == 'damage_ion':
            return "droids, vehicles, and electronic systems"
        elif mechanics == 'status_charmed':
            return "targets with low mental resistance"
        elif mechanics == 'status_stunned':
            return "spellcasters and targets that rely on reactions"
        else:
            return "targets vulnerable to that specific effect"

    def craft_gold_standard_image_prompt(self, analysis: PowerAnalysis) -> Dict:
        """Craft Gold Standard image generation prompts."""

        # Create power-specific base prompt
        sensory_desc = ', '.join(analysis.sensory_elements[:3])

        if analysis.power_type == 'Force':
            if analysis.alignment == 'Light':
                base_prompt = f"A serene and powerful digital painting of {analysis.name} in action. A {analysis.power_type.lower()} user channels {analysis.alignment.lower()} side energy, {analysis.unique_identity}. {sensory_desc} fills the scene as the power takes effect. The mood is {analysis.emotional_tone}, representing the {analysis.narrative_focus}. Cinematic lighting emphasizes the mystical nature of the Force, with dramatic shadows and ethereal glows creating a moment of profound {analysis.power_type.lower()} mastery."
            elif analysis.alignment == 'Dark':
                base_prompt = f"A dark and intense digital painting of {analysis.name} being unleashed. A {analysis.power_type.lower()} user channels {analysis.alignment.lower()} side energy, {analysis.unique_identity}. {sensory_desc} dominates the scene as the power consumes everything in its path. The mood is {analysis.emotional_tone}, representing the {analysis.narrative_focus}. Dramatic lighting with harsh contrasts and deep shadows creates a sense of corrupting power, where the {analysis.power_type.lower()} user's face is illuminated by the unholy {sensory_desc}."
            else:
                base_prompt = f"A focused and precise digital painting of {analysis.name} in execution. A {analysis.power_type.lower()} user channels {analysis.power_type.lower()} energy, {analysis.unique_identity}. {sensory_desc} creates a moment of intense concentration as the power flows through them. The mood is {analysis.emotional_tone}, representing the {analysis.narrative_focus}. Balanced lighting shows both the physical and mystical aspects of the {analysis.power_type.lower()}, with subtle energy effects and determined expressions."

        elif analysis.power_type == 'Tech':
            base_prompt = f"A technical and precise digital painting of {analysis.name} in operation. A {analysis.power_type.lower()} specialist uses advanced equipment, {analysis.unique_identity}. {sensory_desc} fills the air as technology responds to their expertise. The mood is {analysis.emotional_tone}, representing the {analysis.narrative_focus}. Clean, futuristic lighting illuminates holographic displays and mechanical details, showing the perfect fusion of human skill and machine efficiency."

        else:  # Maneuver
            base_prompt = f"A dynamic and fluid digital painting of {analysis.name} being executed. A skilled operative performs the maneuver, {analysis.unique_identity}. {sensory_desc} captures the intensity of the moment as training becomes art. The mood is {analysis.emotional_tone}, representing the {analysis.narrative_focus}. Dynamic lighting freezes the action at the perfect moment, showing the grace and precision of tactical mastery."

        # Enhanced negative keywords
        base_negative_keywords = [
            "static", "boring", "cartoonish", "blurry", "unclear", "small", "weak",
            "amateur", "simple", "generic", "placeholder", "template", "basic",
            "low quality", "distorted", "amateurish", "clichéd", "overused",
            "stock photo", "unoriginal", "predictable", "conventional"
        ]

        return {
            "base_prompt": base_prompt,
            "base_negative_keywords": base_negative_keywords
        }

    def apply_artisanal_pass_to_power(self, power_id: str, power_data: Dict) -> bool:
        """Apply the Artisanal Pass transformation to elevate a power to Gold Standard."""
        try:
            # Analyze the power's unique identity
            analysis = self.analyze_power_identity(power_data)

            # Check if it needs transformation (has generic content)
            needs_transformation = self._check_if_needs_transformation(power_data, analysis)

            if not needs_transformation:
                return False  # Already good

            # Apply Gold Standard transformations
            modified = False

            # Transform narrative
            current_narrative = power_data.get('narrative', '')
            if self._is_generic_narrative(current_narrative, analysis):
                power_data['narrative'] = self.craft_gold_standard_narrative(analysis)
                modified = True

            # Transform LLM guidance
            llm_guidance = power_data.get('llm_guidance', {})
            if self._is_generic_llm_guidance(llm_guidance, analysis):
                power_data['llm_guidance'] = self.craft_gold_standard_llm_guidance(analysis)
                modified = True

            # Transform image generation
            image_generation = power_data.get('image_generation', {})
            if self._is_generic_image_prompt(image_generation, analysis):
                power_data['image_generation'] = self.craft_gold_standard_image_prompt(analysis)
                modified = True

            if modified:
                self.save_power(power_id, power_data)
                return True

        except Exception as e:
            self.errors.append(f"Error processing {power_id}: {e}")
            return False

    def _check_if_needs_transformation(self, power_data: Dict, analysis: PowerAnalysis) -> bool:
        """Check if a power needs the Artisanal Pass transformation."""
        # Check for generic narrative content
        narrative = power_data.get('narrative', '')
        if "tactical maneuver" in narrative and analysis.name != "Tactical Maneuver":
            return True
        if "execute a precise tactical maneuver" in narrative:
            return True
        if "outmaneuver your opponents and control the battlefield" in narrative:
            return True

        # Check for generic LLM guidance
        llm_guidance = power_data.get('llm_guidance', {})
        roleplay_guidance = llm_guidance.get('roleplay_guidance', '')
        if "tactical maneuver" in roleplay_guidance and analysis.name != "Tactical Maneuver":
            return True
        if "precise execution of the tactical maneuver" in roleplay_guidance:
            return True

        # Check for generic image prompts
        image_generation = power_data.get('image_generation', {})
        base_prompt = image_generation.get('base_prompt', '')
        if "tactical maneuver" in base_prompt and analysis.name != "Tactical Maneuver":
            return True
        if "skilled operative performs a precise tactical maneuver" in base_prompt:
            return True

        return False

    def _is_generic_narrative(self, narrative: str, analysis: PowerAnalysis) -> bool:
        """Check if narrative contains generic content that needs replacement."""
        generic_phrases = [
            "tactical maneuver",
            "execute a precise tactical maneuver",
            "outmaneuver your opponents and control the battlefield",
            "raw dark side power that leaves only ruin",
            "unbridled destruction that echoes through the Force",
            "deploy advanced weaponry and tactical systems with deadly precision",
            "manipulate electronic systems and energy with precision and skill",
            "channel the Force to manipulate objects and energy with your mind"
        ]

        for phrase in generic_phrases:
            if phrase in narrative:
                return True

        return False

    def _is_generic_llm_guidance(self, llm_guidance: Dict, analysis: PowerAnalysis) -> bool:
        """Check if LLM guidance contains generic content."""
        roleplay_guidance = llm_guidance.get('roleplay_guidance', '')

        generic_phrases = [
            "tactical maneuver",
            "precise execution of the tactical maneuver",
            "superior positioning and timing",
            "describe the precise execution of the tactical maneuver"
        ]

        for phrase in generic_phrases:
            if phrase in roleplay_guidance:
                return True

        return False

    def _is_generic_image_prompt(self, image_generation: Dict, analysis: PowerAnalysis) -> bool:
        """Check if image prompt contains generic content."""
        base_prompt = image_generation.get('base_prompt', '')

        generic_phrases = [
            "tactical maneuver",
            "skilled operative performs a precise tactical maneuver",
            "moving with calculated grace and battlefield awareness",
            "captures the intensity of combat, with dramatic lighting"
        ]

        for phrase in generic_phrases:
            if phrase in base_prompt:
                return True

        return False

    def save_power(self, power_id: str, power_data: Dict):
        """Save a power back to its file."""
        for power_file in self.powers_directory.glob("*.yml"):
            if power_file.name.startswith("power_"):
                with open(power_file, 'r', encoding='utf-8') as f:
                    file_data = yaml.safe_load(f)
                    if file_data and file_data.get('id') == power_id:
                        with open(power_file, 'w', encoding='utf-8') as f:
                            yaml.dump(power_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
                        break

    def process_all_powers(self) -> Dict[str, bool]:
        """Process all powers and apply Artisanal Pass enhancements."""
        results = {}

        for power_id in self.powers.keys():
            try:
                modified = self.apply_artisanal_pass_to_power(power_id, self.powers[power_id])
                results[power_id] = modified

                if modified:
                    self.processed_powers += 1

            except Exception as e:
                self.errors.append(f"Error processing {power_id}: {e}")
                results[power_id] = False

        return results

    def generate_report(self, results: Dict[str, bool]) -> str:
        """Generate a comprehensive report of the Artisanal Pass process."""
        report = []
        report.append("=" * 80)
        report.append("ARTISANAL PASS - GOLD STANDARD REPORT")
        report.append("=" * 80)
        report.append("")

        # Summary statistics
        total_powers = len(results)
        powers_processed = sum(1 for processed in results.values() if processed)
        powers_skipped = total_powers - powers_processed

        report.append(f"Total Powers Analyzed: {total_powers}")
        report.append(f"Powers Elevated to Gold Standard: {powers_processed}")
        report.append(f"Powers Already at Gold Standard: {powers_skipped}")
        report.append("")

        if self.errors:
            report.append("ERRORS ENCOUNTERED:")
            report.append("-" * 40)
            for error in self.errors:
                report.append(f"❌ {error}")
            report.append("")

        # Powers processed
        if powers_processed > 0:
            report.append("POWERS ELEVATED TO GOLD STANDARD:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        # Powers skipped
        if powers_skipped > 0:
            report.append("POWERS ALREADY AT GOLD STANDARD:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if not was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        report.append("=" * 80)
        report.append("ARTISANAL PASS COMPLETE - ALL POWERS NOW AT GOLD STANDARD")
        report.append("=" * 80)

        return "\n".join(report)

    def run_artisanal_pass(self) -> bool:
        """Run the complete Artisanal Pass transformation."""
        print("Loading powers...")
        if not self.load_powers():
            return False

        print("Analyzing powers for Gold Standard transformation needs...")
        powers_to_process = []
        for power_id, power_data in self.powers.items():
            if self._check_if_needs_transformation(power_data, self.analyze_power_identity(power_data)):
                powers_to_process.append(power_id)

        print(f"Found {len(powers_to_process)} powers that need Gold Standard elevation")
        if len(powers_to_process) <= 5:
            print(f"Powers to process: {', '.join(powers_to_process)}")
        else:
            print(f"Powers to process: {', '.join(powers_to_process[:5])} and {len(powers_to_process) - 5} more...")

        print("Applying Artisanal Pass - elevating to Gold Standard...")
        results = self.process_all_powers()

        print("Generating report...")
        report = self.generate_report(results)

        # Save report to file
        report_file = Path("artisanal_pass_gold_standard_report.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)

        print(f"Report saved to {report_file}")
        print("\n" + report)

        return len(self.errors) == 0

def main():
    """Main function to run Artisanal Pass."""
    processor = ArtisanalPassProcessor()
    success = processor.run_artisanal_pass()

    if success:
        print("\n✅ Artisanal Pass completed successfully!")
        print("All powers have been elevated to Gold Standard with unique, power-specific content.")
        sys.exit(0)
    else:
        print("\n❌ Artisanal Pass completed with errors.")
        sys.exit(1)

if __name__ == "__main__":
    main()
