#!/usr/bin/env node

/**
 * SW5e Data Hub - YAML Validator
 * Comprehensive validation system for all YAML files
 * 
 * Features:
 * - Schema validation against JSON schemas
 * - Cross-reference validation
 * - Balance validation
 * - Performance optimization
 * - Automated testing
 * - Error reporting and suggestions
 */

import fs from 'fs-extra';
import path from 'path';
import { glob } from 'glob';
import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import YAML from 'yaml';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configuration
const CONFIG = {
  // Paths
  DATA_DIR: path.join(__dirname, '../data'),
  SCHEMA_DIR: path.join(__dirname, '../schema'),
  VALIDATION_RULES: path.join(__dirname, '../schema/yaml_validation_rules.yml'),
  PERFORMANCE_GUIDELINES: path.join(__dirname, '../schema/performance_guidelines.yml'),
  AUTOMATED_TESTING: path.join(__dirname, '../schema/automated_testing.yml'),
  
  // Output
  OUTPUT_DIR: path.join(__dirname, '../validation-results'),
  LOG_DIR: path.join(__dirname, '../validation-logs'),
  
  // Defaults
  DEFAULT_MODE: 'standard',
  DEFAULT_OUTPUT_FORMAT: 'json',
  MAX_PARALLEL_JOBS: 4,
  TIMEOUT_SECONDS: 300
};

// Validation results structure
class ValidationResult {
  constructor() {
    this.timestamp = new Date().toISOString();
    this.summary = {
      total_files: 0,
      passed: 0,
      warnings: 0,
      errors: 0,
      critical: 0
    };
    this.results = [];
    this.performance = {
      start_time: Date.now(),
      end_time: null,
      duration_ms: 0,
      memory_usage: {
        start: process.memoryUsage(),
        end: null,
        peak: null
      }
    };
    this.recommendations = [];
  }

  addResult(filePath, result) {
    this.results.push({
      file: filePath,
      ...result
    });
    
    // Update summary
    this.summary.total_files++;
    switch (result.severity) {
      case 'pass':
        this.summary.passed++;
        break;
      case 'warning':
        this.summary.warnings++;
        break;
      case 'error':
        this.summary.errors++;
        break;
      case 'critical':
        this.summary.critical++;
        break;
    }
  }

  finalize() {
    this.performance.end_time = Date.now();
    this.performance.duration_ms = this.performance.end_time - this.performance.start_time;
    this.performance.memory_usage.end = process.memoryUsage();
    this.performance.memory_usage.peak = {
      rss: Math.max(this.performance.memory_usage.start.rss, this.performance.memory_usage.end.rss),
      heapUsed: Math.max(this.performance.memory_usage.start.heapUsed, this.performance.memory_usage.end.heapUsed),
      heapTotal: Math.max(this.performance.memory_usage.start.heapTotal, this.performance.memory_usage.end.heapTotal),
      external: Math.max(this.performance.memory_usage.start.external, this.performance.memory_usage.end.external)
    };
  }
}

// Main validator class
class YAMLValidator {
  constructor(options = {}) {
    this.options = {
      mode: options.mode || CONFIG.DEFAULT_MODE,
      outputFormat: options.outputFormat || CONFIG.DEFAULT_OUTPUT_FORMAT,
      parallel: options.parallel !== false,
      maxParallelJobs: options.maxParallelJobs || CONFIG.MAX_PARALLEL_JOBS,
      timeout: options.timeout || CONFIG.TIMEOUT_SECONDS,
      ...options
    };

    this.ajv = new Ajv({
      allErrors: true,
      verbose: true,
      strict: this.options.mode === 'strict'
    });
    addFormats(this.ajv);

    this.validationRules = null;
    this.performanceGuidelines = null;
    this.automatedTesting = null;
    this.schemas = new Map();
    this.referenceCache = new Map();
    this.result = new ValidationResult();
  }

  async initialize() {
    console.log('🔧 Initializing YAML Validator...');
    
    // Load configuration files
    await this.loadConfiguration();
    
    // Load schemas
    await this.loadSchemas();
    
    // Initialize reference cache
    await this.initializeReferenceCache();
    
    console.log('✅ YAML Validator initialized successfully');
  }

  async loadConfiguration() {
    try {
      // Load validation rules
      const validationRulesContent = await fs.readFile(CONFIG.VALIDATION_RULES, 'utf8');
      this.validationRules = YAML.parse(validationRulesContent);

      // Load performance guidelines
      const performanceGuidelinesContent = await fs.readFile(CONFIG.PERFORMANCE_GUIDELINES, 'utf8');
      this.performanceGuidelines = YAML.parse(performanceGuidelinesContent);

      // Load automated testing configuration
      const automatedTestingContent = await fs.readFile(CONFIG.AUTOMATED_TESTING, 'utf8');
      this.automatedTesting = YAML.parse(automatedTestingContent);

      console.log('📋 Configuration loaded successfully');
    } catch (error) {
      console.error('❌ Failed to load configuration:', error.message);
      throw error;
    }
  }

  async loadSchemas() {
    try {
      const schemaFiles = await glob('*.json', { cwd: CONFIG.SCHEMA_DIR });
      
      for (const schemaFile of schemaFiles) {
        const schemaPath = path.join(CONFIG.SCHEMA_DIR, schemaFile);
        const schemaContent = await fs.readFile(schemaPath, 'utf8');
        const schema = JSON.parse(schemaContent);
        
        // Add schema to AJV
        const schemaName = path.basename(schemaFile, '.json');
        this.ajv.addSchema(schema, schemaName);
        this.schemas.set(schemaName, schema);
        
        console.log(`📄 Loaded schema: ${schemaName}`);
      }
      
      console.log(`📚 Loaded ${this.schemas.size} schemas`);
    } catch (error) {
      console.error('❌ Failed to load schemas:', error.message);
      throw error;
    }
  }

  async initializeReferenceCache() {
    try {
      // Scan all YAML files to build reference cache
      const yamlFiles = await glob('**/*.yml', { cwd: CONFIG.DATA_DIR });
      
      for (const yamlFile of yamlFiles) {
        const filePath = path.join(CONFIG.DATA_DIR, yamlFile);
        const content = await fs.readFile(filePath, 'utf8');
        const data = YAML.parse(content);
        
        // Extract references based on file type
        const references = this.extractReferences(yamlFile, data);
        this.referenceCache.set(yamlFile, references);
      }
      
      console.log(`🔗 Built reference cache for ${this.referenceCache.size} files`);
    } catch (error) {
      console.error('❌ Failed to initialize reference cache:', error.message);
      throw error;
    }
  }

  extractReferences(filePath, data) {
    const references = {
      species: [],
      classes: [],
      powers: [],
      items: [],
      backgrounds: [],
      factions: [],
      starships: []
    };

    // Extract references based on file type and content
    if (filePath.includes('species/')) {
      references.species.push(data.id || data.name);
    } else if (filePath.includes('classes/')) {
      references.classes.push(data.name);
    } else if (filePath.includes('powers/')) {
      references.powers.push(data.id || data.name);
    } else if (filePath.includes('items/')) {
      references.items.push(data.id || data.name);
    } else if (filePath.includes('backgrounds/')) {
      references.backgrounds.push(data.name);
    } else if (filePath.includes('factions/')) {
      references.factions.push(data.id || data.name);
    } else if (filePath.includes('starships/')) {
      references.starships.push(data.id || data.name);
    }

    return references;
  }

  async validateFiles(filePatterns = ['**/*.yml']) {
    console.log('🔍 Starting file validation...');
    
    try {
      // Find all YAML files
      const yamlFiles = [];
      for (const pattern of filePatterns) {
        const files = await glob(pattern, { cwd: CONFIG.DATA_DIR });
        yamlFiles.push(...files);
      }
      
      console.log(`📁 Found ${yamlFiles.length} files to validate`);
      
      // Validate files
      if (this.options.parallel && yamlFiles.length > 1) {
        await this.validateFilesParallel(yamlFiles);
      } else {
        await this.validateFilesSequential(yamlFiles);
      }
      
      // Finalize results
      this.result.finalize();
      
      console.log('✅ File validation completed');
    } catch (error) {
      console.error('❌ File validation failed:', error.message);
      throw error;
    }
  }

  async validateFilesParallel(yamlFiles) {
    const chunks = this.chunkArray(yamlFiles, this.options.maxParallelJobs);
    
    for (const chunk of chunks) {
      const promises = chunk.map(file => this.validateFile(file));
      await Promise.all(promises);
    }
  }

  async validateFilesSequential(yamlFiles) {
    for (const file of yamlFiles) {
      await this.validateFile(file);
    }
  }

  async validateFile(filePath) {
    try {
      const fullPath = path.join(CONFIG.DATA_DIR, filePath);
      const content = await fs.readFile(fullPath, 'utf8');
      const data = YAML.parse(content);
      
      const result = {
        severity: 'pass',
        errors: [],
        warnings: [],
        suggestions: []
      };

      // Schema validation
      await this.validateSchema(filePath, data, result);
      
      // Cross-reference validation
      await this.validateCrossReferences(filePath, data, result);
      
      // Balance validation
      await this.validateBalance(filePath, data, result);
      
      // Performance validation
      await this.validatePerformance(filePath, content, result);
      
      // Determine overall severity
      if (result.errors.length > 0) {
        result.severity = 'error';
      } else if (result.warnings.length > 0) {
        result.severity = 'warning';
      }
      
      this.result.addResult(filePath, result);
      
    } catch (error) {
      this.result.addResult(filePath, {
        severity: 'critical',
        errors: [`Failed to validate file: ${error.message}`],
        warnings: [],
        suggestions: []
      });
    }
  }

  async validateSchema(filePath, data, result) {
    try {
      // Determine schema based on file path
      const schemaName = this.determineSchema(filePath);
      if (!schemaName || !this.schemas.has(schemaName)) {
        result.warnings.push(`No schema found for file type: ${schemaName}`);
        return;
      }

      const validate = this.ajv.getSchema(schemaName);
      const valid = validate(data);
      
      if (!valid) {
        result.errors.push(...validate.errors.map(error => 
          `Schema validation failed: ${error.instancePath} ${error.message}`
        ));
      }
      
    } catch (error) {
      result.errors.push(`Schema validation error: ${error.message}`);
    }
  }

  async validateCrossReferences(filePath, data, result) {
    try {
      const references = this.extractReferencesFromData(data);
      
      for (const [type, refs] of Object.entries(references)) {
        for (const ref of refs) {
          if (!this.referenceExists(type, ref)) {
            result.errors.push(`Cross-reference error: ${type} '${ref}' not found`);
          }
        }
      }
      
    } catch (error) {
      result.errors.push(`Cross-reference validation error: ${error.message}`);
    }
  }

  async validateBalance(filePath, data, result) {
    try {
      // Validate power levels
      if (data.level && data.damage) {
        const maxDamage = this.getMaxDamageForLevel(data.level);
        if (data.damage > maxDamage) {
          result.warnings.push(`Balance warning: Damage ${data.damage} exceeds maximum ${maxDamage} for level ${data.level}`);
        }
      }
      
      // Validate costs
      if (data.cost) {
        const minCost = this.validationRules.core_rules.balance_validation.power_level_rules.cost_validation.min_cost;
        const maxCost = this.validationRules.core_rules.balance_validation.power_level_rules.cost_validation.max_cost;
        
        if (data.cost < minCost || data.cost > maxCost) {
          result.warnings.push(`Balance warning: Cost ${data.cost} outside valid range [${minCost}, ${maxCost}]`);
        }
      }
      
    } catch (error) {
      result.errors.push(`Balance validation error: ${error.message}`);
    }
  }

  async validatePerformance(filePath, content, result) {
    try {
      const fileSize = Buffer.byteLength(content, 'utf8');
      const maxSize = this.performanceGuidelines.file_size_optimization.general_guidelines.max_file_size_kb * 1024;
      
      if (fileSize > maxSize) {
        result.warnings.push(`Performance warning: File size ${(fileSize / 1024).toFixed(2)}KB exceeds maximum ${maxSize / 1024}KB`);
      }
      
      // Check line length
      const lines = content.split('\n');
      const longLines = lines.filter(line => line.length > this.performanceGuidelines.file_size_optimization.general_guidelines.max_line_length);
      
      if (longLines.length > 0) {
        result.suggestions.push(`Consider breaking ${longLines.length} long lines for better readability`);
      }
      
    } catch (error) {
      result.errors.push(`Performance validation error: ${error.message}`);
    }
  }

  determineSchema(filePath) {
    if (filePath.includes('species/')) return 'Species';
    if (filePath.includes('classes/')) return 'Class';
    if (filePath.includes('powers/')) return 'Power';
    if (filePath.includes('items/')) return 'Item';
    if (filePath.includes('backgrounds/')) return 'Background';
    if (filePath.includes('factions/')) return 'Faction';
    if (filePath.includes('starships/')) return 'Starship';
    if (filePath.includes('modes/')) return 'Mode';
    if (filePath.includes('synergies/')) return 'Synergy';
    return null;
  }

  extractReferencesFromData(data) {
    const references = {
      species: [],
      classes: [],
      powers: [],
      items: [],
      backgrounds: [],
      factions: [],
      starships: []
    };

    // Extract references from data structure
    if (data.species_id) references.species.push(data.species_id);
    if (data.class_name) references.classes.push(data.class_name);
    if (data.power_id) references.powers.push(data.power_id);
    if (data.item_id) references.items.push(data.item_id);
    if (data.background_name) references.backgrounds.push(data.background_name);
    if (data.faction_id) references.factions.push(data.faction_id);
    if (data.starship_id) references.starships.push(data.starship_id);

    return references;
  }

  referenceExists(type, reference) {
    for (const [filePath, refs] of this.referenceCache) {
      if (refs[type] && refs[type].includes(reference)) {
        return true;
      }
    }
    return false;
  }

  getMaxDamageForLevel(level) {
    const damageTable = this.validationRules.core_rules.balance_validation.power_level_rules.powers;
    
    if (level === 0) return damageTable.cantrip_max_damage;
    if (level >= 1 && level <= 9) return damageTable[`level_${level}_max_damage`];
    return damageTable.level_9_max_damage; // Default for higher levels
  }

  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  async generateReport() {
    console.log('📊 Generating validation report...');
    
    try {
      // Ensure output directory exists
      await fs.ensureDir(CONFIG.OUTPUT_DIR);
      
      // Generate report based on output format
      const reportPath = path.join(CONFIG.OUTPUT_DIR, `validation-report-${Date.now()}`);
      
      switch (this.options.outputFormat) {
        case 'json':
          await fs.writeFile(`${reportPath}.json`, JSON.stringify(this.result, null, 2));
          break;
        case 'yaml':
          await fs.writeFile(`${reportPath}.yml`, YAML.stringify(this.result));
          break;
        case 'text':
          await this.generateTextReport(`${reportPath}.txt`);
          break;
        case 'html':
          await this.generateHtmlReport(`${reportPath}.html`);
          break;
        default:
          await fs.writeFile(`${reportPath}.json`, JSON.stringify(this.result, null, 2));
      }
      
      console.log(`📄 Report generated: ${reportPath}.${this.options.outputFormat}`);
      
      // Print summary
      this.printSummary();
      
    } catch (error) {
      console.error('❌ Failed to generate report:', error.message);
      throw error;
    }
  }

  async generateTextReport(filePath) {
    const lines = [
      'SW5e Data Hub - YAML Validation Report',
      '=====================================',
      '',
      `Generated: ${this.result.timestamp}`,
      `Duration: ${this.result.performance.duration_ms}ms`,
      '',
      'Summary:',
      `  Total Files: ${this.result.summary.total_files}`,
      `  Passed: ${this.result.summary.passed}`,
      `  Warnings: ${this.result.summary.warnings}`,
      `  Errors: ${this.result.summary.errors}`,
      `  Critical: ${this.result.summary.critical}`,
      '',
      'Results:',
      ''
    ];

    for (const result of this.result.results) {
      lines.push(`${result.severity.toUpperCase()}: ${result.file}`);
      if (result.errors.length > 0) {
        lines.push('  Errors:');
        result.errors.forEach(error => lines.push(`    - ${error}`));
      }
      if (result.warnings.length > 0) {
        lines.push('  Warnings:');
        result.warnings.forEach(warning => lines.push(`    - ${warning}`));
      }
      if (result.suggestions.length > 0) {
        lines.push('  Suggestions:');
        result.suggestions.forEach(suggestion => lines.push(`    - ${suggestion}`));
      }
      lines.push('');
    }

    await fs.writeFile(filePath, lines.join('\n'));
  }

  async generateHtmlReport(filePath) {
    const html = `
<!DOCTYPE html>
<html>
<head>
    <title>SW5e Data Hub - YAML Validation Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .summary { background: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .result { margin: 10px 0; padding: 10px; border-left: 4px solid #ccc; }
        .pass { border-left-color: #4caf50; }
        .warning { border-left-color: #ff9800; }
        .error { border-left-color: #f44336; }
        .critical { border-left-color: #9c27b0; }
        .metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; margin: 20px 0; }
        .metric { background: white; padding: 15px; border-radius: 5px; text-align: center; }
        .metric-value { font-size: 2em; font-weight: bold; }
    </style>
</head>
<body>
    <h1>SW5e Data Hub - YAML Validation Report</h1>
    <div class="summary">
        <h2>Summary</h2>
        <div class="metrics">
            <div class="metric">
                <div class="metric-value">${this.result.summary.total_files}</div>
                <div>Total Files</div>
            </div>
            <div class="metric">
                <div class="metric-value" style="color: #4caf50;">${this.result.summary.passed}</div>
                <div>Passed</div>
            </div>
            <div class="metric">
                <div class="metric-value" style="color: #ff9800;">${this.result.summary.warnings}</div>
                <div>Warnings</div>
            </div>
            <div class="metric">
                <div class="metric-value" style="color: #f44336;">${this.result.summary.errors}</div>
                <div>Errors</div>
            </div>
            <div class="metric">
                <div class="metric-value" style="color: #9c27b0;">${this.result.summary.critical}</div>
                <div>Critical</div>
            </div>
        </div>
        <p><strong>Generated:</strong> ${this.result.timestamp}</p>
        <p><strong>Duration:</strong> ${this.result.performance.duration_ms}ms</p>
    </div>
    
    <h2>Results</h2>
    ${this.result.results.map(result => `
        <div class="result ${result.severity}">
            <h3>${result.file}</h3>
            <p><strong>Status:</strong> ${result.severity.toUpperCase()}</p>
            ${result.errors.length > 0 ? `<p><strong>Errors:</strong></p><ul>${result.errors.map(error => `<li>${error}</li>`).join('')}</ul>` : ''}
            ${result.warnings.length > 0 ? `<p><strong>Warnings:</strong></p><ul>${result.warnings.map(warning => `<li>${warning}</li>`).join('')}</ul>` : ''}
            ${result.suggestions.length > 0 ? `<p><strong>Suggestions:</strong></p><ul>${result.suggestions.map(suggestion => `<li>${suggestion}</li>`).join('')}</ul>` : ''}
        </div>
    `).join('')}
</body>
</html>`;

    await fs.writeFile(filePath, html);
  }

  printSummary() {
    console.log('\n📊 Validation Summary:');
    console.log('=====================');
    console.log(`Total Files: ${this.result.summary.total_files}`);
    console.log(`✅ Passed: ${this.result.summary.passed}`);
    console.log(`⚠️  Warnings: ${this.result.summary.warnings}`);
    console.log(`❌ Errors: ${this.result.summary.errors}`);
    console.log(`🚨 Critical: ${this.result.summary.critical}`);
    console.log(`⏱️  Duration: ${this.result.performance.duration_ms}ms`);
    console.log(`💾 Memory Peak: ${(this.result.performance.memory_usage.peak.heapUsed / 1024 / 1024).toFixed(2)}MB`);
    
    if (this.result.summary.errors > 0 || this.result.summary.critical > 0) {
      console.log('\n🔧 Issues found that need attention:');
      this.result.results
        .filter(r => r.severity === 'error' || r.severity === 'critical')
        .forEach(r => {
          console.log(`  ${r.severity.toUpperCase()}: ${r.file}`);
          r.errors.forEach(error => console.log(`    - ${error}`));
        });
    }
  }
}

// CLI interface
async function main() {
  const args = process.argv.slice(2);
  
  // Parse command line arguments
  const options = {
    mode: 'standard',
    outputFormat: 'json',
    parallel: true,
    maxParallelJobs: 4,
    timeout: 300
  };

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--mode':
        options.mode = args[++i];
        break;
      case '--output':
        options.outputFormat = args[++i];
        break;
      case '--parallel':
        options.parallel = true;
        break;
      case '--no-parallel':
        options.parallel = false;
        break;
      case '--max-jobs':
        options.maxParallelJobs = parseInt(args[++i]);
        break;
      case '--timeout':
        options.timeout = parseInt(args[++i]);
        break;
      case '--help':
        printHelp();
        return;
    }
  }

  try {
    const validator = new YAMLValidator(options);
    await validator.initialize();
    await validator.validateFiles();
    await validator.generateReport();
    
    // Exit with appropriate code
    const hasErrors = validator.result.summary.errors > 0 || validator.result.summary.critical > 0;
    process.exit(hasErrors ? 1 : 0);
    
  } catch (error) {
    console.error('❌ Validation failed:', error.message);
    process.exit(1);
  }
}

function printHelp() {
  console.log(`
SW5e Data Hub - YAML Validator

Usage: node yaml-validator.mjs [options]

Options:
  --mode <mode>           Validation mode (strict|standard|performance|quick) [default: standard]
  --output <format>       Output format (json|yaml|text|html) [default: json]
  --parallel              Enable parallel execution [default: true]
  --no-parallel           Disable parallel execution
  --max-jobs <number>     Maximum parallel jobs [default: 4]
  --timeout <seconds>     Timeout in seconds [default: 300]
  --help                  Show this help message

Examples:
  node yaml-validator.mjs --mode strict --output html
  node yaml-validator.mjs --mode quick --no-parallel
  node yaml-validator.mjs --output text --max-jobs 8
`);
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(error => {
    console.error('❌ Unhandled error:', error);
    process.exit(1);
  });
}

export default YAMLValidator;
