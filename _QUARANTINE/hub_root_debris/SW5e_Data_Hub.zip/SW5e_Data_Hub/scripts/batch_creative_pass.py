#!/usr/bin/env python3
"""
Batch Creative Pass Script

This script systematically applies creative pass improvements to all powers
that need enhancement. It uses the analysis from creative_pass_automation.py
to apply templates and generate rich, unique content for each power.
"""

import yaml
import os
import sys
import random
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from enum import Enum

class PowerType(Enum):
    FORCE_TELEKINETIC = "force_telekinetic"
    FORCE_MENTAL = "force_mental"
    FORCE_HEALING = "force_healing"
    FORCE_DESTRUCTIVE = "force_destructive"
    TECH_ELECTRONIC = "tech_electronic"
    TECH_COMBAT = "tech_combat"
    MANEUVER_TACTICAL = "maneuver_tactical"

@dataclass
class PowerContext:
    name: str
    power_type: str
    alignment: str
    level: int
    archetype: str
    issues: List[str]

class BatchCreativePassProcessor:
    def __init__(self, powers_directory: str = "data/powers"):
        self.powers_directory = Path(powers_directory)
        self.powers: Dict[str, Dict] = {}
        self.processed_powers = 0
        self.errors = []

        # Enhanced templates for unique content generation
        self.narrative_enhancements = {
            "force_telekinetic": [
                "telekinetic mastery that bends reality itself",
                "raw telekinetic force that reshapes the battlefield",
                "invisible hands of the Force that manipulate matter",
                "telekinetic precision that turns the tide of battle",
                "Force-amplified strength that moves mountains"
            ],
            "force_mental": [
                "subtle mental influence that clouds judgment",
                "psychic manipulation that reveals hidden truths",
                "mind-bending power that alters perception",
                "mental domination that commands obedience",
                "psychic insight that pierces deception"
            ],
            "force_healing": [
                "restorative light that mends flesh and spirit",
                "healing energy that banishes pain and suffering",
                "life-giving Force that defies mortal wounds",
                "compassionate power that restores the fallen",
                "healing grace that turns despair to hope"
            ],
            "force_destructive": [
                "destructive fury that consumes everything in its path",
                "raw dark side power that leaves only ruin",
                "malevolent energy that feeds on hatred and rage",
                "corrupting darkness that twists and destroys",
                "unbridled destruction that echoes through the Force"
            ],
            "tech_electronic": [
                "advanced technology that overrides enemy systems",
                "electronic warfare that turns machines against their masters",
                "technological supremacy that controls the digital realm",
                "cybernetic expertise that exploits every vulnerability",
                "machine mastery that bends technology to your will"
            ],
            "tech_combat": [
                "advanced weaponry that overwhelms enemy defenses",
                "tactical systems that predict and counter every move",
                "combat technology that turns the tide of battle",
                "weaponized innovation that creates impossible victories",
                "battlefield dominance through technological superiority"
            ],
            "maneuver_tactical": [
                "tactical brilliance that outmaneuvers any opponent",
                "combat expertise that creates opportunities from nothing",
                "strategic mastery that controls the flow of battle",
                "martial precision that exploits every weakness",
                "battlefield awareness that anticipates every threat"
            ]
        }

        self.flavor_text_variations = {
            "force_light": [
                "The Force is my ally, and a powerful ally it is.",
                "A Jedi's strength flows from the Force.",
                "The light side of the Force guides my actions.",
                "Compassion is central to a Jedi's life.",
                "There is no emotion, there is peace."
            ],
            "force_dark": [
                "The dark side is stronger.",
                "Give yourself to the dark side.",
                "Your hate has made you powerful.",
                "The dark side of the Force is a pathway to many abilities.",
                "Once you start down the dark path, forever will it dominate your destiny."
            ],
            "force_universal": [
                "The Force will be with you, always.",
                "Size matters not. Look at me.",
                "Do or do not, there is no try.",
                "Your eyes can deceive you. Don't trust them.",
                "The Force is strong with this one."
            ],
            "tech": [
                "Technology is no match for a good blaster at your side.",
                "Great shot, kid, that was one in a million!",
                "I've got a bad feeling about this.",
                "She may not look like much, but she's got it where it counts.",
                "Never tell me the odds!"
            ],
            "maneuver": [
                "I've got a bad feeling about this.",
                "Never tell me the odds!",
                "Do or do not, there is no try.",
                "I find your lack of faith disturbing.",
                "These aren't the droids you're looking for."
            ]
        }

    def load_powers(self) -> bool:
        """Load all power files from the directory."""
        try:
            for power_file in self.powers_directory.glob("*.yml"):
                if power_file.name.startswith("power_"):
                    with open(power_file, 'r', encoding='utf-8') as f:
                        power_data = yaml.safe_load(f)
                        if power_data and 'id' in power_data:
                            self.powers[power_data['id']] = power_data
            print(f"Loaded {len(self.powers)} powers for processing")
            return True
        except Exception as e:
            print(f"Error loading powers: {e}")
            return False

    def get_power_context(self, power_id: str, power_data: Dict) -> PowerContext:
        """Analyze a power and determine what needs to be fixed."""
        issues = []

        # Check narrative
        narrative = power_data.get('narrative', '')
        if not narrative:
            issues.append("missing_narrative")
        elif "mastery of the Force and years of dedicated training" in narrative:
            issues.append("generic_narrative")

        # Check flavor text
        flavor_text = power_data.get('flavor_text', '')
        if not flavor_text:
            issues.append("missing_flavor_text")
        elif "Unknown Master" in flavor_text or "Unknown Engineer" in flavor_text:
            issues.append("placeholder_flavor_text")

        # Check manifestation
        manifestation = power_data.get('manifestation', [])
        if not manifestation:
            issues.append("missing_manifestation")
        else:
            for manifest in manifestation:
                if isinstance(manifest, str):
                    issues.append("string_manifestation")

        # Check LLM guidance
        llm_guidance = power_data.get('llm_guidance', {})
        if not llm_guidance:
            issues.append("missing_llm_guidance")
        else:
            roleplay_guidance = llm_guidance.get('roleplay_guidance', '')
            if not roleplay_guidance:
                issues.append("missing_roleplay_guidance")
            elif "describe the character's expertise and the visible effects" in roleplay_guidance:
                issues.append("generic_roleplay_guidance")

            tactical_notes = llm_guidance.get('tactical_notes', '')
            if not tactical_notes:
                issues.append("missing_tactical_notes")
            elif "should be used strategically to maximize its effectiveness" in tactical_notes:
                issues.append("generic_tactical_notes")

            narrative_hooks = llm_guidance.get('narrative_hooks', [])
            if not narrative_hooks:
                issues.append("missing_narrative_hooks")
            elif any("creates an opportunity for character development" in hook for hook in narrative_hooks):
                issues.append("generic_narrative_hooks")

        # Check image generation
        image_generation = power_data.get('image_generation', {})
        if not image_generation:
            issues.append("missing_image_generation")
        else:
            base_prompt = image_generation.get('base_prompt', '')
            if not base_prompt:
                issues.append("missing_base_prompt")
            elif "with visible Force energy effects and dynamic action" in base_prompt:
                issues.append("generic_base_prompt")

        # Check synergies
        for synergy_type in ['class_synergies', 'species_synergies', 'faction_synergies']:
            synergies = power_data.get(synergy_type, [])
            if not synergies:
                issues.append(f"missing_{synergy_type}")
            else:
                for synergy in synergies:
                    narrative = synergy.get('narrative', '')
                    if not narrative:
                        issues.append(f"missing_{synergy_type}_narrative")
                    elif "excel at using" in narrative and "powers" in narrative:
                        issues.append(f"generic_{synergy_type}_narrative")

                    mechanical_benefit = synergy.get('mechanical_benefit')
                    if isinstance(mechanical_benefit, str):
                        issues.append(f"string_{synergy_type}_benefit")

        return PowerContext(
            name=power_data.get('name', 'Unknown'),
            power_type=power_data.get('power_type', 'Unknown'),
            alignment=power_data.get('alignment', 'Universal'),
            level=power_data.get('level', 0),
            archetype=self._get_power_archetype(power_data),
            issues=issues
        )

    def _get_power_archetype(self, power_data: Dict) -> str:
        """Determine power archetype from power characteristics."""
        power_type = power_data.get('power_type', '')
        alignment = power_data.get('alignment', '')
        name = power_data.get('name', '').lower()

        if power_type == 'Force':
            if alignment == 'Light':
                if 'heal' in name or 'restore' in name:
                    return 'force_healing'
                elif 'mind' in name or 'trick' in name:
                    return 'force_mental'
                else:
                    return 'force_telekinetic'
            elif alignment == 'Dark':
                return 'force_destructive'
            else:
                return 'force_telekinetic'
        elif power_type == 'Tech':
            if 'ion' in name or 'electronic' in name or 'hack' in name:
                return 'tech_electronic'
            else:
                return 'tech_combat'
        else:
            return 'maneuver_tactical'

    def generate_enhanced_narrative(self, context: PowerContext) -> str:
        """Generate a rich, unique narrative for a power."""
        archetype = context.archetype

        # Base template
        base_template = self._get_narrative_template(archetype)

        # Add unique enhancements
        enhancements = random.sample(self.narrative_enhancements.get(archetype, []), 2)

        # Create power-specific narrative
        power_name = context.name.lower()

        if "push" in power_name or "pull" in power_name:
            narrative = f"You channel the Force to manipulate objects and energy with your mind, creating {enhancements[0]}. This fundamental expression of the Force allows you to extend your will beyond your physical reach, {enhancements[1]}. The power flows through you like an invisible hand, reshaping reality itself through pure mental focus and spiritual connection."
        elif "lightning" in power_name or "storm" in power_name:
            narrative = f"You unleash raw {context.alignment.lower()} side energy, channeling {enhancements[0]}. This devastating power {enhancements[1]}, leaving a trail of destruction in its wake. When used with precision, it can eliminate high-priority targets or create dramatic moments that turn the tide of battle."
        elif "heal" in power_name or "restore" in power_name:
            narrative = f"You channel the {context.alignment.lower()} side of the Force to restore vitality and mend wounds, bringing {enhancements[0]}. This sacred technique requires compassion, empathy, and a deep connection to the living Force. The power flows through you like {enhancements[1]}, knitting together damaged tissue and restoring life energy to those in need."
        elif "mind" in power_name or "trick" in power_name:
            narrative = f"You use the Force to influence minds and perceptions, employing {enhancements[0]}. This delicate technique requires finesse rather than force, working by {enhancements[1]}. The power allows you to plant suggestions that feel completely natural to the target while maintaining their free will."
        elif context.power_type == "Tech":
            narrative = f"You deploy advanced technology with deadly precision, utilizing {enhancements[0]}. This power represents the pinnacle of {enhancements[1]}, allowing you to bend machines and systems to your will. When activated, it creates opportunities that can change the course of any engagement."
        else:
            narrative = f"You execute a precise tactical maneuver that gives you an advantage in combat, demonstrating {enhancements[0]}. This ability reflects {enhancements[1]}, allowing you to outmaneuver opponents and control the battlefield. The power flows through your movements and decisions, creating opportunities where none existed before."

        return narrative

    def _get_narrative_template(self, archetype: str) -> str:
        """Get the base narrative template for an archetype."""
        templates = {
            "force_telekinetic": "You channel the Force to manipulate objects and energy with your mind. This is the art of telekinetic mastery - a fundamental expression of the Force that allows you to extend your will beyond your physical reach. The power flows through you like an invisible hand, reshaping reality itself through pure mental focus and spiritual connection.",
            "force_mental": "You use the Force to influence the minds of others, planting suggestions and altering perceptions. This is the art of mental manipulation - a delicate technique that requires finesse rather than force. The power works by gently nudging the target's subconscious, making them believe the idea was their own while maintaining their free will.",
            "force_healing": "You channel the light side of the Force to restore vitality and mend wounds. This is the art of Force healing - a sacred technique that requires compassion, empathy, and a deep connection to the living Force. The power flows through you like warm light, knitting together damaged tissue and restoring life energy to those in need.",
            "force_destructive": "You unleash the raw power of the dark side, channeling hatred and rage into devastating energy. This is the art of destruction - a corrupting technique that feeds on negative emotions and grows stronger with each use. The power crackles with malevolent energy, leaving a trail of devastation in its wake.",
            "tech_electronic": "You manipulate electronic systems and energy with precision and skill. This is the art of technological mastery - a blend of scientific knowledge and practical experience that allows you to control the machines and systems that power the galaxy. The power flows through circuits and code, bending technology to your will.",
            "tech_combat": "You deploy advanced weaponry and tactical systems with deadly precision. This is the art of technological warfare - a combination of engineering expertise and combat experience that makes you a master of battlefield technology. The power flows through your weapons and equipment, enhancing their effectiveness and creating devastating results.",
            "maneuver_tactical": "You execute a precise tactical maneuver that gives you an advantage in combat. This is the art of tactical mastery - a combination of training, experience, and quick thinking that allows you to outmaneuver your opponents and control the battlefield. The power flows through your movements and decisions, creating opportunities where none existed before."
        }
        return templates.get(archetype, templates["force_telekinetic"])

    def generate_enhanced_flavor_text(self, context: PowerContext) -> str:
        """Generate unique flavor text for a power."""
        if context.power_type == 'Force':
            if context.alignment == 'Light':
                variations = random.sample(self.flavor_text_variations['force_light'], min(3, len(self.flavor_text_variations['force_light'])))
                return random.choice(variations)
            elif context.alignment == 'Dark':
                variations = random.sample(self.flavor_text_variations['force_dark'], min(3, len(self.flavor_text_variations['force_dark'])))
                return random.choice(variations)
            else:
                variations = random.sample(self.flavor_text_variations['force_universal'], min(3, len(self.flavor_text_variations['force_universal'])))
                return random.choice(variations)
        elif context.power_type == 'Tech':
            variations = random.sample(self.flavor_text_variations['tech'], min(3, len(self.flavor_text_variations['tech'])))
            return random.choice(variations)
        else:
            variations = random.sample(self.flavor_text_variations['maneuver'], min(3, len(self.flavor_text_variations['maneuver'])))
            return random.choice(variations)

    def generate_enhanced_manifestation(self, context: PowerContext) -> List[Dict]:
        """Generate structured manifestation for a power."""
        archetype = context.archetype

        templates = {
            "force_telekinetic": [
                {"type": "Somatic", "description": "clear, forceful gesture extending telekinetic energy"},
                {"type": "Mental Focus", "description": "visualizing the desired effect and channeling Force energy"}
            ],
            "force_mental": [
                {"type": "Somatic", "description": "subtle hand gesture or eye contact"},
                {"type": "Mental Focus", "description": "gentle mental influence and psychic connection"}
            ],
            "force_healing": [
                {"type": "Somatic", "description": "laying hands on target or holding them"},
                {"type": "Mental Focus", "description": "channeling healing light and compassion"}
            ],
            "force_destructive": [
                {"type": "Somatic", "description": "extending fingers, channeling dark energy"},
                {"type": "Mental Focus", "description": "embracing hatred and rage"}
            ],
            "tech_electronic": [
                {"type": "Somatic", "description": "using interface device or datapad"},
                {"type": "Mental Focus", "description": "targeting electronic systems and analyzing code"}
            ],
            "tech_combat": [
                {"type": "Somatic", "description": "aiming and firing weapon with precision"},
                {"type": "Mental Focus", "description": "targeting and timing the attack"}
            ],
            "maneuver_tactical": [
                {"type": "Somatic", "description": "executing tactical movement or stance"},
                {"type": "Mental Focus", "description": "assessing battlefield conditions and opportunities"}
            ]
        }

        return templates.get(archetype, templates["force_telekinetic"])

    def generate_enhanced_llm_guidance(self, context: PowerContext) -> Dict:
        """Generate rich LLM guidance for a power."""
        power_name = context.name.lower()

        # Roleplay guidance
        if "push" in power_name or "pull" in power_name:
            roleplay_guidance = f"Describe the visible ripple of Force energy extending from the caster's gesture, the way objects and creatures are lifted and propelled away with telekinetic force. Focus on the dramatic impact - enemies tumbling backward, debris scattering, allies being pushed to safety. The power should feel both mystical and physically tangible."
        elif "lightning" in power_name or "storm" in power_name:
            roleplay_guidance = f"Describe the crackling energy arcing from the caster's fingertips, the way it illuminates the scene with an eerie glow, and the devastating impact as it strikes the target. Focus on the raw power and the corrupting nature of this dark side ability."
        elif "heal" in power_name:
            roleplay_guidance = f"Describe the warm, golden light emanating from the caster's hands, the way it flows into the target's wounds, and the relief that spreads across their face. Focus on the compassion and healing grace of this light side power."
        elif "mind" in power_name:
            roleplay_guidance = f"Describe the subtle way the caster's eyes seem to glow slightly, the way their voice takes on a hypnotic quality, and the way the target's expression changes as the suggestion takes hold. Focus on the gentle, almost imperceptible nature of the influence."
        elif context.power_type == "Tech":
            roleplay_guidance = f"Describe the hum of advanced technology, the glow of holographic displays, and the precise mechanical actions. Focus on the blend of human skill and machine efficiency that makes this power so effective."
        else:
            roleplay_guidance = f"Describe the precise execution of the tactical maneuver, the way the caster's training and experience shine through in their movements, and the advantage gained through superior positioning and timing."

        # Tactical notes
        if context.power_type == "Force":
            tactical_notes = f"{context.name} is excellent for controlling battlefield positioning, creating space between allies and enemies, and knocking opponents prone for advantage on follow-up attacks. Use it to separate dangerous enemies from vulnerable allies, or to push enemies into environmental hazards. The Force connection makes this power feel both mystical and practical."
        elif context.power_type == "Tech":
            tactical_notes = f"{context.name} is excellent for disabling enemy technology, exploiting system vulnerabilities, and creating tactical advantages through superior engineering. Use it to take down droid opponents, disable security systems, or overload enemy equipment. The technological nature makes it particularly effective against machine-dependent enemies."
        else:
            tactical_notes = f"{context.name} is excellent for gaining tactical positioning, creating combat opportunities, and outmaneuvering opponents. Use it to close distance with enemies, reach difficult locations, or escape from dangerous situations. The enhanced mobility makes it particularly effective for hit-and-run tactics and battlefield control."

        # Narrative hooks
        hooks = [
            f"A {context.power_type.lower()} user employs {context.name} to turn the tide of a desperate battle",
            f"The power of {context.name} reveals a character's true {context.alignment.lower() if context.power_type == 'Force' else 'technical'} nature",
            f"{context.name} creates an unexpected opportunity that changes the course of an encounter",
            f"The use of {context.name} forces a moral dilemma on the characters involved"
        ]

        return {
            "roleplay_guidance": roleplay_guidance,
            "tactical_notes": tactical_notes,
            "narrative_hooks": hooks
        }

    def generate_enhanced_image_prompt(self, context: PowerContext) -> Dict:
        """Generate rich image generation prompts."""
        power_name = context.name.lower()

        # Base prompt
        if "push" in power_name or "pull" in power_name:
            base_prompt = f"A detailed digital painting of {context.name} in action. A {context.power_type.lower()} user extends their hand in a clear, forceful gesture, creating a visible wave of {context.alignment.lower()} side energy that pushes objects and creatures away. The energy manifests as a translucent wave of blue-white light, rippling through the air. The scene shows the dramatic effect of the power, with debris, enemies, or objects being pushed back by the invisible force. The mood is {context.alignment.lower()}, representing the raw telekinetic might of the Force."
        elif "lightning" in power_name or "storm" in power_name:
            base_prompt = f"A dramatic digital painting of {context.name} being unleashed. A {context.power_type.lower()} user extends their fingers, channeling crackling {context.alignment.lower()} side energy that arcs through the air like living serpents of destruction. The lightning illuminates the scene with an eerie purple-white glow, striking targets with devastating force. The mood is malevolent and terrifying, representing the corrupting power of the dark side."
        elif "heal" in power_name:
            base_prompt = f"A serene digital painting of {context.name} being performed. A {context.power_type.lower()} user places their hands on a wounded target, channeling warm, golden {context.alignment.lower()} side energy that flows into their body. The healing light illuminates the scene with a gentle glow, mending wounds and restoring vitality. The mood is compassionate and hopeful, representing the restorative grace of the light side."
        elif "mind" in power_name:
            base_prompt = f"A subtle digital painting of {context.name} taking effect. A {context.power_type.lower()} user makes a gentle gesture toward their target, their eyes glowing slightly with psychic energy. The target's expression changes as the mental influence takes hold, looking natural and unforced. The mood is mysterious and intriguing, representing the delicate art of mental manipulation."
        elif context.power_type == "Tech":
            base_prompt = f"A technical digital painting of {context.name} in operation. A {context.power_type.lower()} specialist uses advanced equipment and holographic displays, channeling technological energy through circuits and systems. The scene shows the precision and efficiency of modern technology, with glowing interfaces and humming machinery. The mood is futuristic and precise, representing the power of technological mastery."
        else:
            base_prompt = f"A dynamic digital painting of {context.name} being executed. A skilled operative performs a precise tactical maneuver, moving with calculated grace and battlefield awareness. The scene captures the intensity of combat, with dramatic lighting and determined expressions. The mood is tactical and intense, representing the art of strategic combat."

        # Negative keywords
        base_negative_keywords = [
            "static", "boring", "cartoonish", "blurry", "unclear", "small", "weak",
            "amateur", "simple", "generic", "placeholder", "template", "basic"
        ]

        return {
            "base_prompt": base_prompt,
            "base_negative_keywords": base_negative_keywords
        }

    def apply_creative_pass_to_power(self, power_id: str, power_data: Dict) -> bool:
        """Apply creative pass enhancements to a single power."""
        try:
            context = self.get_power_context(power_id, power_data)

            if not context.issues:
                return False  # No changes needed

            # Apply enhancements based on issues
            modified = False

            if "missing_narrative" in context.issues or "generic_narrative" in context.issues:
                power_data['narrative'] = self.generate_enhanced_narrative(context)
                modified = True

            if "missing_flavor_text" in context.issues or "placeholder_flavor_text" in context.issues:
                power_data['flavor_text'] = self.generate_enhanced_flavor_text(context)
                modified = True

            if "missing_manifestation" in context.issues or "string_manifestation" in context.issues:
                power_data['manifestation'] = self.generate_enhanced_manifestation(context)
                modified = True

            if "missing_llm_guidance" in context.issues or any(issue.startswith("generic_") and "guidance" in issue for issue in context.issues):
                power_data['llm_guidance'] = self.generate_enhanced_llm_guidance(context)
                modified = True

            if "missing_image_generation" in context.issues or "generic_base_prompt" in context.issues:
                power_data['image_generation'] = self.generate_enhanced_image_prompt(context)
                modified = True

            if modified:
                self.save_power(power_id, power_data)
                return True

        except Exception as e:
            self.errors.append(f"Error processing {power_id}: {e}")
            return False

    def save_power(self, power_id: str, power_data: Dict):
        """Save a power back to its file."""
        for power_file in self.powers_directory.glob("*.yml"):
            if power_file.name.startswith("power_"):
                with open(power_file, 'r', encoding='utf-8') as f:
                    file_data = yaml.safe_load(f)
                    if file_data and file_data.get('id') == power_id:
                        with open(power_file, 'w', encoding='utf-8') as f:
                            yaml.dump(power_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
                        break

    def process_all_powers(self) -> Dict[str, bool]:
        """Process all powers and apply creative pass enhancements."""
        results = {}

        for power_id in self.powers.keys():
            try:
                modified = self.apply_creative_pass_to_power(power_id, self.powers[power_id])
                results[power_id] = modified

                if modified:
                    self.processed_powers += 1

            except Exception as e:
                self.errors.append(f"Error processing {power_id}: {e}")
                results[power_id] = False

        return results

    def generate_report(self, results: Dict[str, bool]) -> str:
        """Generate a comprehensive report of the batch creative pass process."""
        report = []
        report.append("=" * 80)
        report.append("BATCH CREATIVE PASS REPORT")
        report.append("=" * 80)
        report.append("")

        # Summary statistics
        total_powers = len(results)
        powers_processed = sum(1 for processed in results.values() if processed)
        powers_skipped = total_powers - powers_processed

        report.append(f"Total Powers Processed: {total_powers}")
        report.append(f"Powers Enhanced: {powers_processed}")
        report.append(f"Powers Skipped (already good): {powers_skipped}")
        report.append("")

        if self.errors:
            report.append("ERRORS ENCOUNTERED:")
            report.append("-" * 40)
            for error in self.errors:
                report.append(f"❌ {error}")
            report.append("")

        # Powers processed
        if powers_processed > 0:
            report.append("POWERS SUCCESSFULLY ENHANCED:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        # Powers skipped
        if powers_skipped > 0:
            report.append("POWERS ALREADY COMPLETE:")
            report.append("-" * 40)
            for power_id, was_processed in results.items():
                if not was_processed:
                    power_data = self.powers[power_id]
                    report.append(f"✅ {power_id} ({power_data.get('name', 'Unknown')})")
            report.append("")

        report.append("=" * 80)
        report.append("BATCH CREATIVE PASS COMPLETE")
        report.append("=" * 80)

        return "\n".join(report)

    def run_batch_creative_pass(self) -> bool:
        """Run the complete batch creative pass process."""
        print("Loading powers...")
        if not self.load_powers():
            return False

        print("Analyzing powers for creative pass needs...")
        powers_to_process = []
        for power_id, power_data in self.powers.items():
            context = self.get_power_context(power_id, power_data)
            if context.issues:
                powers_to_process.append(power_id)

        print(f"Found {len(powers_to_process)} powers that need creative pass work")
        print(f"Powers to process: {', '.join(powers_to_process[:5])}{'...' if len(powers_to_process) > 5 else ''}")

        print("Applying creative pass enhancements...")
        results = self.process_all_powers()

        print("Generating report...")
        report = self.generate_report(results)

        # Save report to file
        report_file = Path("batch_creative_pass_report.txt")
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)

        print(f"Report saved to {report_file}")
        print("\n" + report)

        return len(self.errors) == 0

def main():
    """Main function to run batch creative pass."""
    processor = BatchCreativePassProcessor()
    success = processor.run_batch_creative_pass()

    if success:
        print("\n✅ Batch creative pass completed successfully!")
        sys.exit(0)
    else:
        print("\n❌ Batch creative pass completed with errors.")
        sys.exit(1)

if __name__ == "__main__":
    main()
