#!/usr/bin/env node

/**
 * Class Update Template Script
 * Helps update class files to match the gold standard schema
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

// Template for required fields
const requiredFields = {
  era: "Galactic_Empire", // or appropriate era
  rarity: "common", // or appropriate rarity
  narrative: "Rich narrative description of the class...",
  flavor_text: "Iconic quote or description...",
  cultural_significance: "How this class is viewed in the galaxy...",
  origin_story: "The history and origin of this class...",
  class_identity_profile: {
    core_fantasy: "The core fantasy this class fulfills...",
    key_attributes: ["Primary ability", "Secondary ability"],
    iconic_gear: ["Item 1", "Item 2", "Item 3"],
    role_in_galaxy: "The role this class plays in the galaxy...",
    famous_exemplars: ["Example 1", "Example 2", "Example 3"],
    species_synergies: ["species1", "species2"],
    faction_synergies: ["faction1", "faction2"]
  },
  level_progression: [
    {
      level: 1,
      features: [
        { feature_id: "feature_name", feature_type: "class_feature" }
      ]
    }
    // ... more levels
  ],
  connections: [
    {
      target_id: "target_id",
      target_type: "Faction",
      relationship: "Common Among",
      narrative: "Description of connection...",
      mechanical_benefit: "Optional benefit..."
    }
  ],
  llm_guidance: {
    roleplay_guidance: "Guidance for roleplaying...",
    narrative_hooks: ["Hook 1", "Hook 2"],
    social_dynamics: "How this class interacts...",
    common_motivations: ["Motivation 1", "Motivation 2"]
  },
  image_generation: {
    base_prompt: "Base prompt for image generation...",
    contextual_modifiers: [
      {
        target_type: "Portrait",
        modifier_text: "Portrait modifier..."
      }
    ]
  },
  ui: {
    image: "images/classes/class_name.jpg",
    icon: "icons/classes/class_name.svg",
    color: "#COLOR_CODE"
  }
};

// Class-specific data
const classData = {
  guardian: {
    era: "Galactic_Republic",
    rarity: "rare",
    narrative: "Force-wielders who excel at protection and defense. They are the shield of the Jedi Order, using the Force to protect others and maintain peace through strength and unwavering resolve.",
    flavor_text: "A Jedi uses the Force for knowledge and defense, never for attack. - Yoda",
    cultural_significance: "Guardians are revered as protectors of peace and justice, embodying the Jedi ideal of using strength to defend the weak.",
    origin_story: "The Guardian tradition dates back to the earliest days of the Jedi Order, when the first Jedi realized that the Force could be used not just for knowledge, but for protection.",
    class_identity_profile: {
      core_fantasy: "A stalwart defender of peace and justice, wielding the Force as both shield and sword to protect the innocent and stand against darkness.",
      key_attributes: ["Strength (for lightsaber combat)", "Wisdom (for Force connection and insight)"],
      iconic_gear: ["Lightsaber (often with a blue or green crystal)", "Jedi Robes and armor", "Meditation kit", "Force-imbued items and protective gear"],
      role_in_galaxy: "Guardians are the protectors of the Republic and the Jedi Order, standing as the first line of defense against threats both physical and spiritual.",
      famous_exemplars: ["Obi-Wan Kenobi", "Mace Windu", "Qui-Gon Jinn", "Plo Koon", "Kit Fisto"],
      species_synergies: ["human", "kel_dor", "miraluka"],
      faction_synergies: ["jedi_order", "galactic_republic"]
    }
  },
  consular: {
    era: "Galactic_Republic",
    rarity: "rare",
    narrative: "Force-wielders who focus on diplomacy, healing, and the deeper mysteries of the Force. They are the scholars and healers of the Jedi Order, using wisdom and compassion to resolve conflicts.",
    flavor_text: "The Force will be with you, always. - Obi-Wan Kenobi",
    cultural_significance: "Consulars are respected as wise counselors and healers, representing the peaceful and scholarly aspects of the Jedi Order.",
    origin_story: "The Consular tradition emerged as the Jedi Order grew, recognizing that not all conflicts could be resolved through combat and that the Force had deeper mysteries to explore.",
    class_identity_profile: {
      core_fantasy: "A wise scholar and healer, using the Force to understand, heal, and bring peace through knowledge and compassion.",
      key_attributes: ["Wisdom (for Force mastery and insight)", "Charisma (for diplomacy and leadership)"],
      iconic_gear: ["Lightsaber (often with a green or yellow crystal)", "Jedi Robes", "Meditation crystals", "Healing supplies"],
      role_in_galaxy: "Consulars serve as diplomats, healers, and scholars, using their wisdom to resolve conflicts and advance knowledge.",
      famous_exemplars: ["Yoda", "Obi-Wan Kenobi", "Plo Koon", "Shaak Ti", "Aayla Secura"],
      species_synergies: ["cerean", "kel_dor", "miraluka"],
      faction_synergies: ["jedi_order", "galactic_republic"]
    }
  }
};

function updateClassFile(className) {
  const filePath = path.join(__dirname, '..', 'data', 'classes', `${className}.yml`);
  
  if (!fs.existsSync(filePath)) {
    console.log(`❌ File not found: ${className}.yml`);
    return;
  }
  
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const data = yaml.load(content);
    
    // Get class-specific data or use defaults
    const classInfo = classData[className] || {};
    
    // Update required fields
    if (!data.era) data.era = classInfo.era || "Galactic_Empire";
    if (!data.rarity) data.rarity = classInfo.rarity || "common";
    if (!data.narrative) data.narrative = classInfo.narrative || `Rich narrative description for ${className}...`;
    if (!data.flavor_text) data.flavor_text = classInfo.flavor_text || `Iconic quote for ${className}...`;
    if (!data.cultural_significance) data.cultural_significance = classInfo.cultural_significance || `Cultural significance for ${className}...`;
    if (!data.origin_story) data.origin_story = classInfo.origin_story || `Origin story for ${className}...`;
    
    // Update class identity profile
    if (!data.class_identity_profile && classInfo.class_identity_profile) {
      data.class_identity_profile = classInfo.class_identity_profile;
    }
    
    // Fix proficiencies structure if needed
    if (data.proficiencies && data.proficiencies.tools && typeof data.proficiencies.tools === 'object') {
      if (data.proficiencies.tools.choose) {
        // Convert choose structure to simple array
        data.proficiencies.tools = data.proficiencies.tools.from || [];
      }
    }
    
    // Fix species and faction synergies if they're objects
    if (data.class_identity_profile) {
      if (data.class_identity_profile.species_synergies && Array.isArray(data.class_identity_profile.species_synergies)) {
        data.class_identity_profile.species_synergies = data.class_identity_profile.species_synergies.map(s => 
          typeof s === 'object' ? s.species : s
        );
      }
      if (data.class_identity_profile.faction_synergies && Array.isArray(data.class_identity_profile.faction_synergies)) {
        data.class_identity_profile.faction_synergies = data.class_identity_profile.faction_synergies.map(f => 
          typeof f === 'object' ? f.faction : f
        );
      }
    }
    
    // Write updated file
    const updatedContent = yaml.dump(data, { 
      indent: 2, 
      lineWidth: -1,
      noRefs: true,
      sortKeys: false
    });
    
    fs.writeFileSync(filePath, updatedContent);
    console.log(`✅ Updated ${className}.yml`);
    
  } catch (error) {
    console.log(`❌ Error updating ${className}.yml: ${error.message}`);
  }
}

// Main execution
const className = process.argv[2];

if (!className) {
  console.log('Usage: node update_class_template.js <class_name>');
  console.log('Available classes:');
  const classesDir = path.join(__dirname, '..', 'data', 'classes');
  const classFiles = fs.readdirSync(classesDir).filter(file => file.endsWith('.yml'));
  classFiles.forEach(file => {
    console.log(`  - ${file.replace('.yml', '')}`);
  });
  process.exit(1);
}

updateClassFile(className);
