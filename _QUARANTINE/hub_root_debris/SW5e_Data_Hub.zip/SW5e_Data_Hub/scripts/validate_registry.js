#!/usr/bin/env node

/**
 * SW5e Data Hub - Registry Validation Script
 * Validates the "single source of truth" principle for registry references
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

class RegistryValidator {
    constructor() {
        this.registryDir = path.join(__dirname, '../data/registry');
        this.dataDir = path.join(__dirname, '../data');
        this.registries = new Map();
        this.results = {
            timestamp: new Date().toISOString(),
            summary: { total_registries: 0, broken_references: 0 },
            recommendations: []
        };
    }

    async run() {
        console.log('🚀 Starting Registry Validation\n');
        
        try {
            await this.loadRegistries();
            await this.validateReferences();
            this.generateRecommendations();
            await this.saveResults();
            
            console.log('\n✅ Registry validation complete!');
            
        } catch (error) {
            console.error('❌ Registry validation failed:', error);
        }
    }

    async loadRegistries() {
        console.log('📚 Loading registry files...');
        
        if (!fs.existsSync(this.registryDir)) {
            console.error('❌ Registry directory not found');
            return;
        }
        
        const files = fs.readdirSync(this.registryDir)
            .filter(file => file.endsWith('.yml'));
        
        for (const file of files) {
            const filePath = path.join(this.registryDir, file);
            const registryName = file.replace('.yml', '');
            
            try {
                const content = fs.readFileSync(filePath, 'utf8');
                const data = yaml.load(content);
                this.registries.set(registryName, data);
                this.results.summary.total_registries++;
                console.log(`  ✅ Loaded ${registryName} registry`);
            } catch (error) {
                console.error(`  ❌ Failed to load ${registryName}:`, error.message);
            }
        }
    }

    async validateReferences() {
        console.log('\n🔍 Validating registry references...');
        
        const dataFiles = this.findYamlFiles(this.dataDir);
        let totalReferences = 0;
        let validReferences = 0;
        
        for (const filePath of dataFiles) {
            if (filePath.includes('registry/')) continue;
            
            try {
                const content = fs.readFileSync(filePath, 'utf8');
                const data = yaml.load(content);
                
                const references = this.findReferences(data);
                totalReferences += references.length;
                
                for (const ref of references) {
                    if (this.validateReference(ref)) {
                        validReferences++;
                    } else {
                        this.results.summary.broken_references++;
                    }
                }
                
            } catch (error) {
                console.error(`  ❌ Failed to process ${filePath}:`, error.message);
            }
        }
        
        console.log(`📊 Found ${totalReferences} references, ${validReferences} valid`);
    }

    findReferences(obj, path = '') {
        const references = [];
        
        if (typeof obj === 'object' && obj !== null) {
            for (const [key, value] of Object.entries(obj)) {
                const newPath = path ? `${path}.${key}` : key;
                
                if (this.isRegistryReference(key, value)) {
                    references.push({
                        path: newPath,
                        key: key,
                        value: value,
                        registryType: this.getRegistryType(key)
                    });
                } else if (typeof value === 'object') {
                    references.push(...this.findReferences(value, newPath));
                }
            }
        }
        
        return references;
    }

    isRegistryReference(key, value) {
        if (typeof value !== 'string') return false;
        return key.endsWith('_id') || key.includes('registry_id');
    }

    getRegistryType(key) {
        const mapping = {
            'background_id': 'backgrounds',
            'class_id': 'classes',
            'species_id': 'species',
            'faction_id': 'factions',
            'item_id': 'items',
            'power_id': 'powers'
        };
        return mapping[key] || 'unknown';
    }

    validateReference(ref) {
        const registry = this.registries.get(ref.registryType);
        if (!registry) {
            console.error(`  ❌ Registry "${ref.registryType}" not found for ${ref.path}`);
            return false;
        }
        
        const exists = this.findIdInRegistry(registry, ref.value);
        if (!exists) {
            console.error(`  ❌ ID "${ref.value}" not found in ${ref.registryType} registry`);
            return false;
        }
        
        console.log(`  ✅ ${ref.path} → ${ref.value} (${ref.registryType})`);
        return true;
    }

    findIdInRegistry(obj, targetId) {
        if (typeof obj === 'object' && obj !== null) {
            for (const [key, value] of Object.entries(obj)) {
                if (key === 'id' && value === targetId) return true;
                if (typeof value === 'object' && this.findIdInRegistry(value, targetId)) return true;
            }
        }
        return false;
    }

    findYamlFiles(dir) {
        const files = [];
        const scanDir = (currentDir) => {
            const items = fs.readdirSync(currentDir);
            for (const item of items) {
                const itemPath = path.join(currentDir, item);
                const stat = fs.statSync(itemPath);
                if (stat.isDirectory()) {
                    scanDir(itemPath);
                } else if (item.endsWith('.yml')) {
                    files.push(itemPath);
                }
            }
        };
        scanDir(dir);
        return files;
    }

    generateRecommendations() {
        console.log('\n💡 Recommendations:');
        
        if (this.results.summary.broken_references === 0) {
            console.log('  🟢 All registry references are valid!');
            this.results.recommendations.push('Registry integration is working correctly');
        } else {
            console.log(`  🔴 Fix ${this.results.summary.broken_references} broken references`);
            this.results.recommendations.push('Fix broken registry references');
        }
    }

    async saveResults() {
        const resultsFile = path.join(__dirname, '../registry_validation_results.json');
        fs.writeFileSync(resultsFile, JSON.stringify(this.results, null, 2));
        console.log(`\n💾 Results saved to ${resultsFile}`);
    }
}

if (require.main === module) {
    new RegistryValidator().run();
}

module.exports = RegistryValidator;
